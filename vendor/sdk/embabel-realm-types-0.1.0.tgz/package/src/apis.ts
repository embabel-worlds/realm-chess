/**
 * How a realm reaches an outside API, and what it is allowed to call through it.
 *
 * The key this spec is filed under in `Realm.apis` is the gateway namespace by default:
 * an `omdb` entry is what makes `omdb.getMovie` resolvable, the same way a producer's
 * key becomes its name. Set `name` and that becomes the namespace instead — the engine
 * uses the entry's declared name as the gateway prefix, so the two have to agree.
 *
 * The document itself can either ship with the realm (`url: "apis/omdb-openapi.json"`,
 * checked and copied into the output) or live at the vendor (`url:
 * "https://api.hubapi.com/openapi-spec"`, fetched by the host at load time). Vendoring
 * is the safer default — nobody publishes an OpenAPI document worth fetching live for
 * most third-party APIs — but plenty of real realms point at a remote one, so both work.
 */

/**
 * How the OAuth callback asks the provider which account just authorised.
 *
 * Without it the connect flow still completes, but the world only knows "connected"
 * rather than "connected as user@acme.com", and nothing can key a webhook back to
 * the account.
 */
export interface OAuth2Introspection {
  /**
   * The endpoint to call. May contain the literal `{token}`, which the host replaces
   * with the URL-encoded access token — HubSpot wants the token as a path segment.
   */
  url: string;
  /** `GET` (the default) or `POST`. */
  method?: "GET" | "POST";
  /**
   * How the access token is sent: `bearer` (default), `path-token` (interpolated into
   * `url`), `header:X-Api-Key`, or `query:access_token`.
   */
  auth?: string;
  /** The JSON field to read as the stable account id. Top-level fields only. */
  accountIdField: string;
  /** The JSON field to read as the human-readable label. Falls back to `accountIdField`. */
  displayNameField?: string;
}

/**
 * Records the account this OAuth grant belongs to under a named webhook tenant store,
 * so an unauthenticated webhook carrying the same key can be routed back to the user.
 * The store name has to match the `tenancy.store` in the realm's webhooks YAML.
 */
export interface OAuth2WebhookTenancy {
  store: string;
}

/**
 * OAuth2 for one API entry. Set `auth: "oauth2"` alongside it — the host only takes
 * this path when the auth type says so, and this block does nothing without it.
 *
 * There is no `clientSecret` here on purpose. The engine's type has the field, but
 * nothing reads it: the classic OAuth App flow takes the client id and secret from the
 * user's wallet or the deployment vault, keyed by provider. A secret written here would
 * be plaintext key material in a committed file that also had no effect.
 */
export interface OAuth2Config {
  /**
   * The published, non-secret client id. Only used for the PKCE flow, where there is no
   * secret to pair it with; the classic flow reads both from the wallet or vault.
   */
  clientId?: string;
  /** Where the user is sent to approve the grant. */
  authUrl?: string;
  /** Where the authorization code is exchanged for tokens. */
  tokenUrl?: string;
  /** Space-separated scope list, exactly as the provider spells them. */
  scopes?: string;
  /**
   * Shared-connection key. Several API entries naming the same provider share one
   * credential slot, one Connected Services row, and one consent flow whose scopes are
   * the union of the group — which is what you want when one Google account backs
   * Sheets, Drive and Docs. Absent means the entry's own name is the key.
   */
  provider?: string;
  /** Resolve which account authorised, so the world can name it and key webhooks to it. */
  identity?: OAuth2Introspection;
  /** Register the resolved account id as a webhook tenant key. Needs `identity` to resolve one. */
  webhookTenancy?: OAuth2WebhookTenancy;
  /**
   * Use the PKCE flow: no client secret is sent, a one-time code verifier is used
   * instead. For providers whose secret cannot be shipped per deployment. Needs
   * `clientId`, since PKCE is the one flow that publishes it in the realm.
   */
  pkce?: boolean;
  /**
   * One-click install URL, for GitHub-App-style providers that need an install step
   * before Authorize does anything. The Connected Services UI shows it as an "Install"
   * button ahead of "Authorize".
   */
  installUrl?: string;
}

/** One API document a realm declares, and the operations it may call through it. */
export interface ApiSpec {
  /**
   * Where the document is. Either a realm-relative path to a file that ships with the
   * realm ("apis/omdb-openapi.json"), which synth checks and copies into the output, or
   * an http(s) URL the host fetches at load time.
   */
  url: string;
  /** `openapi` for a REST document, `graphql` for an endpoint the host introspects. */
  type: "openapi" | "graphql";
  /**
   * The entry's own name, which is what the engine uses as the gateway namespace and as
   * the credential-store key. Leave it out and the key this spec is filed under is used,
   * which is what almost every realm wants.
   *
   * Write `null` to say the entry genuinely has no name — then the engine derives one
   * from the URL, and nothing in this realm can reference the entry by a dotted
   * `namespace.operation`, because synth has no name to check it against.
   */
  name?: string | null;
  /** How the gateway authenticates: "none", "bearer", "api-key", or "oauth2". */
  auth?: string;
  /**
   * The environment variable the host reads the credential from at dispatch time. The
   * host injects it on the way out to the real API; the guest handler never sees the key.
   */
  tokenEnv?: string;
  /**
   * Extra HTTP headers on every outbound call. A value may reference a secret as
   * `${VAR}`, which the host resolves from the credential store or the environment —
   * that is the only way a credential belongs in one of these.
   */
  headers?: Record<string, string>;
  /** OAuth2 settings. Only read when `auth` is "oauth2". */
  oauth2?: OAuth2Config;
  /**
   * Expose only operations carrying one of these OpenAPI tags. The coarse filter, for a
   * document like GitHub's where the whole surface is far more than a realm wants.
   * Composes with `operationIds`.
   */
  tags?: string[];
  /**
   * The exact operation ids this realm may call. The narrow filter: every extra id grows
   * the surface an LLM sees, whether or not a handler ever calls it. When the document
   * ships with the realm, synth checks each id really is an `operationId` in it, and
   * checks every dotted operation reference elsewhere in the realm against this list.
   *
   * Leave both this and `tags` out to expose everything the document declares. That is a
   * real and common choice — it is what the arXiv and HubSpot realms do — but it is a
   * wide one, so make it deliberately.
   */
  operationIds?: string[];
  /**
   * GraphQL only: the mutations to expose as gateway tools. Nothing side-effecting is
   * ever exposed unless it is named here, so this list is the whole of a realm's
   * decision to let something write.
   */
  mutations?: string[];
}
