/**
 * The value model a realm definition may produce.
 *
 * Synth serializes whatever the definition exports, so it has to be something YAML
 * can hold. Functions, Date, Map, BigInt and cycles have no realm wire representation:
 * confining the type here means the compiler rejects them at the point they're written.
 * The emitter never has to fail later with a stack trace.
 */
export type JsonValue = string | number | boolean | null | JsonValue[] | { [k: string]: JsonValue };

/** An object whose every leaf is a JSON value. */
export type JsonObject = { [k: string]: JsonValue };
