/**
 * Types for a captured Realm's declarations: the profiles a Kotlin reader parses
 * straight off the realm's own files, rather than the conventional GOAP loader. Each
 * one here mirrors one reader in the host, named in its own doc comment.
 */

import type { HandlerSpec } from "./handlers.ts";
import type { JsonValue } from "./json.ts";

/**
 * Every handler name a realm can refer to, built from the realm's own `handlers` block:
 * each verb key paired with its namespace, as `namespace.verb`. A realm declaring
 * `{ reply: { namespace: "discord" } }` can only write `"discord.reply"`, so a typo or a
 * borrowed namespace is a compile error where it was written rather than a refusal from
 * the host at install time.
 *
 * When the handlers are not known — a realm typed as plain `CapturedRealm`, or anything
 * built at runtime rather than written out by an author — `keyof H` is the open `string`
 * and there is nothing to derive a union from. That case falls back to `string`, which
 * keeps every realm written as `satisfies Realm` checking exactly as it always has. Only
 * a realm passed through {@link defineRealm} has handlers specific enough to check.
 */
export type HandlerRef<H extends Record<string, { namespace: string }>> = string extends keyof H
  ? string
  : { [K in keyof H & string]: `${H[K]["namespace"]}.${K}` }[keyof H & string];

/**
 * A version-1 goal declaration a captured Realm ships under `goals/<key>.yml`: which
 * approved handler runs, what type it takes, what it produces. The file's own key
 * becomes the `goal` field on the wire; declaring one grants nothing by itself — the
 * handler still needs its own approval.
 *
 * Mirrors `CapturedGoalManifest.kt`'s `CapturedGoalDeclaration`.
 */
export interface CapturedGoalSpec<Handler extends string = string> {
  /**
   * The approved handler this goal calls, written as `namespace.verb`. Inside
   * {@link defineRealm} this is narrowed to the realm's own {@link HandlerRef} union, so
   * only a handler the realm actually declares will do. On its own it is any string.
   */
  handler: Handler;
  /** The Realm type name the handler takes as its input. */
  input: string;
  /** The Realm type name the handler is approved to produce. Can never be `"UserInput"`. */
  output: string;
  description?: string;
  /**
   * Fields this shape must never carry: the identity and version synth generates
   * itself, plus what a conventional `GoalSpec` carries. They are `never` rather than
   * merely absent because leaving a field out only catches a fresh object literal —
   * a separately declared object holding one stays assignable, and the value would
   * then be dropped or overwritten with no error anywhere. Typed `never`, it is a
   * compile error however the object was built.
   */
  version?: never;
  goal?: never;
  outputTypeName?: never;
  export?: never;
}

/** The record fields a trigger may carry through to its consumer. */
export type TriggerInputField =
  | "offset"
  | "eventId"
  | "streamId"
  | "type"
  | "occurredAt"
  | "gap"
  | "payload";

/**
 * A version-1 trigger binding a captured Realm ships under `triggers/<key>.yml`: one
 * declared channel source delivered to one declared consumer, in a chosen mode,
 * carrying a bounded slice of the record's fields. This is just the binding — nothing
 * gets delivered from declaring it alone.
 *
 * Mirrors `CapturedTriggerManifest.kt`'s `CapturedTriggerDeclaration`.
 */
export interface TriggerSpec {
  source: string;
  consumer: string;
  /**
   * Whether delivery only lets the consumer look at the record (`"observe"`) or lets it
   * act on it (`"apply"`). `"apply"` type-checks, but the host still refuses to deliver
   * it until the destination policy that enforces observe-only lands.
   */
  mode: "observe" | "apply";
  /** Which record fields the consumer sees. Defaults to every field the host allows. */
  input?: TriggerInputField[];
  description?: string;
  /**
   * Fields this shape must never carry: the identity and version synth generates
   * itself, plus nothing else. They are `never` rather than
   * merely absent because leaving a field out only catches a fresh object literal —
   * a separately declared object holding one stays assignable, and the value would
   * then be dropped or overwritten with no error anywhere. Typed `never`, it is a
   * compile error however the object was built.
   */
  version?: never;
  trigger?: never;
}

/** A declared input stream for captured triggers. The map key becomes the wire name. */
export interface CapturedDataPipeSourceSpec {
  stream: string;
  type: string;
  name?: never;
}

/** A declared handler consumer for captured triggers. The map key becomes the wire name. */
export interface CapturedDataPipeConsumerSpec<Handler extends string = string> {
  handler: Handler;
  name?: never;
}

/** The one `data-pipes.yml` document a captured realm may ship. */
export interface CapturedDataPipesSpec<Handler extends string = string> {
  sources?: Record<string, CapturedDataPipeSourceSpec>;
  consumers?: Record<string, CapturedDataPipeConsumerSpec<Handler>>;
  version?: never;
}

/**
 * A version-1 watch a captured Realm ships under `watches/<key>.yml`: one of the
 * Realm's own lenses re-read on a cron schedule and checked against a fixed criteria
 * query, with an optional judge instruction for the changed items. There is
 * deliberately no field for where anything goes — a Realm is shared across owners, so
 * it declares the subscription and the host alone decides how, and whether, an owner
 * hears about it. Declaring a watch grants nothing by itself; it only runs once the
 * owner has approved a WATCH grant for it.
 *
 * `Lens` is the set of lens names this Realm declares. Write the watches through
 * {@link watching} and it is inferred from the lenses you declare alongside them, so
 * naming a lens the Realm does not have is a compile error rather than something synth
 * has to catch later. Synth still refuses it, for a Realm assembled some other way.
 *
 * Mirrors `CapturedWatchManifest.kt`'s `CapturedWatchDeclaration`.
 */
export interface CapturedWatchSpec<Lens extends string = string> {
  /** The lens this watch re-reads. Has to be a lens this Realm's own `capturedLenses` declares. */
  lens: Lens;
  /** A six-field cron expression. A watch may run no more often than once every five minutes. */
  schedule: string;
  /** The fixed criteria query checked against the lens's results. At most 2048 bytes of UTF-8. */
  criteria: string;
  /** An instruction for the LLM judge that decides which changed items are worth surfacing. At most 1024 bytes of UTF-8. Absent means no judge at all. */
  judge?: string;
  /**
   * Fields this shape must never carry: the identity and version synth generates
   * itself, plus nothing else. They are `never` rather than merely absent because
   * leaving a field out only catches a fresh object literal — a separately declared
   * object holding one stays assignable, and the value would then be dropped or
   * overwritten with no error anywhere. Typed `never`, it is a compile error however
   * the object was built.
   */
  version?: never;
  name?: never;
}

/**
 * A version-1 lens a captured Realm ships under `lenses/<key>.yml`: a saved view the
 * owner can open, backed by one of the Realm's own approved handlers. The key is the
 * lens's id on the wire, and the host still needs the handler's own approval before the
 * lens is available at all.
 *
 * This is a different profile from the conventional `Lens`, not a narrower version of
 * it: the conventional one carries a `spec` (a cypher script or a module class) and the
 * captured reader refuses that field outright, because a captured lens is always a
 * handler call. So a captured Realm declares its lenses here and never through the
 * conventional `lenses` field — synth refuses that field on a captured Realm, since the
 * file it would write is one this Realm's own host reader throws the whole directory
 * away over.
 *
 * Mirrors `CapturedLensManifest.kt`'s `CapturedRealmLens.Declaration`.
 */
export interface CapturedLensSpec<Handler extends string = string> {
  /** What the owner sees this lens called. At most 128 characters. */
  name: string;
  /**
   * The approved handler that produces the view, written as `namespace.verb`. Narrowed
   * to the realm's own {@link HandlerRef} union inside {@link defineRealm}; any string
   * otherwise.
   */
  handler: Handler;
  /** At most 512 characters. */
  description?: string;
  /** Whether the handler hands back data (`"json"`, the default) or rendered content. */
  result?: "json" | "content";
  /**
   * Fields this shape must never carry: the identity and version synth generates
   * itself, plus the conventional `Lens`'s own view fields, which the captured reader
   * refuses. They are `never` rather than merely absent because leaving a field out
   * only catches a fresh object literal — a separately declared object holding one
   * stays assignable, and the value would then be dropped or overwritten with no error
   * anywhere. Typed `never`, it is a compile error however the object was built.
   */
  version?: never;
  id?: never;
  spec?: never;
  persona?: never;
  schedule?: never;
  params?: never;
  presentation?: never;
  output?: never;
  source?: never;
}

/**
 * Adds the two captured-only profiles this file declares to `CapturedRealm` without
 * editing `realm.ts`: the types belong here, next to every other captured profile's own
 * shape, and this merges the fields into the interface `realm.ts` declares rather than
 * duplicating that declaration.
 *
 * This works because `realm.ts` already imports from this file for the other captured
 * profiles (`CapturedGoalSpec`, `TriggerSpec`, and so on), so this file — and the merge
 * below — is always part of the same program wherever `CapturedRealm` is used, whatever
 * path led there.
 *
 * The lens field is `capturedLenses` rather than `lenses` because `lenses` already means
 * the conventional shape on every realm, captured or not, and a merge cannot re-type a
 * field a realm already has: TypeScript answers that with "Interface 'CapturedRealm'
 * incorrectly extends interface 'RealmBase' ... Property 'spec' is missing in type
 * 'CapturedLensSpec' but required in type 'Lens'". Both fields still emit into
 * `lenses/`, which is where the host reads them; only the name an author writes differs.
 *
 * The merge has to repeat `CapturedRealm`'s type parameter exactly as `realm.ts` writes
 * it, defaults included — TypeScript refuses a merge whose parameters differ at all.
 */
declare module "./realm.ts" {
  interface CapturedRealm<H extends Record<string, HandlerSpec> = Record<string, HandlerSpec>> {
    /**
     * Declared lenses, one file per key under `lenses/`. `NoInfer` is what puts the
     * mistake where it was made: without it a lens naming a handler this realm never
     * declares would widen `H` to admit it, and the error would land on the `handlers`
     * block instead of on the lens that made the name up.
     */
    capturedLenses?: Record<string, CapturedLensSpec<NoInfer<HandlerRef<H>>>>;
    /** Declared watches, one file per key under `watches/`. */
    watches?: Record<string, CapturedWatchSpec>;
  }
}

/**
 * Declares a captured Realm's lenses and the watches that re-read them together, so
 * each watch's `lens` can only be one of the names declared right beside it. Spread the
 * result into the Realm:
 *
 * ```ts
 * export default {
 *   name: "example",
 *   execution: "captured",
 *   ...watching({
 *     capturedLenses: { digest: { name: "Digest", handler: "Notes.digest" } },
 *     watches: { "daily-brief": { lens: "digest", schedule: "0 0 8 * * *", criteria: "..." } },
 *   }),
 * } satisfies Realm;
 * ```
 *
 * Writing `lens: "digset"` there is a compile error, which is the whole point of the
 * function: a plain object literal checked with `satisfies Realm` gets no inference from
 * a sibling field's keys, and a call does. The host refuses a watch naming a lens the
 * Realm never declared (`UNDECLARED_LENS`), and finding that out at install time — after
 * the Realm has shipped — is much too late.
 *
 * `Handler` is the handler names these lenses may call. Called on its own it is any
 * string, which is why a realm that has not moved to {@link defineRealm} keeps compiling
 * unchanged. Spread the call into a `defineRealm` and the lens handlers are checked
 * against that realm's declared handlers along with everything else. It is `const` so the
 * names stay the literals you wrote rather than widening to `string`.
 *
 * Nothing happens at runtime: the declarations come back exactly as written.
 */
export function watching<
  const Lens extends string,
  const Handler extends string = string,
>(declared: {
  capturedLenses: Record<Lens, CapturedLensSpec<Handler>>;
  // `NoInfer` keeps the lens names coming from the lenses above and only from there.
  // Without it a watch naming a lens nobody declared widens the union to include it, and
  // the mistake is reported against the lenses — "property 'missing' is missing" — instead
  // of against the watch that made it up.
  watches: Record<string, CapturedWatchSpec<NoInfer<Lens>>>;
}): {
  capturedLenses: Record<Lens, CapturedLensSpec<Handler>>;
  watches: Record<string, CapturedWatchSpec<Lens>>;
} {
  return declared;
}

/** One edge a captured producer's fetched record joins into the graph. */
export interface CapturedProducerJoin {
  targetLabel: string;
  anchorLabel: string;
  relationship: string;
  keyField: string;
  recordKeyField: string;
}

/** How far a captured producer pages, and which argument carries the cursor. */
export interface CapturedProducerPage {
  /** The call argument that carries the cursor. Must differ from `keyArgument`. */
  argument: string;
  /** How many pages the host follows before refusing. 1 to 16. */
  maxPages: number;
}

/**
 * A query filter a captured producer's handler applies itself. When a query pins
 * `property` with `=` or `IN`, the host passes the allowed values to the handler as
 * `argument`, a list of strings. The graph still applies the filter afterwards, so a
 * handler that ignores the argument returns the same answer, only after fetching more.
 */
export interface CapturedProducerPushdown {
  /** The record property the query filters on. */
  property: string;
  /** The handler argument that receives the allowed values. Must differ from `keyArgument` and the page argument. */
  argument: string;
}

/**
 * A version-1 producer declaration a captured Realm ships under
 * `producers/<key>.yml`: which approved handler fetches records, which argument
 * carries the anchor key, and which edges the fetched records join into the graph.
 *
 * Deliberately has no `kind` — a captured producer is one shape, not a polymorphic
 * union like the conventional `ProducerSpec`. The `kind?: never` here only exists so
 * code that reads `Realm.producers` generically (gateway-operation discovery, template
 * validation) keeps compiling against the wider `Realm` union without needing to know
 * about captured producers at all; nothing ever sets it.
 *
 * Mirrors `CapturedProducerManifest.kt`'s `Declaration`.
 */
export interface CapturedProducerSpec<Handler extends string = string> {
  kind?: never;
  handler: Handler;
  keyArgument: string;
  joins: CapturedProducerJoin[];
  page?: CapturedProducerPage;
  /** Query filters the handler applies itself. Up to 16. */
  pushdown?: CapturedProducerPushdown[];
  /**
   * Fields this shape must never carry: the identity and version synth generates
   * itself, plus the conventional `ProducerSpec`'s own dispatch fields. They are `never` rather than
   * merely absent because leaving a field out only catches a fresh object literal —
   * a separately declared object holding one stays assignable, and the value would
   * then be dropped or overwritten with no error anywhere. Typed `never`, it is a
   * compile error however the object was built.
   */
  version?: never;
  name?: never;
  operation?: never;
  args?: never;
  records?: never;
  cache?: never;
}

/**
 * Two short names for the response types most realms want: `json` is `application/json`
 * and `ndjson` is `application/x-ndjson`.
 */
export const CAPTURED_API_RESPONSE_MODES = ["json", "ndjson"] as const;

/** One of {@link CAPTURED_API_RESPONSE_MODES}. */
export type CapturedApiResponseMode = (typeof CAPTURED_API_RESPONSE_MODES)[number];

/** A media type such as `text/csv; header=present`, or a range such as `text/*`. */
export type CapturedApiMediaType = `${string}/${string}`;

/**
 * What an operation answers with. The host sends it as `Accept`, checks the reply's
 * `Content-Type` against it, and decodes the body with it:
 *
 * - `json`, or any JSON type, gives the document.
 * - `ndjson`, `application/x-ndjson`, `application/jsonl` or `application/json-seq` gives
 *   `{ records, truncated }`.
 * - An XML type gives `{ "<root>": element }`.
 * - `text/csv` gives `{ header, rows }`, with the header row taken out under `header=present`.
 * - A YAML type gives the document.
 * - `application/x-www-form-urlencoded` gives an object of strings.
 * - `text/plain` and any other text type gives one string.
 * - `{ raw: <type> }` gives `{ contentType, text }` for the handler to decode itself. The type
 *   may be any text type, or a range: `text/*`, `application/*`, or every type at once.
 *
 * Binary types are refused, raw or not.
 */
export type CapturedApiResponseType =
  | CapturedApiResponseMode
  | CapturedApiMediaType
  | { raw: CapturedApiMediaType };

/** Settings for one operation of a captured api entry. */
export interface CapturedApiOperationSpec {
  /**
   * What the operation answers with. Leave it out and the host reads the reply as one JSON
   * document, whatever type the vendored document names. Only an operation that sets this
   * gets its reply's `Content-Type` checked. A write cannot answer with a stream of records.
   */
  response?: CapturedApiResponseType;
}

/**
 * One API document a captured Realm declares, and the operations it may call through
 * it. Narrower than the conventional `ApiSpec`: no `oauth2`, `tags`, or `mutations` —
 * every field here always has a value the host trusts up front, never a shape the
 * loader would have to infer.
 *
 * Mirrors `CapturedApiContract.kt`'s reader.
 */
export interface CapturedApiSpec {
  /** Filename under `apis/`, e.g. `"omdb-openapi.json"`. Always vendored — a captured api is never fetched from a remote url. */
  url: string;
  type: "openapi";
  /** The gateway namespace this entry registers, and the credential-store key. Always required — there is no "derive from url" fallback like the conventional api. */
  name: string;
  /**
   * How the gateway authenticates. `bearer` and `api-key` attach the credential to the
   * request — an `Authorization` header, or the header or query field the document's own
   * security scheme names. `path` is for a provider that wants the token in the URL
   * itself, the way Telegram does: the vendored document writes `{credential}` in its
   * server url or in an operation path, the host substitutes the bound value there and
   * checks it appears nowhere else, and the generated client takes no argument for it.
   * `none` is for a public api that takes no credential at all, like Wikibooks. The entry
   * then names no credential and may only read: no `writeOperationIds`, and no `security`
   * requirement in the document, since nothing would fill it.
   */
  auth: "bearer" | "api-key" | "path" | "none";
  /**
   * The environment variable the host reads the credential from at dispatch time.
   *
   * @deprecated Declare a credential on the realm and reference it with `credential`
   * instead. Still accepted for one release: synth translates it into an implicit
   * credential whose id is this env-var name, writes `credential:` beside `token-env:`
   * on the wire so the host can migrate on one key, and warns while it does. Removed in
   * the next release.
   */
  tokenEnv?: string;
  /**
   * The id of a credential the realm declares in its own `credentials` block. Exactly
   * one of this and `tokenEnv` — an entry with neither cannot authenticate, and an entry
   * with both says the credential two ways and leaves no answer to which one wins.
   * Under `auth: "none"` the entry names neither.
   */
  credential?: string;
  /**
   * Up to 16 fixed HTTP headers on every outbound call. Each name starts with `X-`, except
   * `User-Agent`, which replaces the one the host sends by default. Values are printable
   * ASCII with no `${VAR}` substitution.
   */
  headers?: Record<string, string>;
  /** The operations this realm may read. Required — a captured api entry always names its exact allowed surface. */
  operationIds: string[];
  /** The operations this realm may call to write. Disjoint from `operationIds`. */
  writeOperationIds?: string[];
  /**
   * Settings for single operations, keyed by operation id. Reads and writes both take one:
   * `{ playerExplorer: { response: "ndjson" } }`.
   */
  operations?: Record<string, CapturedApiOperationSpec>;
  /**
   * Fields this shape must never carry: the identity and version synth generates
   * itself, plus the three conventional `ApiSpec` fields the captured reader
   * refuses outright — `oauth2`, `tags` and `mutations`. They are `never` rather than
   * merely absent because leaving a field out only catches a fresh object literal —
   * a separately declared object holding one stays assignable, and the value would
   * then be dropped or overwritten with no error anywhere. Typed `never`, it is a
   * compile error however the object was built.
   */
  oauth2?: never;
  tags?: never;
  mutations?: never;
}

/** One scalar variable of a persisted GraphQL query. An optional one may be omitted or null. */
export interface CapturedGraphqlVariableSpec {
  /** The variable's name in the document, without the `$`. */
  name: string;
  /** `string` covers GraphQL `String` and `ID`, `integer` is `Int`, `number` is `Float`. */
  type: "string" | "integer" | "number" | "boolean";
  /** Matches a `!` on the variable in the document. Defaults to false. */
  required?: boolean;
  /** Bounds on the value's text length, from 0 to 2048. */
  minLength?: number;
  maxLength?: number;
  /** Up to 128 allowed values. */
  enum?: readonly (string | number | boolean)[];
}

/**
 * One persisted query. The document is fixed in the realm and never changes per call: a call
 * supplies only `variables`. It has to be exactly one `query`, with no mutation,
 * subscription, fragment, introspection or variable default, at most 16 KiB, and its variables
 * have to match the list here exactly.
 */
export interface CapturedGraphqlOperationSpec {
  document: string;
  /** At most 32. */
  variables?: readonly CapturedGraphqlVariableSpec[];
  /** The key in `operations` is the name. */
  name?: never;
}

/**
 * A captured realm's GraphQL source, written once as `graphql/operations.yml`: one fixed
 * HTTPS endpoint and a fixed set of persisted queries. The host calls it the way it calls an
 * approved API operation, as `ctx.gateway.<name>.<operation>({ variables })`, and returns the
 * response's `data` member.
 *
 * Authentication is a declared credential, sent as a bearer token or in a named api-key
 * header. A credential that only this source names still counts as referenced.
 *
 * Mirrors the host's captured GraphQL operation profile.
 */
export type CapturedGraphqlSpec = {
  /** The gateway namespace the operations are called under. */
  name: string;
  /** One fixed HTTPS origin on the default port, with no query, fragment or placeholder. */
  endpoint: `https://${string}`;
  /** A credential the realm declares in its own `credentials` block. */
  credential: string;
  /** Up to 16 fixed `X-` headers, printable ASCII, no substitution. */
  headers?: Record<string, string>;
  /** Between 1 and 32 persisted queries, keyed by operation name. */
  operations: Record<string, CapturedGraphqlOperationSpec>;
  version?: never;
  tokenEnv?: never;
} & (
  | { auth: "bearer"; header?: never }
  | {
      auth: "api-key";
      /** The header the key travels in. Not a header the host owns, like `Authorization`. */
      header: string;
    }
);

/** One alias a captured Realm's guest Cypher may name in place of an owner-granted view. */
export interface CapturedViewReference {
  alias: string;
  view: string;
}

/**
 * A captured Realm's `queries/references.yml`: the bounded set of view aliases its
 * guest Cypher may use, each standing in for an owner-granted view once the owner
 * grants it. Declaring this expands nothing by itself.
 *
 * Mirrors `CapturedQueryReferences.kt`.
 */
export interface QueryReferences {
  /** May be empty: a realm that ships the file with no aliases is one the reader accepts. */
  views: CapturedViewReference[];
  /** Generated by synth; see the note on `CapturedGoalSpec`. */
  version?: never;
}

/**
 * The parameter types a view can declare, as the host spells them. `float` and `double` are
 * the same as `number`.
 */
export type CapturedViewParamType =
  | "string"
  | "int"
  | "number"
  | "float"
  | "double"
  | "boolean"
  | "date";

/** One parameter a view takes, written `$name` in its cypher. The key in `params` is the name. */
export interface CapturedViewParamSpec {
  /** How the host coerces a supplied value, and which control a UI draws for it. */
  type: CapturedViewParamType;
  /** Used when a caller leaves the parameter out. Without one, every call has to supply it. */
  default?: JsonValue;
  /** What the parameter means. Discovery shows it as the field's hint. */
  description?: string;
  /** The only values accepted, shown as a select. Each has to fit `type`. */
  choices?: readonly JsonValue[];
}

/** The ODCS data contract a tabular view promises to meet. */
export interface CapturedViewDataContract {
  id: string;
  version: string;
  object: string;
  /** `observe` reports a breach; `enforce` refuses the result. Defaults to `observe`. */
  mode?: "observe" | "enforce";
}

/**
 * A saved Cypher view a captured realm ships. Synth writes every view into one
 * `views/<realm>.yml`, in the order they are declared, as the list the host reads.
 *
 * Mirrors the host's `ViewSpec`.
 */
export interface CapturedViewSpec {
  /** What callers name the view by, as `(v:Name {param: value})` or through discovery. */
  name: string;
  /** The query. Every `$param` it uses has to be declared in `params`. */
  cypher: string;
  /** One line on what the view answers, shown to the model and in discovery. */
  description?: string;
  params?: Record<string, CapturedViewParamSpec>;
  /** Cache the result per user until `ttl` runs out. A materialized view takes no params. */
  materialized?: boolean;
  /** How long a materialized result is kept, like `30m`, `2h` or `1d`. Defaults to `1h`. */
  ttl?: string;
  /** The node label the view's rows are. A materialized view needs one. */
  outputLabel?: string;
  /** Channels a user has to have opted into to see the view. Empty means everyone. */
  audience?: readonly string[];
  dataContract?: CapturedViewDataContract;
  /** The host stamps the realm's name here when it loads the file. */
  source?: never;
}

/**
 * A browser app a captured Realm declares in `apps/<key>.app.json`: the handlers it
 * may call, plus the stylesheet and script resources it inlines ahead of the page.
 *
 * The key is the page's own filename, so it has to end in `.html` — the reader opens
 * `apps/<key>` to get the page itself. Synth ships that page and every resource named
 * here alongside the manifest, because an app whose page is missing fails the moment
 * anyone opens it.
 *
 * Mirrors `CapturedBrowserApps.kt`'s `App`.
 */
export interface AppSpec {
  /**
   * The handlers, as `namespace.verb`, this app is allowed to call. May be empty: a
   * static page that calls nothing back is an app the reader accepts.
   */
  handlers: string[];
  /** Realm-relative asset paths under `apps/<key>.assets/`, `.css` or `.js` only. */
  resources?: string[];
  /** Generated by synth; see the note on `CapturedGoalSpec`. */
  version?: never;
}

/**
 * The two things a proposed write can be: a call to a named, approved method on the
 * record, or a plain decoration that sets fields on it.
 */
export type WriteProposalKind = "method-write-back" | "decoration";

/** Whether a proposed write stays in the owner's own storage or reaches something outside it. */
export type WriteProposalEffect = "private-storage" | "external";

/**
 * The alphabet halves, written out so a template literal can fix the first character of a
 * name the host's grammar pins. Only the first character: a template literal cannot say
 * "and nothing but letters and digits after it, up to 64 of them", so the rest of each
 * grammar stays the reader's own refusal.
 */
type UpperLetter =
  | "A"
  | "B"
  | "C"
  | "D"
  | "E"
  | "F"
  | "G"
  | "H"
  | "I"
  | "J"
  | "K"
  | "L"
  | "M"
  | "N"
  | "O"
  | "P"
  | "Q"
  | "R"
  | "S"
  | "T"
  | "U"
  | "V"
  | "W"
  | "X"
  | "Y"
  | "Z";
type LowerLetter = Lowercase<UpperLetter>;

/** A node label, which the host reads as a type name: `Note`, never `note` or `com.foo.Note`. */
export type WriteProposalLabel = `${UpperLetter}${string}`;

/** A write-back method name, which the host reads as a member name: `archive`, never `Archive`. */
export type WriteProposalMethodName = `${LowerLetter}${string}`;

/** The record a proposed write targets: its label and its key, named the way a captured query would name it. */
export interface WriteProposalTarget {
  label: WriteProposalLabel;
  /** The record's own key. At most 2048 bytes of UTF-8. */
  key: string;
}

/**
 * Field names a proposed write may never carry, at any depth: the host's own identity and
 * ownership fields, plus anything starting with an underscore, which the host keeps for
 * itself everywhere else too.
 *
 * They are `never` rather than merely absent for the reason the rest of this file gives:
 * leaving a field out only catches a fresh object literal, while a separately declared
 * object holding one stays assignable and the host would then refuse the whole proposal at
 * dispatch with nothing named. Typed `never`, it is a compile error however the object was
 * built. The underscore half is a template-literal pattern, so it covers names nobody
 * thought to list.
 */
export type WriteProposalReservedFields = {
  userId?: never;
  worldId?: never;
  workspaceId?: never;
  visibleTo?: never;
  owner?: never;
  ownerId?: never;
  labels?: never;
} & { [name: `_${string}`]: never };

/** A leaf a proposed write can carry. Anything else — a function, a Date, undefined — has no wire form. */
type WriteProposalScalar = string | number | boolean | null;

/**
 * The nesting cap, written as one type per level rather than as a recursive type, because
 * the host counts levels and refuses past four: the `fields` object itself is level one, so
 * three nested objects or arrays inside it are as deep as a proposal goes. A fifth level is
 * a compile error here instead of a refusal at dispatch.
 */
type WriteProposalLevel4 =
  | WriteProposalScalar
  | WriteProposalScalar[]
  | ({ [name: string]: WriteProposalScalar } & WriteProposalReservedFields);
type WriteProposalLevel3 =
  | WriteProposalScalar
  | WriteProposalLevel4[]
  | ({ [name: string]: WriteProposalLevel4 } & WriteProposalReservedFields);
type WriteProposalLevel2 =
  | WriteProposalScalar
  | WriteProposalLevel3[]
  | ({ [name: string]: WriteProposalLevel3 } & WriteProposalReservedFields);

/**
 * What a proposed write actually sets. At least one field and at most
 * {@link WRITE_PROPOSAL_LIMITS}.maxFields of them, none of them reserved, nested no deeper
 * than the levels above allow. "At least one" and "at most 64" are the two parts of that a
 * type cannot say, so they stay refusals at dispatch.
 */
export type WriteProposalFields = {
  [name: string]: WriteProposalLevel2;
} & WriteProposalReservedFields;

/** Fields every proposed write carries, whichever kind it is. */
interface WriteProposalBase {
  /** The document version the host reads. There is one. */
  version: 1;
  target: WriteProposalTarget;
  fields: WriteProposalFields;
  effect: WriteProposalEffect;
  /**
   * The revision the guest believes the record is at, so the host can refuse a write built
   * on a stale read. A whole number, never negative. Absent or null means "don't check".
   */
  expectedRevision?: number | null;
}

/**
 * What a captured handler hands the host when it wants to write something back to the
 * graph. It is only a proposal: the host still validates it, shows it, and confirms it, and
 * nothing is applied by proposing. Mirrors `CapturedWriteProposal.kt`.
 *
 * The two kinds are a union rather than one shape with an optional method, because the host
 * reads them that way: a method write-back needs the method name, and a decoration refuses
 * to carry one at all.
 */
export type WriteProposal =
  | (WriteProposalBase & {
      kind: "method-write-back";
      /** The approved method the host calls on the record. */
      method: WriteProposalMethodName;
    })
  | (WriteProposalBase & {
      kind: "decoration";
      /** A decoration sets fields directly, so naming a method is a compile error rather than a refusal at dispatch. */
      method?: never;
    });

/**
 * What comes back when the host accepts a proposal: the id it filed it under, for the
 * guest to correlate with the confirmation that follows.
 *
 * There is no refused shape here. The host either answers with this or refuses, and a
 * refusal arrives as a rejected promise carrying one fixed message — never as a value with
 * a different shape, and never with a reason the guest could branch on.
 */
export interface WriteProposalResult {
  proposalId: string;
}

/**
 * The bounds the host puts on one proposal, mirrored from `CapturedWriteProposal.kt` so an
 * author can check against them before sending rather than reading a refusal.
 *
 * These are the parts of the contract a type cannot hold: how many bytes the document may
 * take, how many fields one object may have, and how many levels deep the nesting may go
 * (the type above holds that last one structurally as well). Exceeding any of them refuses
 * the whole proposal with nothing named.
 */
export const WRITE_PROPOSAL_LIMITS = {
  /** Bytes of UTF-8 for the whole proposal document. */
  maxBytes: 65_536,
  /** Entries in any one object or array in `fields`, not just the top one. */
  maxFields: 64,
  /** Nesting levels, counting the `fields` object itself as the first. */
  maxDepth: 4,
  /** Bytes of UTF-8 for `target.key`. */
  maxKeyBytes: 2048,
} as const;
