/**
 * What a captured realm says it needs to authenticate, without ever saying what the
 * secret is.
 *
 * A realm declares credentials by need — "I need a bearer token for the catalog API,
 * here is what it is for and where to get one" — and the host binds a real secret to
 * that slot when someone approves the realm. Nothing here can carry key material: the
 * `never` fields below make `value`, `env`, `tokenEnv` and `walletItem` compile errors
 * rather than quietly-ignored keys, so a realm that tries to ship its own token fails
 * at authoring time instead of at a security review.
 *
 * `scopes` belongs to `oauth2` and only to `oauth2`. Any other kind is a single opaque
 * secret with nothing to scope, and an oauth2 credential with no scopes asks for a
 * grant that authorizes nothing, so the union requires at least one.
 *
 * `scheme` belongs to `bearer` and only to `bearer`. It is the word in front of the
 * token in the `Authorization` header, which is `Bearer` almost everywhere and is not
 * everywhere: a Discord bot token is sent as `Bot <token>` and a `Bearer` there is an
 * OAuth2 access token that cannot authorize the call at all. Saying it on the
 * declaration keeps the provider's name out of the host and the secret out of the guest.
 */
export type CredentialSpec = {
  /** What this credential is for, in the words the approval screen shows the person granting it. */
  description: string;
  /** The service that issues it, when several credentials share one. */
  provider?: string;
  /** Where to go to get one. Must be an https url. */
  docs?: `https://${string}`;
  /**
   * Fields this shape must never carry: every way a realm could try to write the
   * secret itself, or point at where the secret already sits. They are `never` rather
   * than merely absent because leaving a field out only catches a fresh object
   * literal — a separately declared object holding one stays assignable, and the value
   * would then be dropped with no error anywhere. Typed `never`, it is a compile error
   * however the object was built.
   */
  value?: never;
  env?: never;
  tokenEnv?: never;
  walletItem?: never;
} & (
  | {
      kind: "bearer";
      /**
       * The authorization scheme the token is sent under, when it is not `Bearer`.
       * Printable ASCII, no whitespace, at most 32 characters — it is one header token,
       * not a sentence. Leave it out and the host sends `Bearer`.
       */
      scheme?: string;
      scopes?: never;
    }
  | { kind: "api-key" | "basic" | "public-key"; scheme?: never; scopes?: never }
  | { kind: "oauth2"; scheme?: never; scopes: readonly [string, ...string[]] }
);
