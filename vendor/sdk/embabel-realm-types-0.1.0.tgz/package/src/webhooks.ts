import type { JsonValue } from "./json.ts";

/**
 * Where the HMAC secret for a webhook's signature comes from.
 *
 * Only `oauthApp` is modelled here — a name in `oauth-apps.yml` whose OAuth client
 * secret the host reuses as the signing key, the shape every OAuth-integrated provider
 * needs. The engine's own type also accepts a `literal` secret value, but that puts key
 * material straight into a committed file, so it is not exposed here at all, the same
 * way an API entry's OAuth2 config has no `clientSecret` field.
 */
export interface WebhookSecretRef {
  oauthApp: string;
}

/** Anti-replay timestamp check for a webhook signature. */
export interface WebhookTimestampConfig {
  /** Header carrying the timestamp. */
  header: string;
  /** Rejects a request whose timestamp is further than this from now. Defaults to 300. */
  toleranceSeconds?: number;
  /** `"ms"` (epoch millis) or `"s"` (epoch seconds). Defaults to `"ms"`. */
  unit?: "ms" | "s";
}

/**
 * How a webhook's signature is verified. `scheme` selects the algorithm family (e.g.
 * `"hmac-sha256"`); the rest describes the layout — which header carries the digest,
 * what was hashed, how it's encoded, and the optional anti-replay window.
 */
export interface WebhookSignatureConfig {
  scheme: string;
  secretRef: WebhookSecretRef;
  /** Header carrying the digest, e.g. `"X-Hub-Signature-256"`. */
  header?: string;
  /** Prefix to strip before comparing, e.g. `"sha256="`. */
  prefix?: string;
  /** `"hex"` (default) or `"base64"`. */
  encoding?: "hex" | "base64";
  /**
   * Template for the bytes to HMAC, from `{method}`, `{fullUrl}`, `{body}`, `{timestamp}`.
   * Defaults to `"{body}"` (the GitHub/Shopify shape).
   */
  template?: string;
  timestamp?: WebhookTimestampConfig;
}

/** How the host works out which user's world a webhook belongs to. */
export interface WebhookTenancyConfig {
  /** Which resolver strategy to use, e.g. `"payload-field"` or `"path-token"`. */
  resolver: string;
  /** For `"payload-field"`: the JSON field to read the tenant id from. */
  field?: string;
  /** Namespace the tenant registry stores this provider's ids under. Defaults to `source`. */
  store?: string;
}

/** Auto-registering this webhook with the external service once it's connected. */
export interface WebhookRegisterConfig {
  /** Tool name the host calls to register the webhook. */
  tool: string;
  /** Arguments for that call. Values support `{{template}}` substitution. */
  args?: Record<string, JsonValue>;
}

/**
 * A webhook receiver this realm wants to accept traffic for.
 *
 * `source` is the path segment the host routes on (`/api/v1/webhooks/{source}`), and
 * `action` names the registered action the host invokes once a request passes signature
 * verification and tenancy resolution. Every realm's `webhooks/` directory is scanned at
 * boot the same way `actions/` and `goals/` are.
 */
export interface WebhookSpec {
  description?: string;
  /** Path segment the webhook is reachable at: `/api/v1/webhooks/{source}`. */
  source: string;
  /** Event types this registration subscribes to (documentation/filtering only). */
  events?: string[];
  /** Registered action name to run when the webhook fires. */
  action?: string;
  register?: WebhookRegisterConfig;
  /**
   * Verifies the request's signature before dispatch, rejecting a mismatch with 401.
   * Absent means no verification is performed — the historical, back-compat behaviour.
   */
  signature?: WebhookSignatureConfig;
  /**
   * Identifies the calling user from the request itself rather than an authenticated
   * session — required for a webhook the vendor calls with no session to attach to.
   */
  tenancy?: WebhookTenancyConfig;
}
