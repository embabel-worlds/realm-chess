import type { JsonValue } from "./json.ts";

/**
 * A live connector that pushes events into the realm.
 *
 * Channels and events together form the realm's signal support: channels push live
 * connector traffic, and events ingest webhooks and polls. The engine loads those two
 * surfaces. There is no third "signals" block.
 *
 * `tokenEnv` and `signalType` have standard meanings; connector configs carry
 * connector-specific keys that you pass as extra properties on this object. Emit maps
 * camelCase fields to kebab-case for the wire (tokenEnv → token-env).
 */
export type ChannelSpec = {
  /** Connector class, as the engine knows it. */
  type: string;
  /** Environment variable name where the connector finds its credentials. */
  tokenEnv?: string;
  /** Signal type the connector emits. */
  signalType?: string;
  /**
   * Whether the host starts this channel's connector at boot. Defaults to `true`
   * on the engine side, so leaving this out behaves exactly as it always has.
   * Written camelCase here; emit maps it to the `auto-start` the engine reads.
   */
  autoStart?: boolean;
} & Record<string, JsonValue | undefined>;

/**
 * An ingestion surface (poll or webhook) that feeds events into the realm.
 *
 * The `type` field names the signal being ingested. The discriminator is the
 * presence of `poll` or `webhook`: a signal either arrives on a schedule or
 * through HTTP.
 */
export type EventSpec =
  | {
      /** Signal type, matched against the channel's signalType. */
      type: string;
      /** Poll on a schedule. */
      poll: {
        /** How often to run, e.g. "5m", "6h". */
        every: string;
        /** API producer name to call. */
        api: string;
        /** Operation to call on the API. */
        method: string;
        /**
         * Arguments for the call. Values are Jinja-templated against `{ user, cursor }`,
         * so the host can inject the user identity and the persisted cursor without any
         * per-realm code.
         */
        args?: Record<string, string>;
        /**
         * How this poll tracks where it left off. Without one, every run starts from
         * scratch and reports every row again — fine for a small, fully-refetched
         * source, but not for an incremental one.
         */
        cursor?: {
          /** API parameter name the persisted cursor value is written into. */
          param?: string;
          /** JSONPath into each result item; the maximum value across the batch becomes the next cursor. */
          from?: string;
          /**
           * Value substituted for `{{cursor}}` on the FIRST run, before anything is
           * persisted. The host defaults this to "*" (everything), which a
           * date-qualified API can reject — set an explicit floor (an ISO date, say)
           * when that's the case.
           */
          initial?: string;
        };
        /** JSONPath expressions ($-rooted) or literal strings, mapping signal fields. */
        mapping: Record<string, string>;
      };
    }
  | {
      /** Signal type, matched against the channel's signalType. */
      type: string;
      /** Ingest via webhook. */
      webhook: {
        /** Signature validation scheme ("none" to skip). */
        signature: string;
        /**
         * Env-var name carrying the signature secret. Required for any scheme other
         * than "none". Written camelCase here; emit maps it to the `signature-secret`
         * the engine reads — that kebab form is not optional, camelCase is dropped
         * with no error at all.
         */
        signatureSecret?: string;
        /** Tenancy model for multi-tenant apps ("path-token", etc). */
        tenancy: string;
        /**
         * Tier overrides, keyed by tier name (`INTERRUPTIVE`, `TIMELY`, …) with a
         * boolean-expression value; the first one that's true wins. Written camelCase
         * here; emit maps it to the `tier-when` the engine reads.
         */
        tierWhen?: Record<string, string>;
        /** JSONPath expressions or literal strings, mapping signal fields. */
        mapping: Record<string, string>;
      };
    };
