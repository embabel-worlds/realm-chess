import type { JsonValue } from "./json.ts";

/**
 * A GOAP prompted action: bridges one input type to an output type by prompting an LLM.
 *
 * The engine scans every loaded realm's `actions/` directory for these, one file per
 * action, whether or not the realm exports anything — the GOAP planner needs the whole
 * set to plan with. Whether the chat LLM can call it directly as a tool is controlled by
 * `export`, not by realm-level export filtering.
 */
export interface ActionSpec {
  description: string;
  /**
   * Jinja-templated instruction. Receives the input types as lower-camel variables —
   * `{{researchRequest.topic}}` for an input type named `ResearchRequest`.
   */
  prompt: string;
  /** Type names (declared in this realm or another loaded one) this action accepts. */
  inputTypeNames: string[];
  /** Type name this action produces. */
  outputTypeName: string;
  /**
   * LLM tuning for this action's prompt call — model, temperature, and the rest of what
   * `LlmOptions` carries. Left untyped here (Jackson binds the engine's own class); synth
   * passes it through as written.
   */
  llm?: Record<string, JsonValue>;
  /** Goal names that must already be satisfied before the planner picks this action. */
  pre?: string[];
  /** Goal names the planner treats as satisfied once this action succeeds. */
  post?: string[];
  /** GOAP cost hint, 0 to 1. */
  cost?: number;
  /** GOAP value hint, 0 to 1. */
  value?: number;
  /** Whether the planner may invoke this action more than once in one run. */
  canRerun?: boolean;
  /** Named tool-group requirements, e.g. `["web-search"]`. */
  toolGroups?: string[];
  /** Specific tool names to make available to the prompt. */
  tools?: string[];
  /** Names of `reference/`-declared resources to include as context. */
  references?: string[];
  /** When true, a null output is valid and triggers replanning rather than failing. */
  nullable?: boolean;
  /**
   * When true, the host auto-generates a goal for this action so the chat LLM can
   * invoke it directly as a tool — the YAML equivalent of `@AchievesGoal`.
   */
  export?: boolean;
}
