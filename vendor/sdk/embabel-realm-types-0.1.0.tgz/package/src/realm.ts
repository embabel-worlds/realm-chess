import type { ActionSpec } from "./actions.ts";
import type { ApiSpec } from "./apis.ts";
import type {
  AppSpec,
  CapturedApiSpec,
  CapturedDataPipesSpec,
  CapturedGoalSpec,
  CapturedGraphqlSpec,
  CapturedProducerSpec,
  CapturedViewSpec,
  HandlerRef,
  QueryReferences,
  TriggerSpec,
} from "./captured.ts";
import type { ChannelSpec, EventSpec } from "./channels.ts";
import type {
  CapturedChannelSpec,
  CapturedConsumerSpec,
  CapturedSourceSpec,
  DeclaredApiOperations,
  OperationRef,
} from "./connecting.ts";
import type { CredentialSpec } from "./credentials.ts";
import type { DependencySpec } from "./dependencies.ts";
import type { GoalSpec } from "./goals.ts";
import type { HandlerSpec } from "./handlers.ts";
import type { JsonValue } from "./json.ts";
import type { ProducerSpec } from "./producers.ts";
import type { TypeSpec } from "./types.ts";
import type { VirtualCypher } from "./vc.ts";
import type { WebhookSpec } from "./webhooks.ts";

/** Where a realm's handlers run. */
export type RealmHost = "wasm" | "docker";

/**
 * The guest runtime the handlers are written for. TypeScript is the default. It is the
 * only runtime a host builds from source today. The others name what the prebuilt
 * module contains: an interpreter carrying the realm's code, or a guest compiled
 * straight to wasm from a language like Rust or Go. Non-TypeScript runtimes resolve
 * through the registry once the runtime mechanism lands.
 */
export type GuestLanguage = "typescript" | "python" | "ruby" | "lua" | "compiled";

/** A saved view over the graph. */
export type LensSpec =
  | {
      kind: "cypherscript";
      /** Written with the `vc` tag so the query is checked when the realm is built. */
      script: VirtualCypher;
    }
  | {
      kind: "module";
      className: string;
      /** Path to the lens class, relative to the realm root. The loader inlines its JS. */
      module: string;
      presentKind?: string;
      dataType?: string;
    };

/** A declared parameter a lens accepts at open time, e.g. a briefing's `since` window. */
export interface LensParam {
  name: string;
  /** Drives which control a UI offers and light validation. Defaults to `"STRING"`. */
  type?: "STRING" | "INT" | "DATE" | "DURATION" | "BOOLEAN";
  /** Defaults to `name`. */
  label?: string;
  default?: JsonValue;
  required?: boolean;
}

/**
 * How a lens claims a top-level surface. `href` embeds an HTML file (e.g. a vibe-coded
 * app) in a frame; a lens with no presentation at all renders generically.
 */
export interface LensPresentationSpec {
  /** The top-level surface this lens claims, e.g. `"today"`. */
  surface?: string;
  /** Realm-relative HTML file to embed. */
  href?: string;
}

/**
 * A versioned public contract for what a lens hands back through `gateway.lens.present`.
 * An empty `schema` is fine during incremental adoption — consumers still get a stable
 * `kind`/`schemaVersion` pair, and a fuller schema additionally enables validation and
 * generated controls.
 */
export interface LensOutputContract {
  kind: string;
  /** Defaults to `"1"`. */
  schemaVersion?: string;
  schema?: Record<string, JsonValue>;
}

/** A named lens with its display metadata. */
export interface Lens {
  name: string;
  description?: string;
  spec: LensSpec;
  /** Persona slug the opened view carries. */
  persona?: string;
  /** Cron expression: refresh the view and notify on change. */
  schedule?: string;
  /** Parameters the lens accepts at open time, supplied as args to open. */
  params?: LensParam[];
  presentation?: LensPresentationSpec;
  /** Public output contract for browser apps and other headless consumers. */
  output?: LensOutputContract;
  /**
   * For a realm-shipped lens the loader always stamps this to the realm's own name once
   * it reads the file, discarding whatever is written here — so there is nothing to gain
   * by setting it to anything other than this realm's name, and synth refuses any other
   * value rather than let it look like it did something.
   */
  source?: string;
}

/** Narrows the assistant's visible skills to a set of realms. */
export interface Focus {
  displayName: string;
  description?: string;
  icon?: string;
  realms: string[];
  /** Keep the framework's built-in chat tools alongside the realm's own. */
  builtins?: boolean;
  /** Persona slug this focus switches to by default when the user enters it. */
  defaultPersona?: string;
  /** By-name tool allowlist. Absent exposes every tool the realm's exports normally would. */
  tools?: string[];
}

/** How a realm retries a failed outbound call. */
export interface RetrySpec {
  attempts?: number;
  baseBackoff?: string;
  multiplier?: number;
  jitter?: number;
  maxBackoff?: string;
  retryOn?: string[];
}

/**
 * The readiness claims a realm can make about itself, as the host spells them. Installing an
 * experimental realm asks the user to confirm first; the others only change the badge.
 */
export const REALM_MATURITIES = ["experimental", "beta", "stable", "deprecated"] as const;

/** One of {@link REALM_MATURITIES}. */
export type RealmMaturity = (typeof REALM_MATURITIES)[number];

/**
 * What a captured realm can ask the owner to grant at admission, as the host spells it.
 * `model` lets its handlers call the host's `ai_complete`. The owner may say no, and the
 * realm keeps working without it: the call is refused with `MODEL_NOT_GRANTED`.
 */
export const REALM_CAPABILITIES = ["model"] as const;

/** One of {@link REALM_CAPABILITIES}. */
export type RealmCapability = (typeof REALM_CAPABILITIES)[number];

/** How the host admits and runs the realm's declarations. Absent means conventional. */
export type RealmExecution = "conventional" | "captured";

/** Fields every realm carries, whichever way the host admits and runs its declarations. */
export interface RealmBase {
  name: string;
  /**
   * Where this realm's executable surface runs. Absent means the same as it always
   * has: the host infers placement from what is actually on disk, rather than a
   * declared default — a realm with no handlers at all, or one shipping a prebuilt
   * wasm module, never had to say "wasm" or "docker" for the engine to load it.
   */
  host?: RealmHost;
  /**
   * The language the realm's handlers are written in. Defaults to "typescript".
   *
   * Not the runtime: `host` says whether the guest runs under wasm or docker. The key stays
   * `runtime` because that is the spelling already on the wire.
   */
  runtime?: GuestLanguage;
  version: string;
  description?: string;
  /** How ready the author says this realm is. Absent makes no claim. */
  maturity?: RealmMaturity;
  author?: string;
  url?: string;
  tags?: string[];
  icon?: string;
  /**
   * The realm-relative path to the handler source module the build compiles.
   * Defaults to "wasm/handlers.ts" when absent. For a Python runtime the
   * conventional default is "wasm/handlers.py". This field is runtime-agnostic;
   * the default it falls back to follows the declared runtime.
   */
  entry?: string;
  /** Deterministic timestamp for emitted manifest.json. Defaults to "1970-01-01T00:00:00Z" (fixture timestamp). */
  generatedAt?: string;
  /** Names the realm exports. Empty or absent exports everything. */
  exports?: string[];
  retry?: RetrySpec;
  types?: Record<string, TypeSpec>;
  /** Handlers this realm exposes, keyed by verb name (the public operation identifier). */
  handlers?: Record<string, HandlerSpec>;
  /**
   * WebAssembly modules to mount beside the handlers, keyed by the name handlers will
   * know them by. Declaration only today: synth validates and emits the manifest, and
   * the engine ignores it until the dependency mechanism lands.
   */
  dependencies?: Record<string, DependencySpec>;
  /**
   * Dependency-only realms this realm builds on, as "name@version" references. A layer
   * bundles a set of registry modules that belong together, the way a Docker base image
   * bundles a filesystem. Every module a layer names still resolves through the
   * registry. Declaration only today, like dependencies.
   */
  layers?: string[];
  /** Ingestion surfaces (poll or webhook) that feed events into the realm. The key names the emitted file. */
  events?: Record<string, EventSpec[]>;
  lenses?: Record<string, Lens>;
  focuses?: Record<string, Focus>;
  /**
   * GOAP prompted actions this realm contributes. Scanned by the planner for every
   * loaded realm regardless of `exports` — a chat-callable tool is the separate,
   * per-action `export` flag.
   */
  actions?: Record<string, ActionSpec>;
  /** Webhook receivers this realm wants to accept traffic for, keyed by registration name. */
  webhooks?: Record<string, WebhookSpec>;
}

/**
 * A realm the host builds and loads the way it always has: GOAP goals, the
 * remote/generative/aggregate producer union, and OpenAPI/GraphQL apis with their
 * full field set. `triggers`, `queries` and `apps` are a captured realm's profiles
 * only, so they can never be set here.
 */
export interface ConventionalRealm extends RealmBase {
  execution?: "conventional";
  /**
   * Live connectors that push events into the realm, keyed by connector name. This is the
   * shape the engine has always read: a connector class plus whatever keys that class
   * takes. A captured realm declares its channels a different way — see
   * {@link CapturedRealm} — so this one stays here rather than on `RealmBase`.
   */
  channels?: Record<string, ChannelSpec>;
  /**
   * OpenAPI documents this realm vendors, keyed by the gateway namespace producers and
   * retrievals reference (an `omdb` entry is what makes `omdb.getMovie` resolvable).
   * Once this is declared, synth checks every dotted operation reference elsewhere in
   * the realm against the matching entry's allowlist. A realm that declares no `apis`
   * gets none of that checking: dotted references stay unvalidated, the same as before
   * this field existed.
   */
  apis?: Record<string, ApiSpec>;
  producers?: Record<string, ProducerSpec>;
  /** GOAP goals this realm contributes. Scanned the same way as `actions`. */
  goals?: Record<string, GoalSpec>;
  triggers?: never;
  queries?: never;
  apps?: never;
  capturedLenses?: never;
  watches?: never;
  dataPipes?: never;
  graphql?: never;
  views?: never;
  skills?: never;
  capabilities?: never;
}

/**
 * A realm the host runs from a verified capture (wasm or docker): every declaration is
 * a bounded, versioned document a Kotlin reader parses directly, rather than the
 * conventional GOAP loader. `goals`, `producers` and `apis` carry the narrower
 * captured shapes here, not the conventional ones.
 *
 * `H` is the realm's own `handlers` block. Every place the realm names a handler is
 * typed against {@link HandlerRef}`<H>` — the `namespace.verb` names those handlers
 * actually add up to — so a name the realm never declared is a compile error. Nothing
 * infers `H` on its own, though: write the realm as a plain object and `H` stays the
 * open default, which checks exactly as it did before this parameter existed. Pass it
 * through {@link defineRealm} to get the checking.
 */
export interface CapturedRealm<
  H extends Record<string, HandlerSpec> = Record<string, HandlerSpec>,
  A extends Record<string, DeclaredApiOperations> = Record<string, DeclaredApiOperations>,
> extends RealmBase {
  execution: "captured";
  /**
   * Handlers this realm exposes, keyed by verb name. Narrower than `RealmBase`'s so the
   * exact verbs and namespaces are captured in `H`, which is where every handler
   * reference below gets its allowed names from.
   */
  handlers?: H;
  /**
   * OpenAPI documents this realm vendors, keyed by the entry's own file key. `A` is what
   * they add up to, and it is where a channel handshake gets its allowed operation names
   * from. The intersection is doing two jobs: the entry still has to be a full
   * {@link CapturedApiSpec}, while `A` keeps the exact names and operation ids as written
   * so there is something to check a reference against.
   */
  apis?: A & Record<string, CapturedApiSpec>;
  /**
   * What this realm needs to authenticate, keyed by the id the rest of the realm
   * references — an api entry's `credential`, and the channel shapes that come later.
   * Emitted once as `credentials.yml`. A credential nothing references is refused:
   * it would ask a person to hand over a secret no call ever uses.
   */
  credentials?: Record<string, CredentialSpec>;
  /**
   * Live connections this realm opens or accepts, one file per key under `channels/`.
   * Nothing like the conventional shape above it: no connector class, no environment
   * variable, and the host owns reconnect, budgets and whether it starts at all.
   *
   * Write these through {@link connecting}, which is where the credential, channel and
   * source names actually get checked against each other. Here they are plain strings,
   * because a realm object on its own has no way to know which credentials sit beside it.
   * `NoInfer` keeps a wrong handler reported against the channel that wrote it.
   *
   * A websocket handshake names an api operation, and it is checked against the operations
   * the realm's own `apis` block allows — so `apps.connections.open` is fine when an entry
   * named `apps` allows it, and a name nothing declares is a compile error. A realm that
   * declares no apis has nothing to check against, so any dotted name will do there.
   */
  channels?: Record<
    string,
    CapturedChannelSpec<string, NoInfer<HandlerRef<H>>, NoInfer<OperationRef<A>>>
  >;
  /**
   * Named streams of events the channels produce, one file per key under `sources/`.
   * A source is what the owner grants access to, and what a consumer subscribes to.
   */
  sources?: Record<string, CapturedSourceSpec<string>>;
  /** Handlers that read those sources, one file per key under `consumers/`. */
  consumers?: Record<string, CapturedConsumerSpec<string, NoInfer<HandlerRef<H>>>>;
  producers?: Record<string, CapturedProducerSpec<NoInfer<HandlerRef<H>>>>;
  /** Captured goal declarations, one file per key under `goals/`. */
  goals?: Record<string, CapturedGoalSpec<NoInfer<HandlerRef<H>>>>;
  /** Trigger bindings, one file per key under `triggers/`. */
  triggers?: Record<string, TriggerSpec>;
  /** The realm's whole `queries/references.yml`, emitted once. */
  queries?: QueryReferences;
  /** Browser apps, one manifest per key under `apps/`. */
  apps?: Record<string, AppSpec>;
  /** Declared trigger sources and consumers, emitted once as `data-pipes.yml`. */
  dataPipes?: CapturedDataPipesSpec<NoInfer<HandlerRef<H>>>;
  /**
   * A GraphQL source with fixed persisted queries, emitted once as `graphql/operations.yml`.
   * Its credential has to be declared in `credentials`, and naming it here counts as using it.
   */
  graphql?: CapturedGraphqlSpec;
  /**
   * Saved Cypher views, emitted together as `views/<realm>.yml` in the order written. Each
   * `$param` a view's cypher uses has to be declared in its `params`, with a type.
   */
  views?: readonly CapturedViewSpec[];
  /**
   * Skill folders this realm ships, by name: `"chess-plans"` ships `skills/chess-plans/`.
   * Each needs a `SKILL.md` whose frontmatter `name` is the folder's. Synth copies the folders
   * as they are and puts each one's sha256 in the generated handler types as
   * `skills.digest["chess-plans"]`, so a handler can key a cache on the exact skill text.
   */
  skills?: readonly string[];
  /**
   * What this realm asks the owner to grant, written to realm.yml. The admission preview
   * offers each one for the owner to grant or not.
   */
  capabilities?: readonly RealmCapability[];
}

/**
 * A whole realm, in one object.
 *
 * Write it as `export default { ... } satisfies Realm`. The `satisfies` keeps the exact
 * shape you wrote, so the editor knows which producers exist by name, while still
 * checking every field against this type. It emits no runtime code; by the time the
 * definition is evaluated it is a plain object.
 *
 * Anything keyed by name here (types, producers, lenses, focuses) is emitted with that
 * key filled in as the entry's `name`, so a name is never written twice.
 *
 * A realm is one or the other, never both: `execution: "captured"` switches every
 * profile that differs between the two — `goals`, `producers`, `apis`, plus the
 * captured-only `triggers`, `queries` and `apps` — to its captured shape all at once.
 * Leave `execution` out (or write `"conventional"`) and every field keeps meaning
 * exactly what it always has.
 */
export type Realm = ConventionalRealm | CapturedRealm;

/**
 * Declares a captured realm, checking every handler it names against the handlers it
 * declares. Write it instead of `satisfies Realm`:
 *
 * ```ts
 * export default defineRealm({
 *   name: "example",
 *   version: "0.1.0",
 *   execution: "captured",
 *   handlers: { digest: { namespace: "notes" } },
 *   goals: { brief: { handler: "notes.digest", input: "UserInput", output: "Brief" } },
 * });
 * ```
 *
 * Writing `handler: "notes.digset"` there is a compile error on that line, and so is
 * `"other.digest"` — right verb, a namespace this realm does not own. `satisfies Realm`
 * cannot do this: a plain object literal gets no inference from a sibling field, and a
 * call does. The host refuses an undeclared handler when the realm is installed, which
 * is a long way from where the name was typed.
 *
 * `const` is what keeps the handler names as the literals you wrote, rather than
 * widening them to `string` and leaving nothing to check against. It does the same for
 * the `apis` block, which is where a channel handshake's operation names come from.
 *
 * `A` defaults to the open record rather than to the empty one `H` falls back to, because
 * the two absences mean different things. A realm with no handlers block may name no
 * handler at all, so refusing every name is the right answer. A realm with no apis block
 * has said nothing about which operations exist — the host still knows — so any dotted
 * operation name is accepted there, and checking only begins once apis are declared.
 *
 * A realm with no `handlers` block at all declares no handlers, so it may name none:
 * `H` falls back to the empty map rather than to its constraint, and every reference is
 * checked against an empty set of names. Without that default an omitted block left `H`
 * as the open `Record<string, HandlerSpec>`, whose `HandlerRef` is plain `string`, and
 * forgetting to declare your handlers quietly turned the checking off — the one case
 * where you most want to hear about it. `CapturedRealm`'s own default stays open, so a
 * realm written as `satisfies Realm` is unaffected.
 *
 * Nothing happens at runtime: the realm comes back exactly as written.
 */
export function defineRealm<
  const H extends Record<string, HandlerSpec> = Record<never, never>,
  const A extends Record<string, DeclaredApiOperations> = Record<string, DeclaredApiOperations>,
>(realm: CapturedRealm<H, A>): CapturedRealm<H, A> {
  return realm;
}
