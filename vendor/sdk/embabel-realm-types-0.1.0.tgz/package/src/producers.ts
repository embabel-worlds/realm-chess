import type { JsonObject } from "./json.ts";
import type { Interpolated, KeyTemplate, RecordPath } from "./templates.ts";

/**
 * How a producer caches what it fetches. Orthogonal to the kind of producer: the engine
 * wraps the call in the policy, and the producer itself never knows.
 *
 * `none` and `fresh` are the same thing to the engine. They read differently on the
 * page, and that is the point: `fresh` says "this source is timely, always re-read it",
 * where `none` just says "do not cache".
 */
export type CacheSpec =
  /** Never cache. Hit the source every run. The default when nothing is declared. */
  | { kind: "none" }
  /** Same as `none`, said the other way round: this data is only worth having live. */
  | { kind: "fresh" }
  | {
      kind: "ttl";
      /** How long a fetched record stays usable. */
      seconds: number;
      /** Optionally cache misses too, for this long, so a known-empty key is not re-asked. */
      negativeTtlSeconds?: number;
    }
  /** Cache for the life of one chat process. */
  | { kind: "session" }
  /** Reference data that never changes. Never expires. */
  | { kind: "immutable" }
  /**
   * The cache is the graph itself: the result is persisted as a real node and served
   * from there while its inputs hash the same. Only an `aggregate` producer honours
   * this; on any other kind the engine quietly falls back to no caching at all, so
   * synth refuses it there rather than let you believe otherwise.
   */
  | { kind: "graph" };

/**
 * How volatile the fact behind a generated edge is, which decides whether the model may
 * answer from its own knowledge.
 *
 * `static` is durable world knowledge and may be answered parametrically. `volatile`
 * changes fast and must come from a tool. Declared only on a generative producer,
 * because that is the only kind that generates rather than fetches — writing it
 * anywhere else sets nothing.
 */
export type Volatility = "static" | "slow" | "volatile";

/** What every producer carries, whichever kind it is. */
interface ProducerBase {
  /** Identity within the realm. Synth fills this from the key the producer is filed under. */
  name?: string;
  /** Path to the records in the response, e.g. `$` or `$.streamingOptions.au[*]`. */
  records?: RecordPath;
  cache?: CacheSpec;
}

/**
 * Rewrites a key into the source's own query language before the call.
 *
 * For a source that speaks Lucene, or Essie, or its own dialect — a property of the
 * source, not of any one question. Only the outgoing argument changes; the key's
 * identity, which is what the join matches on, stays the caller's phrase, so a rewrite
 * can never silently re-key the graph.
 */
export interface KeyTransform {
  /** Only `ai` today. A named kind leaves room for a deterministic transform later. */
  kind?: "ai";
  /** What the source's query language is, and how to say the caller's intent in it. */
  instruction: string;
  /** Worked `phrase → expression` pairs. The cheapest way to pin a dialect's syntax. */
  examples?: { input: string; output: string }[];
  /** How long a rewritten phrase stays valid. A week by default; dialects do not move. */
  cacheSeconds?: number;
}

/**
 * Reads records from an API the realm declares. The commonest kind by a wide margin.
 *
 * There is no `edgeType`, `identityField`, `anchorKeyField` or `volatility` here, and
 * that is not an omission: the engine's remote producer has no such fields. A join says
 * which edge it populates and which record field carries the anchor key; a remote
 * producer just fetches.
 */
export interface RemoteProducer extends ProducerBase {
  kind: "remote";
  /** Bare gateway operation id, e.g. `getMovie`, not `omdb.getMovie`. */
  operation: string;
  /** Arguments for the operation. `{keys}` interpolates the anchor keys. */
  args?: JsonObject;
  /** How one anchor key is rendered into an argument. Must contain `{key}`. */
  keyTemplate?: KeyTemplate;
  /**
   * Split one anchor key into these named call arguments, for an operation whose key
   * maps to separate path parameters rather than a search term — an `"acme/widgets"` key
   * becoming `owner=acme, repo=widgets`. Forces one key per call.
   */
  keyArgs?: string[];
  /** The delimiter `keyArgs` splits the key on. `/` by default, and meaningless without it. */
  keySplit?: string;
  keyTransform?: KeyTransform;
  /**
   * Whether several keys may be fetched in one call. False forces one call per key,
   * which some APIs require, and getting it wrong silently returns unlinkable records.
   */
  batchSafe?: boolean;
  /** Stamps the queried key onto each record so the edge can link back to its anchor. */
  echoKeyAs?: string;
  /** Maps response fields onto the type's own field names. */
  project?: Record<string, string>;
}

/**
 * Generates candidates from an LLM. The prompt is realm-authored: the host backend
 * knows no domain and ships no prompt.
 */
export interface LlmGenerator {
  kind: "llm";
  /** Rendered with anchors, exclude, want, round and constraints in scope. */
  prompt: string;
  /**
   * Tool-group roles the generation is grounded with, e.g. `["web"]`. A generator with
   * tools is no longer answering from memory, so the volatility gate relaxes and a
   * `slow` or `volatile` edge becomes allowable.
   */
  tools?: string[];
  /**
   * A portable model role for this edge, like `chat_cheap` — never a concrete model
   * name, which would not survive a change of deployment. Absent uses the ops default.
   */
  role?: string;
  /** Sampling temperature, layered over whatever the role resolves to. */
  temperature?: number;
}

/**
 * Generates candidates from a host-supplied resumable function: given the keys, what to
 * exclude, how many are wanted and which round this is, it yields records.
 */
export interface FunctionGenerator {
  kind: "function";
  /** The registered generator function to call. */
  operation: string;
}

/** How a generative producer actually produces candidates. */
export type GeneratorSpec = LlmGenerator | FunctionGenerator;

/** Turns a generated name into a real record, usually via a remote lookup. */
export interface ResolveVia {
  name: string;
  kind: "remote";
  operation: string;
  args?: JsonObject;
  keyTemplate?: KeyTemplate;
  keyArgs?: string[];
  keySplit?: string;
  keyTransform?: KeyTransform;
  batchSafe?: boolean;
  records?: RecordPath;
  echoKeyAs?: string;
  project?: Record<string, string>;
}

/**
 * Generates edges from the model's own knowledge, or from a function: "films someone
 * who liked this would also like". No store is read. Resumable: it keeps generating
 * until enough candidates survive the filters.
 */
export interface GenerativeProducer extends ProducerBase {
  kind: "generative";
  generator: GeneratorSpec;
  /** The edge this populates, e.g. `SIMILAR_TO`. The engine has no default for it. */
  edgeType: string;
  /** The identity property of the records produced, e.g. `imdbId`. No default either. */
  identityField: string;
  /** The record field the anchor key is echoed into, so each result links back. */
  anchorKeyField?: string;
  /** The human-readable name the generator emits, before identity resolution. */
  nameField?: string;
  resolveVia?: ResolveVia;
  /**
   * How forgiving resolution is when `resolveVia` cannot match the generated name
   * exactly — `none` for strict, or the id of a registered relaxation strategy. Absent
   * uses the default punctuation-stripping one. Means nothing without `resolveVia`.
   */
  resolveRelaxation?: string;
  volatility?: Volatility;
  /** How many survivors to aim for when the query states no limit of its own. */
  defaultWant?: number;
  /** Drop candidates the generator is less confident about than this. */
  confidenceFloor?: number;
  /**
   * Tell the generator what it has already produced so it does not repeat itself. On by
   * default, and turning it off makes a second round return the first round's answers.
   */
  supportsExclusion?: boolean;
}

/** How an aggregate gathers the records it folds together. */
export interface CollectSpec {
  /** The label of the neighbours to gather, e.g. `MovieRating`. */
  targetLabel: string;
  /** The edge from the anchor to each neighbour, e.g. `RATED`. */
  via: string;
  /**
   * Renders one text item per collected record. Must interpolate at least one field,
   * since a constant would make every record read identically.
   */
  text: Interpolated;
  /** Where the traversal starts. The acting user by default. */
  anchorLabel?: string;
  /** An extra condition on each neighbour, e.g. `t.rating >= 6`. */
  where?: string;
  /** Cap on how many neighbours are gathered per anchor. */
  limit?: number;
  /**
   * Switches to per-anchor mode: the anchor property matched against each producer key,
   * rather than reducing the acting user's whole neighbourhood once. In this mode the
   * producer's `anchorKeyField` has to differ from its `identityField`, because the
   * identity carries the per-anchor node id and the anchor key carries its link value.
   */
  anchorKeyProperty?: string;
  /** True when the neighbours point at the anchor rather than away from it. */
  incoming?: boolean;
}

/** How the collected records are reduced to one value. */
export interface ReduceSpec {
  /** The registered aggregation to reduce with. `synthesize` by default. */
  using?: string;
  /** The record field the reduced value lands in. `summary` by default. */
  into?: string;
  /** Extra arguments for the aggregation — for `synthesize`, the goal it writes toward. */
  args?: string[];
  /** A portable model role for this reduction. Never a concrete model name. */
  role?: string;
  /** Sampling temperature, layered over whatever the role resolves to. */
  temperature?: number;
  /**
   * Target length in words. For a graph-cached producer this quantizes to a band, so
   * one band is one stable result rather than free text that drifts every run.
   */
  wordcount?: number;
}

/** Folds many records into one: a taste summary over every rating a user has, say. */
export interface AggregateProducer extends ProducerBase {
  kind: "aggregate";
  /** The edge this populates, e.g. `HAS_TASTE_SUMMARY`. The engine has no default for it. */
  edgeType: string;
  collect: CollectSpec;
  reduce: ReduceSpec;
  /** The identity property of the one node produced. Set it to the anchor key so there is one per anchor. */
  identityField?: string;
  /** The record field the anchor key is echoed into, which is the join's `recordKeyField`. */
  anchorKeyField?: string;
}

/**
 * A producer fetches the records behind one virtual relationship.
 *
 * These three cover every producer in every shipped realm. The engine registers many
 * more (sql, vector, keyword, cypher, graphql, sparql, elasticsearch and others), and
 * they belong here too, generated from the same wire schema the JVM reads. Hand-writing
 * this union is how it drifts: the first draft of this file guessed `fieldMap`,
 * `recordsAt` and a duration-string cache, where the real spec uses `project`, `records`
 * and `seconds`, and its second draft offered `volatility` on every kind when only one
 * kind has the field.
 */
export type ProducerSpec = RemoteProducer | GenerativeProducer | AggregateProducer;
