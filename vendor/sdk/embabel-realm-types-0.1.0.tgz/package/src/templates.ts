/**
 * The placeholder strings a realm spec uses, expressed as types.
 *
 * Several fields are not free text: they are small templates the host interpolates.
 * Getting one wrong fails at run time, and it reads as missing data, so the mistake is
 * hard to find. TypeScript can hold the shape of these directly, so a missing brace is a
 * compile error at the line that wrote it.
 */

/** Interpolates every anchor key at once: `{ i: "{keys}" }`. */
export type KeysTemplate = `${string}{keys}${string}`;

/** Interpolates one key per call: `keyTemplate: "{key}"`. */
export type KeyTemplate = `${string}{key}${string}`;

/**
 * A JSONPath into a response: `$`, `$.docs[*]`, `$.streamingOptions.au[*]`.
 * Anything not rooted at `$` selects nothing.
 */
export type RecordPath = `$${string}`;

/**
 * A string rendered by the host's template engine, carrying at least one `{{ … }}`
 * substitution, like `"{{ title }}: rated {{ rating }}/10"`. A constant string here means
 * every collected record renders identically, which is never what was intended.
 */
export type Interpolated = `${string}{{${string}}}${string}`;
