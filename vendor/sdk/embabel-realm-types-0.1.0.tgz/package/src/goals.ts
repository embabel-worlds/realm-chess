/**
 * A GOAP goal: a state the planner can aim for, described by the type it wants produced.
 *
 * Scanned from every loaded realm's `goals/` directory exactly like `actions/` — the
 * whole set feeds the planner regardless of the realm's export list. `export` is the
 * separate, per-goal decision to also publish it as a directly callable chat tool.
 */
export interface GoalSpec {
  description: string;
  /** Type name the planner considers this goal achieved once it has produced. */
  outputTypeName: string;
  /**
   * When true, the host publishes this goal as a tool the chat LLM can call directly,
   * starting from `UserInput` — the YAML equivalent of a locally exported goal.
   */
  export?: boolean;
}
