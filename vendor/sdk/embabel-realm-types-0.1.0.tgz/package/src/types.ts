import type { JsonObject, JsonValue } from "./json.ts";

/**
 * The engine's `Cardinality`: how many values a property holds.
 *
 * Written uppercase because that is what the engine's enum is called. Its parser
 * uppercases whatever you write, so case does not actually matter on the wire, but
 * one spelling in the type keeps generated code and goldens from drifting apart.
 */
export type PropertyCardinality = "OPTIONAL" | "ONE" | "LIST" | "SET";

/**
 * One check a property's value has to pass.
 *
 * A bare string is a rule that takes no arguments, like `"nonEmpty"`. The object form
 * names the rule and carries its arguments alongside it — `{ rule: "range", min: 1,
 * max: 10 }`. Which arguments a rule takes is the rule's business, so anything beyond
 * `rule` passes through as written.
 */
export type ValidationRule = string | ({ rule: string } & Record<string, JsonValue>);

/**
 * Where a property's legal values come from, so a caller can be offered them instead
 * of guessing. Mostly this stops a query generator inventing literals — writing
 * `state = 'OPEN'` when the data says `open`.
 *
 * Either declare the set yourself with `list`, or say `source: "distinct"` to ask the
 * underlying source to enumerate them. `max` bounds the answer: past it the caller is
 * told how many exist plus a sample, because a truncated list lies about the domain.
 */
export interface PropertyValues {
  /** Ask the source to enumerate its distinct values. Leave out when `list` supplies them. */
  source?: "distinct";
  /** A fixed value set the realm already knows. */
  list?: string[];
  /** Above this many distinct values, report a count and a sample instead of the whole set. Defaults to 100. */
  max?: number;
}

/** A property's declared shape. A bare string is shorthand for its description. */
export type PropertySpec =
  | string
  | {
      description?: string;
      /** Declared so queries can order and compare on it; the host coerces the source value. */
      type?: "string" | "int" | "number" | "boolean";
      /** How many values the property holds. Defaults to exactly one. */
      cardinality?: PropertyCardinality;
      /** Checks the value has to pass before it is written. */
      validation?: ValidationRule[];
      /** The property's legal values. A bare array is shorthand for `{ list: [...] }`. */
      values?: string[] | PropertyValues;
      /** Free-form annotations carried through to the graph. */
      metadata?: Record<string, string>;
      /** The key the store merges on. Exactly one property per type carries it. */
      identity?: boolean;
      required?: boolean;
      /** Opens this property to the graph-annotation surface, so it can be written by hand. */
      annotatable?: boolean;
      /** Marks this property as the type's concurrency field for annotation writes. */
      annotationVersion?: boolean;
    };

/**
 * How instances of a type relate to the world user.
 *
 * The predicate name carries the reading. `OWNED_BY` reads "entry OWNED_BY user", so it
 * points from the entry; `RATED` reads "user RATED entry", so it points from the user.
 * Leave the whole thing out for the default (`OWNED_BY`, from the entry), or say `false`
 * for shared reference data that belongs to nobody.
 */
export interface UserAnchorSpec {
  /** Uppercase, like a Cypher relationship type. The engine refuses anything else. */
  predicate: string;
  direction?: "from-entry" | "from-user";
}

/** How a type's instances are pulled from a connected source, in pages. */
export interface PagingSpec {
  /** Request argument carrying the page number. */
  param?: string;
  sizeParam?: string;
  size?: number;
  maxPages?: number;
  /** First page number sent to the source, for page-number paging. */
  startPage?: number;
  /** `"page"` walks page numbers; `"cursor"` follows an opaque cursor. */
  style?: "page" | "cursor";
  /** Cursor style only: the request argument the cursor rides in, e.g. HubSpot's `after`. */
  cursorParam?: string;
  /** Cursor style only: where in the response the next cursor lives, e.g. `$.paging.next.after`. */
  cursorPath?: string;
}

/**
 * How a type is filled from a connected source, through the realm's gateway.
 *
 * The type that gets populated says which operation to call, how to page through it,
 * and which part of the response holds the records. `{since}` and `{page}` in `args`
 * are filled in at run time with this type's watermark and the page number.
 */
export interface PopulationSpec {
  /** Provenance kind stamped on every record. */
  sourceKind: string;
  /**
   * The operation to call. This is matched against the world's API tool names, which
   * is a different vocabulary from a gateway `namespace.verb` reference — GitHub's is
   * `repos/list-commits` — so synth does not hold it to the gateway naming rules.
   */
  operation: string;
  /** Arguments passed to the operation; `{since}` and `{page}` are substituted at run time. */
  args?: JsonObject;
  paging?: PagingSpec;
  /** Where the record list sits in the response, as a JSONPath. Defaults to `$`. */
  records?: string;
  /** Which record field carries the source's own id. Defaults to the identity property. */
  id?: string;
  /** How often to poll. Defaults to hourly. */
  cadenceMinutes?: number;
}

/** Which way a virtual edge points, relative to its anchor. */
export type JoinDirection = "FROM_ANCHOR" | "TO_ANCHOR";

/**
 * One attempt at finding a join's target.
 *
 * `"none"` ends the chain with no link, which is a legitimate answer rather than a
 * failure. `{ key: … }` matches an anchor property against a target field. `{ ask: … }`
 * stops and asks a person, offering what the earlier rules turned up.
 */
export type JoinRule =
  | "none"
  | {
      key: {
        /** Property of the anchor. */
        on: string;
        /** Field of the target. */
        to: string;
        /** Compare trimmed and case-insensitively — what an email needs and an id does not. */
        ci?: boolean;
        confidence?: string;
      };
    }
  | { ask: string | { question: string; options?: string[]; confidence?: string } };

/**
 * How a join finds its target when one key is not the whole story: attempts in order,
 * first that yields wins.
 *
 * Note the wrapper object. The engine reads this as a `JoinPolicySpec` with a `rules`
 * list, so `policy: { rules: [...] }` is the shape that parses — a bare list does not,
 * whatever the engine's own doc comment shows.
 */
export interface JoinPolicySpec {
  rules: JoinRule[];
}

/**
 * One rule in a bridge join's identity-resolution chain, tried in order until one
 * yields. A bare string names a rule that needs no configuration; the object form is a
 * single key naming the rule, with its settings under it.
 */
export type ResolutionRule = string | Record<string, Record<string, string>>;

/** A child node and edge that a fetched record brings along with it. */
export interface BroughtEdge {
  /** The child's type. It has to be one this realm declares. */
  childType: string;
  relationship: string;
  direction?: JoinDirection;
  /** JSONPath inside the parent record to the child list. */
  records: string;
  /** Which child field is its identity. */
  id: string;
  /** Lifts a nested scalar in the child record up to a top-level property. */
  project?: Record<string, string>;
  /** The child is staging for a later pass, not a path anyone should query. Keeps it out of the schema. */
  internal?: boolean;
}

/**
 * How a traversal reaches instances of this type on demand.
 *
 * The join lives on the type being reached and describes how you get there: from an
 * anchor node, along a relationship, keyed by one of the anchor's properties, with a
 * named producer doing the fetching. It is a list because the same virtual node can be
 * reachable more than one way — and when it is, the type needs an identity property so
 * the paths converge on one node.
 */
export interface VirtualJoinSpec {
  /** The real node the traversal starts from. */
  anchorLabel: string;
  /** The edge created between anchor and target. */
  relationship: string;
  direction?: JoinDirection;
  /** Anchor property whose values become the keys handed to the producer, and the link key. */
  keyField: string;
  /** Anchor properties handed to the producer as one composite key, when that has to differ from the link key. */
  producerKeyFields?: string[];
  /** Field on each record whose value equals the anchor's key. Defaults to `keyField`. */
  recordKeyField?: string;
  /** Property on an already-materialized target that holds the anchor's key, when `recordKeyField` is nested. */
  materializedKeyField?: string;
  /** Keep anchor nodes minted from materialized targets, instead of discarding them after the query. */
  persistMinted?: boolean;
  policy?: JoinPolicySpec;
  /** The producer that fetches the records. Must be one this realm declares. */
  producer: string;
  /** Which flavour of this edge the join serves, when a target is reachable several ways from the same anchor. */
  via?: string;
  /** One line on what this path means. The query generator reads it verbatim, so keep it a routing signal, not prose. */
  description?: string;
  /** Child types this fetch brings along, materialized and linked beside the primary node. */
  brings?: BroughtEdge[];
  /** Refuse the query if it binds more anchors than this. Left out, the engine picks a budget from the producer's economics. */
  maxAnchors?: number;
  /** Refuse if the projected fan-out, primary plus brought, would exceed this. */
  maxFanoutTotal?: number;
  /** Run this join eagerly over all anchors and persist the result, rather than materializing it per query. */
  persist?: boolean;
  /** Identity-resolution chain for a bridge join, tried in order. */
  resolve?: ResolutionRule[];
  /** Persist a lazily-resolved bridge so it is reused next time. Defaults to true when `resolve` is set. */
  writeThrough?: boolean;
  /** How long a written-through bridge stays fresh, e.g. `30d`. */
  refreshAfter?: string;
}

/**
 * Fills a bridge type from a connected account's identity: authorize the provider and
 * the account it resolves to becomes an instance of this type, linked to the user.
 */
export interface IdentityBridgeSpec {
  /** The OAuth provider whose login resolves the identity. */
  provider: string;
  /** The edge from the linked node to this one. */
  relationship: string;
  /** Which type the identity links back from. Defaults to `Person`. */
  linkFrom?: string;
}

/** A declared parameter of a type method: its name and the TypeScript type it takes. */
export interface MethodParamSpec {
  name: string;
  type?: string;
}

/**
 * A method an instance of this type can call on itself, backed by one of the realm's
 * gateway operations. Where `population` says what fills a type, this says what a type
 * can do.
 *
 * At the call site the model writes `movie.details({})`, and the sandbox turns that
 * into the gateway call, building its arguments from the object's own fields plus
 * whatever the caller passed.
 */
export interface MethodSpec {
  /** The gateway operation this method calls, as `namespace.verb`. */
  gatewayTool: string;
  description?: string;
  params?: MethodParamSpec[];
  /**
   * Gateway argument to where its value comes from: `"$field"` reads a property off the
   * object, `"#param"` reads a method argument, anything else is a literal.
   */
  args?: JsonObject;
  /** The type this returns. Defaults to `any`. */
  returns?: string;
}

/** How the assistant fetches one instance when it needs one. */
export interface RetrievalSpec {
  /** Namespaced gateway operation, e.g. `omdb.getMovie`. */
  operation: string;
  /** Which field names the instance in working state. */
  nameFrom?: string;
  /** Renames response fields onto this type's field names. */
  fieldMap?: Record<string, string>;
}

/**
 * A worked example for the text-to-Cypher generator: a question someone might ask, and
 * the query that answers it over this type's paths. Only shown to the generator when
 * this realm is connected, so the examples it sees match the data it can actually reach.
 *
 * Use made-up data. Never a real person, repo, org or email.
 */
export interface CypherExample {
  /** The question, in the words a user would use. */
  q: string;
  /** The Cypher that answers it. Checked at build time. */
  cypher: string;
}

/** A domain type the realm contributes to the graph. */
export interface TypeSpec {
  description?: string;
  properties: Record<string, PropertySpec>;
  /**
   * Types this one inherits labels from, by simple name. Resolution is best-effort:
   * a name the world cannot place is dropped with a warning and the type still loads.
   */
  parents?: string[];
  /**
   * `public` (the default) puts the type in the repository tool the model sees.
   * `internal` keeps it in the data dictionary for planning and extraction but hides
   * it from that surface — right for action input/output types and signal payloads.
   */
  visibility?: "public" | "internal";
  /**
   * Whether instances belong to a user. False for shared reference data: a film isn't
   * owned by whoever looked it up; their rating is what belongs to them.
   */
  userAnchor?: boolean | UserAnchorSpec;
  /** How this type is filled from a connected source. */
  population?: PopulationSpec;
  /** How a traversal reaches this type's instances on demand. */
  virtualJoins?: VirtualJoinSpec[];
  /** Fills this type from a connected account's resolved identity. */
  identityBridge?: IdentityBridgeSpec;
  /** Methods callable on an instance, keyed by method name. */
  methods?: Record<string, MethodSpec>;
  retrieval?: RetrievalSpec;
  /**
   * The graph holds only part of this type — whatever has been synced, never the whole
   * truth. Set it so the assistant stops counting and listing them, because "0 of them"
   * is a confident wrong answer when the data simply isn't there.
   */
  partial?: boolean;
  /** Few-shot examples for the text-to-Cypher generator. */
  examples?: CypherExample[];
  /** Which extraction perspective this type's memories are pulled under. */
  perspective?: string;
}
