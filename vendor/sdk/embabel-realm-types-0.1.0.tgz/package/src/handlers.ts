import type { JsonObject } from "./json.ts";

/**
 * A verb this realm exposes: the input shape it accepts and output shape it returns.
 *
 * A handler is a named, typed unit of work: the realm declares what each one does and
 * expects to receive, the generated manifest lists them for the engine, and the emitted
 * types ensure handlers implement the right signature.
 */
export interface HandlerSpec {
  /** Which namespace groups this verb (e.g. "movie", "notes"). Handlers in the same namespace share a gateway subtype. */
  namespace: string;
  /** One or two sentences, what the handler does for the caller. */
  description?: string;
  /** JSON-Schema fragment describing the input shape; e.g. `{ type: "object", properties: { title: { type: "string" } }, required: ["title"] }`. Absent or empty schema becomes `{type:"object"}` in the manifest. */
  input?: JsonObject;
  /** JSON-Schema fragment describing the output shape. Same defaults as input. */
  output?: JsonObject;
  /**
   * The type whose instances this handler runs on. Set it and the handler stops being a
   * bare `gateway.<namespace>.<verb>(args)` function and becomes a METHOD you call on an
   * object already in scope — `movie.whereToWatch({ country: "gb" })`. The engine files
   * it in the program-method catalog under this label instead of on the gateway surface.
   *
   * The name is a graph LABEL, not a reference into this realm's `types` block. It may
   * be a type this realm declares, a type the host already knows (`Person`), or a label
   * another realm owns — the catalog matches on the label a node carries, wherever the
   * label was declared. Synth therefore cannot tell a foreign label from a typo, and
   * does not try: it only refuses a blank one. A label nothing in the installed world
   * ever carries means the method simply never appears on anything.
   */
  onType?: string;
  /**
   * For a class-based type method: the class the realm's compiled module exports, which
   * the sandbox instantiates before calling the handler on the instance. Leave it out for
   * the plain function form, which is called as `fn(gateway, self, args)` instead.
   *
   * Only means anything with `onType` set, and only on a JS/docker realm — a wasm realm
   * has no module for the sandbox to require, so the host calls its type methods straight
   * through the gateway and never looks at a class name. Synth refuses both dead cases.
   */
  className?: string;
  /**
   * A Spring six-field cron expression (second minute hour day-of-month month
   * day-of-week), evaluated in the host's timezone. When set, the host runs this
   * handler on that cadence for every user with the realm installed, calling it
   * with no arguments — so a scheduled handler's `input` schema can declare no
   * required field, or every scheduled run would fail before it starts.
   *
   * There is a second, independent way to schedule a handler: a `defineSchedule()`
   * call inside the handler source the wasm build compiles. The two authorities
   * can't name the same handler — synth refuses that combination rather than
   * leaving it to whichever one the host happens to read last.
   */
  schedule?: string;
}
