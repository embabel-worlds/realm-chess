import type { CredentialSpec } from "./credentials.ts";
import type { JsonValue } from "./json.ts";
import type { WebhookTimestampConfig } from "./webhooks.ts";

/**
 * How long something takes, written the way a person says it: "30s", "5m".
 *
 * The type only fixes the spelling. Whether a particular length is allowed where it was
 * written — a keepalive that fires every second would hammer the provider, one that
 * fires every hour would be dropped as dead — is a floor and a cap synth checks, because
 * a template literal type cannot compare numbers.
 */
export type Duration = `${number}s` | `${number}m`;

/**
 * Fields a realm may never set on a channel, a source or a consumer, because the host
 * owns them.
 *
 * Reconnect policy, budgets, limits, cursors and whether a channel starts at all are
 * decisions the person running the host makes, not the realm being run. `name` is the
 * file's own name. `secret` and `secretRef` are the two ways a realm could try to carry
 * key material past the credential system.
 *
 * They are typed `never` rather than merely left out because leaving a field out only
 * catches a fresh object literal: an object declared separately and then referenced
 * stays assignable, and the extra key would be dropped in silence. Typed `never`, it is
 * a compile error however the object was built. Synth refuses them at emit time too,
 * for the realm that reaches this shape from untyped JavaScript.
 */
export interface HostOwned {
  name?: never;
  cursor?: never;
  reconnect?: never;
  autoStart?: never;
  limits?: never;
  budget?: never;
  secret?: never;
  secretRef?: never;
}

/**
 * How the host checks that an inbound webhook really came from the provider.
 *
 * The same layout the conventional webhook shape uses — which header carries the digest,
 * what was hashed, how it is encoded, the optional replay window — except that the
 * secret comes from a declared credential instead of a `secretRef` pointing into someone's
 * wallet. That is the whole difference: a captured realm names what it needs and the host
 * binds a real secret to that slot at approval time.
 */
export interface CapturedWebhookSignature<Credential extends string> {
  scheme: "hmac-sha256" | "ed25519";
  /** A credential declared right beside this channel. Replaces `secretRef`. */
  credential: Credential;
  /** Header carrying the digest, e.g. "X-Hub-Signature-256". */
  header: string;
  /** Prefix to strip before comparing, e.g. "sha256=". */
  prefix?: string;
  /** "hex" (default) or "base64". */
  encoding?: "hex" | "base64";
  /** What was signed, built from `{method}`, `{fullUrl}`, `{body}` and `{timestamp}`. */
  template?: string;
  /** The anti-replay window, when the provider signs a timestamp alongside the body. */
  timestamp?: WebhookTimestampConfig;
  secret?: never;
  secretRef?: never;
}

/**
 * The check a provider runs against a webhook endpoint before it will deliver to it, and how
 * the host answers it.
 *
 * Slack posts a `url_verification` body and wants its `challenge` string back; Discord posts
 * `{"type":1}` and wants `{"type":1}` back. Neither will save an endpoint that answers
 * anything else, and neither check is an event: there is nothing in one that a person said.
 *
 * The handler cannot answer it. A channel handler returns a cursor, and giving it an HTTP
 * response would let guest text reach a provider with nothing budgeting it. So the realm
 * declares the check instead and the host answers it directly: once the signature has passed,
 * the host reads `when.field` out of the body and, when it equals `when.equals`, replies 200
 * itself, dispatches nothing and journals nothing.
 *
 * Two shapes cover every provider we know of. `echo` names the field whose string is sent
 * back as `text/plain`; `body` is a constant written here in the realm and sent back as
 * `application/json`. Exactly one of them, because a reply cannot be both, and neither is a
 * reply the host has no way to write. Both are capped at 1 KiB.
 */
export interface CapturedWebhookVerification {
  /** Which field, and which value in it, marks a request as the check rather than an event. */
  when: {
    /** A dotted path into the request body, like "type" or "payload.kind". */
    field: string;
    /** The value that field holds on the check. Slack sends a word, Discord a number. */
    equals: string | number;
  };
  /** Either the field to echo back, or the constant to answer with. Never both, never neither. */
  reply: { echo: string; body?: never } | { body: JsonValue; echo?: never };
}

/**
 * A live connection a captured realm opens, or one it accepts.
 *
 * Three transports, and they are exclusive: every field belonging to the other two is
 * typed `never` on each one, so writing `every` on a websocket or `keepalive` on a
 * long-poll is a compile error on the line that wrote it rather than a key nothing reads.
 *
 * - `websocket` — the host dials `url` with the bound credential attached and hands every
 *   frame to `onFrame`. `keepalive` sends a tick on a schedule. `handshake` is for a
 *   provider that mints its socket url through an api call first (Slack's Socket Mode):
 *   the host calls that operation, reads `field` out of the answer, and connects there.
 * - `long-poll` — the host fetches `url` every `every` and hands the body to `onResponse`.
 * - `webhook` — the provider calls the host. The host verifies the signature and hands the
 *   verified body to `onRequest`. There is no `url` to declare: the host mints one per
 *   installation at approval time.
 *
 * `Credential` and `Handler` are the names declared alongside — the credentials in the
 * same {@link connecting} call, and the realm's own handlers — so a name nothing declares
 * is a compile error. `Operation` is the realm's declared api operation ids where they are
 * known, and plain `string` where they are not.
 *
 * Unlike the legacy conventional `ChannelSpec`, this shape is closed: there is no
 * pass-through tail for connector-specific keys, because there is no connector class to
 * pass them to. The host reads exactly these fields.
 */
export type CapturedChannelSpec<
  Credential extends string,
  Handler extends string = string,
  Operation extends string = string,
> =
  | ({
      transport: "websocket";
      url: `wss://${string}`;
      credential: Credential;
      onFrame: Handler;
      keepalive?: { every: Duration; handler: Handler };
      /** For a provider that mints the socket url through an api call. */
      handshake?: { operation: Operation; field: string };
      every?: never;
      onResponse?: never;
      onRequest?: never;
      signature?: never;
      verification?: never;
    } & HostOwned)
  | ({
      transport: "long-poll";
      url: `https://${string}`;
      credential: Credential;
      onResponse: Handler;
      /** How often to fetch. Floor 1s; synth defaults it when absent. */
      every?: Duration;
      onFrame?: never;
      keepalive?: never;
      handshake?: never;
      onRequest?: never;
      signature?: never;
      verification?: never;
    } & HostOwned)
  | ({
      transport: "webhook";
      onRequest: Handler;
      signature: CapturedWebhookSignature<Credential>;
      /** The provider's endpoint check, answered by the host before anything is dispatched. */
      verification?: CapturedWebhookVerification;
      url?: never;
      credential?: never;
      onFrame?: never;
      onResponse?: never;
      keepalive?: never;
      handshake?: never;
      every?: never;
    } & HostOwned);

/**
 * The part of an api declaration the handshake reference reads: the namespace the entry
 * registers, and the operations it is allowed to call.
 *
 * Spelled readonly because {@link defineRealm} infers the realm's `apis` block with
 * `const`, which turns every array literal in it into a readonly tuple. A tuple is exactly
 * what makes the operation ids readable as literals, so the constraint has to accept one —
 * a `string[]` constraint would make TypeScript quietly fall back to the widened inference
 * and the whole union would collapse to `string`.
 */
export interface DeclaredApiOperations {
  name: string;
  operationIds: readonly string[];
  writeOperationIds?: readonly string[];
}

/** The element type of a readonly array of strings, and `never` for anything else. */
type OperationIdsOf<Ids> = Ids extends readonly (infer Id extends string)[] ? Id : never;

/**
 * Every operation a realm's declared apis allow, written the way they are referenced:
 * `<namespace>.<operationId>`, where the namespace is the api entry's own `name`.
 *
 * Read and write operations both count — a handshake that mints a socket url is usually a
 * POST, so restricting this to the read list would refuse the one call it exists for.
 *
 * A realm that declares no apis gets plain `string` back, the same way {@link HandlerRef}
 * does for a realm with no handlers block: there is nothing to check against, so checking
 * is off rather than refusing everything.
 */
export type OperationRef<A extends Record<string, DeclaredApiOperations>> = string extends keyof A
  ? string
  : {
      [K in keyof A & string]: `${A[K]["name"]}.${OperationIdsOf<
        A[K]["operationIds"] | A[K]["writeOperationIds"]
      >}`;
    }[keyof A & string];

/**
 * A named stream of events a channel produces, and the thing the owner grants access to.
 *
 * One channel can feed several sources — a gateway socket carrying both messages and
 * presence, say — and it is the source, not the channel, that a consumer subscribes to
 * and that the owner approves. The description is what that owner reads when deciding.
 */
export interface CapturedSourceSpec<Channel extends string> {
  /** A channel declared in the same {@link connecting} call. */
  channel: Channel;
  /** What flows through here, in the words the approval screen shows the owner. */
  description: string;
  name?: never;
  kind?: never;
  installationId?: never;
}

/**
 * A handler that reads one source's events.
 *
 * `assistant: true` asks for the grant that lets this consumer talk to the owner's
 * assistant. It is a separate grant because it spends the owner's model budget and reads
 * their memory, so it is approved on its own rather than riding along with the source.
 */
export interface CapturedConsumerSpec<Source extends string, Handler extends string = string> {
  /** A source declared in the same {@link connecting} call. */
  source: Source;
  handler: Handler;
  /** Requests the ASSISTANT grant. Defaults to false. */
  assistant?: boolean;
  name?: never;
  checkpoint?: never;
}

/**
 * Declares a captured realm's credentials, channels, sources and consumers together, so
 * each one can only name the things declared right beside it. Spread the result into the
 * realm:
 *
 * ```ts
 * export default defineRealm({
 *   name: "example",
 *   version: "0.1.0",
 *   execution: "captured",
 *   handlers: { gateway: { namespace: "example" } },
 *   ...connecting({
 *     credentials: { bot: { kind: "bearer", description: "A bot token." } },
 *     channels: {
 *       socket: {
 *         transport: "websocket",
 *         url: "wss://gateway.example.com",
 *         credential: "bot",
 *         onFrame: "example.gateway",
 *       },
 *     },
 *     sources: { messages: { channel: "socket", description: "Messages from your server." } },
 *     consumers: { reply: { source: "messages", handler: "example.gateway" } },
 *   }),
 * });
 * ```
 *
 * Writing `credential: "bto"` there is a compile error on the channel that wrote it, and
 * so is a source naming a channel nobody declared, or a consumer naming a source nobody
 * declared. A plain object literal checked with `satisfies Realm` gets none of this: it
 * gets no inference from a sibling field's keys, and a call does.
 *
 * `NoInfer` is what keeps the error where the mistake was made. Without it, a channel
 * naming a credential nobody declared would simply widen the credential union to admit
 * the made-up name, and the complaint would land on the `credentials` block — "property
 * 'bto' is missing" — rather than on the channel.
 *
 * Handler names and handshake operations are not checked here — they are checked where they
 * can be, at the `defineRealm` that knows what this realm declares. What this call has to do
 * is carry them out intact, and that is what `const` on `Handler` and `Operation` is for:
 * without it every handler name written here widens from `"probe.read"` to plain `string` on
 * the way out, and the spread that follows then fails against the very handlers block that
 * was supposed to check it. With it, `Handler` comes out as the handler names this call
 * actually used, and `defineRealm` has something to check.
 *
 * So: a wrong credential, channel or source name is an error here, on the line that made it
 * up. A wrong handler or handshake operation is an error on the `defineRealm` argument,
 * naming the name and the allowed ones, because TypeScript resolves the spread before it
 * works out what that realm declared.
 *
 * `Operation` is the one parameter here with nothing to infer from in the ordinary case:
 * `handshake` is optional and most channels have none. What it falls back to in that case is
 * therefore what the result carries, and it has to be `never` rather than `string`. Falling
 * back to `string` made a call that declared no handshake at all promise a handshake naming
 * any operation whatsoever — a wider promise than a realm declaring apis accepts — so
 * spreading it in failed with "string is not assignable to 'apps.connections.open'" over a
 * channel that never mentioned an operation, on all three transports (the channel record's
 * value type is the whole union, so every channel carries the websocket variant's
 * `handshake`). `never` says the honest thing: nothing was declared, so nothing is asked of
 * the apis block, and the result fits a realm with any apis or none.
 *
 * Reaching that fallback takes the `NoInfer` on `Operation` in the return type as well.
 * Spread into a `defineRealm`, the return type is matched against what that realm expects
 * while the realm's own `apis` are still being inferred — so the operation union is still at
 * its constraint, which is plain `string`, and that lands as a candidate for `Operation`. It
 * is a low-priority one, which is why a written handshake still wins with its literal, but
 * with nothing written it beat the default and put `string` back. `NoInfer` drops it, leaving
 * only what the call itself wrote. Write a handshake and the literal is inferred exactly as
 * before, and is still checked against what the realm declares.
 *
 * Nothing happens at runtime: the declarations come back exactly as written.
 */
export function connecting<
  const Credential extends string,
  const Channel extends string,
  const Source extends string,
  const Handler extends string = string,
  const Operation extends string = never,
>(declared: {
  credentials: Record<Credential, CredentialSpec>;
  channels: Record<Channel, CapturedChannelSpec<NoInfer<Credential>, Handler, Operation>>;
  sources: Record<Source, CapturedSourceSpec<NoInfer<Channel>>>;
  consumers: Record<string, CapturedConsumerSpec<NoInfer<Source>, Handler>>;
}): {
  credentials: Record<Credential, CredentialSpec>;
  channels: Record<Channel, CapturedChannelSpec<Credential, Handler, NoInfer<Operation>>>;
  sources: Record<Source, CapturedSourceSpec<Channel>>;
  consumers: Record<string, CapturedConsumerSpec<Source, Handler>>;
} {
  return declared;
}
