/**
 * A WebAssembly module this realm needs mounted beside its handlers.
 *
 * The host resolves the name and version against an operator-curated registry and
 * refuses anything the registry does not hold. The digest pins the exact bytes: if the
 * registry's copy does not hash to this value, the realm does not load. Declaring a
 * dependency here does not grant it anything. What a module may touch is fixed by its
 * registry entry, and what state it sees is decided by the host at mount.
 *
 * No host consumes these declarations yet. Synth validates the shape and emits
 * dependencies/manifest.json so realms can declare forward; the engine ignores the file
 * until the dependency mechanism lands.
 */
/**
 * The declaration key becomes a member on the generated handler context, so it must be
 * a valid identifier and may never collide with the built-in members `log` and
 * `gateway`. Synth refuses declarations that break either rule.
 */
export interface DependencySpec {
  /** Registry module id, e.g. "sqlite3-wasi". Not a URL. The registry owns sources. */
  module: string;
  /**
   * The kind the host loads the module as: `sqlite` keeps state and answers `exec`,
   * `pure-compute` keeps none and answers the methods declared here. A host may offer more.
   *
   * Optional. The operator's allowlist names each module's kind, and the host refuses an
   * entry whose `kind` differs from it. Left out, the module loads as whatever the
   * allowlist says, and synth checks a `sqlite3-wasi` module as `sqlite`. A lowercase name
   * of at most 64 letters, digits and dashes.
   */
  kind?: DependencyKind;
  /** Version requested from the registry, e.g. "3.50". Exact, not a range. */
  version: string;
  /** SHA-256 of the module bytes, lowercase hex. Must match the registry's copy. */
  sha256: string;
  /**
   * Ask the host to keep this dependency's state across dispatches. Off by default:
   * state lives in the instance's virtual filesystem and vanishes with it. Turning this
   * on changes durability, not the API the handlers see.
   */
  persistent?: boolean;
  /**
   * A realm-relative path to a script that runs against empty state before the first
   * dispatch. For ephemeral state, the script runs once per instance. For persistent
   * state, the script runs once when the state is created and persists thereafter.
   */
  init?: string;
  /**
   * SQL scripts that grow a persistent SQLite schema after `init`, in the order they run:
   * `["db/0001-plans.sql", "db/0002-theory.sql"]`. The init script is version 0 and these
   * are versions 1 onwards, so a list here needs an `init`.
   *
   * The host records which scripts it has applied, by hash, beside the database. On mount
   * it runs the ones it has not seen yet, in one transaction. Add new scripts to the end
   * and leave the earlier ones alone: a changed, removed or reordered script that already
   * ran makes the host refuse the database, naming the first one that differs.
   *
   * A `sqlite` dependency, or a `sqlite3-wasi` one with no `kind`, takes migrations, and so
   * does one of another stateful kind the host offers. A `pure-compute` one does not. Each
   * path is a file inside the realm, at most 1 MiB like the init script, and there can be
   * at most 64. For `sqlite` each one is a `.sql` file.
   */
  migrations?: string[];
  /**
   * The methods this realm actually calls on the dependency, keyed by the name it
   * calls them under.
   *
   * The operator's allowlist for the module, not this declaration, decides what a
   * dependency may really do at runtime; a realm cannot see that allowlist statically
   * and may not even see all of it. So this names only what the realm itself calls,
   * and synth types exactly that — nothing more, and nothing the operator didn't also
   * allow, since a call to a method the operator's list omits still refuses at runtime,
   * naming both sides.
   *
   * Only legal on a dependency other than SQLite. SQLite's one method, `exec`, is
   * fixed by the host, so a `sqlite` dependency, or a `sqlite3-wasi` one with no `kind`,
   * declaring `methods` is refused at synth, the same way the host itself refuses it.
   */
  methods?: Record<string, DependencyMethodSpec>;
}

/**
 * The types a dependency method's arguments and result can have: four numbers and text.
 * They are logical types. A wasm signature cannot tell a number from a string, so the
 * realm declares which is which and the host checks the declaration against the
 * module's real signature, and against the operator's allowlist, when it loads.
 *
 * `i32`, `f32` and `f64` cross as themselves and arrive as a native number. `i64` crosses
 * as itself too, but a value like the H3 cell index `617700169958293503` is too big for a
 * JS or Python number to hold exactly (both are doubles, exact only up to 2^53). So the
 * host hands an `i64` result over as a string of decimal digits and refuses a JSON number
 * beyond 2^53 on the way in, and every emitter types it as a string in its language.
 *
 * `string` is UTF-8 text, and it expands on the wasm side:
 *
 * - each `string` argument becomes two i32 slots, pointer then length;
 * - a `string` result is one i64, the pointer in the high 32 bits and the length in the
 *   low 32 bits. An empty string is pointer 0, length 0.
 *
 * Ownership. A module with a string anywhere in its methods exports
 * `embabel_alloc(len: i32) -> i32` and `embabel_free(ptr: i32, len: i32)`. The host
 * allocates each argument through `embabel_alloc`, writes the text, calls the method, and
 * frees the argument with `embabel_free` afterwards, even when the call traps. The module
 * owns the result until the host has copied it out, and then the host frees it. A result
 * may not overlap an argument buffer.
 *
 * Bounds. Each string, either way, is at most 1 MiB. One dispatch may allocate at most
 * 8 MiB in a module. Invalid UTF-8 in a result, a result outside the module's memory, or
 * an overlap ends the dispatch.
 *
 * The handler never sees any of this: it passes and gets back plain strings, and the
 * host does the copying. Byte arrays are not a type.
 */
export const DEPENDENCY_VALUE_TYPES = ["i32", "i64", "f32", "f64", "string"] as const;

/** One of {@link DEPENDENCY_VALUE_TYPES}. */
export type DependencyValueType = (typeof DEPENDENCY_VALUE_TYPES)[number];

/** The two kinds the reference host provides. */
export const DEPENDENCY_KINDS = ["sqlite", "pure-compute"] as const;

/** A dependency kind's name: one of {@link DEPENDENCY_KINDS}, or another kind the host offers. */
export type DependencyKind = (typeof DEPENDENCY_KINDS)[number] | (string & {});

/** The shape a kind's name must have, which the host checks before anything else. */
export const DEPENDENCY_KIND_NAME = /^[a-z][a-z0-9-]{0,63}$/;

/** One method a realm calls on a dependency: its argument types, in call order, and its return type. */
export interface DependencyMethodSpec {
  /** The argument types, in the order the call passes them. */
  args: DependencyValueType[];
  /** The return type. */
  returns: DependencyValueType;
}
