declare const VirtualCypherBrand: unique symbol;

/**
 * A query that has been through the `vc` tag.
 *
 * The brand is required, which is what makes it load-bearing: a plain string cannot be
 * assigned where a `VirtualCypher` is expected, so a lens cannot carry a query that
 * skipped tagging and therefore skipped checking. Only `vc` produces one.
 */
export type VirtualCypher = string & { readonly [VirtualCypherBrand]: true };

/**
 * Virtual cypher, tagged and formatted.
 *
 * `vc` marks a query so it can be checked when the realm is built, the way a GraphQL
 * `gql` tag does. It also normalizes the text: a query written
 * inside a nested object literal is indented to sit in the TypeScript, and that
 * indentation has no business travelling into the emitted spec, where it turns a readable
 * block into a quoted string full of leading whitespace.
 *
 * Normalizing here keeps what you read in the definition and what the engine receives
 * the same query.
 */
export function vc(strings: TemplateStringsArray, ...values: unknown[]): VirtualCypher {
  let raw = strings[0] ?? "";
  for (let i = 0; i < values.length; i++) {
    raw += String(values[i]) + (strings[i + 1] ?? "");
  }
  return format(raw) as VirtualCypher;
}

/**
 * Strips the indentation the surrounding code contributed, and trims the blank first and
 * last lines a multi-line template literal always has.
 *
 * The common indent is measured across non-blank lines only, so a deliberately indented
 * continuation keeps its shape relative to the rest of the query.
 */
export function format(query: string): string {
  const lines = query.replace(/\t/g, "  ").split("\n");

  while (lines.length > 0 && (lines[0] as string).trim() === "") lines.shift();
  while (lines.length > 0 && (lines[lines.length - 1] as string).trim() === "") lines.pop();
  if (lines.length === 0) return "";

  let common = Number.POSITIVE_INFINITY;
  for (const line of lines) {
    if (line.trim() === "") continue;
    common = Math.min(common, line.length - line.trimStart().length);
  }
  if (!Number.isFinite(common)) common = 0;

  return lines.map((l) => l.slice(common).trimEnd()).join("\n");
}
