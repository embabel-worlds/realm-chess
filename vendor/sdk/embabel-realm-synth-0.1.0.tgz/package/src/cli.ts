#!/usr/bin/env bun
import { watch as fsWatch } from "node:fs";
import { mkdir, writeFile } from "node:fs/promises";
import { dirname, relative, resolve } from "node:path";
import { SynthError } from "./canonical.ts";
import {
  emitTypes,
  pathInside,
  type SynthOptions,
  type SynthResult,
  synth,
  writeSynth,
} from "./index.ts";
import {
  APP_LIMIT_FLAGS,
  type AppLimits,
  parseByteSize,
  parseCount,
  resolveAppLimits,
  resolveProfile,
} from "./profile.ts";
import { type ScaffoldRuntime, scaffoldRealm } from "./scaffold.ts";

/**
 * realm-synth <definition.ts> [--out <dir>] [--types <file.d.ts | file.py>] [--watch]
 *             [--profile <name | profile.json>] [--app-limit <size>] [--app-page-limit <size>]
 *             [--app-resource-limit <size>] [--app-total-limit <size>] [--app-resource-count <n>]
 * realm-synth init <dir> [--runtime typescript|python|compiled]
 *
 * Prints the emitted files, or writes them when given --out. --watch keeps running
 * after the first synth and re-runs it on every change under the definition's
 * directory. init scaffolds a new realm directory for one runtime.
 *
 * --profile checks the realm against one execution environment. The app flags raise or
 * lower the limits a captured browser app is held to; sizes take a unit, like "32MiB".
 */

const USAGE =
  "usage: realm-synth <definition.ts> [--out <dir>] [--types <file.d.ts | file.py>] [--watch]\n" +
  "                   [--profile <name | profile.json>] [--app-limit <size>]\n" +
  "                   [--app-page-limit <size>] [--app-resource-limit <size>]\n" +
  "                   [--app-total-limit <size>] [--app-resource-count <n>]\n" +
  "       realm-synth init <dir> [--runtime typescript|python|compiled]";

/** What a synth command line asks for, once it has been read and checked. */
export interface SynthArgs {
  definition?: string;
  outDir?: string;
  typesOut?: string;
  watch: boolean;
  /** A built-in profile name or a path to a JSON profile, exactly as written. */
  profile?: string;
  /** Only the limits the command line set. The rest come from the profile or the defaults. */
  appLimits: Partial<AppLimits>;
}

/** Flags that take the next argument as their value. */
const VALUE_FLAGS = new Set([
  "--out",
  "--types",
  "--profile",
  "--app-limit",
  ...Object.values(APP_LIMIT_FLAGS),
]);

/**
 * Reads a synth command line. A value flag always takes the argument after it, whatever it
 * looks like, so `--out --types` writes to a directory named "--types" and a size never gets
 * mistaken for the definition path. Throws a SynthError naming the flag for a missing or
 * unreadable value, or a flag nobody knows.
 */
export function parseSynthArgs(args: readonly string[]): SynthArgs {
  const parsed: SynthArgs = { watch: false, appLimits: {} };
  const values = new Map<string, string>();
  for (let i = 0; i < args.length; i++) {
    const arg = args[i] as string;
    if (arg === "--watch") {
      parsed.watch = true;
    } else if (VALUE_FLAGS.has(arg)) {
      const value = args[i + 1];
      if (value === undefined) throw new SynthError(`${arg} needs a value.`);
      values.set(arg, value);
      i++;
    } else if (arg.startsWith("--")) {
      throw new SynthError(`${arg} is not a flag realm-synth knows.`);
    } else if (parsed.definition === undefined) {
      parsed.definition = arg;
    } else {
      throw new SynthError(`"${arg}": only one definition file can be synthesized at a time.`);
    }
  }
  parsed.outDir = values.get("--out");
  parsed.typesOut = values.get("--types");
  parsed.profile = values.get("--profile");
  const all = values.get("--app-limit");
  if (all !== undefined) {
    const bytes = parseByteSize(all, "--app-limit");
    parsed.appLimits.pageBytes = bytes;
    parsed.appLimits.resourceBytes = bytes;
    parsed.appLimits.resourcesTotalBytes = bytes;
  }
  // A per-limit flag is more specific than --app-limit, so it wins over it.
  for (const [key, flag] of Object.entries(APP_LIMIT_FLAGS) as [keyof AppLimits, string][]) {
    const value = values.get(flag);
    if (value === undefined) continue;
    parsed.appLimits[key] =
      key === "resourcesPerApp" ? parseCount(value, flag) : parseByteSize(value, flag);
  }
  return parsed;
}

/** Turns the profile and limit flags into the options a synth run takes. */
function synthOptions(args: Pick<SynthArgs, "profile" | "appLimits">): SynthOptions {
  const profile = args.profile === undefined ? undefined : resolveProfile(args.profile);
  // Resolved here as well as in emit, so a bad combination fails before any import runs.
  resolveAppLimits(profile, args.appLimits);
  // Written straight to stderr rather than through console.error, which colors its output
  // when FORCE_COLOR is set. A diagnostic is often a migration instruction, and watch mode
  // forwards it byte for byte, so it has to arrive as the plain text synth wrote.
  const warn = (message: string): void => {
    process.stderr.write(`${message}\n`);
  };
  return { warn, profile, appLimits: args.appLimits };
}

/** Path segments a watch rebuild ignores: generated output, dependencies, and dotfiles. */
const IGNORED_SEGMENTS = new Set([".embabel", "dist", "node_modules"]);

/**
 * True when a changed path should not trigger a rebuild: somewhere under .embabel/,
 * dist/, node_modules/, any dotfile or dotdir segment, or an exact match against one
 * of the caller-supplied `ignoredPaths`. Those extra entries are how watch mode also
 * ignores a custom `--out` directory or a `--types` file that does not happen to
 * start with a dot: both are resolved once, up front, relative to the watched
 * directory, the same base `path` is given in.
 *
 * An `ignoredPaths` entry matches a changed path either when the changed path is
 * exactly that entry, or when the entry is a segment-by-segment prefix of it (the
 * entry names a directory and the change is somewhere under it). A single file, such
 * as the resolved `--types` path, should only ever match itself this way: matching it
 * as a directory prefix would also ignore every unrelated file that happens to share
 * its name as a leading path segment, which is what let `--types src/realm.d.ts`
 * swallow the whole `src/` tree. `--out`, a directory, still matches as a prefix so
 * every file written under it is ignored.
 *
 * An empty `ignoredPaths` entry (a root-level `--types` or `--out` path resolving to
 * "") is skipped. Treating it as a zero-segment prefix would match everything and
 * silently ignore the whole watched tree.
 *
 * `path` and each entry of `ignoredPaths` can be relative or absolute; only their
 * segments matter.
 */
export function isIgnoredPath(
  path: string,
  ignoredPaths: string[] = [],
  ignoredFiles: string[] = [],
): boolean {
  const segments = path.split(/[\\/]+/).filter(Boolean);
  if (segments.some((segment) => IGNORED_SEGMENTS.has(segment) || segment.startsWith("."))) {
    return true;
  }
  if (ignoredFiles.some((file) => file.length > 0 && file === path)) {
    return true;
  }
  return ignoredPaths.some((ignored) => {
    const ignoredSegments = ignored.split(/[\\/]+/).filter(Boolean);
    if (ignoredSegments.length === 0) return false;
    return ignoredSegments.every((segment, i) => segments[i] === segment);
  });
}

/**
 * Wraps `fn` so a burst of calls collapses into one, `ms` after the last call. A
 * save touches a file more than once in quick succession, and this folds that burst
 * into a single rebuild.
 */
export function debounce<Args extends unknown[]>(
  fn: (...args: Args) => void,
  ms: number,
): ((...args: Args) => void) & { cancel: () => void } {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const debounced = (...args: Args): void => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      timer = undefined;
      fn(...args);
    }, ms);
  };
  debounced.cancel = () => {
    if (timer) clearTimeout(timer);
    timer = undefined;
  };
  return debounced;
}

/**
 * Wraps an async `fn` so overlapping calls never run at once. A call made while one
 * is already in flight does not start a second run; it just marks that another run is
 * wanted, with the arguments from the most recent such call, and that one run happens
 * once the in-flight run finishes. A burst of any size while a run is in flight still
 * produces at most two runs total: the one already running, and one more after it
 * that picks up everything that happened meanwhile.
 *
 * `fn` rejecting does not stop later calls from running: the rejection is swallowed
 * here so one bad run can never take the caller down with it or wedge the queue.
 */
export function serialize<Args extends unknown[]>(
  fn: (...args: Args) => Promise<void>,
): (...args: Args) => void {
  let running = false;
  let queued: Args | undefined;

  const run = (...args: Args): void => {
    if (running) {
      queued = args;
      return;
    }
    running = true;
    fn(...args)
      .catch(() => {
        // fn is expected to report its own failures; this is only a backstop so a
        // rejection can never escape as an unhandled promise rejection.
      })
      .finally(() => {
        running = false;
        if (queued) {
          const next = queued;
          queued = undefined;
          run(...next);
        }
      });
  };

  return run;
}

/**
 * Writes `--out` and `--types`, whichever were given, and returns every path written as the
 * user would name it. A types file inside `--out` belongs to that output, so the directory
 * check covers it too and nothing is written when the check fails. A types file elsewhere is
 * written after `--out` succeeds.
 */
async function writeOutputs(
  result: SynthResult,
  outDir: string | undefined,
  typesOut: string | undefined,
): Promise<string[]> {
  const types =
    typesOut === undefined
      ? undefined
      : { path: typesOut, content: emitTypes(result.realm, typesOut) };
  const printed: string[] = [];
  if (outDir) {
    for (const path of await writeSynth(result, outDir, types)) printed.push(`${outDir}/${path}`);
  }
  if (types && !(outDir && pathInside(outDir, types.path) !== undefined)) {
    await mkdir(dirname(types.path), { recursive: true });
    await writeFile(types.path, types.content, "utf8");
    printed.unshift(types.path);
  }
  return printed;
}

/** What one rebuild produced. */
export interface RebuildResult {
  ok: boolean;
  /** "ok" on success, or the failure message otherwise. */
  message: string;
  ms: number;
}

/** The hidden first argument that turns a run of this file into the rebuild worker, used only by the subprocess `rebuild` spawns. */
const REBUILD_WORKER_FLAG = "__rebuild-worker";

/**
 * What `rebuild` hands the worker subprocess, as the single JSON string that is the
 * worker's whole argv after the flag. A defined field is really given; an omitted one
 * really was not asked for. This is what keeps the worker's argument handling free of
 * flag scanning: a definition path that literally contains the text "--types" used to
 * be able to confuse an `indexOf("--types")` lookup into reading the wrong value.
 * Reading one JSON object apart cannot make that mistake.
 */
interface RebuildWorkerOptions {
  definitionPath: string;
  outDir?: string;
  typesOut?: string;
  profile?: string;
  appLimits?: Partial<AppLimits>;
}

/** The profile and limit settings a rebuild carries into its worker. */
export type RebuildSettings = Pick<SynthArgs, "profile" | "appLimits">;

/**
 * Runs one synth-and-write pass, then exits. This is the whole body of the disposable
 * subprocess `rebuild` spawns: it imports the definition, writes `--types` and
 * `--out` when given, and reports success or failure on its exit code and stderr.
 *
 * Every error, of any class, is caught here and turned into an exit code plus a
 * stderr line: a broken definition or a bug in synth itself both look the same to the
 * parent process, a nonzero exit it turns into a failed `RebuildResult`, and neither
 * one can take the watch loop down.
 */
async function runRebuildWorker(
  definitionPath: string,
  outDir?: string,
  typesOut?: string,
  settings: RebuildSettings = { appLimits: {} },
): Promise<void> {
  try {
    const result = await synth(definitionPath, { ...synthOptions(settings), typesOut });
    await writeOutputs(result, outDir, typesOut);
    process.exit(0);
  } catch (error) {
    const message = error instanceof SynthError ? error.message : String(error);
    console.error(message);
    process.exit(1);
  }
}

/**
 * Runs one rebuild in a disposable subprocess and reports what happened.
 *
 * A fresh `bun` process is spawned for every call, running this same file with a
 * hidden worker flag. The parent process never imports the definition itself, so
 * nothing in it can go stale in the parent's module cache, and the child's whole
 * module graph, the definition and everything it imports, is thrown away with the
 * process when the child exits. That is what makes an edit anywhere in that graph
 * show up in the next rebuild. Watch mode used to re-import the definition in the
 * same long-lived process with a cache-busting query string. That only busted the
 * definition file's own identity: anything it imported kept its original one, so an
 * edit to an imported file could rebuild against stale exports of that file.
 */
export async function rebuild(
  definitionPath: string,
  outDir?: string,
  typesOut?: string,
  settings: RebuildSettings = { appLimits: {} },
): Promise<RebuildResult> {
  const start = performance.now();
  const options: RebuildWorkerOptions = {
    definitionPath,
    outDir,
    typesOut,
    profile: settings.profile,
    appLimits: settings.appLimits,
  };
  const proc = Bun.spawn(
    [process.execPath, import.meta.path, REBUILD_WORKER_FLAG, JSON.stringify(options)],
    { stdout: "ignore", stderr: "pipe" },
  );
  const [exitCode, stderr] = await Promise.all([proc.exited, new Response(proc.stderr).text()]);
  const ms = Math.round(performance.now() - start);
  if (exitCode === 0) {
    // A worker that succeeded still had things to say: its stderr on a successful run is
    // its diagnostics, the tokenEnv deprecation among them. Dropping it is how watch mode
    // showed a plain green rebuild for a realm synth was warning about, while the same
    // realm built once on the command line printed the warning. Forwarded byte for byte,
    // because the text of a deprecation is the migration instruction.
    if (stderr.length > 0) process.stderr.write(stderr);
    return { ok: true, message: "ok", ms };
  }
  return { ok: false, message: stderr.trim() || `rebuild exited with code ${exitCode}`, ms };
}

/**
 * Watches the realm definition's directory tree and reruns `rebuild` on every change,
 * debounced so one save produces one rebuild. Logs one line per rebuild: the path
 * that changed, "ok" or the failure message, and elapsed time. A failed rebuild logs
 * and keeps watching; it never exits the process, the way graphql-codegen and
 * Prisma's watch loops behave.
 *
 * Rebuilds are serialized: a change that arrives while one is already running does
 * not start an overlapping one, it queues one more after it. Without that, two
 * rebuilds writing the same `--out` directory at once could interleave their writes.
 *
 * The resolved `--out` directory is added to the ignore list as a directory: every
 * file `rebuild` writes under it is ignored. The resolved `--types` path is added as
 * the exact file it is. Ignoring its whole containing directory suppressed every
 * sibling source file that happened to sit next to a generated types file, which is
 * most of a realm when `--types` writes into `src/`.
 */
function watchLoop(
  definitionPath: string,
  outDir: string | undefined,
  typesOut: string | undefined,
  settings: RebuildSettings,
): void {
  const root = dirname(resolve(definitionPath));
  const extraIgnoredDirs = [outDir]
    .filter((path): path is string => Boolean(path))
    .map((path) => relative(root, resolve(path)));
  const extraIgnoredFiles = [typesOut]
    .filter((path): path is string => Boolean(path))
    .map((path) => relative(root, resolve(path)));

  let lastChanged = definitionPath;
  const runOnce = serialize(async () => {
    const changed = lastChanged;
    const result = await rebuild(definitionPath, outDir, typesOut, settings);
    const rel = relative(root, resolve(root, changed)) || changed;
    const status = result.ok ? "ok" : result.message;
    console.log(`${rel}: ${status} (${result.ms}ms)`);
  });
  const debounced = debounce(runOnce, 150);

  console.log(`watching ${root} for changes...`);
  const watcher = fsWatch(root, { recursive: true }, (_event, filename) => {
    if (!filename) return;
    if (isIgnoredPath(filename, extraIgnoredDirs, extraIgnoredFiles)) return;
    lastChanged = filename;
    debounced();
  });

  process.on("SIGINT", () => {
    watcher.close();
    process.exit(0);
  });
}

async function runInit(args: string[]): Promise<void> {
  const dir = args[1];
  if (!dir || dir.startsWith("--")) {
    console.error("usage: realm-synth init <dir> [--runtime typescript|python|compiled]");
    process.exit(2);
  }
  const runtimeIndex = args.indexOf("--runtime");
  const runtime = (runtimeIndex >= 0 ? args[runtimeIndex + 1] : "typescript") as string;
  if (runtime !== "typescript" && runtime !== "python" && runtime !== "compiled") {
    console.error(`init: unknown runtime "${runtime}"`);
    process.exit(2);
  }
  try {
    const written = await scaffoldRealm(dir, runtime as ScaffoldRuntime);
    for (const path of written) console.log(`${dir}/${path}`);
  } catch (error) {
    if (error instanceof SynthError) {
      console.error(`init failed: ${error.message}`);
      process.exit(1);
    }
    throw error;
  }
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);

  if (args[0] === REBUILD_WORKER_FLAG) {
    const options = JSON.parse(args[1] ?? "{}") as RebuildWorkerOptions;
    await runRebuildWorker(options.definitionPath, options.outDir, options.typesOut, {
      profile: options.profile,
      appLimits: options.appLimits ?? {},
    });
    return;
  }

  if (args[0] === "init") {
    await runInit(args);
    return;
  }

  let parsed: SynthArgs;
  let options: SynthOptions;
  try {
    parsed = parseSynthArgs(args);
    options = synthOptions(parsed);
  } catch (error) {
    if (error instanceof SynthError) {
      console.error(`${error.message}\n${USAGE}`);
      process.exit(2);
    }
    throw error;
  }
  const { definition, outDir, typesOut } = parsed;

  if (!definition) {
    console.error(USAGE);
    process.exit(2);
  }

  if (parsed.watch) {
    const first = await rebuild(definition, outDir, typesOut, parsed);
    console.log(`${definition}: ${first.ok ? "ok" : first.message} (${first.ms}ms)`);
    watchLoop(definition, outDir, typesOut, parsed);
    return;
  }

  try {
    const result = await synth(definition, { ...options, typesOut });
    if (outDir || typesOut) {
      for (const path of await writeOutputs(result, outDir, typesOut)) console.log(path);
    } else {
      for (const [path, text] of Object.entries(result.rendered)) {
        console.log(`# ---- ${path}`);
        console.log(text);
      }
    }
  } catch (error) {
    if (error instanceof SynthError) {
      console.error(`synth failed: ${error.message}`);
      process.exit(1);
    }
    throw error;
  }
}

if (import.meta.main) {
  await main();
}
