import type { Realm } from "@embabel/realm-types";
import { SynthError } from "./canonical.ts";

/**
 * Validates that runtime-checked template fields match their compile-time types.
 *
 * The types in packages/realm-types/src/templates.ts (KeyTemplate, RecordPath,
 * Interpolated) are TypeScript narrowing only: a template built with a variable or
 * assembled dynamically bypasses the type check. This function catches those at
 * run time, with the exact path to the offending field.
 */
export function validateTemplates(realm: Realm): void {
  if (!realm.producers) return;

  for (const [producerName, producer] of Object.entries(realm.producers)) {
    const producerPath = `$.producers.${producerName}`;

    if (producer.kind === "remote") {
      if (producer.keyTemplate !== undefined && !producer.keyTemplate.includes("{key}")) {
        throw new SynthError(
          `${producerPath}.keyTemplate: must contain {key}, got "${producer.keyTemplate}"`,
        );
      }
      if (producer.records !== undefined && !producer.records.startsWith("$")) {
        throw new SynthError(
          `${producerPath}.records: must start with $, got "${producer.records}"`,
        );
      }
    } else if (producer.kind === "generative") {
      if (producer.resolveVia) {
        const resolveViaPath = `${producerPath}.resolveVia`;
        if (
          producer.resolveVia.keyTemplate !== undefined &&
          !producer.resolveVia.keyTemplate.includes("{key}")
        ) {
          throw new SynthError(
            `${resolveViaPath}.keyTemplate: must contain {key}, got "${producer.resolveVia.keyTemplate}"`,
          );
        }
        if (
          producer.resolveVia.records !== undefined &&
          !producer.resolveVia.records.startsWith("$")
        ) {
          throw new SynthError(
            `${resolveViaPath}.records: must start with $, got "${producer.resolveVia.records}"`,
          );
        }
      }
    } else if (producer.kind === "aggregate") {
      const collectPath = `${producerPath}.collect`;
      if (producer.collect.text !== undefined) {
        const text = producer.collect.text;
        if (!text.includes("{{") || !text.includes("}}")) {
          throw new SynthError(`${collectPath}.text: must contain {{ and }}, got "${text}"`);
        }
      }
    }
  }
}
