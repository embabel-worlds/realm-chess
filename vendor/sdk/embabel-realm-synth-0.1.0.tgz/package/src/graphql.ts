import type {
  CapturedApiSpec,
  CapturedGraphqlSpec,
  CapturedGraphqlVariableSpec,
  CredentialSpec,
  JsonObject,
} from "@embabel/realm-types";
import { canonicalize, SynthError } from "./canonical.ts";
import {
  CAPTURED_API_IDENTIFIER,
  CAPTURED_CREDENTIAL_ID,
  CAPTURED_FORBIDDEN_HEADERS,
  CAPTURED_HEADER_FIELD,
  CAPTURED_HEADER_NAME,
  capturedSurfaceName,
  checkCapturedApiBase,
  checkCapturedApiBound,
  checkCapturedBytes,
  isCapturedControlCharacter,
} from "./emit.ts";

/**
 * A captured realm's GraphQL source, checked against the host's captured GraphQL operation
 * profile and rendered as `graphql/operations.yml`.
 *
 * The host reads one fixed endpoint and a fixed set of persisted queries. Nothing about a call
 * is chosen by the guest except its variables, so everything that could go wrong with a
 * document is caught once, here and again at load time: a mutation, a fragment, a variable
 * default, or a variable signature that does not match what the realm declared.
 */

/** Where the host reads the file from. No other name under `graphql/` is recognized. */
export const GRAPHQL_OPERATIONS_PATH = "graphql/operations.yml";

/** The whole file, in bytes. */
const GRAPHQL_FILE_BYTES = 65_536;
/** One persisted document, in bytes. */
const GRAPHQL_DOCUMENT_BYTES = 16_384;
const GRAPHQL_MAX_OPERATIONS = 32;
const GRAPHQL_MAX_VARIABLES = 32;
const GRAPHQL_MAX_ENUM = 128;
const GRAPHQL_MAX_HEADERS = 16;
const GRAPHQL_HEADER_VALUE_CHARS = 1024;

/** The fixed names a guest calls the host by. An operation answering to one refuses the catalogue. */
export const HOST_CALL_NAMES: readonly string[] = [
  "channel_publish",
  "channel_publishBatch",
  "channel_position",
  "write_propose",
  "cypher_query",
  "assistant_chat",
  "stream_send",
  "stream_close",
];

/**
 * Headers the host sets itself, so an api key may not travel in one of them. A function
 * rather than a constant because this module and emit.ts import each other, and a constant
 * built from one of emit.ts's would be read before emit.ts had set it.
 */
function isReservedKeyHeader(name: string): boolean {
  const lower = name.toLowerCase();
  return lower === "idempotency-key" || CAPTURED_FORBIDDEN_HEADERS.includes(lower);
}

/** GraphQL's scalar types, and the variable type each one is declared as. */
const GRAPHQL_SCALARS: Readonly<Record<string, CapturedGraphqlVariableSpec["type"]>> = {
  String: "string",
  ID: "string",
  Int: "integer",
  Float: "number",
  Boolean: "boolean",
};

const VARIABLE_TYPES: readonly string[] = ["string", "integer", "number", "boolean"];

/** Refuses anything that is not a plain object, and any key the host does not read. */
function plainObject(
  value: unknown,
  allowed: readonly string[],
  where: string,
): Record<string, unknown> {
  if (
    typeof value !== "object" ||
    value === null ||
    Array.isArray(value) ||
    (Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null)
  ) {
    throw new SynthError(`${where}: expected a plain object.`);
  }
  for (const key of Object.keys(value)) {
    if (!allowed.includes(key)) {
      throw new SynthError(
        `${where}.${key}: not something the host reads here. It reads ${allowed.join(", ")}.`,
      );
    }
  }
  return value as Record<string, unknown>;
}

/** Nonblank, control-free text within a length. */
function text(value: unknown, limit: number, where: string): asserts value is string {
  if (
    typeof value !== "string" ||
    value.trim() === "" ||
    value.length > limit ||
    [...value].some((char) => isCapturedControlCharacter(char.charCodeAt(0)))
  ) {
    throw new SynthError(`${where}: expected nonblank text of at most ${limit} characters.`);
  }
}

/** Every name the host would give one declared REST operation. */
function apiCallNames(apis: Record<string, CapturedApiSpec> | undefined): Set<string> {
  const names = new Set<string>();
  for (const spec of Object.values(apis ?? {})) {
    for (const id of [...(spec.operationIds ?? []), ...(spec.writeOperationIds ?? [])]) {
      names.add(`${spec.name}.${id}`);
      names.add(`${spec.name}_${id}`);
      names.add(capturedSurfaceName(spec.name, id));
    }
  }
  return names;
}

/**
 * Checks a realm's GraphQL source and returns the document to write. `referenced` is told
 * about its credential, so a credential only this source names is not refused as unused.
 */
export function checkCapturedGraphql(
  spec: CapturedGraphqlSpec,
  apis: Record<string, CapturedApiSpec> | undefined,
  credentials: Record<string, CredentialSpec> | undefined,
  referenced: Map<string, string>,
): JsonObject {
  const where = "$.graphql";
  plainObject(
    spec,
    ["name", "endpoint", "auth", "header", "credential", "headers", "operations"],
    where,
  );
  text(spec.name, 64, `${where}.name`);
  if (!CAPTURED_API_IDENTIFIER.test(spec.name)) {
    throw new SynthError(
      `${where}.name: "${spec.name}" becomes the gateway namespace, and the host reads it ` +
        `against ${CAPTURED_API_IDENTIFIER.source}.`,
    );
  }

  text(spec.endpoint, 2048, `${where}.endpoint`);
  checkCapturedApiBase(spec.endpoint, `${where}.endpoint`, false);

  if (typeof spec.credential !== "string" || !CAPTURED_CREDENTIAL_ID.test(spec.credential)) {
    throw new SynthError(
      `${where}.credential: name a credential the realm declares in $.credentials. The host ` +
        `sends the secret the owner bound to it, and refuses every query while nothing is bound.`,
    );
  }
  if (credentials === undefined || !Object.hasOwn(credentials, spec.credential)) {
    throw new SynthError(
      `${where}.credential: "${spec.credential}" is not declared in $.credentials. A GraphQL ` +
        `source can only name a credential its own realm declares.`,
    );
  }
  if (!referenced.has(spec.credential)) referenced.set(spec.credential, `${where}.credential`);

  let authHeader = "authorization";
  if (spec.auth === "api-key") {
    text(spec.header, 128, `${where}.header`);
    if (!CAPTURED_HEADER_FIELD.test(spec.header) || isReservedKeyHeader(spec.header)) {
      throw new SynthError(
        `${where}.header: "${spec.header}" cannot carry the key. It has to match ` +
          `${CAPTURED_HEADER_FIELD.source} and not be a header the host sets itself.`,
      );
    }
    authHeader = spec.header.toLowerCase();
  } else if (spec.auth !== "bearer" || (spec as { header?: unknown }).header !== undefined) {
    throw new SynthError(
      `${where}.auth: write "bearer" with no header, or "api-key" with the header the key travels in.`,
    );
  }

  if (spec.headers !== undefined) {
    const headers = plainObject(spec.headers, Object.keys(spec.headers), `${where}.headers`);
    if (Object.keys(headers).length > GRAPHQL_MAX_HEADERS) {
      throw new SynthError(
        `${where}.headers: the host takes at most ${GRAPHQL_MAX_HEADERS} fixed headers.`,
      );
    }
    const seen = new Set([authHeader]);
    for (const [name, value] of Object.entries(headers)) {
      const at = `${where}.headers.${name}`;
      if (!CAPTURED_HEADER_NAME.test(name) || seen.has(name.toLowerCase())) {
        throw new SynthError(
          `${at}: a fixed header is named X-..., once, and never the header the key travels in.`,
        );
      }
      if (
        typeof value !== "string" ||
        value.length > GRAPHQL_HEADER_VALUE_CHARS ||
        !/^[\x20-\x7e]*$/.test(value) ||
        value.includes("${")
      ) {
        throw new SynthError(
          `${at}: a fixed header holds at most ${GRAPHQL_HEADER_VALUE_CHARS} printable ASCII ` +
            `characters, with no \${...} substitution.`,
        );
      }
      seen.add(name.toLowerCase());
    }
  }

  const operations = plainObject(
    spec.operations,
    Object.keys(spec.operations ?? {}),
    `${where}.operations`,
  );
  const count = Object.keys(operations).length;
  if (count < 1 || count > GRAPHQL_MAX_OPERATIONS) {
    throw new SynthError(
      `${where}.operations: declare between 1 and ${GRAPHQL_MAX_OPERATIONS} operations, got ${count}.`,
    );
  }

  const claimed = apiCallNames(apis);
  const entries = Object.keys(operations)
    .sort()
    .map((name) => {
      const at = `${where}.operations.${name}`;
      if (!CAPTURED_API_IDENTIFIER.test(name)) {
        throw new SynthError(
          `${at}: "${name}" is not an operation name the host reads. It has to match ` +
            `${CAPTURED_API_IDENTIFIER.source}.`,
        );
      }
      for (const callName of new Set([
        `${spec.name}.${name}`,
        `${spec.name}_${name}`,
        capturedSurfaceName(spec.name, name),
      ])) {
        if (claimed.has(callName)) {
          throw new SynthError(
            `${at}: the host would call this "${callName}", and an api operation already answers ` +
              `to that name. The host refuses every operation in the realm over one clash.`,
          );
        }
        if (HOST_CALL_NAMES.includes(callName)) {
          throw new SynthError(
            `${at}: "${callName}" is a host call's own name. The host refuses every operation in ` +
              `the realm over it. Rename the namespace or the operation.`,
          );
        }
        claimed.add(callName);
      }
      const operation = plainObject(operations[name], ["document", "variables"], at);
      const declared = operation.variables;
      if (
        declared !== undefined &&
        (!Array.isArray(declared) || declared.length > GRAPHQL_MAX_VARIABLES)
      ) {
        throw new SynthError(
          `${at}.variables: declare at most ${GRAPHQL_MAX_VARIABLES} variables, as a list.`,
        );
      }
      const variables = (declared ?? []) as CapturedGraphqlVariableSpec[];
      const names = new Set<string>();
      const wireVariables = variables.map((variable, index) => {
        const field = `${at}.variables[${index}]`;
        plainObject(
          variable,
          ["name", "type", "required", "minLength", "maxLength", "enum"],
          field,
        );
        text(variable.name, 64, `${field}.name`);
        if (!/^[A-Za-z_][A-Za-z0-9_]{0,63}$/.test(variable.name) || names.has(variable.name)) {
          throw new SynthError(
            `${field}.name: "${variable.name}" has to be a GraphQL name, used once per operation.`,
          );
        }
        names.add(variable.name);
        if (!VARIABLE_TYPES.includes(variable.type)) {
          throw new SynthError(
            `${field}.type: expected one of ${VARIABLE_TYPES.join(", ")}, got ${JSON.stringify(variable.type)}.`,
          );
        }
        if (variable.required !== undefined && typeof variable.required !== "boolean") {
          throw new SynthError(`${field}.required: expected true or false.`);
        }
        const min = checkCapturedApiBound(variable.minLength, `${field}.minLength`, 0);
        const max = checkCapturedApiBound(variable.maxLength, `${field}.maxLength`, 2048);
        if (min > max) {
          throw new SynthError(`${field}: minLength ${min} is over maxLength ${max}.`);
        }
        if (
          variable.enum !== undefined &&
          (!Array.isArray(variable.enum) ||
            variable.enum.length > GRAPHQL_MAX_ENUM ||
            variable.enum.some(
              (value) =>
                !["string", "number", "boolean"].includes(typeof value) ||
                (typeof value === "number" && !Number.isFinite(value)),
            ))
        ) {
          throw new SynthError(
            `${field}.enum: expected at most ${GRAPHQL_MAX_ENUM} strings, finite numbers or booleans.`,
          );
        }
        return {
          name: variable.name,
          type: variable.type,
          ...(variable.required === undefined ? {} : { required: variable.required }),
          ...(variable.minLength === undefined ? {} : { "min-length": variable.minLength }),
          ...(variable.maxLength === undefined ? {} : { "max-length": variable.maxLength }),
          ...(variable.enum === undefined ? {} : { enum: [...variable.enum] }),
        };
      });
      checkPersistedQuery(operation.document, variables, `${at}.document`);
      return {
        name,
        document: operation.document,
        ...(declared === undefined ? {} : { variables: wireVariables }),
      };
    });

  const doc = canonicalize(
    {
      version: 1,
      name: spec.name,
      endpoint: spec.endpoint,
      auth: spec.auth,
      credential: spec.credential,
      ...(spec.auth === "api-key" ? { header: spec.header } : {}),
      ...(spec.headers === undefined ? {} : { headers: spec.headers }),
      operations: entries,
    },
    where,
  ) as JsonObject;
  checkCapturedBytes(doc, GRAPHQL_OPERATIONS_PATH, GRAPHQL_FILE_BYTES, where);
  return doc;
}

/**
 * The document with comments and string contents blanked out, so a brace or a keyword inside
 * a string is never read as structure. Refuses an unterminated string.
 */
function stripGraphql(document: string, where: string): string {
  let result = "";
  let index = 0;
  const refuse = (): never => {
    throw new SynthError(`${where}: a string in the document is unterminated or badly escaped.`);
  };
  while (index < document.length) {
    if (document[index] === "#") {
      while (index < document.length && document[index] !== "\n" && document[index] !== "\r") {
        result += " ";
        index++;
      }
    } else if (document.startsWith('"""', index)) {
      result += "0  ";
      index += 3;
      while (index < document.length && !document.startsWith('"""', index)) {
        if (document.startsWith('\\"""', index)) refuse();
        result += document[index] === "\n" ? "\n" : " ";
        index++;
      }
      if (index === document.length) refuse();
      result += "   ";
      index += 3;
    } else if (document[index] === '"') {
      result += "0";
      index++;
      while (index < document.length && document[index] !== '"') {
        if (document[index] === "\\") {
          const escaped = /^\\(?:["\\/bfnrt]|u[0-9A-Fa-f]{4})/.exec(document.slice(index));
          if (!escaped) refuse();
          const length = (escaped as RegExpExecArray)[0].length;
          result += " ".repeat(length);
          index += length;
        } else {
          if (document[index] === "\n" || document[index] === "\r") refuse();
          result += " ";
          index++;
        }
      }
      if (index === document.length) refuse();
      result += " ";
      index++;
    } else {
      result += document[index];
      index++;
    }
  }
  return result;
}

/**
 * Checks one persisted document the way the host does at load time: exactly one `query`, no
 * mutation, subscription, fragment, introspection or variable default, and a variable
 * signature that matches the declared variables name for name, type for type and `!` for
 * `required`.
 */
function checkPersistedQuery(
  document: unknown,
  variables: CapturedGraphqlVariableSpec[],
  where: string,
): asserts document is string {
  if (
    typeof document !== "string" ||
    document.trim() === "" ||
    Buffer.byteLength(document, "utf8") > GRAPHQL_DOCUMENT_BYTES ||
    [...document].some(
      (char) =>
        isCapturedControlCharacter(char.charCodeAt(0)) && !["\n", "\r", "\t"].includes(char),
    )
  ) {
    throw new SynthError(
      `${where}: expected query text of at most ${GRAPHQL_DOCUMENT_BYTES} bytes with no control ` +
        `characters other than tabs and line breaks.`,
    );
  }
  const stripped = stripGraphql(document, where);
  if (/\b(?:fragment|__schema|__type)\b|\.\.\./.test(stripped)) {
    throw new SynthError(
      `${where}: fragments and introspection are outside the persisted query profile. Write the ` +
        `fields out in one query.`,
    );
  }
  let depth = 0;
  let start = -1;
  let end = -1;
  for (let index = 0; index < stripped.length; index++) {
    if (stripped[index] === "{") {
      if (depth === 0) {
        if (start !== -1) {
          throw new SynthError(`${where}: the document holds more than one operation.`);
        }
        start = index;
      }
      depth++;
    } else if (stripped[index] === "}") {
      depth--;
      if (depth < 0) throw new SynthError(`${where}: the braces do not balance.`);
      if (depth === 0) end = index;
    }
  }
  if (
    depth !== 0 ||
    start < 0 ||
    stripped.slice(end + 1).trim() !== "" ||
    stripped.slice(start + 1, end).trim() === ""
  ) {
    throw new SynthError(`${where}: expected exactly one complete query operation.`);
  }
  const head = /^\s*query(?:\s+[A-Za-z_][A-Za-z0-9_]*)?\s*(?:\(([^()]*)\))?\s*$/.exec(
    stripped.slice(0, start),
  );
  if (!head) {
    throw new SynthError(
      `${where}: the operation has to be a query. The host never runs a mutation or a subscription.`,
    );
  }
  const signature = head[1] ?? "";
  const pattern = /\$([A-Za-z_][A-Za-z0-9_]*)\s*:\s*([A-Za-z_][A-Za-z0-9_]*)(!)?/g;
  const found = [...signature.matchAll(pattern)];
  const rest = signature.replace(pattern, "");
  if (!/^[\s,]*$/.test(rest)) {
    throw new SynthError(
      `${where}: the variable signature has something the host does not read, like a default ` +
        `value or a list type. Each variable is "$name: Scalar" with an optional "!".`,
    );
  }
  if (
    found.length !== variables.length ||
    new Set(found.map((match) => match[1])).size !== found.length
  ) {
    throw new SynthError(
      `${where}: the document declares ${found.length} variables and the operation lists ` +
        `${variables.length}. They have to match exactly.`,
    );
  }
  for (const match of found) {
    const [, name, scalar, bang] = match;
    const variable = variables.find((entry) => entry.name === name);
    if (
      variable === undefined ||
      GRAPHQL_SCALARS[scalar as string] !== variable.type ||
      (bang === "!") !== (variable.required ?? false)
    ) {
      throw new SynthError(
        `${where}: "$${name}: ${scalar}${bang ?? ""}" does not match a declared variable of the ` +
          `same name, scalar type and required flag.`,
      );
    }
  }
}
