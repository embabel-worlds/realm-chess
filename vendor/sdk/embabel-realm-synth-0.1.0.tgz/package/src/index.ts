import { existsSync } from "node:fs";
import { mkdir, readdir, readFile, rm, rmdir, writeFile } from "node:fs/promises";
import { dirname, isAbsolute, join, relative, resolve, sep } from "node:path";
import type { Realm } from "@embabel/realm-types";
import { stringify } from "yaml";
import { canonicalize, SynthError } from "./canonical.ts";
import { emitHandlerTypes, type VendoredApiDocuments } from "./dts.ts";
import { type EmittedFile, emit } from "./emit.ts";
import type { AppLimits, ExecutionProfile } from "./profile.ts";
import { emitPythonTypes } from "./pytypes.ts";
import { emitRustTypes } from "./rstypes.ts";
import { SKILL_DIGESTS_PATH } from "./skills.ts";
import { validateTemplates } from "./validate.ts";

export { canonicalize, SynthError } from "./canonical.ts";
export { checkCypher } from "./cypher.ts";
export type { VendoredApiDocuments } from "./dts.ts";
export { emitHandlerTypes } from "./dts.ts";
export type { EmitOptions, EmittedFile } from "./emit.ts";
export { emit } from "./emit.ts";
export type {
  AppLimits,
  ExecutionProfile,
  FeatureSupport,
  ProfileFeature,
  ProfileFeatureId,
} from "./profile.ts";
export {
  APP_LIMIT_FLAGS,
  BUILT_IN_PROFILES,
  checkProfile,
  DEFAULT_APP_LIMITS,
  PROFILE_FEATURES,
  parseByteSize,
  parseCount,
  parseProfile,
  resolveAppLimits,
  resolveProfile,
} from "./profile.ts";
export { emitPythonTypes } from "./pytypes.ts";
export { emitRustTypes } from "./rstypes.ts";
export type { ScaffoldRuntime } from "./scaffold.ts";
export { scaffoldFiles, scaffoldRealm } from "./scaffold.ts";
export { validateTemplates } from "./validate.ts";

/** Anything a synth run needs from its caller beyond the definition itself. */
export interface SynthOptions {
  /**
   * Where deprecation notices go. A deprecated field still emits — it is a warning,
   * not a refusal — so without a sink the author never hears that the realm is relying
   * on something due to be removed. `cli.ts` passes `console.error`; a test passes a
   * collector and asserts on what landed in it.
   */
  warn?: (message: string) => void;
  /**
   * The execution environment to hold the realm to. It can warn about or refuse features that
   * environment does not load, and carry its own app limits. Absent means no profile checks:
   * synth writes everything the realm declares and checks only the rules every host shares.
   */
  profile?: ExecutionProfile;
  /**
   * App size limits that win over the defaults and over the profile's own. `cli.ts` fills
   * these from `--app-limit` and the per-limit flags.
   */
  appLimits?: Partial<AppLimits>;
  /**
   * Where `--types` will write this run's generated TypeScript. A handler that imports it,
   * for the skill digests, gets this run's copy in the bundle even when the file on disk is
   * stale or not written yet.
   */
  typesOut?: string;
}

/** What a synth run produced. */
export interface SynthResult {
  files: EmittedFile[];
  /** Rendered YAML, keyed by path: what would be written, without writing it. */
  rendered: Record<string, string>;
  /** The TypeScript this realm's handlers import, from the same declaration. */
  handlerTypes: string;
  /** The evaluated realm definition, for callers that need to inspect it directly, such as picking a `--types` emitter by runtime. */
  realm: Realm;
  /**
   * A captured realm's vendored OpenAPI documents, parsed, keyed by the `apis` entry each
   * belongs to. This is what a write operation's argument and body types are built from, so a
   * caller emitting types itself can hand these straight to `emitHandlerTypes`. Empty for a
   * conventional realm, whose generated types read no document at all.
   */
  documents: VendoredApiDocuments;
}

/**
 * The vendored documents each synth run parsed, kept against the realm object that run
 * produced.
 *
 * `emitTypes` is handed a realm and an output path, and a realm on its own does not hold its
 * documents: they sit on disk beside the definition, and only the run that resolved that
 * definition knew where. So the run leaves them here, and a `--types` write of that same realm
 * types a captured realm's writes exactly as the run's own `handlerTypes` did, without every
 * caller in between having to carry them. A caller holding documents of its own passes them
 * explicitly, and those win.
 *
 * Weakly keyed, and keyed by the realm object rather than by its name: nothing outlives the
 * realm it belongs to, and two definitions that happen to share a name keep their own
 * documents.
 */
const RUN_DOCUMENTS = new WeakMap<Realm, VendoredApiDocuments>();

/** The skill digests each synth run computed, kept for a later `--types` write the same way. */
const RUN_SKILL_DIGESTS = new WeakMap<Realm, Record<string, string>>();

/** The digests `emit()` wrote to the bundle, if the realm ships skills. */
function skillDigests(files: EmittedFile[]): Record<string, string> | undefined {
  const file = files.find((f) => f.kind === "rendered" && f.path === SKILL_DIGESTS_PATH);
  if (file?.kind !== "rendered") return undefined;
  return (file.value as { digest: Record<string, string> }).digest;
}

/** The bytes `emit()` vendored at one output path, if it vendored anything there. */
function vendoredBytes(files: EmittedFile[], path: string): Buffer | undefined {
  for (const file of files) {
    if (file.kind === "vendored" && file.path === path) return file.bytes;
  }
  return undefined;
}

/**
 * A captured realm's vendored OpenAPI documents, parsed and keyed by the `apis` entry each
 * belongs to.
 *
 * The bytes come from the emitted files rather than from a second read of the disk, so the
 * document a write operation's types are built from is byte for byte the document that lands
 * in the output tree next to the manifest naming it.
 *
 * Two things are settled by the time this runs, both by `emit()`: a captured api's url is
 * always a plain filename vendored at `apis/<url>`, and the file there has already been read
 * and parsed as a JSON OpenAPI 3.x document, with the realm refused outright if it was not
 * one. So neither the lookup nor the parse is a place a bad document is first noticed.
 *
 * A conventional realm gets an empty record: nothing in its generated types reads a document.
 */
function capturedApiDocuments(realm: Realm, files: EmittedFile[]): VendoredApiDocuments {
  if (realm.execution !== "captured" || realm.apis === undefined) return {};
  return Object.fromEntries(
    Object.entries(realm.apis).flatMap(([key, spec]) => {
      const bytes = vendoredBytes(files, `apis/${spec.url}`);
      return bytes === undefined
        ? []
        : [[key, JSON.parse(bytes.toString("utf8")) as unknown] as const];
    }),
  );
}

/**
 * Evaluate a definition module and render its files.
 *
 * Importing the module runs the author's code, which is the point: config written as a
 * program can use loops, helpers and shared constants. That also means synth belongs on
 * the author's machine or in CI, never on a host loading someone else's realm: the same
 * position `cdk synth` occupies.
 *
 * Picking up an edit to the definition module or anything it imports means running this
 * in a fresh process: Bun's module cache is keyed by resolved path for the life of the
 * process, and there is no supported way to invalidate one module's whole import graph
 * from inside it. `cli.ts`'s watch mode gets that fresh process by spawning a disposable
 * subprocess for every rebuild, so it never calls this function twice in the same one.
 */
export async function synth(definitionPath: string, options?: SynthOptions): Promise<SynthResult> {
  const absolute = resolve(definitionPath);
  const module = await import(absolute);
  const definition = module.default;

  if (definition === undefined) {
    throw new SynthError(`${definitionPath}: no default export`);
  }
  if (typeof definition !== "object" || definition === null || Array.isArray(definition)) {
    throw new SynthError(`${definitionPath}: default export must be an object`);
  }

  const realm = definition as Realm;
  for (const field of ["name", "version"] as const) {
    if (typeof realm[field] !== "string" || realm[field] === "") {
      throw new SynthError(`${definitionPath}: missing required "${field}"`);
    }
  }
  // host is the one field that means something different when it is simply absent
  // ("infer placement from what's on disk") than any value could say — so it is only
  // checked when written at all, never required.
  if (realm.host !== undefined && realm.host !== "wasm" && realm.host !== "docker") {
    throw new SynthError(`${definitionPath}: "host" must be "wasm" or "docker" when set`);
  }

  validateTemplates(realm);

  // Canonicalizing the whole definition first means an unrepresentable value is reported
  // with its path before any file is produced from a partially-valid tree.
  canonicalize(realm, "$");

  const typesModule =
    options?.typesOut?.endsWith(".ts") &&
    !options.typesOut.endsWith(".d.ts") &&
    (realm.runtime ?? "typescript") === "typescript"
      ? resolve(options.typesOut)
      : undefined;
  const files = emit(realm, dirname(absolute), {
    warn: options?.warn,
    profile: options?.profile,
    appLimits: options?.appLimits,
    generatedModule: typesModule,
  });
  const rendered: Record<string, string> = {};
  for (const file of files) {
    if (file.kind !== "rendered") continue;
    if (file.path.endsWith(".json")) {
      rendered[file.path] = `${JSON.stringify(file.value, null, 2)}\n`;
    } else {
      rendered[file.path] = stringify(file.value, { lineWidth: 0 });
    }
  }
  // The documents are what the types emitter builds a captured write's argument and body
  // types from, so they are handed over here rather than left to a caller that has no way to
  // find them. Remembering them against this realm is what lets a later `--types` write of it
  // produce these same bytes.
  const documents = capturedApiDocuments(realm, files);
  RUN_DOCUMENTS.set(realm, documents);
  const digests = skillDigests(files);
  if (digests !== undefined) RUN_SKILL_DIGESTS.set(realm, digests);
  const handlerTypes = emitHandlerTypes(realm, documents, digests);
  // emit() left the generated module empty when a handler imports it; it gets the same text
  // `--types` writes, so the constant the handler compiles in is the one this run computed.
  if (typesModule !== undefined) {
    const path = relative(dirname(absolute), typesModule).split(sep).join("/");
    const placeholder = files.findIndex((f) => f.kind === "vendored" && f.path === path);
    if (placeholder >= 0) {
      files[placeholder] = { kind: "vendored", path, bytes: Buffer.from(handlerTypes, "utf8") };
    }
  }
  return { files, rendered, handlerTypes, realm, documents };
}

/**
 * Picks the `--types` emitter by the realm's declared runtime, and checks the output
 * path's extension against it.
 *
 * A `runtime: "typescript"` realm (the default) gets the existing `.d.ts` emitter and
 * needs a path ending ".d.ts" or ".ts". A `runtime: "python"` realm gets the Python
 * emitter and needs a path ending ".py" or ".pyi": a `.d.ts` typing a Python realm
 * types a handler that will never exist. A `runtime: "compiled"` realm covers Rust, C,
 * and Go alike, so the runtime name alone cannot pick a types emitter; the `--types`
 * path extension picks the language instead. Today that's Rust, selected by a path
 * ending ".rs"; C headers and Go structs are future emitters. Any other declared
 * runtime has no types emitter yet.
 *
 * `documents` are a captured realm's vendored OpenAPI documents, the source of a write
 * operation's argument types. A caller that ran `synth()` already has them on its result and
 * may pass them; one that did not gets the documents that run parsed for this same realm, so
 * the `.d.ts` a `--types` write puts on disk is the `.d.ts` that run's `handlerTypes` held. A
 * realm assembled some other way has no documents to find, and its captured writes stay the
 * untyped escape hatch with a generated comment saying so.
 */
export function emitTypes(realm: Realm, path: string, documents?: VendoredApiDocuments): string {
  const runtime = realm.runtime ?? "typescript";

  if (runtime === "typescript") {
    if (!path.endsWith(".d.ts") && !path.endsWith(".ts")) {
      throw new SynthError(
        `--types ${path}: runtime "typescript" needs a path ending ".d.ts" or ".ts"`,
      );
    }
    // A .d.ts holds no values, and the skill digests are a value the handler reads at runtime.
    if (path.endsWith(".d.ts") && realm.execution === "captured" && realm.skills?.length) {
      throw new SynthError(
        `--types ${path}: this realm ships skills, so its types carry skills.digest as a value a ` +
          `handler imports. Write them to a .ts file instead.`,
      );
    }
    return emitHandlerTypes(
      realm,
      documents ?? RUN_DOCUMENTS.get(realm),
      RUN_SKILL_DIGESTS.get(realm),
    );
  }

  if (runtime === "python") {
    if (!path.endsWith(".py") && !path.endsWith(".pyi")) {
      throw new SynthError(`--types ${path}: runtime "python" needs a path ending ".py" or ".pyi"`);
    }
    return emitPythonTypes(realm);
  }

  if (runtime === "compiled") {
    if (!path.endsWith(".rs")) {
      throw new SynthError(
        `--types ${path}: runtime "compiled" needs a path ending ".rs". C headers and Go are future emitters.`,
      );
    }
    return emitRustTypes(realm);
  }

  throw new SynthError(`--types: no types emitter exists yet for runtime "${runtime}"`);
}

/**
 * The file synth leaves in an output directory listing what it wrote there. The next write
 * reads it to know which files are its own to replace.
 */
export const OUTPUT_RECORD = ".realm-synth-output.json";

/** Every file under `root`, as sorted posix paths relative to it. Symlinks count as files. */
async function filesUnder(root: string, prefix = ""): Promise<string[]> {
  const out: string[] = [];
  for (const entry of await readdir(join(root, prefix), { withFileTypes: true })) {
    const path = `${prefix}${entry.name}`;
    if (entry.isDirectory()) out.push(...(await filesUnder(root, `${path}/`)));
    else out.push(path);
  }
  return out.sort();
}

/** A `--types` file to write: where it goes, and the text it holds. */
export interface TypesFile {
  path: string;
  content: string;
}

/**
 * `path` as a posix path relative to `root` when it falls inside it, or undefined when it is
 * somewhere else. The root itself does not count, since it is a directory.
 */
export function pathInside(root: string, path: string): string | undefined {
  const rel = relative(resolve(root), resolve(path));
  if (rel === "" || rel === ".." || rel.startsWith(`..${sep}`) || isAbsolute(rel)) return undefined;
  return rel.split(sep).join("/");
}

/** The files the last write recorded, or undefined when there is no readable record. */
async function recordedFiles(root: string): Promise<Set<string> | undefined> {
  try {
    const record = JSON.parse(await readFile(join(root, OUTPUT_RECORD), "utf8")) as unknown;
    const files = (record as { files?: unknown }).files;
    if (!Array.isArray(files) || !files.every((f) => typeof f === "string")) return undefined;
    return new Set(files as string[]);
  } catch {
    return undefined;
  }
}

/** Removes each now-empty folder that held one of `paths`, deepest first, never `root` itself. */
async function removeEmptyFolders(root: string, paths: Iterable<string>): Promise<void> {
  const folders = new Set<string>();
  for (const path of paths) {
    const parts = path.split("/");
    for (let i = 1; i < parts.length; i++) folders.add(parts.slice(0, i).join("/"));
  }
  for (const folder of [...folders].sort((a, b) => b.length - a.length)) {
    const abs = join(root, folder);
    if (existsSync(abs) && (await readdir(abs)).length === 0) await rmdir(abs);
  }
}

/**
 * Write a synth result into a directory, replacing what synth wrote there before.
 *
 * Synth only takes over a directory that is missing, empty, or holds nothing but its own
 * previous output, as listed in {@link OUTPUT_RECORD}. Anything else, such as a realm root
 * given as `--out .`, is refused naming a file synth did not write, and nothing is touched.
 * Within its own output, every file it wrote last time goes before the new ones are
 * written, so a producer deleted from the definition disappears from disk too. A generated
 * tree that keeps orphans is worse than none: the realm would load rules nothing declares.
 *
 * A rendered file is written from `result.rendered`, the YAML or JSON text already
 * built for it. A vendored file is written from its own raw bytes instead, copied
 * straight from the source document synth read at the path `apis/apis.yml`'s url
 * resolves to. That is what makes a written `--out` tree self-contained: every url an
 * emitted apis.yml names resolves to a real file sitting right next to it, byte for
 * byte the same as the vendored source.
 *
 * `types` is the `--types` file, when one is wanted. If its path falls inside `outDir` it is
 * part of this output: checked against the directory along with everything else before any
 * file is written, and listed in the record so the next run knows it as its own. A path
 * outside `outDir` is left for the caller to write.
 */
export async function writeSynth(
  result: SynthResult,
  outDir: string,
  types?: TypesFile,
): Promise<string[]> {
  const root = resolve(outDir);
  const typesPath = types === undefined ? undefined : pathInside(root, types.path);
  if (types !== undefined && typesPath !== undefined) {
    const clash =
      typesPath === OUTPUT_RECORD
        ? OUTPUT_RECORD
        : result.files.find(
            (file) =>
              file.path === typesPath ||
              file.path.startsWith(`${typesPath}/`) ||
              typesPath.startsWith(`${file.path}/`),
          )?.path;
    if (clash !== undefined) {
      throw new SynthError(
        `--types ${types.path}: that path is "${clash}" inside --out, which synth writes ` +
          `itself. Give --types a path that synth does not already use.`,
      );
    }
  }
  if (existsSync(root)) {
    const present = (await filesUnder(root)).filter((path) => path !== OUTPUT_RECORD);
    const recorded = (await recordedFiles(root)) ?? new Set<string>();
    const foreign = present.find((path) => !recorded.has(path));
    if (foreign !== undefined) {
      throw new SynthError(
        `--out: synth did not write "${root}": it holds "${foreign}", which is not output from an ` +
          `earlier run. Synth only replaces a directory that is empty or that it wrote itself, so ` +
          `nothing was changed. Give --out an empty or new directory.`,
      );
    }
    for (const path of present) await rm(join(root, path), { force: true });
    await rm(join(root, OUTPUT_RECORD), { force: true });
    await removeEmptyFolders(root, present);
  }
  const written: string[] = [];
  for (const file of result.files) {
    const target = join(root, file.path);
    await mkdir(dirname(target), { recursive: true });
    if (file.kind === "rendered") {
      await writeFile(target, result.rendered[file.path], "utf8");
    } else {
      await writeFile(target, file.bytes);
    }
    written.push(file.path);
  }
  if (types !== undefined && typesPath !== undefined) {
    const target = join(root, typesPath);
    await mkdir(dirname(target), { recursive: true });
    await writeFile(target, types.content, "utf8");
    written.push(typesPath);
  }
  written.sort();
  await mkdir(root, { recursive: true });
  await writeFile(
    join(root, OUTPUT_RECORD),
    `${JSON.stringify({ files: written }, null, 2)}\n`,
    "utf8",
  );
  return written;
}
