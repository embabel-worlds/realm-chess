import type { JsonObject, JsonValue, Realm } from "@embabel/realm-types";
import { SynthError } from "./canonical.ts";

/**
 * Keywords whose value is a map from names to schemas. A key inside one of these is a name the
 * author chose, not a JSON Schema keyword, so a property that happens to be called "properties"
 * keeps its (possibly empty) schema.
 */
const NAMED_SCHEMA_MAPS = new Set([
  "properties",
  "patternProperties",
  "$defs",
  "definitions",
  "dependentSchemas",
]);

/** True for an object literal: something a definition wrote out by hand, not a class instance. */
function isPlainObject(value: unknown): value is Record<string, unknown> {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}

function isEmptyObject(value: unknown): boolean {
  return isPlainObject(value) && Object.keys(value).length === 0;
}

/**
 * Copies a schema an exporter produced, dropping the empty `properties: {}` a library writes
 * for an object with no fields. A hand-written schema would just say `{ type: "object" }`, and
 * the two have to come out the same so the manifest does not depend on how a schema was written.
 */
function tidy(value: unknown, namesHere = false): unknown {
  if (Array.isArray(value)) return value.map((item) => tidy(item));
  if (typeof value !== "object" || value === null) return value;
  const out: Record<string, unknown> = {};
  for (const [key, child] of Object.entries(value)) {
    if (namesHere) {
      // Each entry here is a named schema, so it is tidied as a schema and never dropped.
      out[key] = tidy(child);
      continue;
    }
    if (key === "properties" && isEmptyObject(child)) continue;
    out[key] = tidy(child, NAMED_SCHEMA_MAPS.has(key) && isPlainObject(child));
  }
  return out;
}

function describe(value: unknown): string {
  if (value === null) return "null";
  if (Array.isArray(value)) return "an array";
  if (typeof value === "object") return `a ${value.constructor?.name ?? "non-plain"} object`;
  return `a ${typeof value}`;
}

/** Runs whichever JSON Schema exporter the schema value offers, or reports that it has none. */
function exportJsonSchema(value: object, where: string): unknown {
  const schema = value as Record<string, unknown>;
  const standard = schema["~standard"] as { jsonSchema?: { input?: unknown } } | undefined;
  const input = standard?.jsonSchema?.input;
  try {
    // The input view on purpose, for output schemas too: the output view closes every object
    // with additionalProperties: false, which would change what the manifest promises.
    if (typeof input === "function") {
      return input.call(standard?.jsonSchema, { target: "draft-2020-12" });
    }
    if (typeof schema.toJSONSchema === "function") return schema.toJSONSchema();
    if (typeof schema.toJsonSchema === "function") return schema.toJsonSchema();
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);
    throw new SynthError(`${where}: the schema could not be converted to JSON Schema: ${reason}`);
  }
  throw new SynthError(
    `${where}: the schema value has no JSON Schema exporter. Use a library that implements ` +
      `Standard JSON Schema, or write the JSON Schema by hand.`,
  );
}

/**
 * Turns a handler's `input` or `output` into the JSON Schema the manifest carries.
 *
 * A hand-written JSON Schema object comes back untouched, and an absent one stays absent. A
 * schema value from Zod, ArkType or any other Standard Schema library is converted with its own
 * exporter, minus the `$schema` marker and any empty `properties` map. Realm tests can call this
 * to see exactly the schema synth will publish.
 *
 * @param value the handler's `input` or `output` as the definition wrote it
 * @param where the path to name in an error, e.g. `$.handlers.analysePosition.input`
 * @returns the JSON Schema, or undefined when the value was undefined
 * @throws SynthError when the value is not a schema, or its exporter fails
 */
export function handlerJsonSchema(value: unknown, where: string): JsonObject | undefined {
  if (value === undefined) return undefined;
  const isSchemaShaped =
    (typeof value === "object" && value !== null) || typeof value === "function";
  if (!isSchemaShaped) {
    throw new SynthError(
      `${where}: expected a JSON Schema object or a schema value, got ${describe(value)}`,
    );
  }
  if (isPlainObject(value) && !("~standard" in value)) return value as JsonObject;

  const exported = exportJsonSchema(value, where);
  if (!isPlainObject(exported)) {
    throw new SynthError(
      `${where}: the schema's exporter returned ${describe(exported)}, not a JSON Schema object`,
    );
  }
  const { $schema: _marker, ...rest } = exported;
  return tidy(rest) as { [k: string]: JsonValue };
}

/**
 * Replaces every schema value in the realm's handlers with its JSON Schema, in place, so every
 * emitter after this point only ever sees plain JSON.
 *
 * @param realm the definition synth just imported
 * @param path the definition file, named at the head of any error
 */
export function convertHandlerSchemas(realm: Realm, path: string): void {
  const handlers = realm.handlers;
  if (typeof handlers !== "object" || handlers === null) return;
  for (const [name, spec] of Object.entries(handlers)) {
    if (typeof spec !== "object" || spec === null) continue;
    for (const side of ["input", "output"] as const) {
      if (!(side in spec)) continue;
      spec[side] = handlerJsonSchema(spec[side], `${path}: $.handlers.${name}.${side}`);
    }
  }
}
