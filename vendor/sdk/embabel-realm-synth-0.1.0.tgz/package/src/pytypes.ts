import type {
  DependencyValueType,
  HandlerSpec,
  PropertySpec,
  Realm,
  TypeSpec,
} from "@embabel/realm-types";
import { SynthError } from "./canonical.ts";
import {
  bridgeModule,
  checkGatewayOperation,
  disambiguatedNames,
  gatewayOperations,
  HOST_CONTEXT,
  isMultiValued,
  type PropertyDoc,
  pascalCase,
  propertyDoc,
  stringEnumValues,
  syntheticNameSegment,
} from "./dts.ts";

/** The Protocol the dependency container gets, so `ctx.deps.db` has a type to check against. */
const DEPENDENCY_PROTOCOL = "Dependencies";

/**
 * Every name the generated module can import from `typing`.
 *
 * This is the one list. `Emission.used` only holds names from it, so an import the
 * emitter starts writing has to be added here first, and the symbol table reserves the
 * whole list, so a realm can never define a name one of these imports would shadow.
 * `Literal` is the case that made this a list: the enum narrowing started importing it,
 * a realm with a domain type called Literal shadowed the import, and the narrowed types
 * quietly resolved to the domain type.
 */
const TYPING_IMPORTS = [
  "Callable",
  "Literal",
  "NotRequired",
  "Protocol",
  "Sequence",
  "TypedDict",
] as const;

/** One name from the `typing` import list. */
type TypingImport = (typeof TYPING_IMPORTS)[number];

/**
 * The names the generated module always defines itself, whatever the realm declares.
 *
 * `Dependencies` is only written when the realm declares a dependency, but it is held
 * back either way: a realm that is valid today should stay valid the day it adds its
 * first dependency, rather than suddenly colliding with a class it never saw.
 */
const MODULE_NAMES = ["Dependencies", "Gateway", "HandlerContext", "Handlers"] as const;

/** A known dependency module's typed bridge surface, in Python. */
interface PyBridgeSpec {
  /** The exported Protocol name the bridge gets. */
  typeName: string;
  /** Doc comment placed on the exported bridge Protocol. */
  doc: string;
  /** Names this bridge's member signatures need from `typing`. */
  typingNames: TypingImport[];
  /** Member lines emitted inside the bridge Protocol, already indented one level (4 spaces). */
  members: string[];
}

/**
 * The bridge surface for every dependency module the Python emitter knows how to type
 * today. A module absent from this map still gets a context member, typed `object`: the
 * real surface is defined by the module's registry entry and arrives with the host
 * mechanism, so synth cannot type it in advance. The Python guest runtime does not exist
 * yet. Every member here describes the synchronous command-mode shape the shim will
 * expose.
 */
const BRIDGES: Record<string, PyBridgeSpec> = {
  "sqlite3-wasi": {
    typeName: "SqliteBridge",
    doc: "The bridge to a mounted SQLite dependency. State is ephemeral unless the declaration set persistent. The realm owns its database entirely.",
    typingNames: ["Sequence"],
    members: [
      "    def exec(",
      "        self, sql: str, params: Sequence[str | int | float | None] = ...",
      "    ) -> list[dict[str, str | int | float | None]]: ...",
    ],
  },
};

/**
 * The Python spelling of one dependency method's argument or return type. `i64` reads
 * as `str`: the value can overflow what a `float` holds exactly (both are IEEE doubles
 * beyond 2^53), so the wire carries it as a decimal-digit string instead. `string` is
 * text and reads as `str` too. `i32`, `f32` and `f64` all fit a Python number safely. {@link DependencyValueType} is the
 * exhaustive list, so this switch needs no default.
 */
function pyValueType(type: DependencyValueType): string {
  switch (type) {
    case "i32":
      return "int";
    case "i64":
    case "string":
      return "str";
    case "f32":
    case "f64":
      return "float";
  }
}

/**
 * Every string below comes from the realm definition, and a definition can put
 * anything in a description, a module id or a realm name. These two functions are
 * where that text gets made safe before it lands in generated Python, so nobody has to
 * remember to escape it at each call site.
 */

/**
 * The escape text Python reads back as the character at `code`: a two-digit `\xNN` for
 * a control character, and a four-digit `\uNNNN` for a lone surrogate, which is a
 * character UTF-8 has no encoding for.
 */
function pyCharEscape(code: number): string {
  if (code >= 0xd800 && code <= 0xdfff) return `\\u${code.toString(16).padStart(4, "0")}`;
  return `\\x${code.toString(16).padStart(2, "0")}`;
}

/** True for a character Python source cannot carry as itself: a control character other than a line feed or a tab, a delete, or a lone surrogate. */
function needsPyEscape(code: number): boolean {
  if (code === 0x0a || code === 0x09) return false;
  return code < 0x20 || code === 0x7f || (code >= 0xd800 && code <= 0xdfff);
}

/**
 * Definition text, made safe for a comment or a docstring.
 *
 * Line feeds and tabs are left as they are: the caller has already put the text where
 * those are harmless. Everything else Python source cannot carry, a NUL first among
 * them, becomes its printable escape text. A module holding a raw NUL does not compile
 * at all, and the error it raises names the file. It says nothing about the description
 * that carried the NUL in.
 */
function escapeUnprintable(text: string): string {
  let out = "";
  for (const char of text) {
    const code = char.codePointAt(0) as number;
    out += needsPyEscape(code) ? pyCharEscape(code) : char;
  }
  return out;
}

/** Folds CRLF and CR line endings to LF, escapes every backslash and double quote, then escapes whatever Python source cannot carry, so definition text can never close a triple-quoted docstring early, smuggle an escape sequence into one, or stop the module from compiling. */
function escapeDocText(text: string): string {
  return escapeUnprintable(
    text.replace(/\r\n?/g, "\n").replace(/\\/g, "\\\\").replace(/"/g, '\\"'),
  );
}

/** Collapses newlines, so definition text can never break out of a single-line comment, then escapes whatever Python source cannot carry. */
function escapeLineComment(text: string): string {
  return escapeUnprintable(text.replace(/[\r\n]+/g, " "));
}

/** A triple-quoted docstring for `text`, as lines indented by `indent`. */
function pyDoc(text: string, indent = ""): string[] {
  const body = escapeDocText(text.trim()).split("\n");
  if (body.length === 1) return [`${indent}"""${body[0]}"""`];
  return [`${indent}"""${body[0]}`, ...body.slice(1).map((l) => `${indent}${l}`), `${indent}"""`];
}

/**
 * A Python double-quoted string literal for `value`, whatever `value` carries.
 *
 * One encoder writes every string this module puts in Python source: a `Literal[...]`
 * argument and a `TypedDict` key both come through here. Backslashes and double quotes
 * are escaped, a line feed becomes the two-character escape `\n` and a carriage return
 * becomes `\r`, so an embedded line ending can never end the statement early, and the
 * rest of the control characters become `\xNN`. A lone surrogate becomes `\uNNNN`,
 * because UTF-8 has no encoding for one. Printable Unicode is left alone: a key or an
 * enum value in any language stays readable.
 */
function pyStringLiteral(value: string): string {
  let out = "";
  for (const char of value) {
    if (char === "\\") {
      out += "\\\\";
      continue;
    }
    if (char === '"') {
      out += '\\"';
      continue;
    }
    if (char === "\n") {
      out += "\\n";
      continue;
    }
    if (char === "\r") {
      out += "\\r";
      continue;
    }
    if (char === "\t") {
      out += "\\t";
      continue;
    }
    const code = char.codePointAt(0) as number;
    out +=
      code < 0x20 || code === 0x7f || (code >= 0xd800 && code <= 0xdfff)
        ? pyCharEscape(code)
        : char;
  }
  return `"${out}"`;
}

/**
 * `doc`'s lines, in the fixed order every emitter carries them: the description
 * first, collapsed to one line if it spanned several, then "Deprecated." when the
 * property says so, then the facet lines. Each line here becomes its own `#` comment,
 * and gets its own pass through `escapeLineComment` right before it is written, so a
 * value can never carry a raw newline that would end the comment and start a fresh,
 * unprefixed line of Python.
 */
function pyDocLines(doc: PropertyDoc): string[] {
  const lines: string[] = [];
  if (doc.description) lines.push(doc.description.trim());
  if (doc.deprecated) lines.push("Deprecated.");
  lines.push(...doc.facetLines);
  return lines;
}

/**
 * A realm declares names in JSON and TypeScript terms, and this emitter writes them
 * into Python source. The two vocabularies do not line up: `$db` is a fine TypeScript
 * name and a syntax error in Python, `class` is a fine JSON key and a Python keyword,
 * and a name carrying a newline can close the line it sits on and start a statement of
 * its own. Everything below is the gate that keeps such a name out of the generated
 * module, applied here at the emitter boundary so a caller reaching for
 * `emitPythonTypes` directly gets the same refusals a full synth run gets.
 */

/** The shape a bare Python identifier has. */
const PY_IDENTIFIER = /^[A-Za-z_][A-Za-z0-9_]*$/;

/** Python's reserved words as of 3.11. Any of them in a name position stops the module from parsing. */
const KEYWORDS = new Set([
  "False",
  "None",
  "True",
  "and",
  "as",
  "assert",
  "async",
  "await",
  "break",
  "class",
  "continue",
  "def",
  "del",
  "elif",
  "else",
  "except",
  "finally",
  "for",
  "from",
  "global",
  "if",
  "import",
  "in",
  "is",
  "lambda",
  "nonlocal",
  "not",
  "or",
  "pass",
  "raise",
  "return",
  "try",
  "while",
  "with",
  "yield",
]);

/**
 * Words Python reads as keywords only in certain positions. A class or a function
 * carrying one parses today and is a trap for the next reader and for a later Python
 * that hardens them, so the emitter refuses them there. As a dict key or an attribute
 * they are ordinary names and pass.
 */
const SOFT_KEYWORDS = new Set(["match", "case", "type"]);

/** Where a name is about to land in the generated module. The rules differ by position. */
type NameRole = "class" | "def" | "attribute";

/**
 * Passes `name` through when Python can carry it in the given position, and throws a
 * `SynthError` naming the path and the offending name when it cannot.
 */
function checkPyName(name: string, role: NameRole, where: string): string {
  if (!PY_IDENTIFIER.test(name)) {
    throw new SynthError(
      `${where}: "${escapeLineComment(name)}" is not a valid Python identifier. A generated name carries letters, digits and underscores, and it opens with a letter or an underscore.`,
    );
  }
  if (KEYWORDS.has(name)) {
    throw new SynthError(
      `${where}: "${name}" is a Python keyword, so the generated module cannot use it as a name.`,
    );
  }
  if (role !== "attribute" && SOFT_KEYWORDS.has(name)) {
    const position = role === "class" ? "class" : "function";
    throw new SynthError(
      `${where}: "${name}" is a Python soft keyword, so the generated module cannot use it to name a ${position}.`,
    );
  }
  if (role === "class" && name === "_") {
    throw new SynthError(`${where}: "_" cannot name a generated class.`);
  }
  return name;
}

/**
 * Every name the generated module defines at the top level, and what put it there.
 *
 * Python has no duplicate-definition error: the second `class Foo` silently replaces
 * the first, and a handler typed against the name checks against whichever shape landed
 * last. The realm has several places that mint a top-level name (domain types, gateway
 * protocols, per-handler input and output types, nested types synthesized from a
 * schema), and nothing stops two of them from picking the same one. This is the table
 * that catches it while there is still a build to fail, and the error says which two
 * sources met.
 */
class SymbolTable {
  private readonly sources = new Map<string, string>();

  /** Claims a name the generated module owns in every run. */
  reserve(name: string): void {
    this.sources.set(name, "a name the generated module reserves");
  }

  /** Claims a name for `describe`, throwing when something else already holds it. */
  declare(name: string, where: string, describe: string): void {
    const existing = this.sources.get(name);
    if (existing !== undefined) {
      throw new SynthError(`${where}: the generated name "${name}" collides with ${existing}.`);
    }
    this.sources.set(name, describe);
  }
}

/**
 * The names the module holds back from the realm: every name it can import from
 * `typing`, the protocols it always writes, and every bridge protocol it knows how to
 * write. The list is fixed and it is derived from the import list itself, so a realm
 * that is valid today stays valid when a later realm adds the dependency that pulls one
 * of these imports in, and a new import cannot be left out of it.
 */
function reservedNames(): string[] {
  const names = new Set<string>([...TYPING_IMPORTS, ...MODULE_NAMES]);
  for (const bridge of Object.values(BRIDGES)) names.add(bridge.typeName);
  return [...names].sort();
}

/** What one emitter run accumulates: the `typing` imports its output needs, and the names it has defined so far. */
interface Emission {
  used: Set<TypingImport>;
  symbols: SymbolTable;
}

/** One field of a generated `TypedDict`. */
interface PyField {
  /** The key as the realm declares it, which is not always a Python identifier. */
  key: string;
  /** The Python type the field carries. */
  annotation: string;
  /**
   * This field's doc lines, in the fixed facet order. Rendered as one `#` comment per
   * line, above the field, the same way in both `TypedDict` syntaxes.
   */
  docLines: string[];
}

/**
 * Generates the Python a realm's handlers import, for a realm declared `runtime:
 * "python"`.
 *
 * This is the Python counterpart to `emitHandlerTypes`: the same declaration, walked
 * the same way, landing as a `TypedDict` and `Protocol` surface a Python handler
 * checks against. A hand-written surface can drift from the realm. This one cannot:
 * it comes from the same declaration.
 */
export function emitPythonTypes(realm: Realm): string {
  const em: Emission = { used: new Set<TypingImport>(), symbols: new SymbolTable() };
  for (const name of reservedNames()) em.symbols.reserve(name);
  const blocks: string[] = [];

  const typeNames = Object.keys(realm.types ?? {}).sort();
  for (const name of typeNames) {
    const where = `$.types.${name}`;
    checkPyName(name, "class", where);
    em.symbols.declare(name, where, `the domain type "${name}"`);
    const spec = (realm.types as Record<string, TypeSpec>)[name] as TypeSpec;
    blocks.push(emitDomainTypedDict(name, spec, em).join("\n"));
  }

  const dependencyEntries = Object.entries(realm.dependencies ?? {}).sort(([a], [b]) =>
    a < b ? -1 : a > b ? 1 : 0,
  );
  for (const [key] of dependencyEntries) {
    const where = `$.dependencies.${key}`;
    checkPyName(key, "attribute", where);
    // Now that dependencies live in their own container, a dependency called "log" or
    // "gateway" cannot actually reach the context member of that name, so this refusal
    // no longer protects anything. It stays because emit.ts refuses the same two names
    // for every realm and the two should agree; retiring both together is a separate
    // change. It is the list-of-reserved-words mechanism the container replaced, and it
    // should not outlive that coordination.
    if (key === "log" || key === "gateway") {
      throw new SynthError(`${where}: "${key}" collides with a built-in context member.`);
    }
  }

  const usedBridgeIds = new Set<string>();
  for (const [, spec] of dependencyEntries) {
    if (BRIDGES[bridgeModule(spec)]) usedBridgeIds.add(bridgeModule(spec));
  }
  for (const moduleId of [...usedBridgeIds].sort()) {
    const bridge = BRIDGES[moduleId] as PyBridgeSpec;
    em.used.add("Protocol");
    for (const t of bridge.typingNames) em.used.add(t);
    blocks.push(
      [
        `class ${bridge.typeName}(Protocol):`,
        ...pyDoc(bridge.doc, "    "),
        "",
        ...bridge.members,
      ].join("\n"),
    );
  }

  // A dependency outside the built-in BRIDGES map still gets a real, typed bridge when
  // the realm declares the methods it calls on it: the operator's allowlist owns the
  // module's actual surface, not this package, so the only surface synth can type in
  // advance is exactly what the realm says it uses. One Protocol per dependency key,
  // not per module, because two declarations of the same module can each call a
  // different subset of it.
  for (const [key, spec] of dependencyEntries) {
    if (BRIDGES[bridgeModule(spec)] || !spec.methods || Object.keys(spec.methods).length === 0)
      continue;
    const where = `$.dependencies.${key}.methods`;
    const typeName = checkPyName(`${pascalCase(key)}Bridge`, "class", where);
    em.symbols.declare(typeName, where, `the bridge generated for the "${key}" dependency`);
    em.used.add("Protocol");
    const lines = [
      `class ${typeName}(Protocol):`,
      ...pyDoc(
        `The bridge to the "${spec.module}" dependency, typed from exactly the methods this realm declares it calls.`,
        "    ",
      ),
    ];
    for (const methodName of Object.keys(spec.methods).sort()) {
      const methodWhere = `${where}.${methodName}`;
      checkPyName(methodName, "def", methodWhere);
      const method = spec.methods[methodName];
      const args = (method?.args ?? [])
        .map((argType, i) => `, arg${i}: ${pyValueType(argType)}`)
        .join("");
      lines.push(
        "",
        `    def ${methodName}(self${args}) -> ${pyValueType(method?.returns as DependencyValueType)}: ...`,
      );
    }
    blocks.push(lines.join("\n"));
  }

  em.used.add("Protocol");
  const operations = gatewayOperations(realm);
  const namespaces = new Map<string, Set<string>>();
  const bare = new Set<string>();
  for (const op of operations) {
    const where = `gateway operation ${JSON.stringify(op)}`;
    checkGatewayOperation(op, where);
    if (op.includes(".")) {
      const [ns, opName] = op.split(".", 2) as [string, string];
      checkPyName(ns, "attribute", where);
      checkPyName(opName, "def", where);
      if (!namespaces.has(ns)) namespaces.set(ns, new Set());
      (namespaces.get(ns) as Set<string>).add(opName);
    } else {
      checkPyName(op, "def", where);
      bare.add(op);
    }
  }

  if (operations.length > 0) {
    // Two namespaces differing only in case ("foo" and "Foo") both pascalCase to "Foo",
    // and the host installs and dispatches them separately — so this has to name them
    // apart rather than pick whichever happened to build second and let that one fail.
    // `disambiguatedNames` decides every namespace's base at once, sorted, the same rule
    // the TypeScript emitter applies to its gateway interfaces, so a realm's Python and
    // TypeScript surfaces land on identical names for the same namespaces.
    const gatewayBases = disambiguatedNames([...namespaces.keys()], pascalCase);
    for (const ns of [...namespaces.keys()].sort()) {
      const where = `gateway namespace "${ns}"`;
      const className = checkPyName(`${gatewayBases.get(ns)}Gateway`, "class", where);
      em.symbols.declare(className, where, `the gateway protocol generated for "${ns}"`);
      const ops = namespaces.get(ns) as Set<string>;
      const nsLines = [`class ${className}(Protocol):`];
      for (const op of [...ops].sort()) {
        nsLines.push(`    def ${op}(self, args: dict[str, object] | None = None) -> object: ...`);
      }
      blocks.push(nsLines.join("\n"));
    }

    const gatewayLines = [
      "class Gateway(Protocol):",
      "    def __getattr__(self, name: str) -> object: ...",
    ];
    for (const op of [...bare].sort()) {
      gatewayLines.push(
        `    def ${op}(self, args: dict[str, object] | None = None) -> object: ...`,
      );
    }
    for (const ns of [...namespaces.keys()].sort()) {
      gatewayLines.push(`    ${ns}: ${gatewayBases.get(ns)}Gateway`);
    }
    blocks.push(gatewayLines.join("\n"));
  }

  // Dependencies get their own Protocol and hang off the context as one member, rather
  // than landing as attributes on the context itself. The author picks those names and
  // the host picks every other name here, so keeping them apart is what stops a
  // built-in added next year from stealing a name some realm already uses. HOST_CONTEXT
  // has the longer version. A realm with no dependencies writes no container and no
  // Protocol, so its module is unchanged.
  if (dependencyEntries.length > 0) {
    const depLines = [
      `class ${DEPENDENCY_PROTOCOL}(Protocol):`,
      ...pyDoc(
        "The dependencies this realm declared, each under the name it was declared with.",
        "    ",
      ),
    ];
    for (const [key, spec] of dependencyEntries) {
      const bridge = BRIDGES[bridgeModule(spec)];
      depLines.push("");
      if (bridge) {
        depLines.push(`    ${key}: ${bridge.typeName}`);
      } else if (spec.methods && Object.keys(spec.methods).length > 0) {
        depLines.push(`    ${key}: ${pascalCase(key)}Bridge`);
      } else {
        depLines.push(
          `    ${key}: object`,
          ...pyDoc(
            `The bridge surface for "${spec.module}" is defined by the module's registry entry and arrives with the host mechanism.`,
            "    ",
          ),
        );
      }
    }
    blocks.push(depLines.join("\n"));
  }

  const ctxLines = [
    "class HandlerContext(Protocol):",
    ...pyDoc("What the host passes a handler as its second argument.", "    "),
    "",
    "    def log(self, message: str) -> None:",
    ...pyDoc("Writes a line to the host log, attributed to this realm.", "        "),
    "        ...",
  ];
  if (operations.length > 0) {
    ctxLines.push(
      "",
      "    gateway: Gateway",
      ...pyDoc(
        "Calls out through the host. Credentials stay host-side: the guest never sees an API key, and the host injects it on the way out.",
        "    ",
      ),
    );
  }
  if (dependencyEntries.length > 0) {
    ctxLines.push(
      "",
      `    ${HOST_CONTEXT.dependencyContainer}: ${DEPENDENCY_PROTOCOL}`,
      ...pyDoc(
        "The dependencies this realm declared. They live in their own container so an author's chosen name can never collide with a context member the host adds later.",
        "    ",
      ),
    );
  }
  blocks.push(ctxLines.join("\n"));

  const handlers = realm.handlers ?? {};
  const handlerNames = Object.keys(handlers).sort();
  if (handlerNames.length > 0) {
    // Every per-handler name is claimed before any handler is emitted, so a collision
    // between two handlers is reported the same way whichever one is walked first.
    for (const name of handlerNames) {
      const where = `$.handlers.${name}`;
      checkPyName(name, "def", where);
      const stem = pascalCase(name);
      for (const [suffix, describe] of [
        ["Input", "the input type"],
        ["Output", "the output type"],
        ["Handler", "the handler alias"],
      ] as const) {
        const generated = checkPyName(`${stem}${suffix}`, "class", where);
        em.symbols.declare(generated, where, `${describe} generated for the ${name} handler`);
      }
    }

    for (const name of handlerNames) {
      const spec = handlers[name] as HandlerSpec;
      const stem = pascalCase(name);
      blocks.push(
        handlerSchemaType(
          spec.input,
          `${stem}Input`,
          "input",
          em,
          `$.handlers.${name}.input`,
          `Input for the ${name} handler.`,
        ).join("\n"),
      );
      blocks.push(
        handlerSchemaType(
          spec.output,
          `${stem}Output`,
          "output",
          em,
          `$.handlers.${name}.output`,
        ).join("\n"),
      );
    }

    em.used.add("Protocol");
    const handlersLines = [
      "class Handlers(Protocol):",
      ...pyDoc(
        "Every handler this realm exposes, keyed by name and typed by input/output.",
        "    ",
      ),
      "",
    ];
    for (const name of handlerNames) {
      const stem = pascalCase(name);
      handlersLines.push(
        `    def ${name}(self, input: ${stem}Input, ctx: HandlerContext) -> ${stem}Output: ...`,
      );
    }
    blocks.push(handlersLines.join("\n"));

    em.used.add("Callable");
    const aliasLines: string[] = [];
    for (const name of handlerNames) {
      const stem = pascalCase(name);
      aliasLines.push(`${stem}Handler = Callable[[${stem}Input, HandlerContext], ${stem}Output]`);
    }
    blocks.push(aliasLines.join("\n"));
  }

  const header = [
    "# Generated from realm.ts by @embabel/realm-synth. Do not edit.",
    `# Realm: ${escapeLineComment(realm.name)} (${escapeLineComment(realm.version)})`,
    "",
    "from __future__ import annotations",
  ];
  const importNames = [...em.used].sort();
  if (importNames.length > 0) {
    header.push("", `from typing import ${importNames.join(", ")}`);
  }

  return `${header.join("\n")}\n\n${blocks.join("\n\n\n")}\n`;
}

/** A declared domain type, as a `TypedDict`. Property mapping mirrors `tsType` in dts.ts. */
function emitDomainTypedDict(name: string, spec: TypeSpec, em: Emission): string[] {
  const fields: PyField[] = [];
  for (const property of Object.keys(spec.properties ?? {}).sort()) {
    const declared = spec.properties[property] as PropertySpec;
    const description = typeof declared === "string" ? declared : declared.description;
    let annotation = domainPyType(declared);
    if (domainOptional(declared)) {
      em.used.add("NotRequired");
      annotation = `NotRequired[${annotation}]`;
    }
    fields.push({ key: property, annotation, docLines: description ? [description.trim()] : [] });
  }
  return typedDictBlock(name, fields, spec.description, em);
}

/**
 * A domain property is required when it is the identity or says so. Everything else is
 * optional: a realm materializes records from sources that routinely omit fields, and a
 * type that claims otherwise would make handlers lie about what they have.
 */
function domainOptional(spec: PropertySpec): boolean {
  if (typeof spec === "string") return true;
  return !(spec.identity === true || spec.required === true);
}

/**
 * A domain property with no declared type, or one this doesn't recognize, is treated as
 * text, the same default dts.ts uses for TypeScript. A LIST or SET property becomes a
 * `list[...]`, so the Python side sees the same arity the graph holds.
 */
function domainPyType(spec: PropertySpec): string {
  if (typeof spec === "string") return "str";
  const scalar = pyScalar(spec.type);
  return isMultiValued(spec) ? `list[${scalar}]` : scalar;
}

function pyScalar(type: string | undefined): string {
  switch (type) {
    case "int":
      return "int";
    case "number":
      return "float";
    case "boolean":
      return "bool";
    default:
      return "str";
  }
}

/**
 * A handler's input or output schema, as the Python the handler checks against.
 *
 * The shape follows what the TypeScript emitter does with the same schema. An object
 * schema with properties becomes a named `TypedDict`. A scalar or an array becomes a
 * named alias for that type, so a handler returning a bare string is typed as returning
 * a bare string. A schema that is absent, empty or unrecognized falls back the way
 * `jsonSchemaToTsType` falls back: an input gets an empty `TypedDict`, which is the
 * Python reading of `Record<string, never>`, and an output gets `object`, which is the
 * Python reading of `unknown`.
 *
 * The name is always emitted, because `Handlers` and the per-verb alias reference it
 * either way.
 */
function handlerSchemaType(
  schema: unknown,
  name: string,
  role: "input" | "output",
  em: Emission,
  where: string,
  doc?: string,
): string[] {
  const obj =
    schema && typeof schema === "object" ? (schema as Record<string, unknown>) : undefined;
  const type = typeof obj?.type === "string" ? (obj.type as string) : undefined;

  if (type === "object") {
    const properties = (obj?.properties as Record<string, unknown> | undefined) ?? {};
    const required = (obj?.required as string[] | undefined) ?? [];
    if (Object.keys(properties).length > 0) {
      return buildTypedDict(name, properties, required, em, where, doc);
    }
  } else if (type !== undefined) {
    const nested: string[][] = [];
    const annotation = jsonSchemaToPyType(schema, name, nested, em, where);
    if (annotation !== "object") return aliasBlock(name, annotation, nested, doc);
  }

  if (role === "input") return typedDictBlock(name, [], doc, em);
  return aliasBlock(name, "object", [], doc);
}

/** A named alias for a type that is not a `TypedDict`, preceded by any nested classes the annotation names. */
function aliasBlock(name: string, annotation: string, nested: string[][], doc?: string): string[] {
  const lines: string[] = [];
  for (const block of nested) lines.push(...block, "", "");
  lines.push(`${name} = ${annotation}`);
  if (doc) lines.push(...pyDoc(doc));
  return lines;
}

/**
 * The subset of JSON Schema `jsonSchemaToTsType` in dts.ts supports, walked the same
 * way but landing as a Python type instead: string/number/integer/boolean, arrays, and
 * nested objects (each becoming its own named `TypedDict`, defined ahead of whatever
 * references it). Anything else falls back to `object`; it does not guess. A string
 * property with a string `enum` narrows to `Literal[...]` over those values, the
 * Python reading of the literal union `jsonSchemaToTsType` narrows to. Field
 * documentation is attached where the field itself is built, in `buildTypedDict`; this
 * walk only resolves the type each field gets.
 */
function jsonSchemaToPyType(
  schema: unknown,
  syntheticName: string,
  nested: string[][],
  em: Emission,
  where: string,
): string {
  if (!schema || typeof schema !== "object") return "object";
  const obj = schema as Record<string, unknown>;
  const type = obj.type as string | undefined;
  if (!type) return "object";

  if (type === "string") {
    const values = stringEnumValues(obj);
    if (values) {
      em.used.add("Literal");
      return `Literal[${values.map(pyStringLiteral).join(", ")}]`;
    }
    return "str";
  }
  if (type === "integer") return "int";
  if (type === "number") return "float";
  if (type === "boolean") return "bool";

  if (type === "array") {
    const items = obj.items as Record<string, unknown> | undefined;
    const itemType = jsonSchemaToPyType(
      items,
      `${syntheticName}Item`,
      nested,
      em,
      `${where}.items`,
    );
    return `list[${itemType}]`;
  }

  if (type === "object") {
    const properties = obj.properties as Record<string, unknown> | undefined;
    const required = (obj.required as string[] | undefined) ?? [];
    if (!properties || Object.keys(properties).length === 0) return "object";
    checkPyName(syntheticName, "class", where);
    em.symbols.declare(syntheticName, where, `the nested type generated for ${where}`);
    nested.push(buildTypedDict(syntheticName, properties, required, em, where));
    return syntheticName;
  }

  return "object";
}

/** One `TypedDict` built from a JSON Schema object, as its lines in emission order: any nested classes its own fields need, then the class itself. */
function buildTypedDict(
  name: string,
  properties: Record<string, unknown>,
  required: string[],
  em: Emission,
  where: string,
  doc?: string,
): string[] {
  const childBlocks: string[][] = [];
  const fields: PyField[] = [];
  for (const prop of Object.keys(properties).sort()) {
    const propSchema = properties[prop];
    const propType = jsonSchemaToPyType(
      propSchema,
      `${name}${syntheticNameSegment(prop)}`,
      childBlocks,
      em,
      `${where}.properties.${prop}`,
    );
    let annotation = propType;
    if (!required.includes(prop)) {
      em.used.add("NotRequired");
      annotation = `NotRequired[${propType}]`;
    }
    fields.push({ key: prop, annotation, docLines: pyDocLines(propertyDoc(propSchema)) });
  }

  const lines: string[] = [];
  for (const block of childBlocks) lines.push(...block, "", "");
  lines.push(...typedDictBlock(name, fields, doc, em));
  return lines;
}

/**
 * One `TypedDict`, written in whichever of the two syntaxes its keys allow.
 *
 * Class syntax is the readable one and it needs every key to be a Python identifier.
 * Real schemas carry keys like "user-id" that are perfectly good JSON and cannot be
 * written that way, so those types are written with the functional syntax, which is
 * the escape hatch the typing docs point at for exactly this. Renaming the key would
 * type a handler against a shape the host never sends, so the emitter never does it.
 * Every key in that syntax goes through `pyStringLiteral`, so a key carrying a space, a
 * quote, a backslash or a control character lands as one inert string.
 *
 * A type with no fields and no docstring gets `pass`, because a class with an empty
 * body does not parse.
 *
 * Each field's doc lines land as `#` comments right above it, one line per comment, in
 * both syntaxes. A `#` comment cannot span a real line break without a `#` of its own
 * on the next line, so a field's doc text is never handed to Python as one block: every
 * line is escaped and written on its own, right before it is written, so nothing a
 * schema carries can end a comment early and start a fresh line of Python.
 */
function typedDictBlock(
  name: string,
  fields: PyField[],
  doc: string | undefined,
  em: Emission,
): string[] {
  em.used.add("TypedDict");
  const classSyntax = fields.every((f) => PY_IDENTIFIER.test(f.key) && !KEYWORDS.has(f.key));

  if (!classSyntax) {
    const lines = [`${name} = TypedDict(`, `    ${pyStringLiteral(name)},`, "    {"];
    for (const field of fields) {
      for (const docLine of field.docLines) lines.push(`        # ${escapeLineComment(docLine)}`);
      lines.push(`        ${pyStringLiteral(field.key)}: ${field.annotation},`);
    }
    lines.push("    },", ")");
    if (doc) lines.push(...pyDoc(doc));
    return lines;
  }

  const lines = [`class ${name}(TypedDict):`];
  if (doc) lines.push(...pyDoc(doc, "    "));
  if (fields.length > 0) {
    if (doc) lines.push("");
    for (const field of fields) {
      for (const docLine of field.docLines) lines.push(`    # ${escapeLineComment(docLine)}`);
      lines.push(`    ${field.key}: ${field.annotation}`);
    }
  } else if (!doc) {
    lines.push("    pass");
  }
  return lines;
}
