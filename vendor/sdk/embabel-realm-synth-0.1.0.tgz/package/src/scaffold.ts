import { existsSync, readFileSync } from "node:fs";
import { mkdir, readdir, writeFile } from "node:fs/promises";
import { basename, dirname, join, relative, resolve, sep } from "node:path";
import { SynthError } from "./canonical.ts";
import { conventionalEntry as sharedConventionalEntry } from "./emit.ts";

/** The three runtimes `init` can scaffold. Ruby and Lua are declarable but have no scaffold yet. */
export type ScaffoldRuntime = "typescript" | "python" | "compiled";

/** One file `init` writes, path relative to the scaffold directory. */
interface ScaffoldFile {
  path: string;
  content: string;
}

/** Turns an arbitrary directory name into a safe identifier for a realm name and a handler namespace. */
function identifierize(name: string): string {
  const slug = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return slug.length > 0 ? slug : "realm";
}

/**
 * The realm-relative handler entry path a runtime conventionally uses. Delegates to
 * `emit.ts`'s `conventionalEntry`, the same lookup synth's own assembly step uses to
 * find a realm's entry when the definition leaves the field unset, so a scaffolded
 * realm and synth's own default can never drift apart.
 */
function conventionalEntry(runtime: ScaffoldRuntime): string {
  return sharedConventionalEntry(runtime);
}

/** The realm-relative path `--types` should write to for a runtime, matching what its handler template imports. */
function conventionalTypesPath(runtime: ScaffoldRuntime): string {
  if (runtime === "python") return ".embabel/realm_types.py";
  if (runtime === "compiled") return ".embabel/realm_types.rs";
  return ".embabel/realm.d.ts";
}

/**
 * Walks up from `dir`'s parent looking for a `package.json` that declares npm/bun
 * `workspaces` globs, and reports whether `dir` sits inside one of them.
 *
 * This is what the scaffold's own `@embabel/realm-types` dependency is decided by:
 * inside this workspace, `workspace:*` resolves to the local package; outside it,
 * nothing resolves that specifier, and the scaffold writes a placeholder that says so.
 *
 * Each glob is matched against `dir`'s path relative to the workspace root with
 * `Bun.Glob`, the same matching a package manager itself would do. The old code only
 * compared first path segments. That made a pattern like `packages/realm-*` falsely
 * claim `packages/unrelated`, and made a bare `*` (meant to match only direct
 * children of a directory) claim nothing at any depth.
 */
function inWorkspace(dir: string): boolean {
  const target = resolve(dir);
  let current = dirname(target);
  for (let depth = 0; depth < 20; depth++) {
    const pkgPath = join(current, "package.json");
    if (existsSync(pkgPath)) {
      try {
        const pkg = JSON.parse(readFileSync(pkgPath, "utf8")) as { workspaces?: unknown };
        const workspaces = Array.isArray(pkg.workspaces) ? (pkg.workspaces as unknown[]) : [];
        if (workspaces.length > 0) {
          const relPath = relative(current, target).split(sep).join("/");
          return workspaces.some(
            (glob) => typeof glob === "string" && new Bun.Glob(glob).match(relPath),
          );
        }
      } catch {
        // Not parseable JSON, so it is not really a package.json. Keep walking up.
      }
    }
    const parent = dirname(current);
    if (parent === current) return false;
    current = parent;
  }
  return false;
}

/**
 * The files `init` writes for one runtime, named after the target directory.
 *
 * Every scaffold is a minimal one-handler realm: a liveness verb called `ping`, with an
 * empty input and output schema, the same floor `examples/realm-notes` uses. It proves
 * the loop end to end. It does not demonstrate every field a realm can declare.
 */
export function scaffoldFiles(
  dirName: string,
  runtime: ScaffoldRuntime,
  scaffoldInWorkspace: boolean,
): ScaffoldFile[] {
  const name = identifierize(dirName);
  const entry = conventionalEntry(runtime);
  const typesPath = conventionalTypesPath(runtime);
  // A package.json has no comment syntax, and a "//" key is not a comment either:
  // npm, bun, and every other package manager treat it as a real dependency and can
  // fail install trying to resolve it. The explanation for the placeholder version
  // lives in the scaffold's README instead, in readmeFor below.
  const dependencies = scaffoldInWorkspace
    ? { "@embabel/realm-types": "workspace:*" }
    : { "@embabel/realm-types": "0.0.0" };
  const files: ScaffoldFile[] = [
    {
      path: "package.json",
      content: `${JSON.stringify(
        {
          name: `@embabel/realm-${name}`,
          version: "0.1.0",
          private: true,
          type: "module",
          scripts: { typecheck: "tsc --noEmit" },
          dependencies,
        },
        null,
        2,
      )}\n`,
    },
    {
      path: "tsconfig.json",
      content: `${JSON.stringify(
        {
          compilerOptions: {
            target: "ES2022",
            module: "Preserve",
            moduleResolution: "bundler",
            allowImportingTsExtensions: true,
            noEmit: true,
            strict: true,
            skipLibCheck: true,
            verbatimModuleSyntax: true,
          },
          include: [
            "*.ts",
            entry.endsWith(".ts") ? "wasm/**/*.ts" : undefined,
            ".embabel/*.d.ts",
          ].filter(Boolean),
        },
        null,
        2,
      )}\n`,
    },
    {
      path: "README.md",
      content: readmeFor(name, runtime, typesPath),
    },
  ];

  if (runtime === "typescript") {
    files.push({ path: "realm.ts", content: typescriptRealm(name) });
    files.push({ path: entry, content: typescriptHandlers() });
  } else if (runtime === "python") {
    files.push({ path: "realm.ts", content: pythonRealm(name, entry) });
    files.push({ path: entry, content: pythonHandlers() });
  } else {
    files.push({ path: "realm.ts", content: compiledRealm(name, entry) });
    files.push({ path: entry, content: compiledHandlers() });
  }

  return files;
}

function readmeFor(name: string, runtime: ScaffoldRuntime, typesPath: string): string {
  return `# ${name}

A realm scaffolded by \`realm-synth init\` for the "${runtime}" runtime. The commands
below assume the realm-ts workspace checkout is the current directory, the same as
every other \`bun packages/realm-synth/src/cli.ts\` example in this repo.

- \`bun packages/realm-synth/src/cli.ts realm.ts --out dist\` synthesizes the realm.
- \`bun packages/realm-synth/src/cli.ts realm.ts --types ${typesPath}\` generates
  the types this realm's handler source imports.
- \`bun packages/realm-synth/src/cli.ts realm.ts --out dist --types ${typesPath} --watch\`
  re-runs both on every change to this directory.

\`package.json\` depends on \`@embabel/realm-types\` with \`workspace:*\` when this realm
was scaffolded inside the realm-ts workspace, where that resolves to the local
package. Scaffolded elsewhere, \`workspace:*\` resolves to nothing, so the dependency
is a placeholder version. Replace it with the published \`@embabel/realm-types\`
version before installing.
`;
}

function typescriptRealm(name: string): string {
  return `import type { Realm } from "@embabel/realm-types";

/** A realm scaffolded by realm-synth init. One handler, nothing else. */
export default {
  name: "${name}",
  host: "wasm",
  version: "0.1.0",
  description: "A realm scaffolded by realm-synth init.",
  handlers: {
    ping: {
      namespace: "${name}",
      description: "Liveness check.",
      input: { type: "object" },
      output: { type: "object" },
    },
  },
} satisfies Realm;
`;
}

function typescriptHandlers(): string {
  return `import type { PingHandler } from "../.embabel/realm.d.ts";

/** Liveness check. Returns immediately. */
export const ping: PingHandler = async (_input, ctx) => {
  ctx.log("ping");
  return {};
};
`;
}

function pythonRealm(name: string, entry: string): string {
  return `import type { Realm } from "@embabel/realm-types";

/**
 * A realm scaffolded for the Python runtime by realm-synth init.
 *
 * Declares runtime: "python" and an explicit entry naming the handler source path.
 * The handler is typed against .embabel/realm_types.py, the module --types generates
 * for a realm on this runtime.
 */
export default {
  name: "${name}",
  host: "wasm",
  runtime: "python",
  entry: "${entry}",
  version: "0.1.0",
  description: "A realm scaffolded by realm-synth init.",
  handlers: {
    ping: {
      namespace: "${name}",
      description: "Liveness check.",
      input: { type: "object" },
      output: { type: "object" },
    },
  },
} satisfies Realm;
`;
}

function pythonHandlers(): string {
  return `# The host runtime mechanism for Python does not exist yet. This file documents the
# target shape a future shim will call: one function per declared verb, taking the
# parsed input dict and a context object, returning a plain dict matching the verb's
# output schema. The import only runs under a type checker, since the guest never has
# a realm_types module on its path at runtime.
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from realm_types import HandlerContext, PingInput, PingOutput


def ping(input: "PingInput", ctx: "HandlerContext") -> "PingOutput":
    """Liveness check. Returns immediately."""
    return {}
`;
}

function compiledRealm(name: string, entry: string): string {
  return `import type { Realm } from "@embabel/realm-types";

/**
 * A realm scaffolded for a compiled Rust guest by realm-synth init.
 *
 * Declares runtime: "compiled" and an explicit entry naming the handler source path.
 * The handler is typed against .embabel/realm_types.rs, the module --types generates
 * for a realm on this runtime.
 */
export default {
  name: "${name}",
  host: "wasm",
  runtime: "compiled",
  entry: "${entry}",
  version: "0.1.0",
  description: "A realm scaffolded by realm-synth init.",
  handlers: {
    ping: {
      namespace: "${name}",
      description: "Liveness check.",
      input: { type: "object" },
      output: { type: "object" },
    },
  },
} satisfies Realm;
`;
}

function compiledHandlers(): string {
  return `// Documents the target shape for this realm's handler in Rust. The engine does not
// dispatch a compiled guest yet, so nothing calls this function today.
//
// The generated contract for this realm lives at ../../.embabel/realm_types.rs. A real
// build copies or path-includes that module here so PingInput, PingOutput, and
// HandlerContext are in scope; that build step is still open work, so this file does
// not declare or import them itself.

/// Liveness check. Returns immediately.
pub fn ping(_input: PingInput, ctx: &dyn HandlerContext) -> PingOutput {
    ctx.log("ping");
    PingOutput {}
}
`;
}

/**
 * Writes a runtime's scaffold into `dir`, refusing a directory that already has
 * anything in it. `dir`'s basename becomes the realm's name.
 */
export async function scaffoldRealm(dir: string, runtime: ScaffoldRuntime): Promise<string[]> {
  if (existsSync(dir)) {
    const existing = await readdir(dir);
    if (existing.length > 0) {
      throw new SynthError(`init: "${dir}" is not empty`);
    }
  }
  const files = scaffoldFiles(basename(dir) || "realm", runtime, inWorkspace(dir));
  const written: string[] = [];
  for (const file of files) {
    const target = join(dir, file.path);
    await mkdir(dirname(target), { recursive: true });
    await writeFile(target, file.content, "utf8");
    written.push(file.path);
  }
  return written.sort();
}
