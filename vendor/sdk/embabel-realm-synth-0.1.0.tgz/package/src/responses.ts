/**
 * What a captured api operation answers with, read the way the host reads it.
 *
 * The host decodes each reply with a codec chosen by media type, and hands the guest a value
 * whose shape depends on that codec. Synth needs the same answer twice: to refuse a
 * `responses:` declaration the host would refuse, and to type the gateway method's result.
 * This file holds the one copy of those rules.
 */

/** The decoders the host reads a reply with. */
export type ResponseCodec = "json" | "records" | "xml" | "csv" | "yaml" | "form" | "text";

/**
 * Which decoder reads which type. A key is an exact type, a `+suffix`, or a whole family such
 * as every `text` type, tried in that order.
 */
const CODECS: Readonly<Record<string, ResponseCodec>> = {
  "application/json": "json",
  "+json": "json",
  "application/x-ndjson": "records",
  "application/jsonl": "records",
  "application/x-jsonlines": "records",
  "application/jsonlines": "records",
  "application/json-seq": "records",
  "application/xml": "xml",
  "text/xml": "xml",
  "+xml": "xml",
  "text/csv": "csv",
  "application/yaml": "yaml",
  "application/x-yaml": "yaml",
  "text/yaml": "yaml",
  "text/x-yaml": "yaml",
  "+yaml": "yaml",
  "application/x-www-form-urlencoded": "form",
  "text/plain": "text",
  "text/*": "text",
};

/** Types the host counts as text although no decoder reads them, so raw mode may name them. */
const OTHER_TEXT = [
  "application/javascript",
  "application/ecmascript",
  "application/graphql",
  "application/sql",
];

/** The type families a raw declaration may name as a range. */
const RAW_RANGES = ["*", "text", "application"];

/** The longest declared type the host reads. */
export const MAX_RESPONSE_TYPE_LENGTH = 256;

/** The most operations one entry's `responses:` map may name. */
export const MAX_DECLARED_RESPONSES = 128;

const TOKEN = /^[A-Za-z0-9!#$&^_.+-]{1,127}$/;
const VALUE = /^(?:[A-Za-z0-9!#$&^_.+-]{1,127}|"[A-Za-z0-9!#$&^_.+ /=:-]{0,127}")$/;

/** A parsed media type. Type, subtype and parameter names are lower-cased; values keep their case. */
export interface MediaType {
  type: string;
  subtype: string;
  parameters: Record<string, string>;
}

/** `type/subtype`, the part that picks the decoder. */
export function essence(media: MediaType): string {
  return `${media.type}/${media.subtype}`;
}

/** True for a range: a star for the subtype, or for both halves. */
export function isRange(media: MediaType): boolean {
  return media.subtype === "*";
}

/** `text` as a media type, or undefined when the host would not read it as one. */
export function parseMediaType(text: string): MediaType | undefined {
  if (text.length > MAX_RESPONSE_TYPE_LENGTH) return undefined;
  const pieces = text.split(";").map((piece) => piece.trim());
  const halves = (pieces[0] ?? "").split("/");
  if (halves.length !== 2) return undefined;
  const [type, subtype] = halves.map((half) => half.toLowerCase()) as [string, string];
  if (!(TOKEN.test(type) || type === "*") || !(TOKEN.test(subtype) || subtype === "*")) {
    return undefined;
  }
  if (type === "*" && subtype !== "*") return undefined;
  const parameters: Record<string, string> = {};
  for (const parameter of pieces.slice(1).filter((piece) => piece !== "")) {
    const at = parameter.indexOf("=");
    const name = (at < 0 ? "" : parameter.slice(0, at)).trim().toLowerCase();
    const value = (at < 0 ? "" : parameter.slice(at + 1)).trim();
    if (!TOKEN.test(name) || !VALUE.test(value) || Object.hasOwn(parameters, name)) {
      return undefined;
    }
    parameters[name] = value.replace(/^"(.*)"$/, "$1");
  }
  return { type, subtype, parameters };
}

/** The decoder for `media`, or undefined when the host has none for it. */
export function codecFor(media: MediaType): ResponseCodec | undefined {
  const plus = media.subtype.lastIndexOf("+");
  const suffix =
    plus < 0 || plus === media.subtype.length - 1 ? undefined : media.subtype.slice(plus);
  return (
    CODECS[essence(media)] ??
    (suffix === undefined ? undefined : CODECS[suffix]) ??
    CODECS[`${media.type}/*`]
  );
}

/** Whether the host would hand a guest this type's body as text. */
function textual(media: MediaType): boolean {
  return (
    media.type === "text" || codecFor(media) !== undefined || OTHER_TEXT.includes(essence(media))
  );
}

/** One operation's reply type: what it declares, or JSON when it declares nothing. */
export interface ResponseFormat {
  media: MediaType;
  /** The guest decodes the body itself and receives `{ contentType, text }`. */
  raw: boolean;
  /** The decoder, absent for raw. */
  codec?: ResponseCodec;
}

/** How the host reads an operation that declares no response type: as one JSON document. */
export const UNDECLARED_FORMAT: ResponseFormat = {
  media: { type: "application", subtype: "json", parameters: {} },
  raw: false,
  codec: "json",
};

/**
 * A `response` value as the realm wrote it, checked the way the host checks a `responses:`
 * entry. Returns the format and the value to write on the wire, or the reason the host
 * would refuse the whole file.
 */
export function declaredResponse(
  value: unknown,
  write: boolean,
): { format: ResponseFormat; wire: string | { raw: string } } | { refused: string } {
  if (value === "json") return declaredResponse("application/json", write);
  if (value === "ndjson") return declaredResponse("application/x-ndjson", write);
  if (typeof value === "string") {
    const media = parseMediaType(value);
    if (media === undefined) return { refused: `"${value}" is not a media type` };
    if (isRange(media)) {
      return {
        refused: `"${value}" is a range, and only { raw: "${value}" } may name one`,
      };
    }
    const codec = codecFor(media);
    if (codec === undefined) {
      return {
        refused:
          `the host has no decoder for "${essence(media)}". ` +
          `Declare { raw: "${value}" } to read it as text, unless it is binary, which the host refuses`,
      };
    }
    if (codec === "csv") {
      const header = media.parameters.header;
      if (header !== undefined && !["present", "absent"].includes(header.toLowerCase())) {
        return { refused: `a CSV "header" parameter is present or absent, got "${header}"` };
      }
    }
    if (write && codec === "records") {
      return {
        refused:
          "a write cannot answer with a stream of records, since its outcome is one whole document",
      };
    }
    return { format: { media, raw: false, codec }, wire: value };
  }
  if (typeof value === "object" && value !== null && !Array.isArray(value)) {
    const keys = Object.keys(value);
    const raw = (value as { raw?: unknown }).raw;
    if (keys.length !== 1 || keys[0] !== "raw" || typeof raw !== "string") {
      return { refused: 'expected a media type, or an object with only a "raw" media type' };
    }
    const media = parseMediaType(raw);
    if (media === undefined) return { refused: `"${raw}" is not a media type` };
    const allowed = isRange(media) ? RAW_RANGES.includes(media.type) : textual(media);
    if (!allowed) {
      return {
        refused: isRange(media)
          ? `a raw range covers every type, every text type or every application type, got "${raw}"`
          : `"${essence(media)}" is not a text type, and the host refuses binary bodies, raw or not`,
      };
    }
    return { format: { media, raw: true }, wire: { raw } };
  }
  return { refused: 'expected a media type, "json", "ndjson", or { raw: <media type> }' };
}

/**
 * The single 2xx content type an OpenAPI operation names, following a `$ref` into
 * `#/components/responses`. Undefined when it names none, several, a range, or one that does
 * not parse.
 *
 * The host never reads a reply by this type. Synth uses it only to warn a realm whose
 * undeclared operation is documented as something other than JSON.
 */
export function documentedResponse(
  operation: Record<string, unknown>,
  document: Record<string, unknown>,
): MediaType | undefined {
  const responses = record(operation.responses);
  if (responses === undefined) return undefined;
  const found: MediaType[] = [];
  for (const [status, response] of Object.entries(responses)) {
    if (!/^2(?:[0-9]{2}|XX)$/.test(status)) continue;
    const content = record(record(resolved(response, document))?.content);
    for (const name of Object.keys(content ?? {})) {
      const media = parseMediaType(name);
      if (media === undefined) return undefined;
      if (!found.some((seen) => essence(seen) === essence(media))) found.push(media);
    }
  }
  const [only] = found;
  return found.length === 1 && only !== undefined && !isRange(only) ? only : undefined;
}

/**
 * A `response` that would have the host read `media` the way its document describes it, or
 * undefined when none can, as for a binary type. A write cannot declare a stream of records,
 * so it gets raw mode for one.
 */
export function suggestedDeclaration(media: MediaType, write: boolean): string | undefined {
  const type = essence(media);
  const codec = codecFor(media);
  if (codec !== undefined && !(write && codec === "records")) return JSON.stringify(type);
  return textual(media) ? `{ raw: ${JSON.stringify(type)} }` : undefined;
}

/** The operation in an OpenAPI document carrying `id`, under any HTTP method. */
export function findOperation(
  document: Record<string, unknown>,
  id: string,
): Record<string, unknown> | undefined {
  for (const item of Object.values(record(document.paths) ?? {})) {
    for (const operation of Object.values(record(item) ?? {})) {
      const found = record(operation);
      if (found?.operationId === id) return found;
    }
  }
  return undefined;
}

function resolved(response: unknown, document: Record<string, unknown>): unknown {
  const ref = record(response)?.$ref;
  if (typeof ref !== "string" || !ref.startsWith("#/components/responses/")) return response;
  const name = ref.slice("#/components/responses/".length);
  return record(record(record(document.components)?.responses)?.[name]);
}

function record(value: unknown): Record<string, unknown> | undefined {
  return typeof value === "object" && value !== null && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : undefined;
}
