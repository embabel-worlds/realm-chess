import type {
  CapturedChannelSpec,
  CapturedConsumerSpec,
  CapturedRealm,
  CapturedSourceSpec,
  CapturedWebhookVerification,
  JsonObject,
  JsonValue,
} from "@embabel/realm-types";
import { canonicalize, SynthError } from "./canonical.ts";
import type { RenderedFile } from "./emit.ts";

/**
 * What a realm may never set on a channel, because the host sets it.
 *
 * The types already say `never` for each of these, which catches the realm written as an
 * object literal. It does not catch one assembled some other way — built in a loop, spread
 * from a shared constant, or written in plain JavaScript — and the fields here are the ones
 * where a silently ignored key is worst: a realm that thinks it turned reconnect off, or
 * that thinks it shipped its own secret.
 */
const HOST_OWNED_CHANNEL_FIELDS = [
  "autoStart",
  "budget",
  "cursor",
  "limits",
  "name",
  "reconnect",
  "secret",
  "secretRef",
] as const;

/**
 * What a realm may never set on a webhook signature.
 *
 * A captured realm names a credential and the host binds a real secret to it at approval
 * time. These two are the old way of saying where the secret lives, and letting either
 * through would put the location of key material in a file the owner never approved.
 */
const HOST_OWNED_SIGNATURE_FIELDS = ["secret", "secretRef"] as const;

/**
 * How a digest can be written, as the host knows how to read one.
 *
 * The types already say these two. A realm that gets past them was assembled outside them,
 * and the host refuses anything else at the first inbound request — which is a long way from
 * the line that wrote it, and looks like a bad secret rather than a spelling nobody reads.
 */
const SIGNATURE_ENCODINGS = ["hex", "base64"] as const;

/** How a signed timestamp can be written: whole seconds, or milliseconds. */
const TIMESTAMP_UNITS = ["s", "ms"] as const;

/**
 * The most a host-written verification answer may be, in bytes of canonical json.
 *
 * A provider's endpoint check wants a nonce back or a fixed acknowledgement; every one we
 * know of answers in well under a hundred bytes. The cap is here because this is the one
 * response the host writes out of a realm's own words rather than out of a request, and a
 * realm that can put a kilobyte there can put a megabyte there.
 */
const VERIFICATION_REPLY_BYTES = 1024;

/**
 * What a realm may never set on a source: the file's own name, and the two fields that
 * belong to one installation rather than to the declaration shared by all of them.
 */
const HOST_OWNED_SOURCE_FIELDS = ["installationId", "kind", "name"] as const;

/**
 * What a realm may never set on a consumer. `checkpoint` is how far the host has read,
 * which is per installation and moves on its own; a realm setting it is asking to replay
 * or skip somebody else's events.
 */
const HOST_OWNED_CONSUMER_FIELDS = ["checkpoint", "name"] as const;

/**
 * The one shape a channel, source or consumer key may take, because the key becomes a
 * file name.
 *
 * Same spelling as every other captured name — a lowercase letter, then letters, digits
 * and dashes. It has to be this narrow: the key is interpolated straight into
 * `channels/<key>.yml`, so a key holding a slash or a `..` would write outside the
 * directory it was meant for, and a well-chosen one would land on top of `realm.yml` and
 * quietly replace the realm's own metadata. Refusing the name is the only place to catch
 * that — by the time there is a path there is nothing left to tell apart.
 */
const CAPTURED_FILE_STEM = /^[a-z][a-z0-9-]{0,63}$/;

/** The one spelling of a length of time synth reads: whole seconds or whole minutes. */
const DURATION = /^([0-9]+)(s|m)$/;

/** How often a long-poll fetches when the realm does not say. */
const DEFAULT_EVERY = "5s";

/**
 * The four things the host knows how to put into the string a webhook signature covers.
 *
 * Anything else in braces is text the host has nothing to substitute for, so the digest it
 * computes would never be the one the provider sent — and the failure would look like a bad
 * secret rather than a typo in a template.
 */
const TEMPLATE_PLACEHOLDERS = ["method", "fullUrl", "body", "timestamp"] as const;

/** Anything in braces, which is the only way a template asks for a substitution. */
const TEMPLATE_PLACEHOLDER = /\{([^}]*)\}/g;

/** A dotted-quad address written out, like "127.0.0.1". */
const IPV4_LITERAL = /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/;

/** A channel url may contain one credential stand-in, never two. */
const CHANNEL_CREDENTIAL_PLACEHOLDER = /\{credential\}/g;

/**
 * Reads "30s" or "5m" as a number of seconds.
 *
 * The type says the spelling, and that is all a template literal type can say: `"0s"`,
 * `"-1s"` and `"1.5s"` all match `` `${number}s` `` and none of them is a length of time
 * anything can wait for. This is the one place any duration in a captured realm is read,
 * so a floor or a cap elsewhere compares numbers that were all parsed the same way.
 */
export function parseDurationSeconds(value: string, where: string): number {
  const match = DURATION.exec(value);
  if (match === null) {
    throw new SynthError(
      `${where}: "${value}" is not a length of time the host can wait for. Write whole seconds or ` +
        `whole minutes, like "30s" or "5m" — no fractions, no negatives, no other units.`,
    );
  }
  const amount = Number(match[1]);
  if (amount === 0) {
    throw new SynthError(
      `${where}: "${value}" is no time at all, so nothing would ever wait. Write how long the host ` +
        `should actually leave between attempts, like "30s".`,
    );
  }
  return match[2] === "m" ? amount * 60 : amount;
}

/** Every channel a captured realm declares, as key/spec pairs in the order keys sort. */
function channelEntries(
  realm: CapturedRealm,
): [string, CapturedChannelSpec<string, string, string>][] {
  return Object.entries(realm.channels ?? {}).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
}

/**
 * Refuses any of `fields` the declaration actually carries, naming the path it was written
 * at and never the value.
 *
 * The value is left out on purpose. Two of these fields are where a secret would sit, and
 * an error message is the one place a secret reliably gets copied into a terminal, a CI log
 * and an issue. The name of the field is all anyone needs to find the line.
 */
function refuseHostOwned(
  declared: unknown,
  where: string,
  fields: readonly string[],
  owned: string,
): void {
  const carried = declared as Record<string, unknown>;
  for (const field of fields) {
    if (Object.hasOwn(carried, field) && carried[field] !== undefined) {
      throw new SynthError(
        `${where}.${field}: host-owned field. The host decides this one — ${owned} — so a value ` +
          `written here would be read by nobody. Drop ${field}.`,
      );
    }
  }
}

/**
 * Refuses a key that could not be a file name.
 *
 * Every one of these keys becomes a file, so the check is on the key rather than on the
 * path built from it: once `../realm` has been joined onto an output directory it is
 * indistinguishable from a realm that meant to write there.
 */
function checkFileStem(id: string, where: string, collection: string): void {
  if (!CAPTURED_FILE_STEM.test(id)) {
    throw new SynthError(
      `${where}: "${id}" cannot be a file name, and this key becomes one — it is emitted as ` +
        `${collection}/${id}.yml. Name it with a lowercase letter followed by letters, digits ` +
        `or dashes, like "gateway", and keep it under 64 characters.`,
    );
  }
}

/**
 * Reads a field that the types say is always there, without trusting that it is.
 *
 * Every field this is used for is required in `CapturedChannelSpec`, so the only realm that
 * can arrive here missing one is a realm assembled outside the types — in a loop, spread
 * from a shared constant, or written in plain JavaScript. A blank string counts as missing:
 * a handler named `""` resolves to nothing just as surely as no handler at all.
 */
function declaredString(declared: unknown, field: string): string | undefined {
  const value = (declared as Record<string, unknown>)[field];
  return typeof value === "string" && value.trim() !== "" ? value : undefined;
}

/**
 * A written value the way a refusal quotes it back: a string in quotes, anything else as the
 * JSON it was. `undefined` for a value JSON cannot write — a function, a symbol — which is
 * written out as the word rather than left as a hole in the sentence.
 */
function quoted(value: unknown): string {
  return JSON.stringify(value) ?? String(value);
}

/** Whether a written value is one of a fixed set of spellings, without trusting its type. */
function included(allowed: readonly string[], value: unknown): boolean {
  return typeof value === "string" && allowed.includes(value);
}

/**
 * Reads a length of time and holds it between a floor and, where there is one, a cap.
 *
 * Both ends are written the way an author writes them and parsed the same way the value is,
 * so the message can quote the bound back in the spelling it will be retyped in. `tooOften`
 * and `tooRarely` say what goes wrong at each end, because that differs per field: too many
 * ticks is a flood the provider throttles, too few is a socket dropped as dead.
 */
function checkDuration(
  value: string,
  where: string,
  bounds: { floor: string; tooOften: string; cap?: { most: string; tooRarely: string } },
): void {
  const seconds = parseDurationSeconds(value, where);
  if (seconds < parseDurationSeconds(bounds.floor, where)) {
    throw new SynthError(
      `${where}: "${value}" is under the ${bounds.floor} floor. ${bounds.tooOften} Write ` +
        `"${bounds.floor}" or longer.`,
    );
  }
  if (bounds.cap !== undefined && seconds > parseDurationSeconds(bounds.cap.most, where)) {
    throw new SynthError(
      `${where}: "${value}" is over the ${bounds.cap.most} cap. ${bounds.cap.tooRarely} Write ` +
        `"${bounds.cap.most}" or shorter.`,
    );
  }
}

/**
 * Refuses a url whose origin is this machine or a bare address.
 *
 * A realm is written once and installed by many people, and the host dials these urls from
 * wherever it happens to run. `localhost` and an IP literal are the two ways to write an
 * address that means one thing on the machine the realm was written on and something else —
 * or nothing, or somebody else's service — everywhere it is installed.
 *
 * The url itself never appears in the message. A url may carry `user:password@` in front of
 * its host, and an error message is the one place that reliably gets copied into a terminal,
 * a CI log and an issue; the origin is what the refusal is about and all it names.
 */
function checkOrigin(url: string, where: string): void {
  if ([...url.matchAll(CHANNEL_CREDENTIAL_PLACEHOLDER)].length > 1) {
    throw new SynthError(
      `${where}: the url names {credential} more than once. The host substitutes one owner-bound ` +
        `credential into one channel url; a second copy would expose it twice. Keep at most one ` +
        `{credential} placeholder.`,
    );
  }
  // The host substitutes {credential} and nothing else, and refuses a url with anything else
  // in braces. The offending text is quoted on its own, never the whole url.
  const leftover = url.replace(CHANNEL_CREDENTIAL_PLACEHOLDER, "");
  const brace = /\{[^{}]*\}|[{}]/.exec(leftover);
  if (brace !== null) {
    throw new SynthError(
      `${where}: "${brace[0]}" is not a placeholder the host fills in. A channel url may carry ` +
        `one {credential} and nothing else in braces, so the host refuses this channel. Write ` +
        `the value out, or use {credential} for the owner-bound secret.`,
    );
  }
  let host: string;
  try {
    host = new URL(url).hostname;
  } catch {
    throw new SynthError(
      `${where}: nothing in this reads as a host the host can dial. Write the provider's full ` +
        `origin, like "wss://gateway.example.com/socket". (The value is left out of this ` +
        `message on purpose — a url can carry a password in front of its host.)`,
    );
  }
  // A name written with a terminal dot is the same name: "localhost." is the absolute
  // spelling of "localhost", and every resolver reads the two as one host. Dropping the dot
  // before comparing is what stops the absolute spelling from walking straight past a rule
  // the ordinary spelling is caught by.
  const name = host.replace(/\.+$/, "");
  const local =
    name === "localhost" ||
    name.endsWith(".localhost") ||
    IPV4_LITERAL.test(name) ||
    name.startsWith("[");
  if (local) {
    throw new SynthError(
      `${where}: "${host}" is this machine or a bare address, not a provider. One realm is ` +
        `installed by many people and the host dials this from wherever it runs, so it would ` +
        `reach nothing there, or somebody else's service. Write the provider's own host name.`,
    );
  }
}

/**
 * Refuses a signed-string template asking for something the host cannot substitute.
 *
 * Checked against what is in braces rather than against the whole string, because the rest
 * of a template is literal text the provider also signs — separators, a version marker —
 * and refusing those would refuse most real providers.
 */
function checkTemplate(template: string, where: string): void {
  const allowed: readonly string[] = TEMPLATE_PLACEHOLDERS;
  for (const [, name] of template.matchAll(TEMPLATE_PLACEHOLDER)) {
    if (!allowed.includes(name)) {
      throw new SynthError(
        `${where}: "{${name}}" is not something the host can put in the string it signs. It ` +
          `substitutes ${allowed.map((one) => `{${one}}`).join(", ")} and nothing else, so what ` +
          `it hashed would never be what the provider hashed and every request would be ` +
          `refused as unsigned. Build the template out of those four.`,
      );
    }
  }
}

/**
 * Refuses a handler name this realm does not declare.
 *
 * A realm with no `handlers` block at all declares no handlers, so a name there is refused
 * like any other. The host dispatches only to handlers the realm's manifest registers, and
 * with no block there is no manifest to find one in.
 */
function checkHandlerReference(
  name: string,
  declared: ReadonlySet<string>,
  where: string,
  consequence: string,
): void {
  if (declared.has(name)) return;
  const inventory =
    declared.size === 0 ? "it declares no handlers" : `it has: ${[...declared].sort().join(", ")}`;
  throw new SynthError(
    `${where}: "${name}" is not a handler this realm declares (${inventory}). ${consequence} ` +
      `Declare it under handlers, or name one that is already there, spelled ` +
      `<namespace>.<verb>.`,
  );
}

/**
 * The handler a channel hands what arrives to: present at all, and one this realm declares.
 *
 * A channel with no handler is the quietest way a realm can be broken. Everything connects,
 * the provider sees a live client, and every event is read off the wire and dropped — so the
 * consumers downstream of it never run, and nothing anywhere reports a failure.
 */
function checkChannelHandler(
  channel: unknown,
  field: string,
  transport: string,
  where: string,
  declaredHandlers: ReadonlySet<string>,
): void {
  const handler = declaredString(channel, field);
  if (handler === undefined) {
    throw new SynthError(
      `${where}.${field}: a ${transport} channel hands what arrives to a handler, and this one ` +
        `names none. The host would hold the connection open and drop every event off it, ` +
        `silently. Name the handler that reads them, spelled <namespace>.<verb>.`,
    );
  }
  checkHandlerReference(
    handler,
    declaredHandlers,
    `${where}.${field}`,
    "The host only grants a handler this realm's manifest registers, so every event off this " +
      "channel would be dropped.",
  );
}

/**
 * The rules a webhook signature has to satisfy for the host to be able to check one.
 *
 * Both scheme rules are about a field the types already require, which is why they read as
 * belt and braces — but a signature that reaches the wire without them does not fail at the
 * capture, it fails on every inbound request, at a distance from the line that caused it.
 */
function checkSignature(
  signature: Extract<
    CapturedChannelSpec<string, string, string>,
    { transport: "webhook" }
  >["signature"],
  where: string,
): void {
  refuseHostOwned(
    signature,
    where,
    HOST_OWNED_SIGNATURE_FIELDS,
    "the owner binds a secret to the credential named here at approval time",
  );
  if (signature.scheme === "hmac-sha256" && declaredString(signature, "header") === undefined) {
    throw new SynthError(
      `${where}.header: an hmac-sha256 signature arrives in a header and this one names none. ` +
        `The host would have nowhere to read the digest from and would refuse every request as ` +
        `unsigned. Name the header the provider sends it in, like "X-Hub-Signature-256".`,
    );
  }
  if (signature.scheme === "ed25519" && signature.timestamp === undefined) {
    throw new SynthError(
      `${where}.timestamp: an ed25519 signature covers a timestamp and this one declares none. ` +
        `The host would have nothing to measure a replay window against, so one captured ` +
        `request could be replayed at it forever. Add timestamp with the header the provider ` +
        `sends it in.`,
    );
  }
  const encoding = (signature as { encoding?: unknown }).encoding;
  if (encoding !== undefined && !included(SIGNATURE_ENCODINGS, encoding)) {
    throw new SynthError(
      `${where}.encoding: ${quoted(encoding)} is not a way a digest is written. The host reads ` +
        `hex and base64 and nothing else, so it would have no digest to compare the provider's ` +
        `signature against and would refuse every request as unsigned. Write "hex" or "base64".`,
    );
  }
  const unit = (signature.timestamp as { unit?: unknown } | undefined)?.unit;
  if (unit !== undefined && !included(TIMESTAMP_UNITS, unit)) {
    throw new SynthError(
      `${where}.timestamp.unit: ${quoted(unit)} is not a length of time the host counts in. It ` +
        `reads "s" for whole seconds and "ms" for milliseconds, so it would have no age to hold ` +
        `the replay window against and would refuse every request as stale. Write "s" or "ms".`,
    );
  }
  const tolerance = (signature.timestamp as { toleranceSeconds?: unknown } | undefined)
    ?.toleranceSeconds;
  if (tolerance !== undefined && (!Number.isInteger(tolerance) || (tolerance as number) <= 0)) {
    throw new SynthError(
      `${where}.timestamp.toleranceSeconds: ${quoted(tolerance)} is not a positive whole-second ` +
        `replay window. The host would refuse every signed request as stale. Write a positive ` +
        `whole number of seconds, like 30.`,
    );
  }
  if (signature.template !== undefined) {
    checkTemplate(signature.template, `${where}.template`);
  }
}

/**
 * Refuses a `verification` on a channel the provider never posts to.
 *
 * A websocket and a long-poll are dialled by the host: there is no endpoint on this side for
 * anyone to check, so a verification written on one is an answer nothing would ever ask for.
 * It is refused rather than dropped because a realm that wrote one believes its endpoint is
 * being verified.
 */
function refuseVerification(channel: unknown, where: string, transport: string): void {
  const declared = (channel as { verification?: unknown }).verification;
  if (declared === undefined) return;
  throw new SynthError(
    `${where}.verification: only a webhook is verified this way, and this is a ${transport} ` +
      `channel. The host dials it, so there is no endpoint here for a provider to check and ` +
      `nothing would ever ask this question. Drop verification.`,
  );
}

/**
 * Reads a field the host walks to inside a request body: present, and spelt as a path.
 *
 * The host splits this on dots and takes one key at a time, so an empty step — a dot at
 * either end, or two in a row — names no key and stops the walk. The consequence differs per
 * field, which is why the caller supplies it: an unreadable `when.field` recognises no check,
 * and an unreadable `reply.echo` has nothing to send back.
 */
function checkBodyPath(value: unknown, where: string, consequence: string, example: string): void {
  if (typeof value !== "string" || value.trim() === "") {
    throw new SynthError(
      `${where}: ${quoted(value)} is not a field in the request body. ${consequence} Write the ` +
        `field it arrives in, like "${example}".`,
    );
  }
  if (value.split(".").some((step) => step.trim() === "")) {
    throw new SynthError(
      `${where}: "${value}" has an empty step in it. The host walks this path one key at a time ` +
        `and an empty step names no key, so the walk stops there. ${consequence} Write the keys ` +
        `joined by single dots, with no dot at either end, like "${example}".`,
    );
  }
}

/**
 * The rules a host-answered endpoint check has to satisfy.
 *
 * This is the one response the host writes out of a realm's own words, so all four parts of
 * it are checked here: what marks a request as the check, what the marker is compared
 * against, and which of the two answers is being sent — exactly one, never both and never
 * neither, because the host has no way to choose between two answers and no way to write
 * none. A constant answer is canonicalized on the way in as well, so a body carrying
 * something json cannot write is refused at the line that wrote it rather than at emit.
 */
function checkVerification(verification: CapturedWebhookVerification, where: string): void {
  const when = (verification as { when?: unknown }).when as { field?: unknown; equals?: unknown };
  if (typeof when !== "object" || when === null) {
    throw new SynthError(
      `${where}.when: a verification says which request is the provider's check, and this one ` +
        `says nothing. The host would answer every verified request with the verification reply ` +
        `and dispatch none of them. Write when with the field and the value that mark the check.`,
    );
  }
  checkBodyPath(
    when.field,
    `${where}.when.field`,
    "The host reads this out of every verified request to tell the provider's endpoint check " +
      "from a real event, so it would recognise no check — the provider would be answered with " +
      "an event receipt and would refuse to save the endpoint.",
    "type",
  );
  const equals = when.equals;
  if (typeof equals !== "string" && !(typeof equals === "number" && Number.isFinite(equals))) {
    throw new SynthError(
      `${where}.when.equals: ${quoted(equals)} is not a value a request body carries. The host ` +
        `compares what it read at when.field against this one, and it compares a word or a ` +
        `number and nothing else, so no request would ever match and the check would never be ` +
        `answered. Write what the provider sends, like "url_verification" or 1.`,
    );
  }

  const reply = (verification as { reply?: unknown }).reply as
    | { echo?: unknown; body?: unknown }
    | undefined;
  const echoed = reply !== null && typeof reply === "object" && reply.echo !== undefined;
  const constant = reply !== null && typeof reply === "object" && reply.body !== undefined;
  if (echoed && constant) {
    throw new SynthError(
      `${where}.reply: a reply is either a field echoed back or a constant, and this one is ` +
        `both. The host would hold two answers with no way to choose between them, and a ` +
        `provider accepts exactly one. Keep echo, or keep body.`,
    );
  }
  if (!echoed && !constant) {
    throw new SynthError(
      `${where}.reply: a reply with neither echo nor body says nothing back. The host answers ` +
        `this check itself and has nothing here to answer it with, so the provider would read an ` +
        `empty response and refuse to save the endpoint. Write echo with the field to send back, ` +
        `or body with the constant to send.`,
    );
  }
  if (echoed) {
    checkBodyPath(
      reply?.echo,
      `${where}.reply.echo`,
      "The host sends the string it finds there straight back as the answer, so it would have " +
        "nothing to send and the provider would refuse to save the endpoint.",
      "challenge",
    );
    return;
  }
  const canonical = JSON.stringify(canonicalize(reply?.body, `${where}.reply.body`));
  const bytes = new TextEncoder().encode(canonical).length;
  if (bytes > VERIFICATION_REPLY_BYTES) {
    throw new SynthError(
      `${where}.reply.body: this constant is ${bytes} bytes of json and the host writes at most ` +
        `${VERIFICATION_REPLY_BYTES}. An endpoint check wants a fixed acknowledgement back, not ` +
        `a payload, so the host would refuse to write this and the provider would never save the ` +
        `endpoint. Write the short constant the provider expects, like { type: 1 }.`,
    );
  }
}

/**
 * Checks a captured realm's `connecting()` declarations before anything is emitted.
 *
 * Three things live here today, and each one guards the emitter itself. The keys have to be
 * names a file can have, because each one becomes a file and the projection below has no
 * way to tell a key that escaped its directory from one that did not. The host-owned fields
 * have to be absent, because the projection copies the keys the host reads and would drop
 * one of these without a word — leaving a realm believing it turned reconnect off, or
 * shipped its own secret. And every duration has to be readable, or it lands in a file the
 * host then refuses at a distance from where it was written.
 *
 * The rest is everything the types cannot say. A template literal type fixes the spelling of
 * a duration but cannot compare two of them, so the floors and the cap are here. A union
 * cannot say that one member of it requires a field another does not, so which scheme needs
 * which field is here. And nothing in the type system can see across two blocks of the same
 * realm, so every name that has to resolve to something declared elsewhere — a source's
 * channel, a consumer's source, a handler — is checked here as well.
 *
 * Every refusal names the dotted path it happened at, quotes what was written there, says
 * what the host would do with it, and names the fix. Two say less than that on purpose: the
 * host-owned fields never echo the value, because two of them are where a secret would sit,
 * and a url is named by its origin alone, because a url can carry a password in front of
 * its host.
 */
export function checkConnecting(realm: CapturedRealm): void {
  const channels = channelEntries(realm);
  const sources = Object.entries(realm.sources ?? {});
  const consumers = Object.entries(realm.consumers ?? {});
  if (channels.length === 0 && sources.length === 0 && consumers.length === 0) return;

  // Every one of these declarations ends in a handler call, and the host only dispatches
  // one into a TypeScript guest today. Refused here rather than where the runtime is read,
  // because this is the field that makes the combination pointless.
  if (realm.runtime !== undefined && realm.runtime !== "typescript") {
    throw new SynthError(
      `$.runtime: "${realm.runtime}" cannot carry channels, sources or consumers. Each of them ` +
        `ends in a handler call and the host only dispatches those into a TypeScript guest this ` +
        `release, so it would load the capture and then read nothing that arrives. Write the ` +
        `handlers in TypeScript, or drop these declarations until the runtime mechanism lands.`,
    );
  }

  // A realm with no handlers block declares none, so every name is checked against the
  // empty set, the same answer `defineRealm` gives at compile time.
  const declaredHandlers = new Set(
    Object.entries(realm.handlers ?? {}).map(([verb, spec]) => `${spec.namespace}.${verb}`),
  );

  for (const [id, channel] of channels) {
    const where = `$.channels.${id}`;
    checkFileStem(id, where, "channels");
    refuseHostOwned(
      channel,
      where,
      HOST_OWNED_CHANNEL_FIELDS,
      "it tracks this across reconnects and across installations",
    );
    if (channel.transport === "websocket") {
      checkChannelHandler(channel, "onFrame", "websocket", where, declaredHandlers);
      refuseVerification(channel, where, "websocket");
      checkOrigin(channel.url, `${where}.url`);
      if (channel.keepalive !== undefined) {
        checkDuration(channel.keepalive.every, `${where}.keepalive.every`, {
          floor: "10s",
          tooOften:
            "A tick that often is traffic the provider reads as a flood, and it will throttle " +
            "or close the socket rather than answer it.",
          cap: {
            most: "5m",
            tooRarely:
              "A socket left silent that long is dropped as dead at the other end before the " +
              "tick lands, so the keepalive would be keeping nothing alive.",
          },
        });
        checkHandlerReference(
          channel.keepalive.handler,
          declaredHandlers,
          `${where}.keepalive.handler`,
          "The tick would be dispatched to a handler the host never grants, so the socket would " +
            "go quiet and be dropped.",
        );
      }
    } else if (channel.transport === "long-poll") {
      checkChannelHandler(channel, "onResponse", "long-poll", where, declaredHandlers);
      refuseVerification(channel, where, "long-poll");
      checkOrigin(channel.url, `${where}.url`);
      if (channel.every !== undefined) {
        checkDuration(channel.every, `${where}.every`, {
          floor: "1s",
          tooOften:
            "Fetching more than once a second is a request rate providers rate-limit rather " +
            "than serve.",
        });
      }
    } else if (channel.transport === "webhook") {
      checkChannelHandler(channel, "onRequest", "webhook", where, declaredHandlers);
      checkSignature(channel.signature, `${where}.signature`);
      if (channel.verification !== undefined) {
        checkVerification(channel.verification, `${where}.verification`);
      }
    }
  }

  const channelIds = new Set(channels.map(([id]) => id));
  for (const [id, source] of sources) {
    const where = `$.sources.${id}`;
    checkFileStem(id, where, "sources");
    refuseHostOwned(
      source,
      where,
      HOST_OWNED_SOURCE_FIELDS,
      "the file name is the name, and the rest belongs to one installation rather than to " +
        "the declaration every installation shares",
    );
    if (declaredString(source, "description") === undefined) {
      throw new SynthError(
        `${where}.description: a source needs a nonblank description for the owner who ` +
          `approves it. Blank words explain nothing about the events it will carry. Write ` +
          `a short description of the source.`,
      );
    }
    if (!channelIds.has(source.channel)) {
      throw new SynthError(
        `${where}.channel: "${source.channel}" is not a channel this realm declares (it has: ` +
          `${[...channelIds].sort().join(", ")}). Nothing would ever put an event into this ` +
          `source, so the owner would approve a stream that stays empty. Name one of those.`,
      );
    }
  }

  const sourceIds = new Set(sources.map(([id]) => id));
  for (const [id, consumer] of consumers) {
    const where = `$.consumers.${id}`;
    checkFileStem(id, where, "consumers");
    refuseHostOwned(
      consumer,
      where,
      HOST_OWNED_CONSUMER_FIELDS,
      "the file name is the name, and how far this consumer has read moves on its own, per " +
        "installation",
    );
    if (!sourceIds.has(consumer.source)) {
      throw new SynthError(
        `${where}.source: "${consumer.source}" is not a source this realm declares (it has: ` +
          `${[...sourceIds].sort().join(", ")}). A consumer subscribed to a source nothing ` +
          `declares never runs. Name one of those.`,
      );
    }
    checkHandlerReference(
      consumer.handler,
      declaredHandlers,
      `${where}.handler`,
      "The host would register this consumer against a handler it never grants, so the events " +
        "it exists to read would go nowhere.",
    );
  }

  // One name, one stream. The two blocks emit to different files, so nothing downstream
  // collides — it is the host's own set of source names that would hold two of these.
  for (const name of Object.keys(realm.dataPipes?.sources ?? {})) {
    if (sourceIds.has(name)) {
      throw new SynthError(
        `$.dataPipes.sources.${name}: "${name}" is declared at $.sources.${name} as well. The ` +
          `host reads both into one set of source names, so one would shadow the other and a ` +
          `consumer naming it would read a stream it was never pointed at. Rename one of them.`,
      );
    }
  }
}

/**
 * Checks the credentials the channels name, and records the ones that resolve so the rule
 * that refuses a credential nothing uses can see them.
 *
 * Both halves are here, and both have to be, because this runs before the credentials
 * themselves are built. A channel names a credential to authenticate with and a webhook
 * signature names one to verify with; those are real uses, and without recording them a
 * credential only the channels name would look like a secret asked of a person for no call.
 * Recorded against the path that named it, first mention winning, so a later refusal points
 * at where the reference was first made.
 *
 * The refusal is the other half. A name that resolves to nothing cannot be recorded as a
 * use, and if it were merely skipped the realm would emit a channel pointing at an id the
 * host has no secret for — it would be approved, installed, and fail at the first connection
 * with nothing to say why. An api that names an undeclared credential is refused for exactly
 * this reason; a channel is refused the same way and at the same point in the walk, which is
 * before the unused-credential rule can mistake the realm's real credentials for dead ones
 * and refuse it for the wrong thing.
 */
export function checkConnectingCredentials(
  realm: CapturedRealm,
  referenced: Map<string, string>,
): void {
  const note = (id: string, where: string, noun: string): void => {
    // Object.hasOwn, never a plain lookup. `credentials[id]` walks the prototype chain, so
    // "constructor" and "toString" come back defined against a realm that declares nothing
    // at all, and an `=== undefined` test would wave them straight through.
    if (realm.credentials === undefined || !Object.hasOwn(realm.credentials, id)) {
      throw new SynthError(
        `${where}: "${id}" is not declared in $.credentials. ${noun} can only name a credential ` +
          `its own realm declares — the owner is asked for a secret once per declared id at ` +
          `approval time, and there is nothing here to ask for. Declare it as ` +
          `$.credentials.${id}, or name one that is already declared.`,
      );
    }
    if (!referenced.has(id)) referenced.set(id, where);
  };
  for (const [id, channel] of channelEntries(realm)) {
    const where = `$.channels.${id}`;
    if (channel.transport === "webhook") {
      note(channel.signature.credential, `${where}.signature.credential`, "A webhook signature");
    } else {
      note(channel.credential, `${where}.credential`, "A channel");
    }
  }
}

/** The webhook signature layout, in the kebab-case the host reads. */
function renderSignature(
  signature: Extract<
    CapturedChannelSpec<string, string, string>,
    { transport: "webhook" }
  >["signature"],
): JsonObject {
  const out: JsonObject = {
    scheme: signature.scheme,
    credential: signature.credential,
    header: signature.header,
  };
  if (signature.prefix !== undefined) out.prefix = signature.prefix;
  if (signature.encoding !== undefined) out.encoding = signature.encoding;
  if (signature.template !== undefined) out.template = signature.template;
  if (signature.timestamp !== undefined) {
    const timestamp: JsonObject = { header: signature.timestamp.header };
    if (signature.timestamp.toleranceSeconds !== undefined) {
      timestamp["tolerance-seconds"] = signature.timestamp.toleranceSeconds;
    }
    if (signature.timestamp.unit !== undefined) timestamp.unit = signature.timestamp.unit;
    out.timestamp = timestamp;
  }
  return out;
}

/**
 * The endpoint check, in the kebab-case the host reads — which here is the same words the
 * realm wrote, because none of them is two words.
 */
function renderVerification(verification: CapturedWebhookVerification): JsonObject {
  const reply: JsonObject =
    verification.reply.echo !== undefined
      ? { echo: verification.reply.echo }
      : { body: verification.reply.body };
  return { when: { field: verification.when.field, equals: verification.when.equals }, reply };
}

/**
 * One channel, projected onto the keys the host reads.
 *
 * Only the declared keys are copied, and only the ones the transport actually has: the
 * captured channel shape is closed, so there is no pass-through tail the way the legacy
 * connector shape has. An absent optional field is left out rather than written as null,
 * which is what lets the host tell "the realm said nothing" from "the realm said no".
 */
function renderChannel(
  channel: CapturedChannelSpec<string, string, string>,
  where: string,
): JsonObject {
  if (channel.transport === "websocket") {
    const out: JsonObject = {
      transport: "websocket",
      url: channel.url,
      credential: channel.credential,
      "on-frame": channel.onFrame,
    };
    if (channel.keepalive !== undefined) {
      out.keepalive = { every: channel.keepalive.every, handler: channel.keepalive.handler };
    }
    if (channel.handshake !== undefined) {
      out.handshake = { operation: channel.handshake.operation, field: channel.handshake.field };
    }
    return out;
  }
  if (channel.transport === "long-poll") {
    const out: JsonObject = {
      transport: "long-poll",
      url: channel.url,
      credential: channel.credential,
      "on-response": channel.onResponse,
    };
    // The one field here that is written when the realm said nothing. A poll with no
    // interval is not a state the host can act on, and leaving the key out would push the
    // choice onto whatever the host happens to default to — so the file says how often it
    // actually fetches, and two installations of the same realm fetch alike.
    out.every = channel.every ?? DEFAULT_EVERY;
    return out;
  }
  if (channel.transport === "webhook") {
    const out: JsonObject = {
      transport: "webhook",
      "on-request": channel.onRequest,
      signature: renderSignature(channel.signature),
    };
    if (channel.verification !== undefined) {
      out.verification = renderVerification(channel.verification);
    }
    return out;
  }
  const transport = (channel as { transport?: unknown }).transport;
  throw new SynthError(
    `${where}.transport: "${String(transport)}" is not a way the host can carry a channel. ` +
      `Write "websocket", "long-poll" or "webhook".`,
  );
}

/** One source: which channel it comes off, and what the owner is being asked to approve. */
function renderSource(source: CapturedSourceSpec<string>): JsonObject {
  return { channel: source.channel, description: source.description };
}

/** One consumer: the source it reads, the handler that reads it, and whether it may chat. */
function renderConsumer(consumer: CapturedConsumerSpec<string, string>): JsonObject {
  const out: JsonObject = { source: consumer.source, handler: consumer.handler };
  if (consumer.assistant !== undefined) out.assistant = consumer.assistant;
  return out;
}

/**
 * Emits a captured realm's channels, sources and consumers — one file each, under
 * `channels/`, `sources/` and `consumers/`.
 *
 * No file carries its own `name`. The file name is the name, and the host reads it from
 * the stem. That is a change from the legacy `channels/*.yml`, which writes `name:` into
 * the document as well; two places to spell one name is two places for them to disagree.
 *
 * Everything is canonicalized on the way out, so keys land sorted and the same declaration
 * always produces the same bytes.
 */
export function emitConnecting(realm: CapturedRealm): RenderedFile[] {
  checkConnecting(realm);
  const files: RenderedFile[] = [];
  for (const [id, channel] of channelEntries(realm)) {
    const where = `$.channels.${id}`;
    files.push({
      kind: "rendered",
      path: `channels/${id}.yml`,
      value: canonicalize(renderChannel(channel, where), where) as JsonValue,
    });
  }
  for (const [id, source] of Object.entries(realm.sources ?? {})) {
    files.push({
      kind: "rendered",
      path: `sources/${id}.yml`,
      value: canonicalize(renderSource(source), `$.sources.${id}`) as JsonValue,
    });
  }
  for (const [id, consumer] of Object.entries(realm.consumers ?? {})) {
    files.push({
      kind: "rendered",
      path: `consumers/${id}.yml`,
      value: canonicalize(renderConsumer(consumer), `$.consumers.${id}`) as JsonValue,
    });
  }
  return files;
}
