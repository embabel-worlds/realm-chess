import type { JsonValue } from "@embabel/realm-types";
import { SynthError } from "./canonical.ts";

/**
 * Checks a rendered document against the field set the engine actually reads.
 *
 * Why this exists: realm-ts hand-maintains a mirror of shapes the engine reads with
 * Jackson, and a hand-maintained mirror drifts. `TypeSpec.relationships` was the proof
 * — it typechecked, synth emitted it, and `TypeEntry` has no such field. Nothing in
 * between noticed. So a key nobody reads shipped, and the realm quietly did less than
 * its author wrote.
 *
 * There is no second gate to catch it. A realm's YAML is read leniently everywhere:
 * a file that fails to parse is logged and skipped, never failing world load. If synth
 * lets a bad key through, the author's next signal is missing data. So the check runs
 * here, over the rendered value — the exact bytes that go on the wire — rather than
 * over the TypeScript object, because what matters is what lands in the file however
 * it got there.
 *
 * The shapes below are transcribed from the engine's Kotlin, each with the file it
 * came from. Transcription is still by hand, but now it is in ONE place, it is
 * executable, and adding a field to the TypeScript without adding it here fails the
 * build instead of shipping.
 */

/** What the engine will accept at one position in a document. */
export type WireShape =
  /** Any JSON the engine takes as-is: a scalar, or a free-form blob it never introspects. */
  | { kind: "value" }
  /**
   * A string, number or boolean and nothing else. This is what a shorthand form is —
   * `properties: { title: "..." }`, `userAnchor: false` — and saying so matters, because
   * a branch that accepts anything would swallow a malformed object form whole and the
   * typo in it would never be reported.
   */
  | { kind: "scalar" }
  /** A fixed set of keys. Anything else is refused by name. */
  | {
      kind: "object";
      /** The engine type this mirrors, so a refusal can say which one. */
      name: string;
      of: Record<string, WireShape>;
      /** Keys the engine has no default for. Omitting one fails its deserializer. */
      required?: readonly string[];
      /**
       * The engine reads this through a custom deserializer that picks keys off the
       * node, so an unknown key is silently ignored rather than refused. That is worse,
       * not better: the value vanishes with no error anywhere. We still refuse it.
       */
      extraKeysVanishSilently?: boolean;
      /** Extra keys are meaningful here — a rule's own arguments, say — so let them through. */
      open?: boolean;
      /** Exactly one of the declared keys may be present. */
      exactlyOne?: boolean;
    }
  /**
   * A string the engine reads through a length-limited, pattern-matched accessor. The
   * captured readers do exactly that for every one of their fields, so a value that
   * merely *is* a string is not enough — an identifier with a capital letter in it, or
   * a description one character too long, makes the reader refuse the whole file. Say
   * the limit here and synth refuses it while the author can still see why.
   */
  | {
      kind: "text";
      /** The reader constant this mirrors, so a refusal can name it. */
      name: string;
      /** The shape the reader's own regex demands, anchored. */
      pattern?: RegExp;
      /** Longest string the reader's `string(node, limit)` call accepts. */
      max?: number;
      /** The reader accepts an empty string here, which it normally refuses. */
      emptyOk?: boolean;
      /** Values the reader refuses outright even though they match the pattern. */
      never?: readonly string[];
    }
  /** A whole number in a closed range. The readers check integrality, not just numberhood. */
  | { kind: "integer"; name: string; min: number; max: number }
  /**
   * A list of one shape. `min`/`max` are the reader's own bounds on how many entries it
   * will read; `unique` and `uniqueBy` are the duplicate checks it makes before using
   * them.
   */
  | {
      kind: "list";
      of: WireShape;
      min?: number;
      max?: number;
      /** No two entries may be equal. */
      unique?: boolean;
      /** No two entries may share a value for any of these fields. */
      uniqueBy?: readonly string[];
    }
  /** A mapping with author-chosen keys, all holding the same shape. */
  | {
      kind: "map";
      of: WireShape;
      exactlyOne?: boolean;
      /** Most keys the reader will read. */
      max?: number;
      /** The shape every key has to have, anchored. */
      keyPattern?: RegExp;
      /** What to call the keys in a refusal — "header name", say. */
      keyName?: string;
      /**
       * Refuse two keys that differ only in case. This one is synth's own refusal, not a
       * reader's: the reader keeps both spellings, but an HTTP header name means the same
       * thing whichever case it is written in, so shipping `X-Key` and `x-key` together
       * leaves it undecided which value a call actually sends.
       */
      caseInsensitiveKeys?: boolean;
    }
  /** Several accepted forms — a string shorthand and its object form, typically. */
  | { kind: "either"; of: readonly WireShape[] }
  /** A closed set of literal values. */
  | { kind: "enum"; name: string; of: readonly string[] };

const value: WireShape = { kind: "value" };
const scalar: WireShape = { kind: "scalar" };
/** A mapping with author-chosen keys. The engine never introspects the values, so neither do we. */
const mapping: WireShape = { kind: "map", of: value };

/** `ValidationRuleSpec` — PropertySpec.kt. A bare rule name, or a mapping naming the rule plus its own arguments. */
const VALIDATION_RULE: WireShape = {
  kind: "either",
  of: [
    scalar,
    {
      kind: "object",
      name: "ValidationRuleSpec",
      of: { rule: value },
      required: ["rule"],
      open: true,
    },
  ],
};

/** `PropertyValues` — PropertySpec.kt. A bare list is shorthand for `{ list: [...] }`. */
const PROPERTY_VALUES: WireShape = {
  kind: "either",
  of: [
    { kind: "list", of: value },
    {
      kind: "object",
      name: "PropertyValues",
      of: { source: value, list: { kind: "list", of: value }, max: value },
    },
  ],
};

/**
 * `PropertySpec` — PropertySpec.kt. A bare string is the description shorthand.
 *
 * `annotatable` and `annotationVersion` are not constructor parameters; the custom
 * deserializer reads them off the node and folds them into `metadata`. They are real
 * wire fields all the same, which is exactly why they need to be listed here.
 */
const PROPERTY_SPEC: WireShape = {
  kind: "either",
  of: [
    scalar,
    {
      kind: "object",
      name: "PropertySpec",
      extraKeysVanishSilently: true,
      of: {
        description: value,
        type: value,
        cardinality: { kind: "enum", name: "Cardinality", of: ["OPTIONAL", "ONE", "LIST", "SET"] },
        validation: { kind: "list", of: VALIDATION_RULE },
        values: PROPERTY_VALUES,
        metadata: mapping,
        identity: value,
        required: value,
        annotatable: value,
        annotationVersion: value,
      },
    },
  ],
};

/** `UserAnchorSpec` — UserAnchorSpec.kt. `false` disables the anchor entirely. */
const USER_ANCHOR: WireShape = {
  kind: "either",
  of: [
    scalar,
    {
      kind: "object",
      name: "UserAnchorSpec",
      extraKeysVanishSilently: true,
      of: {
        predicate: value,
        direction: { kind: "enum", name: "AnchorDirection", of: ["from-entry", "from-user"] },
      },
      required: ["predicate"],
    },
  ],
};

/** `PagingSpec` — PopulationSpec.kt. */
const PAGING: WireShape = {
  kind: "object",
  name: "PagingSpec",
  of: {
    param: value,
    sizeParam: value,
    size: value,
    maxPages: value,
    startPage: value,
    style: { kind: "enum", name: "PagingSpec.style", of: ["page", "cursor"] },
    cursorParam: value,
    cursorPath: value,
  },
};

/** `PopulationSpec` — PopulationSpec.kt. */
const POPULATION: WireShape = {
  kind: "object",
  name: "PopulationSpec",
  of: {
    sourceKind: value,
    operation: value,
    args: mapping,
    paging: PAGING,
    records: value,
    id: value,
    cadenceMinutes: value,
  },
  required: ["sourceKind", "operation"],
};

/** Which way a virtual edge points. `JoinDirection` — VirtualJoinSpec.kt. */
const JOIN_DIRECTION: WireShape = {
  kind: "enum",
  name: "JoinDirection",
  of: ["FROM_ANCHOR", "TO_ANCHOR"],
};

/** `JoinRuleSpec` — JoinPolicySpec.kt. A bare `none`, or a single-key object naming the rule. */
const JOIN_RULE: WireShape = {
  kind: "either",
  of: [
    scalar,
    {
      kind: "object",
      name: "JoinRuleSpec",
      exactlyOne: true,
      of: {
        key: {
          kind: "object",
          name: "KeyRule",
          of: { on: value, to: value, ci: value, confidence: value },
          required: ["on", "to"],
        },
        ask: {
          kind: "either",
          of: [
            scalar,
            {
              kind: "object",
              name: "AskRule",
              of: { question: value, options: { kind: "list", of: value }, confidence: value },
              required: ["question"],
            },
          ],
        },
        none: value,
      },
    },
  ],
};

/** `BroughtEdge` — VirtualJoinSpec.kt. */
const BROUGHT_EDGE: WireShape = {
  kind: "object",
  name: "BroughtEdge",
  of: {
    childType: value,
    relationship: value,
    direction: JOIN_DIRECTION,
    records: value,
    id: value,
    project: mapping,
    internal: value,
  },
  required: ["childType", "relationship", "records", "id"],
};

/** `VirtualJoinSpec` — VirtualJoinSpec.kt. */
const VIRTUAL_JOIN: WireShape = {
  kind: "object",
  name: "VirtualJoinSpec",
  of: {
    anchorLabel: value,
    relationship: value,
    direction: JOIN_DIRECTION,
    keyField: value,
    producerKeyFields: { kind: "list", of: value },
    recordKeyField: value,
    materializedKeyField: value,
    persistMinted: value,
    // A `JoinPolicySpec` is a plain data class wrapping `rules`, with no custom
    // deserializer, so the wrapper object is not optional on the wire. The engine's own
    // doc comment shows a bare list under `policy:`, and that form does not parse.
    policy: {
      kind: "object",
      name: "JoinPolicySpec",
      of: { rules: { kind: "list", of: JOIN_RULE } },
    },
    producer: value,
    via: value,
    description: value,
    brings: { kind: "list", of: BROUGHT_EDGE },
    maxAnchors: value,
    maxFanoutTotal: value,
    persist: value,
    // `ResolutionRuleSpec` — VirtualJoinSpec.kt. A bare rule name, or a single-key
    // object whose key is the rule and whose value is its settings.
    resolve: {
      kind: "list",
      of: { kind: "either", of: [scalar, { kind: "map", of: mapping, exactlyOne: true }] },
    },
    writeThrough: value,
    refreshAfter: value,
  },
  required: ["anchorLabel", "relationship", "keyField", "producer"],
};

/** `ConnectedAccountIdentitySpec` — ConnectedAccountIdentitySpec.kt. */
const IDENTITY_BRIDGE: WireShape = {
  kind: "object",
  name: "ConnectedAccountIdentitySpec",
  of: { provider: value, relationship: value, linkFrom: value },
  required: ["provider", "relationship"],
};

/** `MethodBindingSpec` — MethodBindingSpec.kt. */
const METHOD_BINDING: WireShape = {
  kind: "object",
  name: "MethodBindingSpec",
  of: {
    name: value,
    gatewayTool: value,
    description: value,
    params: {
      kind: "list",
      of: {
        kind: "object",
        name: "MethodParamSpec",
        of: { name: value, type: value },
        required: ["name"],
      },
    },
    args: mapping,
    returns: value,
  },
  required: ["name", "gatewayTool"],
};

/** `RetrievalBindingSpec` — RetrievalBindingSpec.kt. */
const RETRIEVAL: WireShape = {
  kind: "object",
  name: "RetrievalBindingSpec",
  of: { operation: value, fieldMap: mapping, nameFrom: value },
  required: ["operation"],
};

/** `CypherExample` — TypeEntry.kt. */
const CYPHER_EXAMPLE: WireShape = {
  kind: "object",
  name: "CypherExample",
  of: { q: value, cypher: value },
  required: ["q", "cypher"],
};

/**
 * `TypeEntry` — TypeEntry.kt, the whole of it.
 *
 * This is the list a `types/*.yml` entry is held to. Add a field to `TypeSpec` without
 * adding it here and synth refuses the emitted document, which is the point.
 */
export const TYPE_ENTRY: WireShape = {
  kind: "object",
  name: "TypeEntry",
  of: {
    name: value,
    description: value,
    properties: { kind: "map", of: PROPERTY_SPEC },
    parents: { kind: "list", of: value },
    visibility: { kind: "enum", name: "TypeVisibility", of: ["public", "internal"] },
    userAnchor: USER_ANCHOR,
    population: POPULATION,
    virtualJoins: { kind: "list", of: VIRTUAL_JOIN },
    identityBridge: IDENTITY_BRIDGE,
    methods: { kind: "list", of: METHOD_BINDING },
    retrieval: RETRIEVAL,
    partial: value,
    examples: { kind: "list", of: CYPHER_EXAMPLE },
    perspective: value,
  },
  required: ["name"],
};

/** `IntrospectionConfig` — ApiEntry.kt. How the OAuth callback learns which account authorised. */
const OAUTH2_INTROSPECTION: WireShape = {
  kind: "object",
  name: "IntrospectionConfig",
  of: {
    url: value,
    method: value,
    auth: value,
    "account-id-field": value,
    "display-name-field": value,
  },
  required: ["url", "account-id-field"],
};

/**
 * `OAuth2AuthConfig` — ApiEntry.kt.
 *
 * `client-secret` is missing on purpose, and it is the one field here worth explaining.
 * The engine's type does have it, so this is not a transcription slip — but
 * `OAuth2ConfigResolver` never reads it. The classic flow takes the client id and secret
 * from the user's wallet or the deployment vault, keyed by provider, and the PKCE flow
 * sends no secret at all. So a secret written here is plaintext key material in a
 * committed file that also does nothing, and synth refuses it by name before this check
 * ever sees it.
 */
const OAUTH2_CONFIG: WireShape = {
  kind: "object",
  name: "OAuth2AuthConfig",
  of: {
    "client-id": value,
    "auth-url": value,
    "token-url": value,
    scopes: value,
    provider: value,
    identity: OAUTH2_INTROSPECTION,
    "webhook-tenancy": {
      kind: "object",
      name: "WebhookTenancyHook",
      of: { store: value },
      required: ["store"],
    },
    pkce: value,
    "install-url": value,
  },
};

/**
 * `ApiEntry` — ApiEntry.kt.
 *
 * `realmName` is deliberately absent: it carries `@field:JsonIgnore`, so the loader
 * stamps it and Jackson refuses to read it from YAML. A realm that wrote it would be
 * writing a key that cannot land.
 *
 * `mutations` is a body property rather than a constructor parameter — the constructor
 * hit an architecture rule's parameter limit — but it is a plain `var` with a setter, so
 * Jackson binds it like any other field.
 */
export const API_ENTRY: WireShape = {
  kind: "object",
  name: "ApiEntry",
  of: {
    url: value,
    name: value,
    type: value,
    auth: value,
    "token-env": value,
    headers: { kind: "map", of: scalar },
    oauth2: OAUTH2_CONFIG,
    tags: { kind: "list", of: value },
    "operation-ids": { kind: "list", of: value },
    mutations: { kind: "list", of: value },
  },
  required: ["url"],
};

/**
 * `CachePolicy` — CachePolicy.kt. Polymorphic on `kind`, and most variants are
 * field-less singletons: `kind: session` and nothing else.
 */
const CACHE_POLICY: WireShape = {
  kind: "either",
  of: [
    {
      kind: "object",
      name: "TtlCache",
      of: { kind: value, seconds: value, negativeTtlSeconds: value },
      required: ["kind", "seconds"],
    },
    {
      kind: "object",
      name: "CachePolicy",
      of: {
        kind: {
          kind: "enum",
          name: "CachePolicy.kind",
          of: ["none", "fresh", "session", "immutable", "graph"],
        },
      },
      required: ["kind"],
    },
  ],
};

/** `KeyTransformSpec` — RemoteRepository.kt. */
const KEY_TRANSFORM: WireShape = {
  kind: "object",
  name: "KeyTransformSpec",
  of: {
    kind: value,
    instruction: value,
    examples: {
      kind: "list",
      of: {
        kind: "object",
        name: "KeyTransformExample",
        of: { input: value, output: value },
        required: ["input", "output"],
      },
    },
    cacheSeconds: value,
  },
  required: ["instruction"],
};

/**
 * The fields a `RemoteRepository` (RemoteRepository.kt) can be given from realm.ts.
 *
 * Shorter than the Kotlin class, and knowingly so. `keyArg`, `keyType`, `keyJoin`,
 * `edgeProject`, `maxKeysPerCall`, `pushdown`, `requiresFilter`, `emptyErrorPatterns`,
 * `paging`, `partition`, `governance`, `cost` and `follow` are all real fields nothing
 * in realm-ts can produce yet, so listing them here would weaken the check without
 * buying any coverage: an author adding one to the TypeScript would then sail past this
 * gate. Add the field to `RemoteProducer` and to this list in the same change.
 *
 * What is NOT here for a different reason: `edgeType`, `identityField`, `anchorKeyField`
 * and `volatility`. The remote producer has no such fields at all. They belong to the
 * generative and aggregate kinds, and to the join that names the producer.
 */
const REMOTE_FIELDS: Record<string, WireShape> = {
  name: value,
  kind: value,
  operation: value,
  args: mapping,
  keyTemplate: value,
  keyArgs: { kind: "list", of: value },
  keySplit: value,
  keyTransform: KEY_TRANSFORM,
  batchSafe: value,
  records: value,
  echoKeyAs: value,
  project: mapping,
  cache: CACHE_POLICY,
};

/** `RemoteRepository` as a whole producer entry — `kind: remote` in a producers file. */
const REMOTE_PRODUCER: WireShape = {
  kind: "object",
  name: "RemoteRepository",
  of: REMOTE_FIELDS,
  required: ["name", "kind", "operation"],
};

/**
 * `GenerativeProducer.resolveVia` — a whole `RemoteRepository` nested inside the
 * generative producer, `kind` and all. The engine's own movie realm writes it that way.
 */
const RESOLVE_VIA: WireShape = {
  kind: "object",
  name: "RemoteRepository",
  of: REMOTE_FIELDS,
  required: ["name", "kind", "operation"],
};

/** `GeneratorSpec` — GenerativeProducer.kt. Polymorphic on `kind`: an LLM or a function. */
const GENERATOR: WireShape = {
  kind: "either",
  of: [
    {
      kind: "object",
      name: "LlmGenerator",
      of: {
        kind: value,
        prompt: value,
        tools: { kind: "list", of: value },
        role: value,
        temperature: value,
      },
      required: ["kind", "prompt"],
    },
    {
      kind: "object",
      name: "FunctionGenerator",
      of: { kind: value, operation: value },
      required: ["kind", "operation"],
    },
  ],
};

/**
 * `GenerativeProducer` — GenerativeProducer.kt.
 *
 * `edgeType` and `identityField` have no Kotlin defaults, so leaving either out fails
 * the deserializer and takes the whole producers file with it.
 */
const GENERATIVE_PRODUCER: WireShape = {
  kind: "object",
  name: "GenerativeProducer",
  of: {
    name: value,
    kind: value,
    generator: GENERATOR,
    edgeType: value,
    identityField: value,
    anchorKeyField: value,
    nameField: value,
    resolveVia: RESOLVE_VIA,
    resolveRelaxation: value,
    volatility: { kind: "enum", name: "Volatility", of: ["static", "slow", "volatile"] },
    defaultWant: value,
    confidenceFloor: value,
    supportsExclusion: value,
    records: value,
    cache: CACHE_POLICY,
  },
  required: ["name", "kind", "generator", "edgeType", "identityField"],
};

/** `CollectSpec` — AggregateProducer.kt. `targetLabel`, `via` and `text` have no defaults. */
const COLLECT_SPEC: WireShape = {
  kind: "object",
  name: "CollectSpec",
  of: {
    targetLabel: value,
    via: value,
    text: value,
    anchorLabel: value,
    where: value,
    limit: value,
    anchorKeyProperty: value,
    incoming: value,
  },
  required: ["targetLabel", "via", "text"],
};

/**
 * `ReduceSpec` — AggregateProducer.kt.
 *
 * `hint` is left out: the interpreter sets it per query from the edge's own directives,
 * so a realm pinning it would be writing over something that gets replaced anyway.
 */
const REDUCE_SPEC: WireShape = {
  kind: "object",
  name: "ReduceSpec",
  of: {
    using: value,
    into: value,
    args: { kind: "list", of: value },
    role: value,
    temperature: value,
    wordcount: value,
  },
};

/**
 * `AggregateProducer` — AggregateProducer.kt.
 *
 * `targetLabel` and `demand` are left out on purpose. Both are real constructor
 * parameters, and both say "NOT for YAML" in the Kotlin: the interpreter stamps
 * `targetLabel` from the join's target type at query time and derives `demand` from the
 * query's LIMIT, so an authored value is overwritten before it is ever read.
 */
const AGGREGATE_PRODUCER: WireShape = {
  kind: "object",
  name: "AggregateProducer",
  of: {
    name: value,
    kind: value,
    edgeType: value,
    collect: COLLECT_SPEC,
    reduce: REDUCE_SPEC,
    identityField: value,
    anchorKeyField: value,
    records: value,
    cache: CACHE_POLICY,
  },
  required: ["name", "kind", "edgeType", "collect", "reduce"],
};

/**
 * The producer shapes, keyed by the `kind` that picks between them on the wire.
 *
 * A producers file is read as a polymorphic list, so the entry's own `kind` decides
 * which engine class binds it — and the three classes share far less than they look
 * like they do. That is the whole reason this is a lookup rather than one merged shape:
 * `volatility: static` is perfectly good on a generative producer and reaches nothing at
 * all on a remote one.
 */
export const PRODUCER_SPECS: Record<string, WireShape> = {
  remote: REMOTE_PRODUCER,
  generative: GENERATIVE_PRODUCER,
  aggregate: AGGREGATE_PRODUCER,
};

/** `PromptedActionSpec` — PromptedActionSpec.kt. One object per file under `actions/`. */
export const PROMPTED_ACTION_SPEC: WireShape = {
  kind: "object",
  name: "PromptedActionSpec",
  of: {
    stepType: value,
    name: value,
    description: value,
    llm: value,
    inputTypeNames: { kind: "list", of: value },
    outputTypeName: value,
    pre: { kind: "list", of: value },
    post: { kind: "list", of: value },
    cost: value,
    value: value,
    canRerun: value,
    prompt: value,
    toolGroups: { kind: "list", of: value },
    tools: { kind: "list", of: value },
    references: { kind: "list", of: value },
    nullable: value,
    export: value,
  },
  required: ["name", "description", "inputTypeNames", "outputTypeName", "prompt"],
};

/** `GoalSpec` — GoalSpec.kt. One object per file under `goals/`. */
export const GOAL_SPEC: WireShape = {
  kind: "object",
  name: "GoalSpec",
  of: {
    stepType: value,
    name: value,
    description: value,
    outputTypeName: value,
    export: value,
  },
  required: ["name", "description", "outputTypeName"],
};

/**
 * Every regex, length limit and count below is transcribed from the Kotlin reader named
 * on the shape that uses it. A captured realm's files are not read leniently: one field
 * out of shape and the reader throws `CapturedInvocationRefused` for the whole file, so
 * an author who writes `summarizeCatalog` where the reader wants `summarize-catalog`
 * gets a realm that installs and then silently has no goals. These limits are the only
 * place that gets caught while the author is still looking at their own definition.
 */

/** A version stamp synth writes itself. Every captured reader accepts exactly 1. */
const CAPTURED_VERSION: WireShape = { kind: "integer", name: "version", min: 1, max: 1 };

/** `Module.function`, the only handler reference shape any captured reader accepts. */
const CAPTURED_HANDLER: WireShape = {
  kind: "text",
  name: "handler",
  pattern: /^[A-Za-z_$][A-Za-z0-9_$]*\.[A-Za-z_$][A-Za-z0-9_$]*$/,
  max: 256,
};

/** `CapturedConsumerManifest.Document` — the one root `data-pipes.yml` document. */
const CAPTURED_DATA_PIPE_SOURCE: WireShape = {
  kind: "object",
  name: "CapturedDataPipeSource",
  of: {
    name: { kind: "text", name: "name", max: 256 },
    stream: { kind: "text", name: "stream", max: 256 },
    type: { kind: "text", name: "type", max: 256 },
  },
  required: ["name", "stream", "type"],
};

const CAPTURED_DATA_PIPE_CONSUMER: WireShape = {
  kind: "object",
  name: "CapturedDataPipeConsumer",
  of: {
    name: { kind: "text", name: "name", max: 256 },
    handler: CAPTURED_HANDLER,
  },
  required: ["name", "handler"],
};

export const CAPTURED_DATA_PIPES: WireShape = {
  kind: "object",
  name: "CapturedConsumerManifest.Document",
  of: {
    version: CAPTURED_VERSION,
    sources: { kind: "list", of: CAPTURED_DATA_PIPE_SOURCE, max: 128, uniqueBy: ["name"] },
    consumers: { kind: "list", of: CAPTURED_DATA_PIPE_CONSUMER, max: 128, uniqueBy: ["name"] },
  },
  required: ["version"],
};

/** A description: optional everywhere, may be empty, and cut off at 512 characters. */
const CAPTURED_DESCRIPTION: WireShape = {
  kind: "text",
  name: "description",
  max: 512,
  emptyOk: true,
};

/**
 * `CapturedGoalDeclaration` — CapturedGoalManifest.kt. One object per file under
 * `goals/`, at the same path a conventional `GoalSpec` uses but a disjoint shape —
 * `execution` picks which of the two a given realm ever emits, so the two never
 * collide on one realm.
 */
export const CAPTURED_GOAL_SPEC: WireShape = {
  kind: "object",
  name: "CapturedGoalDeclaration",
  of: {
    version: CAPTURED_VERSION,
    goal: { kind: "text", name: "GOAL_NAME", pattern: /^[a-z][a-z0-9-]{0,63}$/, max: 64 },
    handler: CAPTURED_HANDLER,
    input: { kind: "text", name: "TYPE_NAME", pattern: /^[A-Z][A-Za-z0-9]{0,63}$/, max: 64 },
    // The reader refuses a goal that claims to produce UserInput: that is the type the
    // planner starts from, so a goal producing it would satisfy itself.
    output: {
      kind: "text",
      name: "TYPE_NAME",
      pattern: /^[A-Z][A-Za-z0-9]{0,63}$/,
      max: 64,
      never: ["UserInput"],
    },
    description: CAPTURED_DESCRIPTION,
  },
  required: ["version", "goal", "handler", "input", "output"],
};

/** `CapturedTriggerDeclaration` — CapturedTriggerManifest.kt. One object per file under `triggers/`. */
export const TRIGGER_SPEC: WireShape = {
  kind: "object",
  name: "CapturedTriggerDeclaration",
  of: {
    version: CAPTURED_VERSION,
    trigger: { kind: "text", name: "TRIGGER_NAME", pattern: /^[a-z][a-z0-9-]{0,63}$/, max: 64 },
    source: {
      kind: "text",
      name: "BINDING_NAME",
      pattern: /^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/,
      max: 128,
    },
    consumer: {
      kind: "text",
      name: "BINDING_NAME",
      pattern: /^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/,
      max: 128,
    },
    mode: { kind: "enum", name: "CapturedTriggerDeclaration.Mode", of: ["observe", "apply"] },
    input: {
      kind: "list",
      max: 7,
      unique: true,
      of: {
        kind: "enum",
        name: "CapturedTriggerDeclaration.input",
        of: ["offset", "eventId", "streamId", "type", "occurredAt", "gap", "payload"],
      },
    },
    description: CAPTURED_DESCRIPTION,
  },
  required: ["version", "trigger", "source", "consumer", "mode"],
};

/** A plain Kotlin-side identifier: what the producer reader reads every join field and its key argument as. */
const CAPTURED_IDENTIFIER: WireShape = {
  kind: "text",
  name: "IDENTIFIER",
  pattern: /^[A-Za-z_][A-Za-z0-9_]{0,63}$/,
  max: 64,
};

/** `CapturedProducerManifest.Join` — CapturedProducerManifest.kt. */
const CAPTURED_PRODUCER_JOIN: WireShape = {
  kind: "object",
  name: "CapturedProducerManifest.Join",
  of: {
    targetLabel: CAPTURED_IDENTIFIER,
    anchorLabel: CAPTURED_IDENTIFIER,
    relationship: CAPTURED_IDENTIFIER,
    keyField: CAPTURED_IDENTIFIER,
    recordKeyField: CAPTURED_IDENTIFIER,
  },
  required: ["targetLabel", "anchorLabel", "relationship", "keyField", "recordKeyField"],
};

/** A handler argument the host adds to a producer call: the page cursor, or a pushed-down filter. */
const CAPTURED_ARGUMENT: WireShape = {
  kind: "text",
  name: "PAGE_ARGUMENT",
  pattern: /^[a-z][A-Za-z0-9]{0,63}$/,
  max: 64,
};

/** `CapturedProducerManifest.Page` — CapturedProducerManifest.kt. */
const CAPTURED_PRODUCER_PAGE: WireShape = {
  kind: "object",
  name: "CapturedProducerManifest.Page",
  of: {
    argument: CAPTURED_ARGUMENT,
    maxPages: { kind: "integer", name: "maxPages", min: 1, max: 16 },
  },
  required: ["argument", "maxPages"],
};

/** `CapturedProducerManifest.Pushdown` — CapturedProducerManifest.kt. */
const CAPTURED_PRODUCER_PUSHDOWN: WireShape = {
  kind: "object",
  name: "CapturedProducerManifest.Pushdown",
  of: {
    property: CAPTURED_IDENTIFIER,
    argument: CAPTURED_ARGUMENT,
  },
  required: ["property", "argument"],
};

/** `CapturedProducerManifest.Declaration` — CapturedProducerManifest.kt. One object per file under `producers/`. */
export const CAPTURED_PRODUCER_SPEC: WireShape = {
  kind: "object",
  name: "CapturedProducerManifest.Declaration",
  of: {
    version: CAPTURED_VERSION,
    name: { kind: "text", name: "NAME", pattern: /^[a-z][a-z0-9._-]{0,63}$/, max: 64 },
    handler: CAPTURED_HANDLER,
    keyArgument: CAPTURED_IDENTIFIER,
    joins: { kind: "list", of: CAPTURED_PRODUCER_JOIN, min: 1, max: 8, unique: true },
    page: CAPTURED_PRODUCER_PAGE,
    pushdown: { kind: "list", of: CAPTURED_PRODUCER_PUSHDOWN, min: 0, max: 16, unique: true },
  },
  required: ["version", "name", "handler", "keyArgument", "joins"],
};

/** An `operation-ids` entry: the reader's own `identifier` regex, which allows dashes an OpenAPI id may carry. */
const CAPTURED_OPERATION_ID: WireShape = {
  kind: "text",
  name: "identifier",
  pattern: /^[A-Za-z_][A-Za-z0-9_-]{0,63}$/,
  max: 64,
};

/**
 * The host's rule for a captured api's document name: a bare filename of at most 64
 * characters ending ".json", ".yaml" or ".yml". No path, never a remote url.
 */
export const CAPTURED_API_FILENAME = /^[A-Za-z0-9_-]{1,64}\.(json|yaml|yml)$/;

/**
 * `CapturedApiContract`'s entry shape — CapturedApiContract.kt. One entry in the same
 * `apis/apis.yml` list a conventional realm writes, but with the narrower allowlist
 * that reader enforces: no `oauth2`, `tags`, or `mutations`, and `write-operation-ids`
 * instead.
 */
export const CAPTURED_API_ENTRY: WireShape = {
  kind: "object",
  name: "CapturedApiEntry",
  of: {
    url: { kind: "text", name: "url", pattern: CAPTURED_API_FILENAME, max: 256 },
    name: {
      kind: "text",
      name: "identifier",
      pattern: /^[A-Za-z_][A-Za-z0-9_-]{0,63}$/,
      max: 64,
    },
    type: { kind: "enum", name: "type", of: ["openapi"] },
    auth: { kind: "enum", name: "auth", of: ["api-key", "bearer"] },
    "token-env": {
      kind: "text",
      name: "keyName",
      pattern: /^[A-Za-z_][A-Za-z0-9_]{0,127}$/,
      max: 128,
    },
    headers: {
      kind: "map",
      max: 16,
      keyName: "header name",
      caseInsensitiveKeys: true,
      keyPattern: /^[Xx]-[A-Za-z0-9-]{0,126}$/,
      of: { kind: "text", name: "header value", pattern: /^[\x20-\x7e]+$/, max: 1024 },
    },
    "operation-ids": {
      kind: "list",
      of: CAPTURED_OPERATION_ID,
      min: 1,
      max: 128,
      unique: true,
    },
    "write-operation-ids": { kind: "list", of: CAPTURED_OPERATION_ID, max: 64, unique: true },
  },
  required: ["url", "name", "type", "auth", "token-env", "operation-ids"],
};

/** `CapturedQueryReferences` — CapturedQueryReferences.kt. `queries/references.yml`, once per realm. */
export const QUERY_REFERENCES: WireShape = {
  kind: "object",
  name: "CapturedQueryReferences",
  of: {
    version: CAPTURED_VERSION,
    views: {
      kind: "list",
      max: 32,
      // The reader wants each alias used once and each view stood in for once, so a
      // second entry sharing either half is refused even though the pair differs.
      uniqueBy: ["alias", "view"],
      of: {
        kind: "object",
        name: "CapturedViewReference",
        of: {
          alias: { kind: "text", name: "ALIAS_NAME", pattern: /^[a-z][a-z0-9_]{0,63}$/, max: 64 },
          view: {
            kind: "text",
            name: "VIEW_NAME",
            pattern: /^[A-Za-z][A-Za-z0-9_]{0,63}$/,
            max: 64,
          },
        },
        required: ["alias", "view"],
      },
    },
  },
  required: ["version", "views"],
};

/** `ViewParamSpec` in ViewExpander.kt: one declared parameter of a view. */
const VIEW_PARAM_SPEC: WireShape = {
  kind: "object",
  name: "ViewParamSpec",
  of: {
    // The host defaults a missing type to string, but a param whose author never said what
    // it is tends to be a number compared as text, which matches nothing. Synth asks for it.
    type: {
      kind: "enum",
      name: "ViewParamSpec.TYPES",
      of: ["string", "int", "number", "float", "double", "boolean", "date"],
    },
    default: value,
    description: value,
    choices: { kind: "list", of: value, min: 1 },
  },
  required: ["type"],
};

/**
 * `ViewSpec` in ViewExpander.kt: one entry of the `views/<realm>.yml` list. `source` is left
 * out because the host stamps it at load time.
 */
export const VIEW_SPEC: WireShape = {
  kind: "object",
  name: "ViewSpec",
  of: {
    // The same name shape a captured realm's query references point at, so any view a realm
    // ships is one its own guest Cypher can name.
    name: { kind: "text", name: "VIEW_NAME", pattern: /^[A-Za-z][A-Za-z0-9_]{0,63}$/, max: 64 },
    cypher: value,
    description: value,
    params: {
      kind: "map",
      of: VIEW_PARAM_SPEC,
      keyPattern: /^[A-Za-z_][A-Za-z0-9_]*$/,
      keyName: "view parameter name",
    },
    materialized: value,
    ttl: value,
    outputLabel: value,
    audience: { kind: "list", of: value },
    dataContract: {
      kind: "object",
      name: "DataContractBindingSpec",
      of: {
        id: value,
        version: value,
        object: value,
        mode: { kind: "enum", name: "DataContractMode", of: ["observe", "enforce"] },
      },
      required: ["id", "version", "object"],
    },
  },
  required: ["name", "cypher"],
};

/** `CapturedBrowserApps.App` — CapturedBrowserApps.kt. `apps/<key>.app.json`, one file per app. */
export const APP_SPEC: WireShape = {
  kind: "object",
  name: "CapturedBrowserApps.App",
  of: {
    version: CAPTURED_VERSION,
    handlers: {
      kind: "list",
      max: 32,
      unique: true,
      of: { kind: "text", name: "handler name", max: 256 },
    },
    resources: {
      kind: "list",
      max: 16,
      unique: true,
      // The reader only loads a resource from the app's own asset directory, and only a
      // stylesheet or a script. The exact `apps/<key>.assets/` prefix is per app, so
      // emit.ts checks that; this is the shape every one of them shares.
      of: {
        kind: "text",
        name: "RESOURCE_NAME",
        pattern:
          /^apps\/[A-Za-z0-9][A-Za-z0-9_.-]*\.assets\/[A-Za-z0-9][A-Za-z0-9_.-]{0,119}\.(css|js)$/,
        max: 300,
      },
    },
  },
  required: ["version", "handlers"],
};

/** `SecretRef` — WebhookRegistration.kt. `literal` is deliberately absent — see webhooks.ts. */
const WEBHOOK_SECRET_REF: WireShape = {
  kind: "object",
  name: "SecretRef",
  of: { "oauth-app": value },
  required: ["oauth-app"],
};

/** `TimestampConfig` — WebhookRegistration.kt. */
const WEBHOOK_TIMESTAMP: WireShape = {
  kind: "object",
  name: "TimestampConfig",
  of: { header: value, "tolerance-seconds": value, unit: value },
  required: ["header"],
};

/** `SignatureConfig` — WebhookRegistration.kt. */
const WEBHOOK_SIGNATURE: WireShape = {
  kind: "object",
  name: "SignatureConfig",
  of: {
    scheme: value,
    "secret-ref": WEBHOOK_SECRET_REF,
    header: value,
    prefix: value,
    encoding: value,
    template: value,
    timestamp: WEBHOOK_TIMESTAMP,
  },
  required: ["scheme", "secret-ref"],
};

/** `TenancyConfig` — WebhookRegistration.kt. */
const WEBHOOK_TENANCY: WireShape = {
  kind: "object",
  name: "TenancyConfig",
  of: { resolver: value, field: value, store: value },
  required: ["resolver"],
};

/** `RegisterConfig` — WebhookRegistration.kt. */
const WEBHOOK_REGISTER: WireShape = {
  kind: "object",
  name: "RegisterConfig",
  of: { tool: value, args: mapping },
  required: ["tool"],
};

/** `WebhookRegistration` — WebhookRegistration.kt. A list of these per file under `webhooks/`. */
export const WEBHOOK_REGISTRATION: WireShape = {
  kind: "object",
  name: "WebhookRegistration",
  of: {
    name: value,
    description: value,
    source: value,
    events: { kind: "list", of: value },
    action: value,
    register: WEBHOOK_REGISTER,
    signature: WEBHOOK_SIGNATURE,
    tenancy: WEBHOOK_TENANCY,
  },
  required: ["name", "source"],
};

/** `PollCursor` — RealmEventConfig.kt. */
const EVENT_POLL_CURSOR: WireShape = {
  kind: "object",
  name: "PollCursor",
  of: { param: value, from: value, initial: value },
};

/** `RealmPollConfig` — RealmEventConfig.kt. */
export const EVENT_POLL: WireShape = {
  kind: "object",
  name: "RealmPollConfig",
  of: {
    every: value,
    api: value,
    method: value,
    args: mapping,
    cursor: EVENT_POLL_CURSOR,
    mapping: mapping,
  },
  required: ["every", "api", "method"],
};

/** `RealmWebhookConfig` — RealmEventConfig.kt. `signatureSecret`/`tierWhen` are kebab on the wire. */
export const EVENT_WEBHOOK: WireShape = {
  kind: "object",
  name: "RealmWebhookConfig",
  of: {
    signature: value,
    "signature-secret": value,
    tenancy: value,
    mapping: mapping,
    "tier-when": mapping,
  },
};

/** `RealmEventConfig` — RealmEventConfig.kt. One list entry per `events/<id>.yml` item. */
export const EVENT_ENTRY: WireShape = {
  kind: "object",
  name: "RealmEventConfig",
  of: { type: value, webhook: EVENT_WEBHOOK, poll: EVENT_POLL },
  required: ["type"],
};

/** `LensParam` — LensParam.kt. */
const LENS_PARAM: WireShape = {
  kind: "object",
  name: "LensParam",
  of: {
    name: value,
    type: {
      kind: "enum",
      name: "LensParamType",
      of: ["STRING", "INT", "DATE", "DURATION", "BOOLEAN"],
    },
    label: value,
    default: value,
    required: value,
  },
  required: ["name"],
};

/** `PresentationSpec` — LensPresentation.kt. */
const LENS_PRESENTATION: WireShape = {
  kind: "object",
  name: "PresentationSpec",
  of: { surface: value, href: value },
};

/** `LensOutputContract` — Lens.kt. */
const LENS_OUTPUT_CONTRACT: WireShape = {
  kind: "object",
  name: "LensOutputContract",
  of: { kind: value, schemaVersion: value, schema: mapping },
  required: ["kind"],
};

/**
 * `LensSpec.CypherScript` / `LensSpec.Module` — LensSpec.kt. The engine also has `fixed`
 * and `anchor` kinds; realm.ts does not author either yet, so they are not listed here —
 * the same reasoning `REMOTE_FIELDS` documents for producer fields nothing emits.
 */
const LENS_SPEC: WireShape = {
  kind: "either",
  of: [
    {
      kind: "object",
      name: "LensSpec.CypherScript",
      of: { kind: value, script: value },
      required: ["kind", "script"],
    },
    {
      kind: "object",
      name: "LensSpec.Module",
      of: {
        kind: value,
        className: value,
        module: value,
        source: value,
        presentKind: value,
        dataType: value,
      },
      required: ["kind", "className"],
    },
  ],
};

/** `Lens` — Lens.kt, the whole of it. One file per lens under `lenses/`. */
export const LENS: WireShape = {
  kind: "object",
  name: "Lens",
  of: {
    id: value,
    name: value,
    spec: LENS_SPEC,
    persona: value,
    schedule: value,
    description: value,
    params: { kind: "list", of: LENS_PARAM },
    presentation: LENS_PRESENTATION,
    output: LENS_OUTPUT_CONTRACT,
    source: value,
  },
  required: ["id", "name", "spec"],
};

/**
 * `FocusSpec` — FocusSpec.kt, the whole of it. One file per focus under `focuses/`.
 * Every field but `name` has an engine default; `name` itself defaults to `""` too, so
 * nothing here is Jackson-required — synth still refuses a blank `name` (see `checkType`
 * elsewhere in emit.ts for the same treatment of a blank identifier).
 */
export const FOCUS_SPEC: WireShape = {
  kind: "object",
  name: "FocusSpec",
  of: {
    name: value,
    displayName: value,
    description: value,
    defaultPersona: value,
    realms: { kind: "list", of: value },
    tools: { kind: "list", of: value },
    builtins: value,
    icon: value,
  },
};

/**
 * `RealmHandlerEntry` — RealmHandlerManifest.kt. One element of `dist/manifest.json`'s
 * `entries` list, and the one shape here that is JSON rather than YAML.
 *
 * The manifest is read by a plain `ObjectMapper().registerKotlinModule()`
 * (RealmHandlerLoader.kt), which keeps Jackson's strict default. So an unknown key does
 * not quietly vanish the way a persister-read YAML key does — it throws, the loader logs
 * "malformed dist/manifest.json", and the realm loses EVERY handler it has. That is the
 * most expensive loss on any surface realm.ts emits, which is why the entries are checked
 * here even though the conformance oracle cannot help: it treats `dist/` as a verbatim
 * tree and never opens this file.
 *
 * `namespace` and `name` are the only two fields with no Kotlin default.
 */
export const REALM_HANDLER_ENTRY: WireShape = {
  kind: "object",
  name: "RealmHandlerEntry",
  of: {
    namespace: value,
    name: value,
    description: value,
    inputSchema: mapping,
    outputSchema: mapping,
    onType: value,
    className: value,
    schedule: value,
  },
  required: ["namespace", "name"],
};

/**
 * Refuses a rendered document that the engine would not read as written.
 *
 * `where` is the path in the realm definition, so the message points at the line the
 * author has to change rather than at the YAML nobody wrote by hand.
 */
export function checkWireShape(node: JsonValue, shape: WireShape, where: string): void {
  switch (shape.kind) {
    case "value":
      return;

    case "scalar": {
      if (typeof node !== "object" || node === null) return;
      throw new SynthError(
        `${where}: expected a plain value here, not ${Array.isArray(node) ? "a list" : "a mapping"}`,
      );
    }

    case "enum": {
      if (typeof node === "string" && shape.of.includes(node)) return;
      throw new SynthError(
        `${where}: ${JSON.stringify(node)} is not a value of the engine's ${shape.name}. ` +
          `Expected one of: ${shape.of.join(", ")}.`,
      );
    }

    case "text": {
      if (typeof node !== "string") {
        throw new SynthError(
          `${where}: the engine reads ${shape.name} as text, not ${typeof node}`,
        );
      }
      if (node === "" && !shape.emptyOk) {
        throw new SynthError(`${where}: the engine refuses an empty ${shape.name}`);
      }
      if (shape.max !== undefined && node.length > shape.max) {
        throw new SynthError(
          `${where}: ${shape.name} is read with a ${shape.max}-character limit, and this is ` +
            `${node.length} characters. The engine refuses the whole file over it.`,
        );
      }
      if (hasControlCharacter(node)) {
        throw new SynthError(
          `${where}: ${shape.name} may not contain a control character — the engine refuses it.`,
        );
      }
      if (hasLoneSurrogate(node)) {
        throw new SynthError(
          `${where}: ${shape.name} carries a lone surrogate — half of a character, with nothing ` +
            `to pair it with — and the engine refuses text its UTF-8 encoder cannot encode.`,
        );
      }
      if (node !== "" && shape.pattern && !shape.pattern.test(node)) {
        throw new SynthError(
          `${where}: ${JSON.stringify(node)} is not the shape the engine reads ${shape.name} as ` +
            `(${shape.pattern.source}), so it refuses the whole file.`,
        );
      }
      if (shape.never?.includes(node)) {
        throw new SynthError(
          `${where}: the engine refuses ${JSON.stringify(node)} as a ${shape.name}.`,
        );
      }
      return;
    }

    case "integer": {
      if (typeof node !== "number" || !Number.isInteger(node)) {
        throw new SynthError(
          `${where}: the engine reads ${shape.name} as a whole number, and ${JSON.stringify(node)} ` +
            `is not one — a fractional value makes it refuse the whole file.`,
        );
      }
      if (node < shape.min || node > shape.max) {
        throw new SynthError(
          `${where}: the engine reads ${shape.name} in ${shape.min}..${shape.max}, got ${node}.`,
        );
      }
      return;
    }

    case "list": {
      if (!Array.isArray(node)) throw new SynthError(`${where}: expected a list`);
      if (shape.min !== undefined && node.length < shape.min) {
        throw new SynthError(
          `${where}: the engine reads at least ${shape.min} here, and this has ${node.length}.`,
        );
      }
      if (shape.max !== undefined && node.length > shape.max) {
        throw new SynthError(
          `${where}: the engine reads at most ${shape.max} here, and this has ${node.length}. ` +
            `Everything past the limit does not simply drop — it refuses the whole file.`,
        );
      }
      node.forEach((item, i) => {
        checkWireShape(item, shape.of, `${where}[${i}]`);
      });
      if (shape.unique) {
        const seen = new Set<string>();
        node.forEach((item, i) => {
          const key = JSON.stringify(item);
          if (seen.has(key)) {
            throw new SynthError(
              `${where}[${i}]: ${key} appears twice, and the engine refuses a duplicate here.`,
            );
          }
          seen.add(key);
        });
      }
      for (const field of shape.uniqueBy ?? []) {
        const seen = new Set<string>();
        node.forEach((item, i) => {
          if (!isPlainObject(item)) return;
          const key = JSON.stringify(item[field]);
          if (seen.has(key)) {
            throw new SynthError(
              `${where}[${i}].${field}: ${key} is already used by an earlier entry, and the engine ` +
                `refuses two entries sharing one ${field}.`,
            );
          }
          seen.add(key);
        });
      }
      return;
    }

    case "map": {
      const entries = asObject(node, where);
      const keys = Object.keys(entries);
      if (shape.exactlyOne && keys.length !== 1) {
        throw new SynthError(
          `${where}: the engine reads exactly one key here, and this has ${keys.length}.`,
        );
      }
      if (shape.max !== undefined && keys.length > shape.max) {
        throw new SynthError(
          `${where}: the engine reads at most ${shape.max} ${shape.keyName ?? "key"}s here, and ` +
            `this has ${keys.length}.`,
        );
      }
      const lowercased = new Set<string>();
      for (const key of keys) {
        if (shape.keyPattern && !shape.keyPattern.test(key)) {
          throw new SynthError(
            `${where}.${key}: ${JSON.stringify(key)} is not the shape the engine reads a ` +
              `${shape.keyName ?? "key"} as (${shape.keyPattern.source}).`,
          );
        }
        if (shape.caseInsensitiveKeys) {
          if (lowercased.has(key.toLowerCase())) {
            throw new SynthError(
              `${where}.${key}: the engine compares ${shape.keyName ?? "key"}s without regard to ` +
                `case, so this collides with another key here.`,
            );
          }
          lowercased.add(key.toLowerCase());
        }
        checkWireShape(entries[key] as JsonValue, shape.of, `${where}.${key}`);
      }
      return;
    }

    case "either": {
      const failures: string[] = [];
      for (const branch of shape.of) {
        try {
          checkWireShape(node, branch, where);
          return;
        } catch (error) {
          failures.push(error instanceof Error ? error.message : String(error));
        }
      }
      // A value that is an object almost always meant the one object branch, so report
      // that branch's complaint rather than a useless "none of these matched".
      const objectBranches = shape.of.filter((b) => b.kind === "object" || b.kind === "map");
      if (isPlainObject(node) && objectBranches.length === 1) {
        throw new SynthError(failures[shape.of.indexOf(objectBranches[0])] as string);
      }
      throw new SynthError(`${where}: no accepted form matches this value. ${failures.join(" ")}`);
    }

    case "object": {
      const entries = asObject(node, where);
      const known = Object.keys(shape.of);
      const present = Object.keys(entries);

      if (!shape.open) {
        for (const key of present) {
          if (known.includes(key)) continue;
          throw new SynthError(
            shape.extraKeysVanishSilently
              ? `${where}.${key}: the engine's ${shape.name} has no field "${key}". Its deserializer ` +
                  `reads the keys it knows and ignores the rest, so this would vanish with no error at ` +
                  `load time. Known fields: ${known.sort().join(", ")}.`
              : `${where}.${key}: the engine's ${shape.name} has no field "${key}", so the whole file ` +
                  `would fail to load and every type in it would be skipped. ` +
                  `Known fields: ${known.sort().join(", ")}.`,
          );
        }
      }

      if (shape.exactlyOne && present.length !== 1) {
        throw new SynthError(
          `${where}: the engine's ${shape.name} reads exactly one of ${known.sort().join(", ")}, ` +
            `and this has ${present.length} keys.`,
        );
      }

      for (const key of shape.required ?? []) {
        if (present.includes(key)) continue;
        throw new SynthError(
          `${where}: the engine's ${shape.name} requires "${key}" and nothing here sets it. ` +
            `It has no default, so its deserializer would fail and the whole file would be skipped.`,
        );
      }

      for (const key of present) {
        const child = shape.of[key];
        if (child) checkWireShape(entries[key] as JsonValue, child, `${where}.${key}`);
      }
      return;
    }
  }
}

/**
 * Whether a string holds a character the engine's own string reader refuses: a C0
 * control, DEL, or a C1 control, the same set Java's `Char.isISOControl` covers
 * (`CapturedApiDocuments.kt`:53). A tab or newline smuggled into an identifier is the
 * interesting case — it reads as invisible in the definition and refuses the whole file at
 * load time — and a C1 control such as U+009F is invisible in most editors too.
 */
function hasControlCharacter(text: string): boolean {
  return [...text].some((character) => {
    const code = character.codePointAt(0) ?? 0;
    return code < 32 || (code >= 127 && code <= 159);
  });
}

/**
 * Whether a string holds a lone surrogate — half of a surrogate pair, with nothing to pair
 * it with. It is legal inside a JavaScript string, and it has no Unicode scalar value of
 * its own, so nothing can encode it: the engine's string reader asks its UTF-8 encoder
 * whether it can encode a value before accepting it (`CapturedApiDocuments.kt`:53), and the
 * answer here is no. Neither a length check nor a byte count stands in for this. The string
 * is one character long, inside every limit the readers set, and it still takes the whole
 * file down at load time.
 */
function hasLoneSurrogate(text: string): boolean {
  return /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/.test(text);
}

function isPlainObject(node: JsonValue): node is { [k: string]: JsonValue } {
  return typeof node === "object" && node !== null && !Array.isArray(node);
}

function asObject(node: JsonValue, where: string): { [k: string]: JsonValue } {
  if (!isPlainObject(node)) throw new SynthError(`${where}: expected a mapping`);
  return node;
}
