import { existsSync, readFileSync, realpathSync, statSync } from "node:fs";
import { dirname, extname, isAbsolute, join, posix, relative, resolve, sep } from "node:path";
import type {
  ApiSpec,
  CapturedApiSpec,
  CapturedProducerSpec,
  CapturedRealm,
  CapturedViewParamSpec,
  CapturedViewSpec,
  ChannelSpec,
  CredentialSpec,
  DependencyValueType,
  EventSpec,
  GuestLanguage,
  HandlerSpec,
  JsonObject,
  JsonValue,
  ProducerSpec,
  Realm,
  RemoteProducer,
  ResolveVia,
  TypeSpec,
  WebhookSpec,
} from "@embabel/realm-types";
import {
  DEPENDENCY_KIND_NAME,
  DEPENDENCY_VALUE_TYPES,
  REALM_CAPABILITIES,
  REALM_MATURITIES,
} from "@embabel/realm-types";
import { parse as parseYamlDocument, stringify as stringifyYaml } from "yaml";
import { canonicalize, SynthError } from "./canonical.ts";
import { checkConnectingCredentials, emitConnecting } from "./connecting.ts";
import { checkCypher } from "./cypher.ts";
import { checkCapturedBodySchema, checkGatewayOperation, pascalCase } from "./dts.ts";
import { checkCapturedGraphql, GRAPHQL_OPERATIONS_PATH, HOST_CALL_NAMES } from "./graphql.ts";
import {
  APP_LIMIT_FLAGS,
  type AppLimits,
  checkProfile,
  type ExecutionProfile,
  resolveAppLimits,
} from "./profile.ts";
import {
  codecFor,
  declaredResponse,
  documentedResponse,
  essence,
  findOperation,
  MAX_DECLARED_RESPONSES,
  suggestedDeclaration,
} from "./responses.ts";
import { checkCapturedSkills, SKILL_DIGESTS_PATH } from "./skills.ts";
import type { WireShape } from "./wire-schema.ts";
import {
  API_ENTRY,
  APP_SPEC,
  CAPTURED_API_ENTRY,
  CAPTURED_DATA_PIPES,
  CAPTURED_GOAL_SPEC,
  CAPTURED_PRODUCER_SPEC,
  checkWireShape,
  EVENT_ENTRY,
  FOCUS_SPEC,
  GOAL_SPEC,
  LENS,
  PRODUCER_SPECS,
  PROMPTED_ACTION_SPEC,
  QUERY_REFERENCES,
  REALM_HANDLER_ENTRY,
  TRIGGER_SPEC,
  TYPE_ENTRY,
  VIEW_SPEC,
  WEBHOOK_REGISTRATION,
} from "./wire-schema.ts";

/** A verb name, a type name, or a dependency key becomes an identifier in generated TypeScript, so all three are checked against this. */
const IDENTIFIER = /^[A-Za-z_$][A-Za-z0-9_$]*$/;

/** The plain semver shape a dependency's requested version must match, e.g. "3.50". */
const SEMVER = /^[0-9]+(\.[0-9]+){0,2}$/;

/** The shape a registry module id must match: lowercase letters, digits and dashes. */
const REGISTRY_ID = /^[a-z0-9][a-z0-9-]*$/;

/**
 * SQLite's registry module id. Its one method, `exec`, is fixed by the host, so a
 * dependency on this module declaring `methods` is refused — mirroring the engine's
 * own refusal at dispatch.
 */
const SQLITE_MODULE = "sqlite3-wasi";

/**
 * Whether synth checks a dependency as SQLite: it says `kind: "sqlite"`, or it names no kind
 * and is the `sqlite3-wasi` module.
 */
function isSqliteDependency(spec: Record<string, unknown>): boolean {
  return spec.kind === "sqlite" || (spec.kind === undefined && spec.module === SQLITE_MODULE);
}

/** Strict OpenAPI 3.x version: a major version of exactly 3, a minor, and an optional patch. */
const OPENAPI_VERSION = /^3\.\d+(\.\d+)?$/;

/** A rendered YAML or JSON file synth produces from the realm definition. */
export interface RenderedFile {
  kind: "rendered";
  /** Path relative to the realm root. */
  path: string;
  value: JsonValue;
}

/**
 * A vendored document's bytes, copied verbatim into the output at the path
 * `apis/apis.yml`'s url resolves to. This is how a written `--out` tree stays able to
 * resolve every url the apis manifest names: the exact bytes validated at synth time
 * land next to it, straight from disk.
 */
export interface VendoredFile {
  kind: "vendored";
  /** Path relative to the realm root, where the output copy goes. */
  path: string;
  bytes: Buffer;
}

/** One file synth produces, and what goes in it. */
export type EmittedFile = RenderedFile | VendoredFile;

/** What an `emit` run takes beyond the realm and its root. */
export interface EmitOptions {
  /** Where warnings go: deprecations, and features the chosen profile does not load. */
  warn?: (message: string) => void;
  /** The execution environment to check the realm against. Absent means no profile checks. */
  profile?: ExecutionProfile;
  /** App limits that win over both the defaults and the profile's own. */
  appLimits?: Partial<AppLimits>;
  /**
   * The absolute path of a module this same run generates, the `--types` file. A handler may
   * import it before it exists, and the bundle should get this run's copy rather than
   * whatever is on disk, so emit leaves an empty placeholder at its path for `synth` to fill.
   */
  generatedModule?: string;
}

/** Builds a rendered-file entry. The one place `files.push` needs to name a `kind`. */
function rendered(path: string, value: JsonValue): EmittedFile {
  return { kind: "rendered", path, value };
}

/**
 * The realm-relative handler entry path a runtime falls back to when the realm does
 * not declare `entry` itself. Shared with `scaffold.ts`, which writes a realm at this
 * same path for a runtime it scaffolds, so the two never drift apart.
 */
export function conventionalEntry(runtime: GuestLanguage): string {
  if (runtime === "python") return "wasm/handlers.py";
  if (runtime === "compiled") return "wasm/src/lib.rs";
  return "wasm/handlers.ts";
}

/**
 * Resolves the realm root's canonical path once, so every containment check below
 * compares against the same real location. Falls back to the plain resolved path in
 * the vanishingly rare case the directory itself cannot be stat'd — a caller synthing
 * from a path that does not exist yet gets a clearer failure further down than a crash
 * here would give it.
 */
function realmRootRealpath(realmRootAbs: string): string {
  try {
    return realpathSync(realmRootAbs);
  } catch {
    return realmRootAbs;
  }
}

/**
 * Refuses a path that resolves — through a symlink, or a long run of legitimate
 * ".." segments climbing back out, it makes no difference which — to somewhere
 * outside the realm's own directory.
 *
 * A realm is third-party content, usually a git clone, and git carries symlinks
 * verbatim: a bare string check on the declared path can be satisfied while the
 * symlink it names still points off the end of the disk. Comparing the realpath of
 * the candidate against the realpath of the realm root is the check that still holds
 * once a symlink is in the mix, and it is why this runs on the resolved absolute path
 * rather than on the specifier or declared path text.
 */
function assertContained(absPath: string, realmRootReal: string, label: string): string {
  const real = realpathSync(absPath);
  const rel = relative(realmRootReal, real);
  if (rel === ".." || rel.startsWith(`..${sep}`) || isAbsolute(rel)) {
    throw new SynthError(
      `${label} resolves to "${real}", which is outside the realm root "${realmRootReal}". ` +
        `A realm may not ship a file from outside its own directory.`,
    );
  }
  return real;
}

/** Every file extension whose contents are worth walking for further relative imports. */
const IMPORT_WALK_EXTENSIONS = [".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs"];

/**
 * Every value-import specifier a TypeScript or JavaScript file names: `import x from
 * "./y"`, `export * from "./y"`, a bare `import "./y"`, and a dynamic `import("./y")`.
 * A `type`-only import or re-export is excluded on purpose — types erase at compile
 * time, so the file behind one is never needed in the shipped artifact.
 *
 * This is a lightweight regex scan of well-formed, non-adversarial handler source, not
 * a real parser. It is good enough for the realistic shapes this repo's examples use;
 * it is not trying to survive deliberately obfuscated input.
 */
function valueImportSpecifiers(source: string): string[] {
  const specifiers: string[] = [];
  const fromRe = /\b(?:import|export)\s+(type\s+)?[\s\S]*?\bfrom\s*["']([^"']+)["']/g;
  for (const match of source.matchAll(fromRe)) {
    if (match[1]) continue; // a `type` keyword right after import/export
    specifiers.push(match[2] as string);
  }
  const bareRe = /\bimport\s*["']([^"']+)["']\s*;/g;
  for (const match of source.matchAll(bareRe)) specifiers.push(match[1] as string);
  const dynamicRe = /\bimport\s*\(\s*["']([^"']+)["']\s*\)/g;
  for (const match of source.matchAll(dynamicRe)) specifiers.push(match[1] as string);
  return specifiers;
}

/**
 * Turns a realm definition into the files the loader reads.
 *
 * The realm's own YAML stays the contract. Synth writes it out, so the loader, the
 * governance validators and every existing test keep working untouched, and what a
 * realm actually declares stays readable on disk.
 *
 * Every collection is keyed by name in the definition and emitted as a list whose
 * entries carry `name`, which is how the loader expects to read them.
 *
 * `realmRoot` is the definition file's directory. It is where a relative path in the
 * definition, such as a dependency's init script, gets resolved and checked.
 */
export function emit(realm: Realm, realmRoot: string, options?: EmitOptions): EmittedFile[] {
  // Deprecations are diagnostics, not refusals: the realm still emits, and the author
  // still has to hear about it. A caller that wants them passes a sink; one that does
  // not gets silence rather than stray output on someone else's stdout.
  const warn = options?.warn ?? ((): void => {});
  const appLimits = resolveAppLimits(options?.profile, options?.appLimits);
  checkProfile(realm, options?.profile, warn);
  if (realm.execution !== "captured") {
    for (const field of [
      "triggers",
      "queries",
      "apps",
      "credentials",
      "dataPipes",
      "capturedLenses",
      "watches",
      "graphql",
      "views",
      "skills",
      "capabilities",
    ] as const) {
      if ((realm as unknown as Record<string, unknown>)[field] !== undefined) {
        throw new SynthError(`$.${field} requires execution: "captured"`);
      }
    }
  }
  const files: EmittedFile[] = [];

  // Everything below that copies an authored file alongside the rendered output —
  // the entry, its sibling imports, a dependency's init script, the icon — goes
  // through this one accumulator, so it gets one collision check and one containment
  // rule no matter which field asked for it.
  const realmRootAbs = resolve(realmRoot);
  const realmRootReal = realmRootRealpath(realmRootAbs);
  const assemblyFiles: VendoredFile[] = [];
  const assemblySeen = new Set<string>();
  // Only a module inside the realm can travel with it, so one outside is just never matched.
  const generatedModule =
    options?.generatedModule === undefined ? undefined : resolve(options.generatedModule);

  /**
   * Copies one authored source file into the assembly set: the handler entry, a
   * sibling module it imports, a dependency's init script, or the realm's icon.
   * Every path is realpath-checked before its bytes are read, so a symlink under the
   * realm root pointing outside it is refused here by name, never silently followed.
   * A TypeScript or JavaScript file additionally has its own relative imports walked
   * and copied — that is what makes a split handler like examples/realm-expenses ship
   * whole rather than just its entry point.
   */
  function addAssemblyFile(absPath: string, label: string): void {
    const relPath = relative(realmRootAbs, absPath).split(sep).join("/");
    if (assemblySeen.has(relPath)) return;
    assemblySeen.add(relPath);
    const real = assertContained(absPath, realmRootReal, label);
    assemblyFiles.push({ kind: "vendored", path: relPath, bytes: readFileSync(real) });
    if (IMPORT_WALK_EXTENSIONS.includes(extname(absPath))) {
      walkSiblingImports(absPath);
    }
  }

  /**
   * Ships one file a captured browser app needs — its page, or one of its inlined
   * resources — and returns how many bytes it came to. Unlike a handler source, an
   * asset's imports are not walked: the host inlines the bytes as they are and never
   * resolves anything out of them.
   */
  function addAppFile(
    absPath: string,
    label: string,
    limits: { limit: number; flag: string; forbid?: RegExp },
  ): number {
    const relPath = relative(realmRootAbs, absPath).split(sep).join("/");
    if (!existsSync(absPath)) {
      throw new SynthError(
        `${label} is not in the realm — the host reads it out of the same capture as the manifest ` +
          `and refuses the app when it is missing. Expected a file at "${absPath}".`,
      );
    }
    const real = assertContained(absPath, realmRootReal, label);
    const bytes = readFileSync(real);
    if (bytes.length > limits.limit) {
      throw new SynthError(
        `${label} is ${bytes.length} bytes, over the ${limits.limit}-byte limit synth was given. ` +
          `A host with larger app limits can take it: raise this one with ${limits.flag} ` +
          `(or all three byte limits with --app-limit), like "${limits.flag} 32MiB".`,
      );
    }
    if (limits.forbid?.test(bytes.toString("utf8"))) {
      throw new SynthError(
        `${label} contains "${limits.forbid.source.replace("\\", "")}". The host inlines this ` +
          `resource into the page inside a tag of its own, so a closing tag in the text would ` +
          `break out of it — it refuses the app rather than serve that.`,
      );
    }
    if (!assemblySeen.has(relPath)) {
      assemblySeen.add(relPath);
      assemblyFiles.push({ kind: "vendored", path: relPath, bytes });
    }
    return bytes.length;
  }

  /** Follows every relative value-import in one file, adding what it finds and recursing into it. */
  function walkSiblingImports(fileAbs: string): void {
    const source = readFileSync(fileAbs, "utf8");
    const dir = dirname(fileAbs);
    const fromRel = relative(realmRootAbs, fileAbs).split(sep).join("/");
    for (const specifier of valueImportSpecifiers(source)) {
      if (!specifier.startsWith("./") && !specifier.startsWith("../")) continue;
      const target = resolve(dir, specifier);
      const generatedRel =
        generatedModule !== undefined && target === generatedModule
          ? relative(realmRootAbs, target)
          : undefined;
      // The generated module ships as a placeholder only when it sits inside the realm. One
      // outside it falls through to the same refusal as any other outside import.
      if (
        generatedRel !== undefined &&
        generatedRel !== ".." &&
        !generatedRel.startsWith(`..${sep}`) &&
        !isAbsolute(generatedRel)
      ) {
        const relPath = generatedRel.split(sep).join("/");
        if (!assemblySeen.has(relPath)) {
          assemblySeen.add(relPath);
          assemblyFiles.push({ kind: "vendored", path: relPath, bytes: Buffer.alloc(0) });
        }
        continue;
      }
      if (!existsSync(target)) {
        throw new SynthError(
          `"${specifier}", imported from "${fromRel}", does not resolve to a file that exists.`,
        );
      }
      addAssemblyFile(target, `"${specifier}" imported from "${fromRel}"`);
    }
  }

  if (realm.entry !== undefined) {
    checkRelativePath(realm.entry, "$.entry");
  }

  // Validated once, up front: every check below that walks a dotted operation
  // reference just consults realm.apis directly, already known to be well-formed.
  const credentialUse: CapturedCredentialUse = { referenced: new Map(), migrated: new Map() };
  const apiResult =
    realm.execution === "captured"
      ? checkCapturedApis(realm.apis, realmRoot, realm.credentials, credentialUse, warn)
      : checkApis(realm.apis, realmRoot);
  if (apiResult) {
    files.push(rendered("apis/apis.yml", apiResult.entries));
    files.push(...apiResult.vendored);
  }
  // After the apis, because that walk is what discovers which credentials anything
  // actually references — including the implicit ones a deprecated tokenEnv derives.
  if (realm.execution === "captured") {
    // Before the credentials are built, because this is what tells them a channel or a
    // webhook signature references a credential. Without it, a credential only the
    // channels name looks like one nothing uses, and the realm is refused for it — and a
    // channel naming a credential nobody declared would be refused for that same wrong
    // reason instead of for the reference that does not resolve.
    checkConnectingCredentials(realm, credentialUse.referenced);
    // Also before the credentials, for the same reason: a credential only the GraphQL source
    // names is still a credential something uses.
    if (realm.graphql !== undefined) {
      files.push(
        rendered(
          GRAPHQL_OPERATIONS_PATH,
          checkCapturedGraphql(
            realm.graphql,
            realm.apis,
            realm.credentials,
            credentialUse.referenced,
          ),
        ),
      );
    }
    const credentials = capturedCredentials(realm.credentials, credentialUse);
    if (credentials) files.push(rendered("credentials.yml", credentials));
  }
  const vendoredRecords = apiResult?.vendoredRecords ?? [];

  const metadata: JsonObject = { name: realm.name };
  // Absent means "infer placement from what's on disk" to the engine — a real,
  // meaningfully different state from any declared value, not a default synth picks
  // for the author. So the key is only written when the author wrote it.
  if (realm.host !== undefined) metadata.host = realm.host;
  metadata.version = realm.version;
  for (const key of ["description", "author", "url", "icon"] as const) {
    if (realm[key] !== undefined) metadata[key] = realm[key] as JsonValue;
  }
  if (realm.maturity !== undefined) {
    // The host refuses the whole realm.yml over a maturity it does not know, so a typo here
    // would cost the realm its metadata rather than just its badge.
    if (!(REALM_MATURITIES as readonly string[]).includes(realm.maturity)) {
      throw new SynthError(
        `$.maturity: expected one of ${REALM_MATURITIES.join(", ")}, got ${JSON.stringify(realm.maturity)}`,
      );
    }
    metadata.maturity = realm.maturity;
  }
  if (realm.execution === "captured" && realm.capabilities !== undefined) {
    metadata.capabilities = checkCapabilities(realm.capabilities);
  }
  if (realm.tags?.length) metadata.tags = realm.tags;
  if (realm.exports?.length) metadata.exports = realm.exports;
  if (realm.retry) metadata.retry = canonicalize(realm.retry, "$.retry");
  files.push(rendered("realm.yml", metadata));

  // The icon is written into realm.yml above exactly as the author wrote it, whatever
  // it is — a url, an emoji, anything a string can hold. Only when it reads as a
  // realm-relative path do we also need its bytes alongside the artifact; a remote
  // url is left to the host to fetch, the same way a remote api document is.
  if (realm.icon !== undefined && !REMOTE_URL.test(realm.icon)) {
    checkRelativePath(realm.icon, "$.icon");
    const iconAbs = join(realmRootAbs, realm.icon);
    if (!existsSync(iconAbs)) {
      throw new SynthError(`$.icon: file not found at "${iconAbs}"`);
    }
    addAssemblyFile(iconAbs, `icon "${realm.icon}"`);
  }

  if (realm.types && Object.keys(realm.types).length > 0) {
    files.push(rendered(`types/${realm.name}.yml`, typeEntries(realm)));
  }

  if (realm.execution === "captured") {
    const capturedProducers = Object.entries(realm.producers ?? {}).sort(([a], [b]) =>
      a.localeCompare(b),
    );
    checkCapturedFileCount(capturedProducers.length, "producers", "$.producers");
    let producerBytes = 0;
    for (const [key, producer] of capturedProducers) {
      const where = `$.producers.${key}`;
      if (key.trim() === "") throw new SynthError(`${where}: a producer name cannot be blank`);
      checkCapturedProducer(producer, where);
      // The author's own fields go down first and the generated ones last, so a spec
      // that happens to carry `version` or `name` cannot overwrite either.
      const doc = canonicalize({ ...producer, version: 1, name: key }, where) as JsonObject;
      checkWireShape(doc, CAPTURED_PRODUCER_SPEC, where);
      checkCapturedHandlerReference(
        producer.handler,
        realm,
        `${where}.handler`,
        "The host refuses a producer whose handler the realm's manifest does not register.",
      );
      const path = `producers/${key}.yml`;
      checkCapturedPath(path, CAPTURED_MANIFEST_PATH, where);
      producerBytes += checkCapturedBytes(doc, path, CAPTURED_DOCUMENT_BYTES, where);
      checkCapturedTotalBytes(producerBytes, "producers", "$.producers");
      files.push(rendered(path, doc));
    }
  } else if (realm.producers && Object.keys(realm.producers).length > 0) {
    files.push(rendered(`producers/${realm.name}.yml`, producerEntries(realm)));
  }

  // Actions and goals are scanned one file per entry — unlike types and producers, the
  // engine never reads a list here, and the filename does not become the name, so the
  // key is simply what the file is called.
  for (const [key, action] of Object.entries(realm.actions ?? {})) {
    const where = `$.actions.${key}`;
    if (key.trim() === "") throw new SynthError(`${where}: an action name cannot be blank`);
    const doc = canonicalize({ name: key, stepType: "action", ...action }, where) as JsonObject;
    checkWireShape(doc, PROMPTED_ACTION_SPEC, where);
    files.push(rendered(`actions/${key}.yml`, doc));
  }

  if (realm.execution === "captured") {
    if (realm.dataPipes !== undefined) {
      const where = "$.dataPipes";
      checkCapturedDataPipesShape(realm.dataPipes, where);
      const doc = canonicalize(
        {
          version: 1,
          ...(realm.dataPipes.sources !== undefined
            ? { sources: named(realm.dataPipes.sources, `${where}.sources`) }
            : {}),
          ...(realm.dataPipes.consumers !== undefined
            ? { consumers: named(realm.dataPipes.consumers, `${where}.consumers`) }
            : {}),
        },
        where,
      ) as JsonObject;
      checkWireShape(doc, CAPTURED_DATA_PIPES, where);
      for (const [key, consumer] of Object.entries(realm.dataPipes.consumers ?? {})) {
        checkCapturedHandlerReference(
          consumer.handler,
          realm,
          `${where}.consumers.${key}.handler`,
          "The host refuses a data-pipes consumer whose handler the realm's manifest does not " +
            "register, and every trigger bound to it with it.",
        );
      }
      const sources = doc.sources;
      for (const source of Array.isArray(sources) ? sources : []) {
        const value = source as JsonObject;
        for (const field of ["name", "stream", "type"] as const) {
          checkUtf8ByteLimit(
            String(value[field]),
            256,
            field,
            `${where}.sources.${value.name}.${field}`,
          );
        }
      }
      checkCapturedBytes(doc, "data-pipes.yml", CAPTURED_TOTAL_BYTES, where);
      files.push(rendered("data-pipes.yml", doc));
    }

    const goals = Object.entries(realm.goals ?? {});
    checkCapturedFileCount(goals.length, "goals", "$.goals");
    let goalBytes = 0;
    for (const [key, goal] of goals) {
      const where = `$.goals.${key}`;
      if (key.trim() === "") throw new SynthError(`${where}: a goal name cannot be blank`);
      // The author's fields first, the generated ones last: a spec carrying its own
      // `version` or `goal` cannot overwrite what synth stamps in.
      const doc = canonicalize({ ...goal, version: 1, goal: key }, where) as JsonObject;
      checkWireShape(doc, CAPTURED_GOAL_SPEC, where);
      checkCapturedHandlerReference(
        goal.handler,
        realm,
        `${where}.handler`,
        "The host refuses a goal whose handler the realm's manifest does not register.",
      );
      warnUndeclaredGoalTypes(goal, realm, where, warn);
      const path = `goals/${key}.yml`;
      checkCapturedPath(path, CAPTURED_MANIFEST_PATH, where);
      goalBytes += checkCapturedBytes(doc, path, CAPTURED_DOCUMENT_BYTES, where);
      checkCapturedTotalBytes(goalBytes, "goals", "$.goals");
      files.push(rendered(path, doc));
    }

    const triggers = Object.entries(realm.triggers ?? {});
    checkCapturedFileCount(triggers.length, "triggers", "$.triggers");
    let triggerBytes = 0;
    for (const [key, trigger] of triggers) {
      const where = `$.triggers.${key}`;
      if (key.trim() === "") throw new SynthError(`${where}: a trigger name cannot be blank`);
      const doc = canonicalize({ ...trigger, version: 1, trigger: key }, where) as JsonObject;
      checkWireShape(doc, TRIGGER_SPEC, where);
      checkDataPipeReference(trigger.source, realm, `${where}.source`, "source");
      checkDataPipeReference(trigger.consumer, realm, `${where}.consumer`, "consumer");
      const path = `triggers/${key}.yml`;
      checkCapturedPath(path, CAPTURED_MANIFEST_PATH, where);
      triggerBytes += checkCapturedBytes(doc, path, CAPTURED_DOCUMENT_BYTES, where);
      checkCapturedTotalBytes(triggerBytes, "triggers", "$.triggers");
      files.push(rendered(path, doc));
    }

    // An empty `views` list is a file the reader reads happily: it declares that this
    // realm's guest Cypher names no view aliases at all. Writing it out is a real
    // statement, so synth emits it rather than second-guessing the author.
    if (realm.queries) {
      const where = "$.queries";
      const doc = canonicalize({ ...realm.queries, version: 1 }, where) as JsonObject;
      checkWireShape(doc, QUERY_REFERENCES, where);
      checkCapturedBytes(doc, "queries/references.yml", CAPTURED_DOCUMENT_BYTES, where);
      files.push(rendered("queries/references.yml", doc));
    }

    if (realm.skills !== undefined && realm.skills.length > 0) {
      const skills = checkCapturedSkills(realm.skills, realmRootAbs, (abs, label) =>
        assertContained(abs, realmRootReal, label),
      );
      for (const file of skills.files) {
        if (assemblySeen.has(file.path)) continue;
        assemblySeen.add(file.path);
        assemblyFiles.push({ kind: "vendored", path: file.path, bytes: file.bytes });
      }
      // The handler types carry the same digests as a constant, so admission can check that
      // what the handler keys on is what the model will be given.
      files.push(rendered(SKILL_DIGESTS_PATH, { version: 1, digest: skills.digest }));
    }

    if (realm.views !== undefined && realm.views.length > 0) {
      files.push(rendered(`views/${realm.name}.yml`, capturedViews(realm.views)));
    }

    const apps = Object.entries(realm.apps ?? {});
    checkCapturedFileCount(apps.length, "apps", "$.apps");
    for (const [key, app] of apps) {
      const where = `$.apps.${key}`;
      if (!CAPTURED_APP_NAME.test(key)) {
        throw new SynthError(
          `${where}: an app's key is the filename of its own page, so it has to end ".html" and ` +
            `read as a plain filename — the host opens apps/${key} to get the page. Got "${key}".`,
        );
      }
      app.handlers.forEach((name, i) => {
        checkCapturedHandlerReference(
          name,
          realm,
          `${where}.handlers[${i}]`,
          "An app naming a handler it cannot call would fail every time it is opened.",
        );
      });
      // Both the page and every resource it names have to travel with the manifest:
      // the host reads them straight out of the same capture, and refuses the app if
      // any one of them is missing.
      addAppFile(join(realmRootAbs, `apps/${key}`), `${where}: the page apps/${key}`, {
        limit: appLimits.pageBytes,
        flag: APP_LIMIT_FLAGS.pageBytes,
      });
      const resourceCount = app.resources?.length ?? 0;
      if (resourceCount > appLimits.resourcesPerApp) {
        throw new SynthError(
          `${where}.resources: names ${resourceCount} resources, over the limit of ` +
            `${appLimits.resourcesPerApp} synth was given. A host that inlines more can take it: ` +
            `raise the limit with ${APP_LIMIT_FLAGS.resourcesPerApp}.`,
        );
      }
      let resourceBytes = 0;
      (app.resources ?? []).forEach((resource, i) => {
        const at = `${where}.resources[${i}]`;
        const prefix = `apps/${key}.assets/`;
        if (!resource.startsWith(prefix)) {
          throw new SynthError(
            `${at}: the host only loads an app's resources out of its own asset directory, so ` +
              `"${resource}" has to start "${prefix}".`,
          );
        }
        resourceBytes += addAppFile(join(realmRootAbs, resource), `${at}: "${resource}"`, {
          limit: appLimits.resourceBytes,
          flag: APP_LIMIT_FLAGS.resourceBytes,
          forbid: resource.endsWith(".css") ? /<\/style/i : /<\/script/i,
        });
        if (resourceBytes > appLimits.resourcesTotalBytes) {
          throw new SynthError(
            `${where}.resources: the host inlines every resource ahead of the page, and these come ` +
              `to ${resourceBytes} bytes, over the ${appLimits.resourcesTotalBytes}-byte total ` +
              `synth was given. Raise it with ${APP_LIMIT_FLAGS.resourcesTotalBytes} (or ` +
              `--app-limit) if your host takes larger apps.`,
          );
        }
      });
      const doc = canonicalize({ ...app, version: 1 }, where) as JsonObject;
      checkWireShape(doc, appSpec(appLimits.resourcesPerApp), where);
      checkCapturedBytes(doc, `apps/${key}.app.json`, CAPTURED_DOCUMENT_BYTES, where);
      files.push(rendered(`apps/${key}.app.json`, doc));
    }

    // The conventional `lenses` field writes what the conventional loader reads: an id,
    // a name and a `spec`. `CapturedLensManifest.kt` reads a different document — version,
    // id, name and a handler — and refuses one carrying `spec` at all. It refuses the
    // whole `lenses/` directory over a single unreadable file, and `CapturedWatchManifest`
    // resolves every watch's lens through it, so one conventional lens file in a captured
    // capture costs the realm its lenses and its watches together. Refused here rather
    // than emitted into a file the host throws away.
    if (realm.lenses && Object.keys(realm.lenses).length > 0) {
      throw new SynthError(
        `$.lenses: a captured realm's lenses are read by CapturedLensManifest, which reads ` +
          `version, id, name and handler and refuses the conventional "spec" field — so these ` +
          `would emit lenses/ files the host throws away, taking every watch that names one of ` +
          `them with them. Declare them under $.capturedLenses instead, each as { name, handler }.`,
      );
    }

    const capturedLenses = Object.entries(realm.capturedLenses ?? {});
    checkCapturedFileCount(capturedLenses.length, "lenses", "$.capturedLenses");
    let lensBytes = 0;
    for (const [key, lens] of capturedLenses) {
      const where = `$.capturedLenses.${key}`;
      if (key.trim() === "") throw new SynthError(`${where}: a lens id cannot be blank`);
      // The author's own fields go down first and the generated ones last, so a spec
      // that happens to carry `version` or `id` cannot overwrite either.
      const doc = canonicalize({ ...lens, version: 1, id: key }, where) as JsonObject;
      checkWireShape(doc, CAPTURED_LENS_SPEC, where);
      checkCapturedHandlerReference(
        lens.handler,
        realm,
        `${where}.handler`,
        "A lens whose handler the host never grants can never be opened.",
      );
      const path = `lenses/${key}.yml`;
      checkCapturedPath(path, CAPTURED_MANIFEST_PATH, where);
      lensBytes += checkCapturedBytes(doc, path, CAPTURED_DOCUMENT_BYTES, where);
      checkCapturedTotalBytes(lensBytes, "lenses", "$.capturedLenses");
      files.push(rendered(path, doc));
    }

    const watches = Object.entries(realm.watches ?? {});
    if (watches.length > CAPTURED_MAX_WATCHES) {
      throw new SynthError(
        `$.watches: the host reads at most ${CAPTURED_MAX_WATCHES} watches out of watches/, and ` +
          `this declares ${watches.length}. Past the limit it refuses every one of them.`,
      );
    }
    let watchBytes = 0;
    for (const [key, watch] of watches) {
      const where = `$.watches.${key}`;
      if (key.trim() === "") throw new SynthError(`${where}: a watch name cannot be blank`);
      // The author's own fields go down first and the generated ones last, so a spec
      // that happens to carry `version` or `name` cannot overwrite either.
      const doc = canonicalize({ ...watch, version: 1, name: key }, where) as JsonObject;
      // Checked before the semantic rules below, the same order goals and triggers
      // hold to: a document that is not even the right shape (a missing field, the
      // wrong type) is refused by name here, rather than reaching a check that assumes
      // the field is there and of the right type.
      checkWireShape(doc, WATCH_SPEC, where);
      checkWatchLensReference(watch.lens, realm, `${where}.lens`);
      checkWatchSchedule(watch.schedule, `${where}.schedule`);
      checkUtf8ByteLimit(watch.criteria, WATCH_CRITERIA_BYTES, "criteria", `${where}.criteria`);
      if (watch.judge !== undefined) {
        checkUtf8ByteLimit(watch.judge, WATCH_JUDGE_BYTES, "judge", `${where}.judge`);
      }
      const path = `watches/${key}.yml`;
      checkCapturedPath(path, CAPTURED_MANIFEST_PATH, where);
      watchBytes += checkCapturedBytes(doc, path, CAPTURED_DOCUMENT_BYTES, where);
      checkCapturedTotalBytes(watchBytes, "watches", "$.watches");
      files.push(rendered(path, doc));
    }
  } else {
    for (const [key, goal] of Object.entries(realm.goals ?? {})) {
      const where = `$.goals.${key}`;
      if (key.trim() === "") throw new SynthError(`${where}: a goal name cannot be blank`);
      const doc = canonicalize({ name: key, stepType: "goal", ...goal }, where) as JsonObject;
      checkWireShape(doc, GOAL_SPEC, where);
      files.push(rendered(`goals/${key}.yml`, doc));
    }
  }

  if (realm.webhooks && Object.keys(realm.webhooks).length > 0) {
    const webhooks = realm.webhooks as Record<string, WebhookSpec>;
    const mapped = Object.fromEntries(
      Object.entries(webhooks).map(([key, spec]) => [key, webhookKebab(spec)]),
    );
    const sorted = Object.keys(mapped).sort();
    const entries = named(mapped, "$.webhooks");
    entries.forEach((entry, i) => {
      checkWireShape(entry, WEBHOOK_REGISTRATION, `$.webhooks.${sorted[i]}`);
    });
    files.push(rendered(`webhooks/${realm.name}.yml`, entries));
  }

  for (const [id, lens] of Object.entries(realm.lenses ?? {})) {
    const where = `$.lenses.${id}`;
    if (lens.spec.kind === "cypherscript") checkCypher(lens.spec.script, `${where}.spec.script`);
    if (lens.source !== undefined && lens.source !== realm.name) {
      throw new SynthError(
        `${where}.source: the loader stamps every realm-shipped lens's source to the realm's ` +
          `own name ("${realm.name}") the moment it reads the file, overwriting whatever is ` +
          `written here. "${lens.source}" would never be read back. Remove the field, or set it ` +
          `to "${realm.name}" if you want the value already written down.`,
      );
    }
    const doc = canonicalize({ id, ...lens }, where) as JsonObject;
    checkWireShape(doc, LENS, where);
    files.push(rendered(`lenses/${id}.yml`, doc));
  }

  if (realm.layers && realm.layers.length > 0) {
    realm.layers.forEach((layer, i) => {
      if (!/^[a-z0-9][a-z0-9-]*@[0-9]+(\.[0-9]+){0,2}$/.test(layer)) {
        throw new SynthError(
          `$.layers[${i}]: expected "name@version" with a plain semver, got "${layer}"`,
        );
      }
    });
  }

  const runtime = realm.runtime ?? "typescript";
  if (!["typescript", "python", "ruby", "lua", "compiled"].includes(runtime)) {
    throw new SynthError(`$.runtime: unknown runtime "${runtime}"`);
  }

  // The entry file is the one thing every runtime needs shipped as written: it is
  // what a handler dispatch actually runs, whatever language it's in. An author who
  // names one explicitly gets a hard failure if it turns out missing — they said a
  // real file lives there. A realm that leaves the field to its runtime's convention
  // just gets nothing copied when nothing is there yet: plenty of fixtures declare
  // handlers as a manifest-only surface before the source exists.
  const hasHandlers = realm.handlers !== undefined && Object.keys(realm.handlers).length > 0;
  if (realm.entry !== undefined) {
    const entryAbs = join(realmRootAbs, realm.entry);
    if (!existsSync(entryAbs)) {
      throw new SynthError(`$.entry: file not found at "${entryAbs}"`);
    }
    addAssemblyFile(entryAbs, `entry "${realm.entry}"`);
  } else if (hasHandlers) {
    const conventional = conventionalEntry(runtime);
    const entryAbs = join(realmRootAbs, conventional);
    if (existsSync(entryAbs)) {
      addAssemblyFile(entryAbs, `the conventional entry "${conventional}"`);
    }
  }

  if (
    (realm.dependencies && Object.keys(realm.dependencies).length > 0) ||
    realm.layers?.length ||
    runtime !== "typescript"
  ) {
    const entries = Object.keys(realm.dependencies ?? {})
      .sort()
      .map((name) => {
        const spec = realm.dependencies?.[name] as unknown as Record<string, unknown>;
        const where = `$.dependencies.${name}`;
        if (!IDENTIFIER.test(name)) {
          throw new SynthError(
            `${where}: "${name}" is not a valid identifier for a context member`,
          );
        }
        if (name === "log" || name === "gateway") {
          throw new SynthError(`${where}: "${name}" collides with a built-in context member`);
        }
        for (const field of ["module", "version", "sha256"] as const) {
          if (typeof spec[field] !== "string" || spec[field] === "") {
            throw new SynthError(`${where}: missing required "${field}"`);
          }
        }
        if (!REGISTRY_ID.test(spec.module as string)) {
          throw new SynthError(
            `${where}.module: expected a registry id of lowercase letters, digits and dashes, got "${spec.module}"`,
          );
        }
        if (!SEMVER.test(spec.version as string)) {
          throw new SynthError(
            `${where}.version: expected a plain semver like "3.50", got "${spec.version}"`,
          );
        }
        if (!/^[0-9a-f]{64}$/.test(spec.sha256 as string)) {
          throw new SynthError(`${where}.sha256: expected 64 lowercase hex characters`);
        }
        if (
          spec.kind !== undefined &&
          (typeof spec.kind !== "string" || !DEPENDENCY_KIND_NAME.test(spec.kind))
        ) {
          throw new SynthError(
            `${where}.kind: expected a lowercase name like "sqlite" or "pure-compute", got ` +
              `${JSON.stringify(spec.kind)}. The host refuses the whole manifest over it.`,
          );
        }
        if (spec.kind === "pure-compute") {
          const stateful = (["persistent", "init", "migrations"] as const).find(
            (field) => spec[field] !== undefined && spec[field] !== false,
          );
          if (stateful !== undefined) {
            throw new SynthError(
              `${where}.${stateful}: a pure-compute dependency keeps no state, so the host ` +
                `refuses "${stateful}" on it as dependency-kind-unsupported`,
            );
          }
        }
        if (spec.init !== undefined && typeof spec.init === "string") {
          if (spec.init.startsWith("/")) {
            throw new SynthError(
              `${where}.init: must be a relative path. An absolute path is refused.`,
            );
          }
          if (spec.init.includes("..")) {
            throw new SynthError(`${where}.init: path may not contain ".." segments`);
          }
          const initPath = join(realmRoot, spec.init);
          if (!existsSync(initPath)) {
            throw new SynthError(`${where}.init: file not found at "${initPath}"`);
          }
          addAssemblyFile(initPath, `dependency "${name}"'s init "${spec.init}"`);
        }
        if (spec.migrations !== undefined) {
          checkMigrations(spec, `${where}.migrations`, (path, label) => {
            const abs = join(realmRoot, path);
            if (!existsSync(abs)) return undefined;
            if (statSync(abs).isDirectory()) return "directory";
            addAssemblyFile(abs, label);
            return readFileSync(abs);
          });
        }
        if (spec.methods !== undefined) {
          if (
            typeof spec.methods !== "object" ||
            spec.methods === null ||
            Array.isArray(spec.methods)
          ) {
            throw new SynthError(`${where}.methods: expected an object keyed by method name`);
          }
          if (isSqliteDependency(spec)) {
            throw new SynthError(
              `${where}.methods: a sqlite dependency's surface is fixed by the host — it has one method, exec, which is not declared here — so "methods" is refused`,
            );
          }
          for (const methodName of Object.keys(spec.methods as Record<string, unknown>).sort()) {
            const methodWhere = `${where}.methods.${methodName}`;
            if (!IDENTIFIER.test(methodName)) {
              throw new SynthError(
                `${methodWhere}: "${methodName}" is not a valid identifier for a generated bridge method`,
              );
            }
            const methodSpec = (spec.methods as Record<string, unknown>)[methodName] as
              | Record<string, unknown>
              | undefined;
            const args = methodSpec?.args;
            if (!Array.isArray(args)) {
              throw new SynthError(`${methodWhere}.args: expected an array of argument types`);
            }
            args.forEach((argType, i) => {
              if (!DEPENDENCY_VALUE_TYPES.includes(argType as DependencyValueType)) {
                throw new SynthError(
                  `${methodWhere}.args[${i}]: expected one of ${DEPENDENCY_VALUE_TYPES.join(", ")}, got ${JSON.stringify(argType)}`,
                );
              }
            });
            if (!DEPENDENCY_VALUE_TYPES.includes(methodSpec?.returns as DependencyValueType)) {
              throw new SynthError(
                `${methodWhere}.returns: expected one of ${DEPENDENCY_VALUE_TYPES.join(", ")}, got ${JSON.stringify(methodSpec?.returns)}`,
              );
            }
          }
        }
        return canonicalize({ name, ...spec }, where);
      });
    const manifest: Record<string, JsonValue> = { version: 1, entries };
    if (runtime !== "typescript") manifest.runtime = runtime;
    if (realm.layers?.length) manifest.layers = [...realm.layers].sort();
    files.push(rendered("dependencies/manifest.json", manifest));
  }

  for (const [id, focus] of Object.entries(realm.focuses ?? {})) {
    const where = `$.focuses.${id}`;
    const doc = canonicalize({ name: id, ...focus }, where) as JsonObject;
    checkWireShape(doc, FOCUS_SPEC, where);
    files.push(rendered(`focuses/${id}.yml`, doc));
  }

  if (realm.handlers && Object.keys(realm.handlers).length > 0) {
    const aliases = new Map<string, string>();
    for (const name of Object.keys(realm.handlers).sort()) {
      const where = `$.handlers.${name}`;
      if (!IDENTIFIER.test(name)) {
        throw new SynthError(`${where}: "${name}" is not a valid identifier for a verb name`);
      }
      const alias = `${pascalCase(name)}Handler`;
      const collidesWith = aliases.get(alias);
      if (collidesWith !== undefined && collidesWith !== name) {
        throw new SynthError(
          `${where}: "${alias}" collides with the alias already generated for $.handlers.${collidesWith}`,
        );
      }
      aliases.set(alias, name);
      checkHandlerTypeMethod(realm.handlers[name] as HandlerSpec, where, realm);
      checkHandlerSchedule(name, realm.handlers[name] as HandlerSpec, where, realm, realmRoot);
    }

    const generatedAt = realm.generatedAt ?? "1970-01-01T00:00:00Z";
    const entries = Object.entries(realm.handlers)
      .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
      .map(([key, spec]) => ({
        namespace: spec.namespace,
        name: key,
        description: spec.description,
        inputSchema: spec.input ?? { type: "object" },
        outputSchema: spec.output ?? { type: "object" },
        ...(spec.onType !== undefined ? { onType: spec.onType } : {}),
        ...(spec.className !== undefined ? { className: spec.className } : {}),
        ...(spec.schedule !== undefined ? { schedule: spec.schedule } : {}),
      }));
    const manifest = {
      version: 1,
      generatedAt,
      entries,
      ...(realm.entry !== undefined ? { entry: realm.entry } : {}),
    };
    const doc = canonicalize(manifest, "$.handlers") as JsonObject;
    // Checked over the rendered value, like every other surface: what matters is the
    // bytes that land in the file, however they got there.
    for (const entry of doc.entries as JsonObject[]) {
      checkWireShape(entry, REALM_HANDLER_ENTRY, `$.handlers.${String(entry.name)}`);
    }
    files.push(rendered("dist/manifest.json", doc));
  }

  // Two different things are called "channels", and they share nothing but the directory
  // they land in. A conventional realm's channel is a connector class the engine
  // instantiates; a captured realm's is a connection the host itself opens, declared
  // through `connecting()` and emitted alongside its sources and consumers.
  if (realm.execution === "captured") {
    const connecting = emitConnecting(realm);
    for (const file of connecting) {
      if (!file.path.startsWith("channels/")) continue;
      checkChannelFileBytes(
        file,
        `$.channels.${file.path.slice("channels/".length, -".yml".length)}`,
      );
    }
    files.push(...connecting);
  } else {
    for (const [id, channel] of Object.entries(realm.channels ?? {})) {
      const mapped = camelToKebab(channel);
      files.push(
        rendered(
          `channels/${id}.yml`,
          canonicalize({ ...mapped, name: id }, `$.channels.${id}`) as JsonObject,
        ),
      );
    }
  }

  for (const [id, eventList] of Object.entries(realm.events ?? {})) {
    files.push(
      rendered(
        `events/${id}.yml`,
        eventList.map((event, idx) => renderEvent(event, `$.events.${id}[${idx}]`)),
      ),
    );
  }

  checkOutputCollisions(files, vendoredRecords, realmRoot);

  // Assembly files land last and get their own, simpler collision check: a copied
  // source landing on a path synth already writes to, rendered or vendored, would
  // silently overwrite it once `writeSynth` gets to it.
  for (const file of assemblyFiles) {
    const collidesWithRendered = files.some((f) => f.kind === "rendered" && f.path === file.path);
    if (collidesWithRendered) {
      throw new SynthError(
        `assembly: copying "${file.path}" would overwrite a file synth generates at that same path.`,
      );
    }
    const collidesWithVendored = files.some((f) => f.kind === "vendored" && f.path === file.path);
    if (collidesWithVendored) {
      throw new SynthError(
        `assembly: copying "${file.path}" would overwrite a vendored api document at that same path.`,
      );
    }
  }
  files.push(...assemblyFiles);

  return files;
}

/**
 * The wire wants `token-env` and `signal-type`; TypeScript writes `tokenEnv` and
 * `signalType`. This is the one place that difference gets bridged: everything else on
 * a channel is a connector-specific key and passes through as written.
 */
function camelToKebab(channel: ChannelSpec): Record<string, JsonValue> {
  const result: Record<string, JsonValue> = {};
  for (const [key, value] of Object.entries(channel)) {
    if (value === undefined) continue;
    if (key === "tokenEnv") {
      result["token-env"] = value;
    } else if (key === "signalType") {
      result["signal-type"] = value;
    } else if (key === "autoStart") {
      result["auto-start"] = value;
    } else {
      result[key] = value;
    }
  }
  return result;
}

/**
 * Renders one event-source entry, mapping its webhook block's `signatureSecret` and
 * `tierWhen` to the kebab-case keys `RealmEventConfig.kt` actually reads — the same
 * silent-drop risk `camelToKebab` exists for on channels, on a surface that is a closed
 * shape rather than an open one, so it is checked against the wire allowlist too.
 */
function renderEvent(event: EventSpec, where: string): JsonValue {
  const base: JsonObject = { type: event.type };
  if ("poll" in event) {
    base.poll = canonicalize(event.poll, `${where}.poll`) as JsonObject;
  } else {
    const webhook = event.webhook as unknown as Record<string, JsonValue | undefined>;
    const mapped: Record<string, JsonValue> = {};
    for (const [key, val] of Object.entries(webhook)) {
      if (val === undefined) continue;
      if (key === "signatureSecret") mapped["signature-secret"] = val;
      else if (key === "tierWhen") mapped["tier-when"] = val;
      else mapped[key] = val;
    }
    base.webhook = canonicalize(mapped, `${where}.webhook`) as JsonObject;
  }
  const doc = canonicalize(base, where);
  checkWireShape(doc, EVENT_ENTRY, where);
  return doc;
}

/**
 * Renders one webhook registration, mapping `signature.secretRef.oauthApp` to the
 * `secret-ref.oauth-app` shape `SignatureConfig`/`SecretRef` read, and `timestamp`'s
 * `toleranceSeconds` to `tolerance-seconds`.
 *
 * Every other key — including one nobody meant to write — passes through as written,
 * the same discipline `camelToKebab` and `renderEvent` hold to. An allowlist copy would
 * quietly DROP a typo'd key before the wire allowlist ever saw it, which is worse than
 * refusing it: the value would vanish with no error, the exact defect this whole
 * mechanism exists to catch.
 */
function webhookKebab(spec: WebhookSpec): Record<string, JsonValue> {
  const out: Record<string, JsonValue> = {};
  for (const [key, val] of Object.entries(spec)) {
    if (val === undefined) continue;
    out[key] =
      key === "signature"
        ? signatureKebab(val as NonNullable<WebhookSpec["signature"]>)
        : (val as JsonValue);
  }
  return out;
}

/** The kebab-case sub-mapping `webhookKebab` applies to a webhook's `signature` block. */
function signatureKebab(sig: NonNullable<WebhookSpec["signature"]>): JsonObject {
  const out: JsonObject = {};
  for (const [key, val] of Object.entries(sig)) {
    if (val === undefined) continue;
    if (key === "secretRef") {
      const ref: Record<string, JsonValue> = {};
      for (const [refKey, refVal] of Object.entries(val as Record<string, JsonValue | undefined>)) {
        if (refVal === undefined) continue;
        ref[refKey === "oauthApp" ? "oauth-app" : refKey] = refVal;
      }
      out["secret-ref"] = ref;
    } else if (key === "timestamp") {
      const timestamp: Record<string, JsonValue> = {};
      for (const [tsKey, tsVal] of Object.entries(val as Record<string, JsonValue | undefined>)) {
        if (tsVal === undefined) continue;
        timestamp[tsKey === "toleranceSeconds" ? "tolerance-seconds" : tsKey] = tsVal;
      }
      out.timestamp = timestamp;
    } else {
      out[key] = val as JsonValue;
    }
  }
  return out;
}

/**
 * Checks a handler that declares itself a method on a type.
 *
 * `onType` names the LABEL whose instances the handler runs on. The engine files such a
 * handler in the program-method catalog rather than on the gateway surface
 * (`RealmHandlerLoader.typeMethods`), and the catalog matches purely on the label a node
 * carries — it never asks which realm declared it. So a label this realm does not declare
 * is NOT an error: a realm may add behaviour to a host type like `Person`, or to a mixin
 * label another realm owns. Refusing those would make a shape the YAML surface can express
 * unwritable here, which the product treats as a defect. Only a blank label is refused,
 * because that one reaches no type at all.
 *
 * `className` is the class-based form: the sandbox instantiates the exported class and
 * calls the method on the instance. It is read in exactly one place — the non-wasm branch
 * of `typeMethods` — so there are two ways to write one that can never be read, and both
 * stop here:
 *
 *  - without `onType`, because that branch is reached only for entries that have one;
 *  - on a `host: "wasm"` realm, because a wasm realm has no module for the sandbox to
 *    `require()`. Its type methods go back through the gateway instead, and the spec the
 *    engine builds for them carries no class name at all. A declared wasm host always
 *    resolves to the wasm placement or to a load-time conflict (`resolvePlacement`), never
 *    to the JS path, so this is dead by construction rather than by circumstance.
 */
function checkHandlerTypeMethod(spec: HandlerSpec, where: string, realm: Realm): void {
  if (spec.onType !== undefined && spec.onType.trim() === "") {
    throw new SynthError(
      `${where}.onType: cannot be blank. It names the graph label whose instances this ` +
        `handler runs on; a blank one reaches no type.`,
    );
  }

  if (spec.className === undefined) return;

  if (spec.className.trim() === "") {
    throw new SynthError(
      `${where}.className: cannot be blank. It names the class the sandbox instantiates; ` +
        `drop it to use the plain function form instead.`,
    );
  }
  if (spec.onType === undefined) {
    throw new SynthError(
      `${where}.className: only means something with onType set — the engine reads it when ` +
        `it builds a TYPE METHOD, and a handler with no onType never becomes one. Add ` +
        `${where}.onType, or drop the className.`,
    );
  }
  if (realm.host === "wasm") {
    throw new SynthError(
      `${where}.className: a wasm realm's type methods are dispatched through the gateway, ` +
        `not by requiring a module, so the engine builds their spec without a class name and ` +
        `this would reach no field. Drop it, or move the realm to host: "docker".`,
    );
  }
}

/** Every whitespace-separated field of a Spring six-field cron expression has to look like one. */
const CRON_FIELD = /^[-0-9*,/?LW#]+$/i;
const CRON_NAME_FIELD = /^[A-Z]{3}(-[A-Z]{3})?$/i;

/**
 * Checks a handler's `schedule` against the same rules the engine's own
 * `RealmHandlerEntry.scheduleProblem()` enforces, plus the cron shape the wasm build's
 * `defineSchedule()` already checks for a source-authored schedule — so a
 * manifest-authored one is held to the same bar.
 *
 * Also refuses the one thing neither authority can see on its own: the SAME handler
 * named by a `defineSchedule()` call in the handler source the wasm build reads. Two
 * schedule authorities naming one function would leave the cadence to whichever one the
 * host happens to read last, silently. Only checked for a TypeScript runtime, since
 * `defineSchedule` is a mechanism of the JS/TS wasm build and nothing else calls it.
 */
function checkHandlerSchedule(
  name: string,
  spec: HandlerSpec,
  where: string,
  realm: Realm,
  realmRoot: string,
): void {
  if (spec.schedule === undefined) return;

  const fields = spec.schedule.trim().split(/\s+/);
  if (fields.length !== 6) {
    throw new SynthError(
      `${where}.schedule: needs SIX cron fields (second minute hour day-of-month month ` +
        `day-of-week), got ${fields.length}. Daily at 08:00 is "0 0 8 * * *".`,
    );
  }
  const illegal = fields.filter((f) => !CRON_FIELD.test(f) && !CRON_NAME_FIELD.test(f));
  if (illegal.length > 0) {
    throw new SynthError(
      `${where}.schedule: ${illegal.length} field(s) are not cron: ${illegal.join(", ")}. ` +
        `Daily at 08:00 is "0 0 8 * * *".`,
    );
  }

  // The engine's own first rule, checked in its order. It refuses the pair at load and
  // then drops the schedule, so without this the author's cron job simply never runs.
  if (spec.onType !== undefined) {
    throw new SynthError(
      `${where}.schedule: a scheduled invocation has no receiver, so schedule and onType ` +
        `cannot combine. The engine refuses it as "function '${spec.namespace}.${name}' ` +
        `declares both schedule and onType" and ignores the schedule. Drop one of them.`,
    );
  }

  const required = (spec.input as { required?: unknown } | undefined)?.required;
  if (Array.isArray(required) && required.length > 0) {
    throw new SynthError(
      `${where}.schedule: a manifest schedule always dispatches with {}, so a required input ` +
        `field guarantees every scheduled run fails. Drop "required" from $.handlers.${name}.input, ` +
        `or drop the schedule.`,
    );
  }

  if ((realm.runtime ?? "typescript") !== "typescript") return;
  const entryPath = realm.entry ?? "wasm/handlers.ts";
  const entryFile = join(realmRoot, entryPath);
  if (!existsSync(entryFile)) return;
  const source = readFileSync(entryFile, "utf8");
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  if (new RegExp(`defineSchedule\\s*\\(\\s*['"\`]${escaped}['"\`]`).test(source)) {
    throw new SynthError(
      `${where}.schedule: "${entryPath}" also calls defineSchedule("${name}", …). A handler can't ` +
        `be scheduled by both the manifest and its own source — the two authorities would silently ` +
        `disagree about the cadence. Remove one.`,
    );
  }
}

/** The most migrations the host reads for one dependency. */
const MAX_MIGRATIONS = 64;

/** The host's byte limit on an init script, which every migration is held to as well. */
const SQL_SCRIPT_BYTES = 1_048_576;

/** The longest script path the host reads. */
const MAX_SCRIPT_PATH = 1024;

/** One path segment the host accepts in a captured script path. */
const SCRIPT_PATH_SEGMENT = /^[A-Za-z0-9_.-]+$/;

/**
 * Checks a dependency's `migrations`: an ordered list of `.sql` files inside the realm, on a
 * `sqlite3-wasi` dependency that has an init script, each one shipped with the realm.
 * `ship` copies a script into the output and returns its bytes, undefined when there is
 * nothing there, or "directory" when the path is a folder.
 */
function checkMigrations(
  spec: Record<string, unknown>,
  where: string,
  ship: (path: string, label: string) => Uint8Array | "directory" | undefined,
): void {
  const migrations = spec.migrations;
  const sqlite = isSqliteDependency(spec);
  // A kind the host offers beyond the two it always has may keep state, and the host
  // decides whether it takes migrations. Without a kind, only the SQLite module does.
  if (!sqlite && spec.kind === undefined) {
    throw new SynthError(
      `${where}: only a ${SQLITE_MODULE} dependency takes migrations, and this one is "${spec.module}"`,
    );
  }
  if (!Array.isArray(migrations)) {
    throw new SynthError(`${where}: expected a list of realm-relative .sql paths`);
  }
  if (spec.init === undefined) {
    throw new SynthError(
      `${where}: needs an init script. The init script is version 0 and migrations run after it.`,
    );
  }
  if (migrations.length > MAX_MIGRATIONS) {
    throw new SynthError(
      `${where}: at most ${MAX_MIGRATIONS} migrations, and this lists ${migrations.length}`,
    );
  }
  const seen = new Set<string>();
  migrations.forEach((path: unknown, i) => {
    const at = `${where}[${i}]`;
    if (typeof path !== "string" || path === "") {
      throw new SynthError(`${at}: expected a realm-relative path, got ${JSON.stringify(path)}`);
    }
    if (path.length > MAX_SCRIPT_PATH) {
      throw new SynthError(
        `${at}: the host reads at most ${MAX_SCRIPT_PATH} characters of a script path, and this one has ${path.length}`,
      );
    }
    checkRelativePath(path, at);
    if (path.split("/").some((segment) => !SCRIPT_PATH_SEGMENT.test(segment) || segment === ".")) {
      throw new SynthError(
        `${at}: each part of the path may use only letters, digits, "_", "." and "-", got "${path}"`,
      );
    }
    if (sqlite && !path.endsWith(".sql")) {
      throw new SynthError(`${at}: expected a .sql file, got "${path}"`);
    }
    if (seen.has(path)) {
      throw new SynthError(`${at}: "${path}" is already in the list, and each script runs once`);
    }
    seen.add(path);
    const bytes = ship(path, `migration "${path}"`);
    if (bytes === undefined) {
      throw new SynthError(`${at}: file not found at "${path}"`);
    }
    if (bytes === "directory") {
      throw new SynthError(`${at}: "${path}" is a directory, and a migration is one .sql file`);
    }
    if (bytes.length > SQL_SCRIPT_BYTES) {
      throw new SynthError(
        `${at}: ${path} is ${bytes.length} bytes, and the host reads at most ${SQL_SCRIPT_BYTES} bytes of a script`,
      );
    }
    try {
      new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    } catch {
      throw new SynthError(
        `${at}: ${path} is not valid UTF-8, and the host reads a script strictly as UTF-8`,
      );
    }
  });
}

/**
 * Checks that a path is realm-relative: no leading slash, no backslashes, and no ".."
 * segment. This is the same shape a dependency's `init` path is held to, applied here
 * to `entry`.
 */
function checkRelativePath(path: string, where: string): void {
  if (path.startsWith("/")) {
    throw new SynthError(`${where}: must be a relative path. Got "${path}"`);
  }
  if (path.includes("\\")) {
    throw new SynthError(`${where}: must not contain backslashes, got "${path}"`);
  }
  if (path.split("/").includes("..")) {
    throw new SynthError(`${where}: path may not contain ".." segments, got "${path}"`);
  }
}

/** Every HTTP method OpenAPI recognizes under a path item. */
const HTTP_METHODS = ["get", "put", "post", "delete", "options", "head", "patch", "trace"] as const;

/**
 * Every `operationId` an OpenAPI document declares under `paths`, mapped to every
 * "METHOD path" location that declares it. A document with no `paths`, or a method
 * with no `operationId`, just contributes nothing here; the allowlist check in
 * `checkApis` is what turns a missing id into an error naming the document. An
 * operationId with more than one location means gateway dispatch cannot tell which
 * operation it is choosing; `checkApis` refuses that once the whole document is
 * walked and every location is known.
 *
 * A path item written as a bare `$ref` (a pointer elsewhere in the document, with no
 * methods declared inline) is refused here by name. Vendoring is a curated, by-hand
 * process already, so the honest scope for it is documents whose path items are
 * inlined; see docs/realm-definitions-in-typescript.md for the note.
 *
 * `webhooks`, an OpenAPI 3.1 document root sibling to `paths`, describes a callback
 * the vendor sends. It names no operation this realm can call, so it is not walked
 * here and does not participate in operation resolution.
 */
function collectOperationIds(doc: Record<string, unknown>, where: string): Map<string, string[]> {
  const locations = new Map<string, string[]>();
  const paths = doc.paths;
  if (!paths || typeof paths !== "object") return locations;
  for (const [path, pathItem] of Object.entries(paths as Record<string, unknown>)) {
    if (!pathItem || typeof pathItem !== "object") continue;
    if ("$ref" in pathItem) {
      throw new SynthError(
        `${where}: path "${path}" is a $ref path item. Vendored documents must inline their path items.`,
      );
    }
    for (const method of HTTP_METHODS) {
      const operation = (pathItem as Record<string, unknown>)[method];
      if (!operation || typeof operation !== "object") continue;
      const operationId = (operation as Record<string, unknown>).operationId;
      if (typeof operationId !== "string") continue;
      const at = `${method.toUpperCase()} ${path}`;
      const existing = locations.get(operationId);
      if (existing) existing.push(at);
      else locations.set(operationId, [at]);
    }
  }
  return locations;
}

/**
 * Reads and parses a vendored API document by its file extension.
 *
 * Someone fetches these documents from a vendor by hand and commits them; nothing here
 * generates them. JSON and YAML are both worth supporting; the `yaml` package already
 * sits in this package's dependencies for emitting realm YAML, so parsing it back costs
 * nothing extra. Any other extension is refused by name. It is never guessed at.
 */
function parseVendoredDocument(
  url: string,
  docPath: string,
  where: string,
): Record<string, unknown> {
  const raw = readFileSync(docPath, "utf8");
  const isJson = url.endsWith(".json");
  const isYaml = url.endsWith(".yaml") || url.endsWith(".yml");
  if (!isJson && !isYaml) {
    throw new SynthError(
      `${where}: only .json, .yaml, and .yml vendored documents are supported, got "${url}"`,
    );
  }
  try {
    return (isJson ? JSON.parse(raw) : parseYamlDocument(raw)) as Record<string, unknown>;
  } catch (error) {
    throw new SynthError(`${where}: "${docPath}" failed to parse: ${(error as Error).message}`);
  }
}

/** A url the host fetches over the network rather than reading off disk. */
const REMOTE_URL = /^https?:\/\//i;

/** An HTTP header field name, per RFC 7230's `token` rule. */
const HEADER_NAME = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/;

/** A `${VAR}` reference inside a header value, as the host's own resolver reads them. */
const HEADER_SUBSTITUTION = /\$\{([^}]*)\}/g;

/** The shape a substituted variable name has to have to be an environment or credential key. */
const SECRET_NAME = /^[A-Za-z_][A-Za-z0-9_]*$/;

/**
 * The two headers that exist to carry a credential. A literal value in one of these is
 * key material in a committed file, which is the one thing a realm definition may never
 * contain.
 */
const CREDENTIAL_HEADERS = ["authorization", "proxy-authorization"];

/**
 * The gateway namespace an api entry contributes, or `undefined` when it contributes
 * none.
 *
 * The engine passes the entry's declared `name` down as the gateway prefix, so `name`
 * and the namespace are the same string. Leaving `name` out of the definition keeps
 * today's behaviour, where the key the spec is filed under becomes the name. Writing
 * `name: null` says the entry has no name at all — then the engine derives one from the
 * url, by rules involving its spec cache that synth cannot reproduce, so synth stops
 * claiming to know what the namespace is rather than guessing at one.
 */
function effectiveApiName(key: string, spec: ApiSpec): string | undefined {
  return spec.name === null ? undefined : (spec.name ?? key);
}

/** Every namespace the realm's apis contribute, mapped back to the key each was filed under. */
function apiNamespaces(
  apis: Record<string, ApiSpec> | undefined,
): Map<string, { key: string; spec: ApiSpec }> {
  const byNamespace = new Map<string, { key: string; spec: ApiSpec }>();
  for (const [key, spec] of Object.entries(apis ?? {})) {
    const name = effectiveApiName(key, spec);
    if (name !== undefined) byNamespace.set(name, { key, spec });
  }
  return byNamespace;
}

/**
 * Every tag any operation in a document carries. What the engine's tag filter matches
 * against, so a tag naming nothing here exposes nothing and says nothing about it.
 */
function collectTags(doc: Record<string, unknown>): Set<string> {
  const tags = new Set<string>();
  const paths = doc.paths;
  if (!paths || typeof paths !== "object") return tags;
  for (const pathItem of Object.values(paths as Record<string, unknown>)) {
    if (!pathItem || typeof pathItem !== "object") continue;
    for (const method of HTTP_METHODS) {
      const operation = (pathItem as Record<string, unknown>)[method];
      if (!operation || typeof operation !== "object") continue;
      const declared = (operation as Record<string, unknown>).tags;
      if (!Array.isArray(declared)) continue;
      for (const tag of declared) if (typeof tag === "string") tags.add(tag);
    }
  }
  return tags;
}

/**
 * Checks a realm's custom headers, and refuses one carrying a secret in the clear.
 *
 * The host substitutes `${VAR}` from the credential store or the environment on the way
 * out, so a credential belongs in a header as a reference and never as a value. An
 * `Authorization` header written out in full would sit in the repository forever and be
 * readable by anyone who can read the realm.
 */
function checkHeaders(headers: Record<string, string>, where: string): void {
  for (const [name, headerValue] of Object.entries(headers)) {
    const at = `${where}.${name}`;
    if (!HEADER_NAME.test(name)) {
      throw new SynthError(`${at}: "${name}" is not a valid HTTP header name`);
    }
    if (headerValue.trim() === "") {
      throw new SynthError(`${at}: a header value cannot be blank`);
    }
    let substitutions = 0;
    for (const match of headerValue.matchAll(HEADER_SUBSTITUTION)) {
      substitutions += 1;
      const variable = match[1] as string;
      if (!SECRET_NAME.test(variable)) {
        throw new SynthError(
          `${at}: "\${${variable}}" is not a usable secret name. The host looks the name up in the ` +
            `credential store and then the environment, so it has to read as one: letters, digits ` +
            `and underscores, not starting with a digit.`,
        );
      }
    }
    if (CREDENTIAL_HEADERS.includes(name.toLowerCase()) && substitutions === 0) {
      throw new SynthError(
        `${at}: an ${name} header has to reference its credential as \${VAR}, which the host ` +
          `resolves at dispatch. Writing the value out puts key material in the realm, where it ` +
          `stays readable to everyone who can read the realm.`,
      );
    }
  }
}

/**
 * Checks an entry's OAuth2 block, and renders it with the keys the engine reads.
 *
 * Most of these are kebab-case on the wire and camelCase in the definition, which is a
 * silent-loss surface: `apis/` is read with unknown-key failure on, so a camelCase key
 * would take the whole file down rather than vanish quietly. Either way it never
 * reaches a field, so the mapping happens here, once.
 */
function oauth2Entry(spec: ApiSpec, where: string): JsonObject {
  const config = spec.oauth2 as NonNullable<ApiSpec["oauth2"]>;

  if (spec.auth !== "oauth2") {
    throw new SynthError(
      `${where}.oauth2: an oauth2 block is only read when auth is "oauth2", and this entry's auth ` +
        `is ${spec.auth === undefined ? "not set" : JSON.stringify(spec.auth)}. As written the ` +
        `whole block is inert.`,
    );
  }
  // The engine's type has client-secret and nothing reads it: the classic flow takes the
  // client id and secret from the user's wallet or the deployment vault, keyed by
  // provider, and PKCE sends no secret at all. So this is refused on both counts.
  if ("clientSecret" in (config as Record<string, unknown>)) {
    throw new SynthError(
      `${where}.oauth2.clientSecret: a client secret never goes in a realm. The host reads it from ` +
        `the user's wallet or the deployment vault, keyed by the provider, so a value here would be ` +
        `key material in a committed file that nothing reads.`,
    );
  }
  if (config.pkce && (config.clientId === undefined || config.clientId.trim() === "")) {
    throw new SynthError(
      `${where}.oauth2.pkce: the PKCE flow sends no client secret, so the client id has to be the ` +
        `one published here. Without it the host builds no oauth config at all and the connect ` +
        `button does nothing.`,
    );
  }
  if ((config.authUrl === undefined) !== (config.tokenUrl === undefined)) {
    throw new SynthError(
      `${where}.oauth2: authUrl and tokenUrl go together — the host only uses an entry that has ` +
        `both, so one on its own is never read.`,
    );
  }
  if (config.webhookTenancy && !config.identity) {
    throw new SynthError(
      `${where}.oauth2.webhookTenancy: the tenant key is the account id that "identity" resolves. ` +
        `Without an identity block there is nothing to register, so the store stays empty.`,
    );
  }

  const entry: JsonObject = {};
  if (config.clientId !== undefined) entry["client-id"] = config.clientId;
  if (config.authUrl !== undefined) entry["auth-url"] = config.authUrl;
  if (config.tokenUrl !== undefined) entry["token-url"] = config.tokenUrl;
  if (config.scopes !== undefined) entry.scopes = config.scopes;
  if (config.provider !== undefined) entry.provider = config.provider;
  if (config.identity) {
    const identity: JsonObject = {
      url: config.identity.url,
      "account-id-field": config.identity.accountIdField,
    };
    if (config.identity.method !== undefined) identity.method = config.identity.method;
    if (config.identity.auth !== undefined) identity.auth = config.identity.auth;
    if (config.identity.displayNameField !== undefined) {
      identity["display-name-field"] = config.identity.displayNameField;
    }
    entry.identity = identity;
  }
  if (config.webhookTenancy) entry["webhook-tenancy"] = { store: config.webhookTenancy.store };
  if (config.pkce !== undefined) entry.pkce = config.pkce;
  if (config.installUrl !== undefined) entry["install-url"] = config.installUrl;
  return entry;
}

/**
 * Validates the realm's API declarations and returns the `apis/apis.yml` entries,
 * ordered by key, alongside the raw bytes of every vendored document those entries'
 * urls point at. Returns `undefined` when the realm declares no apis, so the caller can
 * tell "nothing to check" from "checked and empty".
 *
 * A document either ships with the realm or lives at the vendor. A vendored one is read
 * and parsed here, once, and every operation id and tag the entry names is checked
 * against it; the cross-reference check below never reopens it, it only consults the
 * allowlist already checked here. A remote url is left alone: synth does not fetch at
 * build time, so there is nothing to check the allowlist against, and the allowlist is
 * taken at its word.
 *
 * The vendored bytes are read a second time here, with no encoding, so they are
 * copied to the output exactly as they sit on disk: `writeSynth` writes them straight
 * through, never round-tripping them through the parsed `doc` and its own
 * serialization. That is what keeps an `--out` tree's copy byte-identical to the
 * source, so `apis/apis.yml`'s urls resolve inside the tree that was written.
 */
function checkApis(
  apis: Record<string, ApiSpec> | undefined,
  realmRoot: string,
):
  | { entries: JsonValue[]; vendored: VendoredFile[]; vendoredRecords: VendoredRecord[] }
  | undefined {
  if (!apis || Object.keys(apis).length === 0) return undefined;

  // apis.yml always lands at "apis/apis.yml", so a vendored document's wire-facing url
  // is relative to that directory, the same directory the engine's hand-written apis.yml
  // already sits in. The definition states url realm-relative, the same convention
  // dependencies' `init` uses, so this is the one place the two conventions get bridged.
  const manifestDir = join(realmRoot, "apis");
  const vendored: VendoredFile[] = [];
  const vendoredRecords: VendoredRecord[] = [];

  const namespaces = new Map<string, string>();
  for (const key of Object.keys(apis).sort()) {
    const name = effectiveApiName(key, apis[key] as ApiSpec);
    if (name === undefined) continue;
    const owner = namespaces.get(name);
    if (owner !== undefined) {
      throw new SynthError(
        `$.apis.${key}: this entry's gateway namespace is "${name}", which $.apis.${owner} already ` +
          `uses. Two entries under one namespace make a dotted operation reference ambiguous.`,
      );
    }
    namespaces.set(name, key);
  }

  const entries = Object.keys(apis)
    .sort()
    .map((key) => {
      const spec = apis[key] as ApiSpec;
      const where = `$.apis.${key}`;
      if (!IDENTIFIER.test(key)) {
        throw new SynthError(
          `${where}: "${key}" is not a valid identifier for a gateway namespace`,
        );
      }
      if (spec.type !== "openapi" && spec.type !== "graphql") {
        throw new SynthError(
          `${where}.type: expected "openapi" or "graphql", got ${JSON.stringify(spec.type)}`,
        );
      }

      const name = effectiveApiName(key, spec);
      if (name !== undefined && !IDENTIFIER.test(name)) {
        throw new SynthError(
          `${where}.name: "${name}" becomes the gateway namespace, so handlers reach it as ` +
            `gateway.${name}.someOperation — which means it has to read as an identifier.`,
        );
      }

      if (spec.mutations !== undefined) {
        if (spec.type !== "graphql") {
          throw new SynthError(
            `${where}.mutations: only a graphql entry exposes mutations. On an openapi entry the ` +
              `list is read and then ignored, so nothing here would ever be callable.`,
          );
        }
        if (spec.mutations.length === 0) {
          throw new SynthError(
            `${where}.mutations: an empty list exposes no mutations, which is what leaving the field ` +
              `out already means. Name the mutations, or remove it.`,
          );
        }
      }

      if (spec.headers) checkHeaders(spec.headers, `${where}.headers`);
      if (spec.auth === "oauth2" && !spec.oauth2) {
        throw new SynthError(
          `${where}.auth: "oauth2" needs an oauth2 block. Without one the host finds no ` +
            `authorization url to send the user to, and the api is never connectable.`,
        );
      }

      for (const field of ["operationIds", "tags"] as const) {
        const list = spec[field];
        if (list === undefined) continue;
        if (list.length === 0) {
          throw new SynthError(
            `${where}.${field}: an empty list is not the same as no list — leave the field out to ` +
              `expose everything the document declares, which is what an empty one reads as.`,
          );
        }
        list.forEach((item, i) => {
          if (item.trim() === "") throw new SynthError(`${where}.${field}[${i}]: cannot be blank`);
        });
      }

      const remote = REMOTE_URL.test(spec.url);
      let wireUrl = spec.url;

      if (remote) {
        // Nothing to read at build time: the host fetches this when the world loads. The
        // allowlist is taken at its word, and every dotted reference to it is still
        // checked against that allowlist — just not against the document behind it.
        if (spec.url.trim() !== spec.url) {
          throw new SynthError(`${where}.url: a url cannot have leading or trailing whitespace`);
        }
      } else {
        checkRelativePath(spec.url, `${where}.url`);
        const docPath = join(realmRoot, spec.url);
        if (!existsSync(docPath)) {
          throw new SynthError(`${where}.url: file not found at "${docPath}"`);
        }
        if (spec.type === "openapi") {
          const doc = parseVendoredDocument(spec.url, docPath, `${where}.url`);
          if (typeof doc.openapi !== "string" || !OPENAPI_VERSION.test(doc.openapi)) {
            throw new SynthError(
              `${where}.url: "${spec.url}" does not declare an OpenAPI 3.x document (openapi: ${JSON.stringify(doc.openapi)})`,
            );
          }
          const locations = collectOperationIds(doc, `${where}.url`);
          for (const [operationId, at] of locations) {
            if (at.length > 1) {
              throw new SynthError(
                `${where}.url: "${spec.url}" declares operationId "${operationId}" more than once, at ${at.join(" and ")}. Duplicate operation ids make gateway dispatch ambiguous.`,
              );
            }
          }
          for (const id of spec.operationIds ?? []) {
            if (!locations.has(id)) {
              throw new SynthError(
                `${where}.operationIds: "${id}" is not an operationId in "${spec.url}" (namespace "${name ?? key}")`,
              );
            }
          }
          const declaredTags = collectTags(doc);
          for (const tag of spec.tags ?? []) {
            if (!declaredTags.has(tag)) {
              throw new SynthError(
                `${where}.tags: no operation in "${spec.url}" carries the tag "${tag}", so filtering ` +
                  `by it exposes nothing at all (the document uses: ${[...declaredTags].sort().join(", ") || "no tags"})`,
              );
            }
          }
        }

        wireUrl = relative(manifestDir, docPath).split(sep).join("/");
        const outputPath = posix.join("apis", wireUrl);
        vendored.push({ kind: "vendored", path: outputPath, bytes: readFileSync(docPath) });
        vendoredRecords.push({ key, path: outputPath, sourcePath: docPath });
      }

      const entry: JsonObject = { url: wireUrl, type: spec.type };
      if (name !== undefined) entry.name = name;
      if (spec.auth !== undefined) entry.auth = spec.auth;
      if (spec.tokenEnv !== undefined) entry["token-env"] = spec.tokenEnv;
      if (spec.headers !== undefined) entry.headers = spec.headers;
      if (spec.oauth2 !== undefined) entry.oauth2 = oauth2Entry(spec, where);
      if (spec.tags !== undefined) entry.tags = spec.tags;
      if (spec.operationIds !== undefined) entry["operation-ids"] = spec.operationIds;
      if (spec.mutations !== undefined) entry.mutations = spec.mutations;
      const rendered = canonicalize(entry, where);
      checkWireShape(rendered, API_ENTRY, where);
      return rendered;
    });

  return { entries, vendored, vendoredRecords };
}

/**
 * One vendored document's place in the check below: which api entry it came from,
 * where its bytes land in the output, and the resolved source file on disk those
 * bytes were read from.
 */
interface VendoredRecord {
  key: string;
  path: string;
  sourcePath: string;
}

/**
 * The caps every captured reader shares: it reads at most 32 files out of one
 * directory, at most 8192 bytes out of one file, and at most 65536 bytes out of the
 * directory as a whole. Past any of them it refuses the whole set, so synth measures
 * the real rendered bytes rather than guessing.
 */
const CAPTURED_MAX_FILES = 32;
const CAPTURED_DOCUMENT_BYTES = 8192;
const CAPTURED_TOTAL_BYTES = 65_536;

/** `apis/apis.yml` is read with a larger budget than a per-key manifest. */
const CAPTURED_API_MANIFEST_BYTES = 65_536;

/** What `CapturedApiContract.kt` will read out of one captured api surface. */
const CAPTURED_MAX_OPERATIONS = 128;
const CAPTURED_MAX_API_PATHS = 256;
const CAPTURED_MAX_API_PARAMETERS = 64;
const CAPTURED_MAX_API_ENUM = 128;
const CAPTURED_WRITE_METHODS: readonly string[] = ["post", "put", "patch", "delete"];
const CAPTURED_API_PATH = /^\/[A-Za-z0-9_~./{}-]*$/;

/**
 * The one name a captured api's url may template, and the placeholder spelled out. An api
 * declared `auth: "path"` writes it where the token goes — the same word a channel url
 * writes for the same thing — and the host puts the bound credential there when it builds
 * the request. It is never an operation parameter, so the guest never names it or sees it.
 */
const CAPTURED_CREDENTIAL_NAME = "credential";
const CAPTURED_CREDENTIAL_PLACEHOLDER = `{${CAPTURED_CREDENTIAL_NAME}}`;
/**
 * Two stand-ins the placeholder is swapped for when a url has to be read to find out where
 * the placeholder really landed. Looking for one magic word in one parse cannot work: an
 * author can write that word too, and then their text and the placeholder are the same
 * thing to whoever is reading. Parsing twice and asking which part of the url *changed*
 * tells them apart with no word to fool — everything the author wrote reads identically
 * both times, so the only part that can differ is the one the placeholder is in.
 *
 * The pairs are tried in order. Letters read as a scheme, a host, a path, a query or a
 * fragment but never as a port; digits read as a port or a host but never as a scheme.
 * Between them every part of a url can be told apart.
 */
const CAPTURED_CREDENTIAL_STANDINS: readonly (readonly [string, string])[] = [
  ["aaaa", "bbbb"],
  ["65001", "65002"],
];
export const CAPTURED_API_IDENTIFIER = /^[A-Za-z_][A-Za-z0-9_-]{0,63}$/;
const CAPTURED_API_SCALAR_TYPES = ["string", "integer", "number", "boolean"];
export const CAPTURED_HEADER_FIELD = /^[A-Za-z][A-Za-z0-9-]{0,127}$/;

/**
 * A captured api's `tokenEnv` grammar: `CapturedApiContract.kt`'s own `keyName` regex
 * at :91 (no hyphens, unlike the identifier grammar above, and up to 128 characters).
 */
const CAPTURED_TOKEN_ENV_KEY = /^[A-Za-z_][A-Za-z0-9_]{0,127}$/;

/**
 * The prefix the host reserves for its own SQL sidecar credentials — `RESERVED_PREFIX`
 * in `SqlCredentialReceiver.kt`:282, refused by `SqlCredentialStoreKey.isReserved`
 * (same file, :63) and read by `CapturedApiContract.kt`:114 before it will accept a
 * `token-env` value. A realm author picking their own environment variable name never
 * needs it; it exists so nothing durable a realm declares can collide with a wallet slot
 * the host mints for itself.
 */
const CAPTURED_RESERVED_TOKEN_ENV_PREFIX = "__embabel_sql_v1__";

/** A credential id as a realm's author writes it, and the key `$.credentials` is read under. */
export const CAPTURED_CREDENTIAL_ID = /^[a-z][a-z0-9-]{0,63}$/;

/** The five kinds of secret a captured credential can stand for. */
const CAPTURED_CREDENTIAL_KINDS = ["api-key", "basic", "bearer", "oauth2", "public-key"] as const;

/** Everything a credential declaration is allowed to say. */
const CAPTURED_CREDENTIAL_FIELDS = [
  "description",
  "docs",
  "kind",
  "provider",
  "scheme",
  "scopes",
] as const;

/**
 * The word the host puts in front of a bearer token in the `Authorization` header when
 * the declaration does not say otherwise. Everything that is not this gets written to
 * the wire; `Bearer` itself does not, so a realm that never thought about it emits the
 * same bytes it always did.
 */
const CAPTURED_DEFAULT_BEARER_SCHEME = "Bearer";

/**
 * What a scheme may spell: one header token, printable ASCII with no whitespace. The cap
 * is 32 characters because this is a word like `Bot` or `Bearer`, and anything longer is
 * someone trying to put the credential itself — or a whole header — in the wrong field.
 */
const CAPTURED_BEARER_SCHEME = /^[\x21-\x7e]{1,32}$/;

/**
 * Fields a credential declaration may never carry. `CredentialSpec` types each of these
 * `never`, but a realm definition is ordinary JavaScript by the time synth reads it, so
 * the type is advice to whoever writes it and this is the enforcement.
 *
 * `value` would put the secret itself in a file that ships with the realm. `env` and
 * `tokenEnv` would name the slot it is read out of, which is the host's business and not
 * a realm's. `walletItem` would bind the realm to one person's wallet. A credential says
 * what is needed and who issues it — never what it is, and never whose it is.
 */
const CAPTURED_FORBIDDEN_CREDENTIAL_FIELDS = ["env", "tokenEnv", "value", "walletItem"] as const;

/**
 * What a `credential:` may spell on the wire: an authored id, or the env-var name a
 * credential migrated from a deprecated `tokenEnv` keeps verbatim. Both forms have to
 * pass, because one realm can carry both at once during the deprecation window.
 */
const CAPTURED_CREDENTIAL_REF: WireShape = {
  kind: "text",
  name: "credential id",
  pattern: /^(?:[a-z][a-z0-9-]{0,63}|[A-Za-z_][A-Za-z0-9_]{0,127})$/,
  max: 128,
};

/** One entry in `credentials.yml`: what the realm needs, never what the secret is. */
const CAPTURED_CREDENTIAL_ENTRY: WireShape = {
  kind: "object",
  name: "CapturedCredentialDeclaration",
  of: {
    id: CAPTURED_CREDENTIAL_REF,
    kind: {
      kind: "enum",
      name: "CapturedCredentialDeclaration.Kind",
      of: CAPTURED_CREDENTIAL_KINDS,
    },
    provider: {
      kind: "text",
      name: "provider",
      pattern: /^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$/,
      max: 64,
    },
    description: { kind: "text", name: "description", max: 512 },
    docs: { kind: "text", name: "docs", pattern: /^https:\/\/[^\s]+$/, max: 512 },
    scheme: {
      kind: "text",
      name: "scheme",
      pattern: CAPTURED_BEARER_SCHEME,
      max: 32,
    },
    scopes: {
      kind: "list",
      of: { kind: "text", name: "scope", max: 128 },
      min: 1,
      max: 32,
      unique: true,
    },
  },
  required: ["id", "kind", "description"],
};

/** The whole of `credentials.yml`: one list, sorted by id, one entry per credential. */
const CAPTURED_CREDENTIALS: WireShape = {
  kind: "list",
  of: CAPTURED_CREDENTIAL_ENTRY,
  max: 32,
  uniqueBy: ["id"],
};

/**
 * A captured api entry's fixed header name: an `X-` name, or `User-Agent`, which replaces the
 * one the host sends by default.
 */
export const CAPTURED_API_HEADER_NAME = /^(?:X-[A-Za-z0-9-]{0,126}|User-Agent)$/i;

/**
 * The captured api entry as it goes on the wire during the deprecation window:
 * `CAPTURED_API_ENTRY` plus `credential:`, with `token-env` not required because an entry
 * that names a credential does not write one at all, `auth:` widened to take `path`
 * (decision 180) and `none`, `User-Agent` allowed among the fixed headers, and
 * `responses:`, the type each operation answers with.
 *
 * Derived here because wire-schema.ts transcribes the host's released readers, and the
 * readers for `credential:`, `auth: path`, `auth: none`, `User-Agent` and `responses:` are
 * not among them. They move there when they are.
 */
/** Every `auth:` word a captured api entry may use. */
const CAPTURED_API_AUTH = ["api-key", "bearer", "none", "path"];

const CAPTURED_API_ENTRY_WIRE: WireShape =
  CAPTURED_API_ENTRY.kind === "object"
    ? {
        ...CAPTURED_API_ENTRY,
        of: {
          ...CAPTURED_API_ENTRY.of,
          credential: CAPTURED_CREDENTIAL_REF,
          auth: { kind: "enum", name: "auth", of: CAPTURED_API_AUTH },
          headers: {
            ...(CAPTURED_API_ENTRY.of.headers as WireShape & { kind: "map" }),
            keyPattern: CAPTURED_API_HEADER_NAME,
          },
          // Keyed by operation id with the reader's own id grammar. The values were checked
          // one by one against the host's decoders before they got here.
          responses: {
            kind: "map",
            max: MAX_DECLARED_RESPONSES,
            keyName: "operation id",
            keyPattern: /^[A-Za-z_][A-Za-z0-9_-]{0,63}$/,
            of: { kind: "value" },
          },
        },
        required: [
          ...(CAPTURED_API_ENTRY.required ?? []).filter((key) => key !== "token-env"),
          "credential",
        ],
      }
    : CAPTURED_API_ENTRY;

/**
 * An `auth: none` entry on the wire: the same entry with nothing that names a credential and
 * nothing that writes, so a key the host would read as a credential or a write is refused
 * here as an unknown field.
 */
const CAPTURED_PUBLIC_API_ENTRY_WIRE: WireShape =
  CAPTURED_API_ENTRY_WIRE.kind === "object"
    ? {
        ...CAPTURED_API_ENTRY_WIRE,
        of: Object.fromEntries(
          Object.entries(CAPTURED_API_ENTRY_WIRE.of).filter(
            ([key]) => !["credential", "token-env", "write-operation-ids"].includes(key),
          ),
        ),
        required: (CAPTURED_API_ENTRY_WIRE.required ?? []).filter((key) => key !== "credential"),
      }
    : CAPTURED_API_ENTRY_WIRE;

/**
 * What the api walk learned about credentials, carried back out to the credentials
 * emitter: which ids something actually references, and which ones a deprecated
 * `tokenEnv` had to invent.
 */
interface CapturedCredentialUse {
  /** Referenced credential id, against the path of the api that named it. */
  referenced: Map<string, string>;
  /** Credentials derived from a `tokenEnv`, keyed by the env-var name they took as their id. */
  migrated: Map<string, { kind: "api-key" | "bearer"; where: string }>;
}

/**
 * The authorization scheme a credential's token travels under, checked as it is read.
 *
 * Two places need the answer and they have to agree: `credentials.yml` writes it, and the
 * api walk holds the vendored document's own security scheme to it. A document that says
 * `bearer` beside a credential the host will send as `Bot` describes a call that cannot
 * authorize, and the whole point of naming the scheme is that nobody has to find that out
 * from a 401.
 *
 * Only a bearer credential has one. An api key travels in a field of its own naming, and
 * basic, oauth2 and a public key each have a scheme the protocol already fixed.
 */
function capturedBearerScheme(spec: CredentialSpec | undefined, where: string): string {
  const declared = (spec as { scheme?: unknown } | undefined)?.scheme;
  if (declared === undefined) return CAPTURED_DEFAULT_BEARER_SCHEME;
  if (spec?.kind !== "bearer") {
    throw new SynthError(
      `${where}.scheme: only a bearer credential names an authorization scheme. A ${spec?.kind} ` +
        `credential does not travel in front of a word the realm gets to choose, so this would be ` +
        `read by nothing.`,
    );
  }
  if (typeof declared !== "string" || !CAPTURED_BEARER_SCHEME.test(declared)) {
    throw new SynthError(
      `${where}.scheme: an authorization scheme is one header token — printable ASCII, no ` +
        `whitespace, at most 32 characters, matching ${CAPTURED_BEARER_SCHEME.source}. Write the ` +
        `word that goes in front of the token, like "Bot", or leave it out for ` +
        `"${CAPTURED_DEFAULT_BEARER_SCHEME}".`,
    );
  }
  return declared;
}

/**
 * Builds `credentials.yml` — what this realm needs to authenticate, so a person can be
 * asked for it once at approval time rather than a secret being wired in per call.
 *
 * Two sources feed it: what the author declared under `$.credentials`, and what a
 * deprecated `tokenEnv` on an api entry had to derive. A derived credential keeps the
 * env-var name as its id verbatim, which is what lets the host match the slot it
 * already fills; that also means a derived id does not match the lowercase-and-dashes
 * grammar an authored one has to, so the grammar is only asked of authored keys.
 *
 * Two apis reading one env var share one credential rather than declaring it twice.
 * If they disagree about how they authenticate, there is no one kind to derive and the
 * realm is refused rather than guessed at.
 *
 * Returns undefined when the realm needs nothing, so no empty file is written.
 */
function capturedCredentials(
  declared: Record<string, CredentialSpec> | undefined,
  use: CapturedCredentialUse,
): JsonValue[] | undefined {
  const entries: JsonObject[] = [];

  for (const id of Object.keys(declared ?? {}).sort()) {
    const where = `$.credentials.${id}`;
    if (!CAPTURED_CREDENTIAL_ID.test(id)) {
      throw new SynthError(
        `${where}: "${id}" is not a name the host will read a credential under — it has to match ` +
          `${CAPTURED_CREDENTIAL_ID.source}.`,
      );
    }
    const authored: unknown = (declared as unknown as Record<string, unknown>)[id];
    if (typeof authored !== "object" || authored === null) {
      throw new SynthError(
        `${where}: a credential is an object saying what kind of secret is needed and what it is ` +
          `for — write { kind: "...", description: "..." } here.`,
      );
    }
    const fields = authored as Record<string, unknown>;
    const spec = authored as CredentialSpec;
    // Checked against the declaration as written, before a single field is copied out of
    // it. The projection further down only reads the keys the wire has, so a forbidden
    // field validated after it would never be looked at at all: the realm would
    // synthesize happily with a secret sitting in its source and nothing said. The
    // refusal names the key and never repeats what was under it.
    for (const field of CAPTURED_FORBIDDEN_CREDENTIAL_FIELDS) {
      if (Object.hasOwn(fields, field) && fields[field] !== undefined) {
        throw new SynthError(
          `${where}.${field}: a credential declares what the realm needs, never the secret itself ` +
            `or where one person keeps it. Drop ${field} — the host asks a person for this ` +
            `credential once, at approval time, and holds it from then on.`,
        );
      }
    }
    const stray = Object.keys(fields)
      .filter((field) => !(CAPTURED_CREDENTIAL_FIELDS as readonly string[]).includes(field))
      .sort();
    if (stray.length > 0) {
      throw new SynthError(
        `${where}: "${stray.join('", "')}" is not something a credential says. It carries ` +
          `${CAPTURED_CREDENTIAL_FIELDS.join(", ")}, and nothing else — anything more would be ` +
          `read by nobody, or be a secret.`,
      );
    }
    if (use.migrated.has(id)) {
      throw new SynthError(
        `${where}: an api's deprecated tokenEnv already derives a credential with this id. Drop ` +
          `that tokenEnv and point the api at this credential with credential: "${id}".`,
      );
    }
    if (!(CAPTURED_CREDENTIAL_KINDS as readonly string[]).includes(spec.kind)) {
      throw new SynthError(
        `${where}.kind: "${String(spec.kind)}" is not a kind of secret the host knows how to ask ` +
          `for — expected one of ${CAPTURED_CREDENTIAL_KINDS.join(", ")}.`,
      );
    }
    const scopes = (spec as { scopes?: readonly string[] }).scopes;
    if (spec.kind === "oauth2") {
      if (!Array.isArray(scopes) || scopes.length === 0) {
        throw new SynthError(
          `${where}.scopes: an oauth2 credential names at least one scope — a grant that asks for ` +
            `none authorizes nothing, and the host has nothing to show on the approval screen.`,
        );
      }
    } else if (scopes !== undefined) {
      throw new SynthError(
        `${where}.scopes: only an oauth2 credential is scoped. A ${spec.kind} credential is one ` +
          `opaque secret, so scopes here would be read by nothing.`,
      );
    }
    const scheme = capturedBearerScheme(spec, where);
    if (spec.docs !== undefined && !spec.docs.startsWith("https://")) {
      throw new SynthError(
        `${where}.docs: "${spec.docs}" has to be an https url — the host puts this link in front ` +
          `of the person being asked for the secret.`,
      );
    }
    if (!use.referenced.has(id)) {
      throw new SynthError(
        `${where}: nothing references this credential. Name it from the api that needs it with ` +
          `credential: "${id}", or drop it — the host asks a person for every credential a realm ` +
          `declares, and one nothing uses is a secret handed over for no call.`,
      );
    }
    const entry: JsonObject = { id, kind: spec.kind, description: spec.description };
    if (spec.provider !== undefined) entry.provider = spec.provider;
    if (spec.docs !== undefined) entry.docs = spec.docs;
    // Only when it is not the default: a realm that never thought about the scheme emits
    // the bytes it always did, and a reader seeing `scheme:` knows someone meant it.
    if (scheme !== CAPTURED_DEFAULT_BEARER_SCHEME) entry.scheme = scheme;
    if (scopes !== undefined) entry.scopes = [...scopes];
    entries.push(entry);
  }

  for (const [id, derived] of use.migrated) {
    entries.push({ id, kind: derived.kind, description: "Migrated from tokenEnv" });
  }

  if (entries.length === 0) return undefined;
  // Codepoint order, not localeCompare: a migrated id is an env-var name, so this list
  // mixes cases, and that is exactly where locale-aware collation stops agreeing with
  // itself across machines. A golden is byte-pinned, so the order has to be the same
  // everywhere — and this is the order the canonicalizer already sorts object keys in.
  entries.sort((a, b) => {
    const [x, y] = [String(a.id), String(b.id)];
    return x < y ? -1 : x > y ? 1 : 0;
  });
  const doc = canonicalize(entries, "$.credentials") as JsonValue[];
  checkWireShape(doc, CAPTURED_CREDENTIALS, "$.credentials");
  checkCapturedBytes(doc, "credentials.yml", CAPTURED_TOTAL_BYTES, "$.credentials");
  return doc;
}

/**
 * Headers the host will never put a credential in: they frame the request, or they
 * already mean something to the transport. An api that asked for one could redirect or
 * reshape the call it is being authenticated for.
 */
export const CAPTURED_FORBIDDEN_HEADERS = [
  "host",
  "cookie",
  "set-cookie",
  "authorization",
  "proxy-authorization",
  "proxy-authenticate",
  "connection",
  "proxy-connection",
  "content-length",
  "transfer-encoding",
  "content-type",
  "accept",
  "accept-encoding",
  "expect",
  "upgrade",
  "te",
  "trailer",
];

/**
 * The vendored OpenAPI document, the app page, and one app resource, in bytes. The app limits are
 * the host's defaults; an app inlines everything it needs, engine and data included.
 */
const CAPTURED_API_DOCUMENT_BYTES = 1_048_576;

/**
 * The app manifest's wire shape with its resource list capped at the run's own limit, so a
 * raised `--app-resource-count` is not refused again by the fixed shape.
 */
function appSpec(resourcesPerApp: number): WireShape {
  if (APP_SPEC.kind !== "object") return APP_SPEC;
  const resources = APP_SPEC.of.resources;
  if (resources === undefined || resources.kind !== "list") return APP_SPEC;
  return { ...APP_SPEC, of: { ...APP_SPEC.of, resources: { ...resources, max: resourcesPerApp } } };
}

/** The filename shape every captured `goals/`, `triggers/` and `producers/` file has to have. */
const CAPTURED_MANIFEST_PATH = /^[a-z]+\/[A-Za-z0-9][A-Za-z0-9_.-]{0,127}\.ya?ml$/;

/** An app's key is its page's filename, so it ends in `.html` — `CapturedBrowserApps.APP_NAME`. */
const CAPTURED_APP_NAME = /^[A-Za-z0-9][A-Za-z0-9_.-]{0,119}\.html?$/;

/**
 * How many bytes a rendered captured document comes to, refusing it when that is past
 * what the reader will read. The measurement has to match what actually lands on disk,
 * so it renders the value exactly the way `synth` does.
 */
export function checkCapturedBytes(
  doc: JsonValue,
  path: string,
  limit: number,
  where: string,
): number {
  const text = path.endsWith(".json")
    ? `${JSON.stringify(doc, null, 2)}\n`
    : stringifyYaml(doc, { lineWidth: 0 });
  const bytes = Buffer.byteLength(text, "utf8");
  if (bytes > limit) {
    throw new SynthError(
      `${where}: "${path}" comes to ${bytes} bytes, and the host reads at most ${limit} out of ` +
        `one captured file — past that it refuses the whole directory, not just this file.`,
    );
  }
  return bytes;
}

/** The most one `channels/<name>.yml` may be. The host refuses a larger file. */
const CAPTURED_CHANNEL_FILE_BYTES = 65_536;

/** Refuses a channel file the host would refuse for its size. */
function checkChannelFileBytes(file: RenderedFile, where: string): void {
  const bytes = Buffer.byteLength(stringifyYaml(file.value, { lineWidth: 0 }), "utf8");
  if (bytes > CAPTURED_CHANNEL_FILE_BYTES) {
    throw new SynthError(
      `${where}: "${file.path}" comes to ${bytes} bytes, and the host reads at most ` +
        `${CAPTURED_CHANNEL_FILE_BYTES} out of one channel file. Past that it refuses the channel.`,
    );
  }
}

/** Refuses a captured directory holding more files than its reader will read. */
function checkCapturedFileCount(count: number, directory: string, where: string): void {
  if (count > CAPTURED_MAX_FILES) {
    throw new SynthError(
      `${where}: the host reads at most ${CAPTURED_MAX_FILES} files out of ${directory}/, and this ` +
        `declares ${count}. Past the limit it refuses every one of them.`,
    );
  }
}

/**
 * Refuses a captured directory whose documents together exceed its reader's budget.
 *
 * The goal and trigger readers both hold a per-directory total on top of the per-file
 * one, so synth carries it too. As the field limits stand, nothing can actually reach it
 * — 32 files of the longest goal anyone can write come to about 65 KB, just inside the
 * cap — but the two limits move independently in the host, and this is what keeps a
 * later change to either from silently emitting a directory the reader drops whole.
 */
function checkCapturedTotalBytes(total: number, directory: string, where: string): void {
  if (total > CAPTURED_TOTAL_BYTES) {
    throw new SynthError(
      `${where}: the documents under ${directory}/ come to ${total} bytes together, and the host ` +
        `reads at most ${CAPTURED_TOTAL_BYTES} out of one captured directory.`,
    );
  }
}

/** Refuses an emitted path the reader's own path regex would not match. */
function checkCapturedPath(path: string, pattern: RegExp, where: string): void {
  if (!pattern.test(path)) {
    throw new SynthError(
      `${where}: this emits "${path}", and the host only reads a captured file whose path matches ` +
        `${pattern.source}. It refuses the whole directory over one path it cannot read.`,
    );
  }
}

/** A bare filename ending ".json", exactly what `CapturedApiContract.kt` reads `url` as — no path, never a remote url. */
const CAPTURED_API_FILENAME = /^[A-Za-z0-9_-]+\.json$/;

/** A captured GraphQL source's fixed header name: the host only accepts one starting with "X-". */
export const CAPTURED_HEADER_NAME = /^X-[A-Za-z0-9-]+$/i;

/**
 * True for a character the host's own `Char.isISOControl` refuses — every plain string
 * field `CapturedApiDocuments.string()` reads goes through it (`CapturedApiDocuments.kt`:53),
 * including a captured api's fixed header values at `CapturedApiContract.kt`:137. That is
 * the C0 controls, DEL, and the C1 controls — not just the C0 range below a space, which is
 * as far as this used to check. A header value carrying a bare U+0085 or U+009F was already
 * refused by the wire schema's printable-ASCII rule before it ever reached this check
 * (`wire-schema.ts`:929), so this only gives that refusal a diagnostic naming the C1
 * character instead of the wire schema's generic one.
 */
export function isCapturedControlCharacter(code: number): boolean {
  return (code >= 0x00 && code <= 0x1f) || code === 0x7f || (code >= 0x80 && code <= 0x9f);
}

/**
 * The bare-identifier surface name the gateway resolver accepts as an alias for one call
 * name, mirroring `ToolGrouper.surfaceQualifiedName` (`ToolGrouper.kt`:112-127) exactly:
 * split each of the namespace and the operation id on `_`, `-` and `.`, drop the
 * namespace's own tokens off the front of the operation id's parts when they match
 * case-insensitively, then camelCase each side and join with `_`. Two operations whose
 * dotted key and underscore call name both differ can still collide here — "get-thing" and
 * "getThing" both camelCase to "getThing" — and the host's own `callNames` set
 * (`CapturedApiContract.kt`:165) refuses that collision the same as any other.
 */
function capturedSplitParts(value: string): string[] {
  return value.split(/[_.-]/).filter((part) => part.length > 0);
}

function capturedCapitalize(part: string): string {
  return part.slice(0, 1).toUpperCase() + part.slice(1);
}

function capturedCamelCase(parts: string[]): string {
  const clean = parts
    .map((part) => part.replace(/[^A-Za-z0-9]/g, ""))
    .filter((part) => part.length > 0);
  if (clean.length === 0) return "";
  const [head, ...tail] = clean;
  const joined = head + tail.map(capturedCapitalize).join("");
  return /^[0-9]/.test(joined) ? `_${joined}` : joined;
}

function capturedMethodParts(operationId: string, namespace: string): string[] {
  const nameParts = capturedSplitParts(operationId);
  const namespaceParts = capturedSplitParts(namespace).map((part) => part.toLowerCase());
  const prefixMatches =
    namespaceParts.length > 0 &&
    nameParts.length > namespaceParts.length &&
    nameParts
      .slice(0, namespaceParts.length)
      .map((part) => part.toLowerCase())
      .join("\u0000") === namespaceParts.join("\u0000");
  const stripped = prefixMatches ? nameParts.slice(namespaceParts.length) : nameParts;
  return stripped.length > 0 ? stripped : nameParts;
}

export function capturedSurfaceName(namespace: string, operationId: string): string {
  return `${capturedCamelCase(capturedSplitParts(namespace))}_${capturedCamelCase(
    capturedMethodParts(operationId, namespace),
  )}`;
}

/**
 * Validates a captured realm's api declarations and returns the `apis/apis.yml`
 * entries in the narrower shape `CapturedApiContract.kt` reads: every operation named
 * up front, no oauth2/tags/mutations, and a realm-vendored document only — a captured
 * api is never fetched from a remote url at load time.
 *
 * This checks the same things the conventional `checkApis` does at the authoring
 * level — the document exists, declares the operation ids the entry claims, and
 * headers read sensibly — not the host's full runtime security posture (https-only
 * base url, per-operation security-scheme shape, request-body schema validation):
 * that is the reader's own job at load time, the same division `checkApis` already
 * draws for the conventional path.
 */
function checkCapturedApis(
  apis: Record<string, CapturedApiSpec> | undefined,
  realmRoot: string,
  credentials: Record<string, CredentialSpec> | undefined,
  use: CapturedCredentialUse,
  warn: (message: string) => void,
):
  | { entries: JsonValue[]; vendored: VendoredFile[]; vendoredRecords: VendoredRecord[] }
  | undefined {
  if (!apis || Object.keys(apis).length === 0) return undefined;

  const manifestDir = join(realmRoot, "apis");
  const vendored: VendoredFile[] = [];
  const vendoredRecords: VendoredRecord[] = [];
  const namespaces = new Set<string>();
  // The host keys an operation by its namespace — `catalog.getThing` — so two entries
  // may each expose a `getThing`. What it will not have is two spellings of one
  // qualified name, including the flattened `catalog_getThing` a handler calls it by.
  const claimedOperations = new Set<string>();
  let totalOperations = 0;
  if (Object.keys(apis).length > CAPTURED_MAX_FILES) {
    throw new SynthError(
      `$.apis: the host reads at most ${CAPTURED_MAX_FILES} entries out of apis/apis.yml, and this ` +
        `declares ${Object.keys(apis).length}.`,
    );
  }

  const entries = Object.keys(apis)
    .sort()
    .map((key) => {
      const spec = apis[key] as CapturedApiSpec;
      const where = `$.apis.${key}`;
      if (!IDENTIFIER.test(key)) {
        throw new SynthError(
          `${where}: "${key}" is not a valid identifier for a gateway namespace`,
        );
      }
      if (!CAPTURED_API_IDENTIFIER.test(spec.name)) {
        throw new SynthError(
          `${where}.name: "${spec.name}" becomes the gateway namespace, so handlers reach it as ` +
            `gateway.${spec.name}.someOperation. The host reads a namespace against ` +
            `${CAPTURED_API_IDENTIFIER.source} — the same grammar it reads a parameter name ` +
            `against, not the bare TypeScript identifier this used to check.`,
        );
      }
      if (namespaces.has(spec.name)) {
        throw new SynthError(
          `${where}.name: "${spec.name}" is already the name of another entry. Two entries under ` +
            `one namespace make a dotted operation reference ambiguous.`,
        );
      }
      namespaces.add(spec.name);

      if (!CAPTURED_API_AUTH.includes(spec.auth)) {
        throw new SynthError(
          `${where}.auth: expected one of ${CAPTURED_API_AUTH.join(", ")}, got ${JSON.stringify(spec.auth)}`,
        );
      }

      // The credential id the host signs this entry's calls with. An `auth: "none"` entry
      // has none, so it says nothing about a credential and never writes: the host calls a
      // public api with nothing attached, and a write without a credential is not one it
      // makes.
      let credentialId: string | undefined;
      if (spec.auth === "none") {
        for (const key of ["credential", "tokenEnv"] as const) {
          if (spec[key] !== undefined) {
            throw new SynthError(
              `${where}.${key}: auth: "none" sends no credential, so the entry names none. ` +
                `Leave ${key} out, or pick the auth the api really takes.`,
            );
          }
        }
        if (spec.writeOperationIds !== undefined) {
          const writes = spec.writeOperationIds;
          throw new SynthError(
            `${where}.writeOperationIds: auth: "none" sends no credential, so the host only ` +
              `reads through it. ` +
              (writes.length === 0
                ? "Leave the list out."
                : `${writes.join(", ")} ${writes.length === 1 ? "is a write" : "are writes"}.`),
          );
        }
      } else {
        // How this entry authenticates, as one credential id, whether the author named a
        // credential or is still on the deprecated tokenEnv. Everything downstream —
        // what goes on the wire, what credentials.yml has to hold — works off this.
        if (spec.credential !== undefined && spec.tokenEnv !== undefined) {
          throw new SynthError(
            `${where}: declares both credential and tokenEnv. tokenEnv is the deprecated spelling of ` +
              `the same thing, so an entry carrying both says it twice and leaves no answer to which ` +
              `one the host should read — keep credential: "${spec.credential}" and drop tokenEnv.`,
          );
        }
        if (spec.credential === undefined && spec.tokenEnv === undefined) {
          throw new SynthError(
            `${where}: declares neither credential nor tokenEnv, so nothing authenticates the calls ` +
              `it makes. Declare what it needs in $.credentials and name it here with ` +
              `credential: "<id>".`,
          );
        }
        if (spec.credential !== undefined) {
          // The grammar first, on its own: a name no credential could ever be declared
          // under is refused for being that, rather than for happening to be absent.
          if (!CAPTURED_CREDENTIAL_ID.test(spec.credential)) {
            throw new SynthError(
              `${where}.credential: "${spec.credential}" is not a name a credential can be declared ` +
                `under — it has to match ${CAPTURED_CREDENTIAL_ID.source}.`,
            );
          }
          // Object.hasOwn, never a plain lookup. `credentials[id]` walks the prototype
          // chain, so "constructor" and "toString" come back defined against a realm that
          // declares nothing at all, and an `=== undefined` test waves them straight
          // through — emitting an api that names a credential no credentials.yml answers.
          if (credentials === undefined || !Object.hasOwn(credentials, spec.credential)) {
            throw new SynthError(
              `${where}.credential: "${spec.credential}" is not declared in $.credentials. An api can ` +
                `only name a credential its own realm declares.`,
            );
          }
          credentialId = spec.credential;
        } else {
          // `auth: "path"` is new enough that nothing ever read it out of a tokenEnv, and the
          // deprecated spelling is on its way out either way. Asking for the credential by name
          // keeps the one url-substituting api on the key the host will still have next release
          // — and it leaves the migrated kind below a credential kind, which "path" is not.
          if (spec.auth === "path") {
            throw new SynthError(
              `${where}.credential: auth: "path" puts the credential in the url itself, and the ` +
                `host only substitutes a credential the realm declares and names here. Declare it ` +
                `in $.credentials and name it with credential: "<id>" — the deprecated tokenEnv is ` +
                `not a substitute for it.`,
            );
          }
          const env = spec.tokenEnv as string;
          if (
            !CAPTURED_TOKEN_ENV_KEY.test(env) ||
            env.startsWith(CAPTURED_RESERVED_TOKEN_ENV_PREFIX)
          ) {
            throw new SynthError(
              `${where}.tokenEnv: "${env}" is not a name the host will read a credential ` +
                `under — it has to match ${CAPTURED_TOKEN_ENV_KEY.source}, and it can never start ` +
                `with "${CAPTURED_RESERVED_TOKEN_ENV_PREFIX}", which the host reserves for its own ` +
                `SQL sidecar credentials.`,
            );
          }
          warn(
            `DEPRECATED ${where}.tokenEnv: declare a credential and reference it with ` +
              `credential: "${env}"; tokenEnv is removed in the next release`,
          );
          // One env var is one credential, however many apis read it. Two that disagree
          // about how they authenticate leave no single kind to derive, and guessing one
          // would hand the host a credential that fails at the first call.
          const already = use.migrated.get(env);
          if (already !== undefined && already.kind !== spec.auth) {
            throw new SynthError(
              `$.credentials.${env}: ${already.where} and ${where} both read their credential from ` +
                `tokenEnv "${env}", but one authenticates with ${already.kind} and the other with ` +
                `${spec.auth}. Declare the credential yourself and name it from each api with ` +
                `credential: "<id>".`,
            );
          }
          if (already === undefined) use.migrated.set(env, { kind: spec.auth, where });
          credentialId = env;
        }
        use.referenced.set(credentialId, where);
      }

      if (!CAPTURED_API_FILENAME.test(spec.url)) {
        throw new SynthError(
          `${where}.url: a captured api's document is always vendored under apis/ and named as a ` +
            `plain filename ending ".json" — got "${spec.url}". It is never a path or a remote url.`,
        );
      }
      const docPath = join(manifestDir, spec.url);
      if (!existsSync(docPath)) {
        throw new SynthError(`${where}.url: file not found at "${docPath}"`);
      }
      const docBytes = readFileSync(docPath);
      if (docBytes.length > CAPTURED_API_DOCUMENT_BYTES) {
        throw new SynthError(
          `${where}.url: "${spec.url}" is ${docBytes.length} bytes, and the host reads at most ` +
            `${CAPTURED_API_DOCUMENT_BYTES} out of a captured api document.`,
        );
      }
      const doc = parseVendoredDocument(spec.url, docPath, `${where}.url`);
      if (typeof doc.openapi !== "string" || !OPENAPI_VERSION.test(doc.openapi)) {
        throw new SynthError(
          `${where}.url: "${spec.url}" does not declare an OpenAPI 3.x document (openapi: ${JSON.stringify(doc.openapi)})`,
        );
      }
      // Every `$ref` first, before a single count: `CapturedApiContract.kt` reads the
      // document's references at :160, straight after the `openapi` version and well before
      // it looks at `operation-ids` (:165) or totals the operations it read (:146). A
      // document that points out of itself is refused for that, whatever else is wrong with
      // it, so the message an author gets here names the same thing the host would.
      checkCapturedApiRefs(doc, `${where}.url`);
      const locations = collectOperationIds(doc, `${where}.url`);
      for (const [operationId, at] of locations) {
        if (at.length > 1) {
          throw new SynthError(
            `${where}.url: "${spec.url}" declares operationId "${operationId}" more than once, at ${at.join(" and ")}.`,
          );
        }
      }
      // Required by the types, so a realm missing it was assembled outside them — built in a
      // loop, spread from a shared constant, written in plain JavaScript. Checked before it
      // is read so the author gets the path to the entry rather than a TypeError naming a
      // property of a variable they never wrote.
      if (!Array.isArray(spec.operationIds)) {
        throw new SynthError(
          `${where}.operationIds: a captured api names the operations it may read here, and this ` +
            `entry names none. The host reads the read list and the write list separately and ` +
            `grants nothing from a list that is not there, so every read through this api would ` +
            `be refused. List them, even if the realm only writes today — writeOperationIds is ` +
            `not a substitute for it.`,
        );
      }
      if (spec.operationIds.length === 0) {
        throw new SynthError(
          `${where}.operationIds: cannot be empty — a captured api entry always names its exact ` +
            `allowed surface, unlike a conventional one it can never expose everything.`,
        );
      }
      const writeIds = spec.writeOperationIds ?? [];
      const overlap = spec.operationIds.filter((id) => writeIds.includes(id));
      if (overlap.length > 0) {
        throw new SynthError(
          `${where}: ${overlap.join(", ")} appear in both operationIds and writeOperationIds — an ` +
            `operation is a read or a write, never both.`,
        );
      }
      for (const id of [...spec.operationIds, ...writeIds]) {
        if (!locations.has(id)) {
          throw new SynthError(`${where}: "${id}" is not an operationId in "${spec.url}"`);
        }
        // Qualified all three ways the host names it: the operation key `<namespace>.<id>`,
        // the call name `<namespace>_<id>` a handler reaches it by, and the camelCase
        // surface name (`ToolGrouper.surfaceQualifiedName`) the gateway resolver accepts as
        // an alias for that same call — deduped per id first, so an id whose underscore
        // and surface names happen to coincide (the common case) never collides with itself.
        const qualifiedNames = new Set([
          `${spec.name}.${id}`,
          `${spec.name}_${id}`,
          capturedSurfaceName(spec.name, id),
        ]);
        for (const qualified of qualifiedNames) {
          if (HOST_CALL_NAMES.includes(qualified)) {
            throw new SynthError(
              `${where}: the host would call this operation "${qualified}", which is a host ` +
                `call's own name. The host refuses every operation in the realm over it.`,
            );
          }
          if (claimedOperations.has(qualified)) {
            throw new SynthError(
              `${where}: the host would name this operation "${qualified}", and another entry ` +
                `already claims that name. Two operations cannot answer to one name.`,
            );
          }
          claimedOperations.add(qualified);
        }
      }
      totalOperations += spec.operationIds.length + writeIds.length;
      if (totalOperations > CAPTURED_MAX_OPERATIONS) {
        throw new SynthError(
          `$.apis: the host reads at most ${CAPTURED_MAX_OPERATIONS} captured operations in total, ` +
            `and these come to ${totalOperations}.`,
        );
      }
      // What the document has to say about how the call is signed. A bearer credential may
      // name its own scheme, so the check is against that word rather than against
      // "bearer" — a document declaring one while the host sends the other describes a
      // call that cannot authorize.
      const bearerScheme =
        credentials !== undefined &&
        credentialId !== undefined &&
        Object.hasOwn(credentials, credentialId)
          ? capturedBearerScheme(credentials[credentialId], `$.credentials.${credentialId}`)
          : CAPTURED_DEFAULT_BEARER_SCHEME;
      checkCapturedApiDocument(doc, spec, `${where}.url`, bearerScheme);
      if (spec.headers) {
        for (const [name, headerValue] of Object.entries(spec.headers)) {
          const at = `${where}.headers.${name}`;
          if (!CAPTURED_API_HEADER_NAME.test(name)) {
            throw new SynthError(
              `${at}: a captured api's fixed headers are read straight through, so the host only ` +
                `accepts a name starting "X-", or User-Agent. Got "${name}".`,
            );
          }
          if (
            headerValue.includes("${") ||
            [...headerValue].some((c) => isCapturedControlCharacter(c.charCodeAt(0)))
          ) {
            throw new SynthError(
              `${at}: a captured api's headers are fixed values, not templated — "\${...}" ` +
                `substitution is refused, and the value has to be plain printable text.`,
            );
          }
        }
      }

      const wireUrl = relative(manifestDir, docPath).split(sep).join("/");
      const outputPath = posix.join("apis", wireUrl);
      vendored.push({ kind: "vendored", path: outputPath, bytes: readFileSync(docPath) });
      vendoredRecords.push({ key, path: outputPath, sourcePath: docPath });

      const entry: JsonObject = {
        url: wireUrl,
        name: spec.name,
        type: spec.type,
        auth: spec.auth,
        ...(credentialId !== undefined ? { credential: credentialId } : {}),
        "operation-ids": spec.operationIds,
      };
      // Written only on the deprecated path, and `credential:` above is written beside
      // it naming the same env var — so the host can move to the one key without this
      // realm changing, and this key simply stops appearing when tokenEnv goes.
      if (spec.tokenEnv !== undefined) entry["token-env"] = spec.tokenEnv;
      if (spec.headers !== undefined) entry.headers = spec.headers;
      if (spec.writeOperationIds !== undefined)
        entry["write-operation-ids"] = spec.writeOperationIds;
      const responses = capturedResponses(spec, doc, `${where}.operations`, warn);
      if (responses !== undefined) entry.responses = responses;
      const renderedEntry = canonicalize(entry, where);
      checkWireShape(
        renderedEntry,
        spec.auth === "none" ? CAPTURED_PUBLIC_API_ENTRY_WIRE : CAPTURED_API_ENTRY_WIRE,
        where,
      );
      return renderedEntry;
    });

  checkCapturedBytes(entries, "apis/apis.yml", CAPTURED_API_MANIFEST_BYTES, "$.apis");
  return { entries, vendored, vendoredRecords };
}

/**
 * The `responses:` map an entry writes: the type each operation in `operations` declares,
 * checked the way the host checks it, keyed in the order the reads and then the writes list
 * them. Undefined when nothing is declared, and then the host reads every operation as JSON.
 *
 * The host reads an undeclared operation as one JSON document whatever its document names.
 * When the document names one type and it is not JSON, that read will likely fail, so synth
 * warns and says what to declare. It stays a warning because the host still loads the file.
 */
function capturedResponses(
  spec: CapturedApiSpec,
  doc: Record<string, unknown>,
  where: string,
  warn: (message: string) => void,
): JsonObject | undefined {
  const operations = spec.operations as unknown;
  if (
    operations !== undefined &&
    (typeof operations !== "object" || operations === null || Array.isArray(operations))
  ) {
    throw new SynthError(`${where}: expected an object keyed by operation id`);
  }
  const settings = (operations ?? {}) as Record<string, unknown>;
  const writes = spec.writeOperationIds ?? [];
  const declared = new Map<string, JsonValue>();
  for (const [id, setting] of Object.entries(settings)) {
    const at = `${where}.${id}`;
    if (!spec.operationIds.includes(id) && !writes.includes(id)) {
      throw new SynthError(
        `${at}: "${id}" is not one of this entry's operationIds or writeOperationIds`,
      );
    }
    if (typeof setting !== "object" || setting === null || Array.isArray(setting)) {
      throw new SynthError(`${at}: expected an object like { response: "ndjson" }`);
    }
    for (const field of Object.keys(setting)) {
      if (field !== "response") throw new SynthError(`${at}: unknown field "${field}"`);
    }
    const response = (setting as { response?: unknown }).response;
    if (response === undefined) continue;
    const read = declaredResponse(response, writes.includes(id));
    if ("refused" in read) {
      throw new SynthError(`${at}.response: ${read.refused}. The host refuses the whole file.`);
    }
    declared.set(id, read.wire);
  }
  for (const id of [...spec.operationIds, ...writes]) {
    if (declared.has(id)) continue;
    const operation = findOperation(doc, id);
    const documented = operation === undefined ? undefined : documentedResponse(operation, doc);
    if (documented === undefined) continue;
    if (codecFor(documented) === "json") continue;
    const suggestion = suggestedDeclaration(documented, writes.includes(id));
    warn(
      `${where}.${id}: "${spec.url}" says this operation answers with ` +
        `"${essence(documented)}", and the host reads an operation with no declared response ` +
        "as JSON. " +
        (suggestion === undefined
          ? "The host refuses binary bodies, so no declaration reads this one."
          : `Declare { response: ${suggestion} } to read it as the document describes.`),
    );
  }
  if (declared.size === 0) return undefined;
  const ordered: JsonObject = {};
  for (const id of [...spec.operationIds, ...writes]) {
    const value = declared.get(id);
    if (value !== undefined) ordered[id] = value;
  }
  return ordered;
}

/**
 * A captured realm's `capabilities`, checked against the ones the host grants. The host
 * offers each one to the owner at admission, so a name it does not know is refused here.
 */
function checkCapabilities(capabilities: unknown): string[] {
  if (!Array.isArray(capabilities)) {
    throw new SynthError(
      `$.capabilities: expected a list of ${REALM_CAPABILITIES.join(", ")}, got ${JSON.stringify(capabilities)}`,
    );
  }
  const seen = new Set<string>();
  capabilities.forEach((capability: unknown, i) => {
    if (!(REALM_CAPABILITIES as readonly unknown[]).includes(capability)) {
      throw new SynthError(
        `$.capabilities[${i}]: expected one of ${REALM_CAPABILITIES.join(", ")}, got ${JSON.stringify(capability)}`,
      );
    }
    if (seen.has(capability as string)) {
      throw new SynthError(`$.capabilities[${i}]: "${capability}" is already declared`);
    }
    seen.add(capability as string);
  });
  return [...seen];
}

/**
 * Every `$ref` in a vendored document points inside the document's own `components`, or the
 * host refuses the api whole. This is the first thing it asks of a document it has just
 * parsed — before the operations are counted, before the paths are read — so it is the first
 * thing asked here too.
 */
function checkCapturedApiRefs(doc: Record<string, unknown>, where: string): void {
  for (const ref of collectRefs(doc)) {
    if (typeof ref !== "string" || !ref.startsWith("#/components/")) {
      throw new SynthError(
        `${where}: this document holds a $ref of ${JSON.stringify(ref)}. The host only follows a ` +
          `pointer into "#/components/" — anything else it treats as a way out of the document ` +
          `and refuses the whole api.`,
      );
    }
  }
}

/**
 * Checks the vendored OpenAPI document itself against what `CapturedApiContract.kt`
 * demands of it before it will dispatch a single call: one fixed HTTPS origin, a
 * security scheme matching the entry's declared `auth`, reads that really are GETs,
 * writes that really are not, and a path whose every placeholder is a declared,
 * required, scalar path parameter.
 *
 * None of this is the vendor's fault when it fails — a public OpenAPI document is
 * written for humans and full of `$ref`s, server variables and shared parameters. But a
 * captured realm's whole api surface is refused as one, at install time, with a single
 * "refused" and no field named. That is the failure this turns into a message naming
 * the field while the author is still looking at their own realm.
 */
function checkCapturedApiDocument(
  doc: Record<string, unknown>,
  spec: CapturedApiSpec,
  where: string,
  bearerScheme: string,
): void {
  const servers = doc.servers;
  if (!Array.isArray(servers) || servers.length !== 1) {
    throw new SynthError(
      `${where}: the host reads exactly one \`servers\` entry, which is the single origin every ` +
        `call goes to. This document declares ` +
        `${Array.isArray(servers) ? servers.length : "none"}.`,
    );
  }
  const server = servers[0] as Record<string, unknown>;
  if ("variables" in server) {
    throw new SynthError(
      `${where}: the host refuses a \`servers\` entry with \`variables\` — the origin has to be ` +
        `fixed, not templated per call.`,
    );
  }
  // The one entry allowed to template its origin: `auth: "path"` is what says the token
  // goes in the url, and the placeholder is the only thing it may put there.
  const pathCredential = spec.auth === "path";
  // Entries the host attaches nothing to: the credential is in the url, or there is none.
  const unsigned = pathCredential || spec.auth === "none";
  // Before the origin check, so an entry that wrote the placeholder under the wrong `auth`
  // is told about the placeholder rather than that its origin is templated.
  checkCapturedPathCredential(doc, spec, String(server.url), where);
  checkCapturedApiBase(server.url, where, pathCredential);

  const paths = doc.paths;
  if (!paths || typeof paths !== "object" || Array.isArray(paths)) {
    throw new SynthError(`${where}: the host reads \`paths\` as a mapping, and this has none.`);
  }
  if (Object.keys(paths).length > CAPTURED_MAX_API_PATHS) {
    throw new SynthError(
      `${where}: the host reads at most ${CAPTURED_MAX_API_PATHS} paths, and this declares ` +
        `${Object.keys(paths).length}.`,
    );
  }

  const writeIds = new Set(spec.writeOperationIds ?? []);
  const readIds = new Set(spec.operationIds);
  for (const [path, item] of Object.entries(paths as Record<string, unknown>)) {
    if (!item || typeof item !== "object") continue;
    const pathItem = item as Record<string, unknown>;
    for (const method of HTTP_METHODS) {
      const found = pathItem[method];
      if (!found || typeof found !== "object") continue;
      const operation = found as Record<string, unknown>;
      const id = operation.operationId;
      if (typeof id !== "string" || (!readIds.has(id) && !writeIds.has(id))) continue;
      const at = `${where}: operation "${id}"`;
      if ("servers" in pathItem || "servers" in operation) {
        throw new SynthError(
          `${at} overrides \`servers\`. Every captured call goes to the one origin the document ` +
            `declares, so the host refuses a per-path or per-operation override.`,
        );
      }
      if (!CAPTURED_API_PATH.test(path) || path.split("/").some((s) => s === "." || s === "..")) {
        throw new SynthError(
          `${at} sits at "${path}", which is not a path the host will build a url out of ` +
            `(${CAPTURED_API_PATH.source}, and no "." or ".." segment).`,
        );
      }
      if (writeIds.has(id)) {
        if (!CAPTURED_WRITE_METHODS.includes(method)) {
          throw new SynthError(
            `${at} is declared in writeOperationIds but is a ${method.toUpperCase()}. A write is a ` +
              `${CAPTURED_WRITE_METHODS.join(", ").toUpperCase()}.`,
          );
        }
        checkCapturedRequestBody(operation.requestBody, doc, at);
      } else {
        if (method !== "get") {
          throw new SynthError(
            `${at} is declared in operationIds, so the host reads it as a read and refuses it for ` +
              `being a ${method.toUpperCase()}. Move it to writeOperationIds.`,
          );
        }
        if ("requestBody" in operation) {
          throw new SynthError(
            `${at} is a read and carries a requestBody. The host sends no body on a read and ` +
              `refuses the operation rather than drop it.`,
          );
        }
      }
      // What actually applies to this call: an operation's own `security` replaces the
      // document's, and an empty list is the OpenAPI way of saying "nothing is required
      // here". That is exactly what an api whose credential rides in the url wants to say,
      // and what a public api with no credential says, so an empty list is fine under
      // auth: "path" and auth: "none" wherever it is written. A requirement that names a
      // scheme is not, because the host fills no header and no query field.
      const required = operation.security !== undefined ? operation.security : doc.security;
      if (unsigned && required !== undefined) {
        if (!Array.isArray(required)) {
          throw new SynthError(
            `${at}: \`security\` reads as a list of requirements, and this is not a list.`,
          );
        }
        if (required.length > 0) {
          const why = pathCredential
            ? "where the credential travels in the url and no header or query field carries it"
            : "where the host sends no credential at all";
          throw new SynthError(
            `${at} declares a \`security\` requirement under auth: "${spec.auth}", ${why}. The ` +
              `requirement names a scheme the host would never fill, so it refuses the api rather ` +
              `than leave one nothing reads. An empty \`security: []\` says no requirement at ` +
              `all and is fine.`,
          );
        }
      }
      // Empty when the credential is in the url or there is none: it is not in a header or a
      // query field, so there is no name for the api to collide with.
      const authentication = unsigned
        ? ""
        : checkCapturedSecurity(doc, operation, spec, at, bearerScheme);
      const parameters = checkCapturedParameters(pathItem.parameters, operation.parameters, at);
      if (
        Object.keys(spec.headers ?? {}).some((name) => name.toLowerCase() === authentication) ||
        parameters.some((parameter) => parameter.name.toLowerCase() === authentication)
      ) {
        throw new SynthError(
          `${at}: "${authentication}" is where the host puts the credential, so the api may not ` +
            `also set it as a fixed header or take it as an argument.`,
        );
      }
      const placeholders = [...path.matchAll(/\{([^{}]+)}/g)].map((match) => match[1] as string);
      const declared = parameters.filter((p) => p.location === "path").map((p) => p.name);
      if (pathCredential && parameters.some((p) => p.name === CAPTURED_CREDENTIAL_NAME)) {
        throw new SynthError(
          `${at} takes "${CAPTURED_CREDENTIAL_NAME}" as an argument. Under auth: "path" the host ` +
            `fills "${CAPTURED_CREDENTIAL_PLACEHOLDER}" itself and the generated client has no ` +
            `parameter for it, so an operation declaring one would be asking the guest for the ` +
            `token as data.`,
        );
      }
      // The host fills the credential placeholder from the binding, not from an argument, so
      // it is the one placeholder with no parameter to match.
      const filled = pathCredential
        ? placeholders.filter((name) => name !== CAPTURED_CREDENTIAL_NAME)
        : placeholders;
      if ([...filled].sort().join(",") !== [...declared].sort().join(",")) {
        throw new SynthError(
          `${at} has the path placeholders [${filled.join(", ")}] and the declared path ` +
            `parameters [${declared.join(", ")}]. The host fills a url only when those two match ` +
            `exactly, and refuses the api when they do not.`,
        );
      }
    }
  }
}

/**
 * Where the `{credential}` placeholder is, and whether the entry is entitled to one.
 *
 * An api declared `auth: "path"` says the token goes in the url, so the document has to
 * show where: in the single `servers` url, or in the path of an operation the entry
 * actually declares. One that says it and shows nowhere would send every call unsigned.
 * Any other entry carrying the placeholder is refused for carrying it — the host
 * substitutes nothing under `bearer` or `api-key`, so the literal word would go out in the
 * url and the call would fail in a way no message explains.
 *
 * A placeholder in a query string is refused whatever the entry declares. A token in a
 * query string is written into every access log between here and the provider, and a
 * placeholder there would be asking the host to put it there.
 *
 * Two more rules, both about what the substitution may decide (decision 180). The
 * placeholder may sit only in the *path* — never in the scheme, the userinfo, the host, the
 * port, the query or the fragment — so the bound secret can never change which server the
 * call reaches, and never lands somewhere every proxy on the way writes to a log. And every
 * operation the entry names has to carry it exactly once, because the host substitutes once
 * per call: none leaves that call unsigned, twice would write the token into the url twice.
 *
 * Both rules are settled on the url the host will really send — the `servers` url with the
 * operation path stuck on the end — and not on the two pieces separately. Pieces that pass
 * on their own still join into a url that breaks the rule: a `servers` url ending in a bare
 * `?` drops the whole operation path, placeholder and all, into the query.
 */
function checkCapturedPathCredential(
  doc: Record<string, unknown>,
  spec: CapturedApiSpec,
  serverUrl: string,
  where: string,
): void {
  const paths =
    doc.paths && typeof doc.paths === "object" && !Array.isArray(doc.paths)
      ? (doc.paths as Record<string, unknown>)
      : {};
  // Which paths the host will really build a url out of. A placeholder in a path no
  // declared operation uses is substituted on no call, so it cannot be the one that
  // satisfies `auth: "path"` — but it is still refused for being there under the wrong auth.
  const declaredIds = new Set([...spec.operationIds, ...(spec.writeOperationIds ?? [])]);
  // Every operation the entry actually names, with the path it sits at. These are the urls
  // the host will really build, so they are the ones the once-only rule is about.
  const selected = Object.entries(paths).flatMap(([path, item]) =>
    item === null || typeof item !== "object"
      ? []
      : HTTP_METHODS.flatMap((method) => {
          const operation = (item as Record<string, unknown>)[method] as
            | Record<string, unknown>
            | undefined;
          const id = operation?.operationId;
          return typeof id === "string" && declaredIds.has(id) ? [{ id, path }] : [];
        }),
  );
  const sites: readonly { at: string; text: string; fills: boolean; ids: readonly string[] }[] = [
    {
      at: "its `servers` url",
      text: serverUrl,
      fills: true,
      ids: selected.map((operation) => operation.id),
    },
    ...Object.keys(paths).map((path) => {
      const ids = selected
        .filter((operation) => operation.path === path)
        .map((operation) => operation.id);
      return { at: `the path "${path}"`, text: path, fills: ids.length > 0, ids };
    }),
  ];

  for (const site of sites) {
    const mark = site.text.indexOf("?");
    if (mark >= 0 && site.text.slice(mark).includes(CAPTURED_CREDENTIAL_PLACEHOLDER)) {
      throw new SynthError(
        `${where}: ${site.at} puts "${CAPTURED_CREDENTIAL_PLACEHOLDER}" in a query string. A ` +
          `credential in a query string is written into every access log on the way, so the host ` +
          `will not substitute one there whatever the entry declares.`,
      );
    }
  }

  const carrying = sites.filter((site) => site.text.includes(CAPTURED_CREDENTIAL_PLACEHOLDER));
  if (spec.auth !== "path") {
    const found = carrying[0];
    if (found !== undefined) {
      throw new SynthError(
        `${where}: ${found.at} carries "${CAPTURED_CREDENTIAL_PLACEHOLDER}", but the entry ` +
          `declares auth: "${spec.auth}". Only auth: "path" substitutes a credential into the ` +
          `url — under any other the word would go out on the wire exactly as written.`,
      );
    }
    return;
  }
  if (!carrying.some((site) => site.fills)) {
    throw new SynthError(
      `${where}: the entry declares auth: "path", and nothing in the document says where the ` +
        `credential goes. Write "${CAPTURED_CREDENTIAL_PLACEHOLDER}" into the \`servers\` url or ` +
        `into the path of an operation this entry declares — a placeholder anywhere else is ` +
        `substituted on no call the host makes.`,
    );
  }
  const outside = credentialOutsideServerPath(serverUrl);
  if (outside !== undefined) {
    throw new SynthError(
      `${where}: its \`servers\` url puts "${CAPTURED_CREDENTIAL_PLACEHOLDER}" in ${outside}. The ` +
        `host substitutes the credential into the path and nowhere else, so a placeholder in ` +
        `${outside} would let the bound secret decide which server the call reaches.`,
    );
  }
  // Pieces that cannot be joined into an honest url, refused before anything parses them.
  // An OpenAPI `servers` url has no query string and no fragment, an operation path has
  // neither either, and a bare `?` or `#` is enough: the parser reads an empty query or an
  // empty fragment as absent, so a trailing one slips past every check on the piece and
  // still drops the operation path into the query of the url the host builds. A "." or ".."
  // segment is the same problem from the other end — it survives the piece and is gone by
  // the time the url is normalised, whether it is written plainly or percent-encoded.
  for (const site of sites) {
    const calls = callingOperations(site.ids);
    const delimiter = site.text.includes("?") ? "?" : site.text.includes("#") ? "#" : undefined;
    if (delimiter !== undefined) {
      throw new SynthError(
        `${where}: ${site.at} contains "${delimiter}". A \`servers\` url has no query string or ` +
          `fragment and neither does an operation path, and joining one that does moves ` +
          `"${CAPTURED_CREDENTIAL_PLACEHOLDER}" out of the path the host substitutes into.` +
          calls,
      );
    }
    for (const segment of site.text.split("/")) {
      const fault = relativeSegmentFault(segment);
      if (fault === "unreadable") {
        throw new SynthError(
          `${where}: ${site.at} has the segment "${segment}", whose percent-encoding does not ` +
            `read. Nobody can say what that segment resolves to, so nobody can say whether it ` +
            `walks over the segment carrying "${CAPTURED_CREDENTIAL_PLACEHOLDER}".` +
            calls,
        );
      }
      if (fault === "relative") {
        throw new SynthError(
          `${where}: ${site.at} has a "." or ".." segment. The host joins the \`servers\` url to ` +
            `the operation path and calls what that reads as, and a relative segment can walk ` +
            `over the segment carrying "${CAPTURED_CREDENTIAL_PLACEHOLDER}" before the call goes ` +
            `out.` +
            calls,
        );
      }
    }
  }
  // The pieces are only ever evidence. What decision 180 is about is the url the host will
  // really build, so build each one and read that single string.
  for (const { id, path } of selected) {
    const fault = effectiveCredentialFault(`${serverUrl}${path}`);
    if (fault === undefined) continue;
    throw new SynthError(`${where}: operation "${id}" calls "${serverUrl}${path}", which ${fault}`);
  }
}

/**
 * Reads the url the host will really send for one operation — the `servers` url with the
 * operation path stuck on the end — and says what is wrong with where the credential sits
 * in it, or `undefined` when it sits exactly where it has to.
 *
 * Reading the assembled string is the whole point. A server url and an operation path can
 * each look right on their own and still join into a url whose placeholder lands in the
 * query or the fragment, or into one the parser normalises until the placeholder is gone
 * and the call goes out unsigned. Only the literal `{credential}` counts, here as
 * everywhere else: written percent-encoded it is somebody else's text.
 */
function effectiveCredentialFault(url: string): string | undefined {
  const raw = countCredentialSites(url);
  if (raw !== 1) {
    return (
      `carries "${CAPTURED_CREDENTIAL_PLACEHOLDER}" ${raw} times. The host substitutes the ` +
      `credential once per call, so the url of every operation the entry names has to carry ` +
      `the placeholder exactly once.`
    );
  }
  const placement = credentialPlacement(url);
  if (placement.kind === "path") return undefined;
  if (placement.kind === "part") {
    return (
      `puts "${CAPTURED_CREDENTIAL_PLACEHOLDER}" in ${placement.part}. The host substitutes ` +
      `into the path of the url it builds and nowhere else.`
    );
  }
  if (placement.kind === "unreadable") {
    return (
      `does not read as a url at all. A brace is not a legal character in a host, so a ` +
      `placeholder written anywhere but the path can leave the whole url unreadable — and the ` +
      `host substitutes into the path and nowhere else.`
    );
  }
  return (
    `loses "${CAPTURED_CREDENTIAL_PLACEHOLDER}" once that url is read, so the call the host ` +
    `makes would carry no credential at all.`
  );
}

/** Where a url really puts `{credential}`, once that url is read the way a client reads it. */
type CredentialPlacement =
  | { kind: "path" }
  | { kind: "part"; part: string }
  | { kind: "gone" }
  | { kind: "unreadable" };

/**
 * Works out which part of a url the placeholder lands in, without ever looking for a magic
 * word — see `CAPTURED_CREDENTIAL_STANDINS` for why a word cannot be trusted.
 *
 * The url is read twice, once with each stand-in. Every part the author wrote comes back
 * the same both times, so a part that differs is a part the placeholder is in. If only the
 * `pathname` differs, the placeholder is in the path and still there after the parser has
 * resolved away every "." and ".." — which is exactly what has to be true. If nothing
 * differs, the url swallowed it and the call would go out with no credential at all.
 */
function credentialPlacement(url: string): CredentialPlacement {
  for (const [first, second] of CAPTURED_CREDENTIAL_STANDINS) {
    const one = readUrl(url.split(CAPTURED_CREDENTIAL_PLACEHOLDER).join(first));
    const other = readUrl(url.split(CAPTURED_CREDENTIAL_PLACEHOLDER).join(second));
    if (one === undefined || other === undefined) continue;
    const part = [
      one.protocol !== other.protocol ? "its scheme" : undefined,
      one.username !== other.username || one.password !== other.password
        ? "its userinfo"
        : undefined,
      one.hostname !== other.hostname ? "its host" : undefined,
      one.port !== other.port ? "its port" : undefined,
      one.search !== other.search ? "its query string" : undefined,
      one.hash !== other.hash ? "its fragment" : undefined,
    ].find((candidate) => candidate !== undefined);
    if (part !== undefined) return { kind: "part", part };
    return one.pathname !== other.pathname ? { kind: "path" } : { kind: "gone" };
  }
  return { kind: "unreadable" };
}

/** Reads a url, or says it does not read as one. */
function readUrl(text: string): URL | undefined {
  try {
    return new URL(text);
  } catch {
    return undefined;
  }
}

/**
 * Says whether one path segment is a relative step, however it is written. A url is
 * percent-decoded before it is resolved, so "%2e%2e" walks back exactly as ".." does and is
 * refused the same way. A segment whose escapes do not decode at all is refused too: if
 * nobody can say what it says, nobody can say what it walks over.
 */
function relativeSegmentFault(segment: string): "relative" | "unreadable" | undefined {
  let decoded: string;
  try {
    decoded = decodeURIComponent(segment);
  } catch {
    return "unreadable";
  }
  return decoded === "." || decoded === ".." ? "relative" : undefined;
}

/**
 * Names the operations whose call a faulty piece of url is part of, so a refusal about a
 * `servers` url or a path says which calls it breaks. Empty when no declared operation uses
 * the piece at all — there is then nothing to name.
 */
function callingOperations(ids: readonly string[]): string {
  if (ids.length === 0) return "";
  const names = ids.map((id) => `"${id}"`).join(", ");
  return ids.length === 1 ? ` Operation ${names} calls it.` : ` Operations ${names} call it.`;
}

/** How many times the credential placeholder appears in a piece of url text. */
function countCredentialSites(text: string): number {
  return text.split(CAPTURED_CREDENTIAL_PLACEHOLDER).length - 1;
}

/**
 * Names the part of a server url the placeholder sits in when that part is not the path,
 * or `undefined` when the url either has no placeholder or keeps it in the path.
 *
 * It finds the placeholder the same way the assembled-url check does — by reading the url
 * twice with two different stand-ins and seeing which part changed — so an ordinary host or
 * path that happens to spell out some word is never mistaken for a placeholder. Only the
 * literal `{credential}` counts as a placeholder: written percent-encoded it is not
 * recognised, and the origin check then refuses the url for having a percent-encoded path.
 */
function credentialOutsideServerPath(url: string): string | undefined {
  if (!url.includes(CAPTURED_CREDENTIAL_PLACEHOLDER)) return undefined;
  const placement = credentialPlacement(url);
  if (placement.kind === "part") return placement.part;
  return placement.kind === "unreadable"
    ? "a part of the url that stops it reading as a url at all"
    : undefined;
}

/** The one origin every captured call goes to: HTTPS, no credentials in the url, no traversal, and no template but the credential an `auth: "path"` entry puts there. */
export function checkCapturedApiBase(url: unknown, where: string, pathCredential: boolean): void {
  if (typeof url !== "string" || url === "") {
    throw new SynthError(`${where}: the \`servers\` entry needs a \`url\`, and this has none.`);
  }
  // Parsed with the placeholder standing in as an ordinary segment: braces percent-encode,
  // and the rest of this reads a url the host would never build if it left them in.
  const probe = pathCredential
    ? url.split(CAPTURED_CREDENTIAL_PLACEHOLDER).join(CAPTURED_CREDENTIAL_NAME)
    : url;
  let parsed: URL;
  try {
    parsed = new URL(probe);
  } catch {
    throw new SynthError(`${where}: "${url}" does not read as a url at all.`);
  }
  const complaints = [
    parsed.protocol !== "https:" ? "it is not https" : undefined,
    parsed.hostname === "" ? "it names no host" : undefined,
    parsed.username !== "" || parsed.password !== "" ? "it carries credentials" : undefined,
    parsed.port !== "" && parsed.port !== "443" ? `it uses port ${parsed.port}` : undefined,
    parsed.search !== "" ? "it carries a query string" : undefined,
    parsed.hash !== "" ? "it carries a fragment" : undefined,
    parsed.pathname.includes("%") ? "its path is percent-encoded" : undefined,
    parsed.pathname.split("/").some((s) => s === "." || s === "..")
      ? "its path has a relative segment"
      : undefined,
    probe.includes("{") || probe.includes("}") ? "it is templated" : undefined,
  ].filter((complaint) => complaint !== undefined);
  if (complaints.length > 0) {
    throw new SynthError(
      `${where}: the host refuses "${url}" as the api's origin because ${complaints.join(", ")}. ` +
        `Every captured call goes to one fixed HTTPS origin on the default port.`,
    );
  }
}

/**
 * The security declaration for one operation, root-level or its own, and the scheme it
 * points at. Returns the lowercased name of the header or query field the credential
 * travels in, which is the one thing the api itself may not also use.
 */
function checkCapturedSecurity(
  doc: Record<string, unknown>,
  operation: Record<string, unknown>,
  spec: CapturedApiSpec,
  where: string,
  bearerScheme: string,
): string {
  const security = operation.security ?? doc.security;
  if (!Array.isArray(security) || security.length !== 1) {
    throw new SynthError(
      `${where} has no single \`security\` requirement, at the root or on itself. The host will ` +
        `not send a credential it cannot see where to put, so it refuses the api.`,
    );
  }
  const requirement = security[0] as Record<string, unknown>;
  const names = Object.keys(requirement ?? {});
  if (names.length !== 1) {
    throw new SynthError(
      `${where}: its \`security\` requirement names ${names.length} schemes. The host reads exactly one.`,
    );
  }
  const name = names[0] as string;
  const scopes = requirement[name];
  if (!Array.isArray(scopes) || scopes.length !== 0) {
    throw new SynthError(
      `${where}: the host reads the scheme "${name}" with an empty scope list. A captured api ` +
        `grants no scopes, so anything here is refused.`,
    );
  }
  const components = doc.components as Record<string, unknown> | undefined;
  const schemes = components?.securitySchemes as Record<string, unknown> | undefined;
  const scheme = schemes?.[name] as Record<string, unknown> | undefined;
  if (!scheme) {
    throw new SynthError(
      `${where}: nothing at components.securitySchemes.${name} declares how "${name}" works.`,
    );
  }
  if (spec.auth === "bearer") {
    if (
      scheme.type !== "http" ||
      String(scheme.scheme).toLowerCase() !== bearerScheme.toLowerCase()
    ) {
      // Named the way a document spells it: the default is the registered scheme and is
      // written lowercase everywhere, while a scheme the realm asked for is quoted back in
      // the realm's own spelling. The comparison above is case-insensitive either way.
      const wanted = bearerScheme === CAPTURED_DEFAULT_BEARER_SCHEME ? "bearer" : bearerScheme;
      throw new SynthError(
        `${where}: the entry declares auth: "bearer" against a credential the host sends as ` +
          `"${bearerScheme}", so it wants components.securitySchemes.${name} to be an http ` +
          `${wanted} scheme. It is ` +
          `${JSON.stringify(scheme.type)}/${JSON.stringify(scheme.scheme)}.`,
      );
    }
    return "authorization";
  }
  if (scheme.type !== "apiKey") {
    throw new SynthError(
      `${where}: the entry declares auth: "api-key", so the host wants ` +
        `components.securitySchemes.${name} to be an apiKey scheme, not ${JSON.stringify(scheme.type)}.`,
    );
  }
  if (scheme.in !== "header" && scheme.in !== "query") {
    throw new SynthError(
      `${where}: the host puts an api key in a header or the query string, and this scheme says ` +
        `${JSON.stringify(scheme.in)}.`,
    );
  }
  const field = scheme.name;
  if (typeof field !== "string" || !CAPTURED_HEADER_FIELD.test(field)) {
    throw new SynthError(
      `${where}: ${JSON.stringify(field)} is not a name the host will put a credential in ` +
        `(${CAPTURED_HEADER_FIELD.source}).`,
    );
  }
  if (CAPTURED_FORBIDDEN_HEADERS.includes(field.toLowerCase())) {
    throw new SynthError(
      `${where}: the host refuses to put a credential in "${field}" — that header frames the ` +
        `request or carries its own meaning, so an api that asked for it could redirect the call.`,
    );
  }
  return field.toLowerCase();
}

/** One argument a captured operation takes, in the two places it may be declared. */
interface CapturedApiParameterShape {
  name: string;
  location: string;
}

/** Reads the path-item and operation parameter lists the way the host merges them, refusing what it refuses. */
function checkCapturedParameters(
  onPathItem: unknown,
  onOperation: unknown,
  where: string,
): CapturedApiParameterShape[] {
  const result: CapturedApiParameterShape[] = [];
  for (const declaration of [onPathItem, onOperation]) {
    if (declaration === undefined || declaration === null) continue;
    if (!Array.isArray(declaration) || declaration.length > CAPTURED_MAX_API_PARAMETERS) {
      throw new SynthError(
        `${where}: the host reads a parameter list of at most ${CAPTURED_MAX_API_PARAMETERS} entries here.`,
      );
    }
    for (const entry of declaration) {
      const parameter = (entry ?? {}) as Record<string, unknown>;
      if ("$ref" in parameter || "content" in parameter) {
        throw new SynthError(
          `${where}: a parameter here is a $ref or carries \`content\`. The host reads only ` +
            `parameters declared inline with a plain schema.`,
        );
      }
      const name = parameter.name;
      if (typeof name !== "string" || !CAPTURED_API_IDENTIFIER.test(name)) {
        throw new SynthError(
          `${where}: ${JSON.stringify(name)} is not a parameter name the host will read ` +
            `(${CAPTURED_API_IDENTIFIER.source}).`,
        );
      }
      const location = parameter.in;
      if (location !== "query" && location !== "path") {
        throw new SynthError(
          `${where}: parameter "${name}" is in ${JSON.stringify(location)}. A captured call takes ` +
            `arguments in the path or the query string only.`,
        );
      }
      if (location === "path" && parameter.required !== true) {
        throw new SynthError(
          `${where}: path parameter "${name}" is not marked required. The host cannot build the ` +
            `url without it, so it refuses the api.`,
        );
      }
      const schema = parameter.schema as Record<string, unknown> | undefined;
      if (!schema || typeof schema !== "object") {
        throw new SynthError(`${where}: parameter "${name}" declares no schema.`);
      }
      if (!CAPTURED_API_SCALAR_TYPES.includes(String(schema.type))) {
        throw new SynthError(
          `${where}: parameter "${name}" is a ${JSON.stringify(schema.type)}. The host passes ` +
            `${CAPTURED_API_SCALAR_TYPES.join(", ")} and nothing else.`,
        );
      }
      if (schema.enum !== undefined) {
        if (
          !Array.isArray(schema.enum) ||
          schema.enum.length > CAPTURED_MAX_API_ENUM ||
          schema.enum.some((v) => v === null || typeof v === "object")
        ) {
          throw new SynthError(
            `${where}: parameter "${name}" has an enum the host will not read — at most ` +
              `${CAPTURED_MAX_API_ENUM} plain values, none of them null.`,
          );
        }
      }
      const min = checkCapturedApiBound(
        schema.minLength,
        `${where}: parameter "${name}".minLength`,
        0,
      );
      const max = checkCapturedApiBound(
        schema.maxLength,
        `${where}: parameter "${name}".maxLength`,
        2048,
      );
      if (min > max) {
        throw new SynthError(
          `${where}: parameter "${name}" has minLength ${min} above maxLength ${max}.`,
        );
      }
      result.push({ name, location });
    }
  }
  if (result.length > CAPTURED_MAX_API_PARAMETERS) {
    throw new SynthError(
      `${where}: the host reads at most ${CAPTURED_MAX_API_PARAMETERS} parameters per operation, ` +
        `and this has ${result.length}.`,
    );
  }
  const names = result.map((parameter) => parameter.name);
  const duplicate = names.find((name, i) => names.indexOf(name) !== i);
  if (duplicate !== undefined) {
    throw new SynthError(
      `${where}: "${duplicate}" is declared twice — once on the path item and once on the ` +
        `operation, most likely. The host reads the merged list and refuses a repeat.`,
    );
  }
  return result;
}

/** A `minLength`/`maxLength` bound: a whole number in 0..2048, or the host's own default. */
export function checkCapturedApiBound(value: unknown, where: string, fallback: number): number {
  if (value === undefined) return fallback;
  if (typeof value !== "number" || !Number.isInteger(value) || value < 0 || value > 2048) {
    throw new SynthError(
      `${where}: the host reads this as a whole number in 0..2048, got ${JSON.stringify(value)}.`,
    );
  }
  return value;
}

/** A write's body: absent, or a bounded `application/json` object schema. */
function checkCapturedRequestBody(
  body: unknown,
  document: Record<string, unknown>,
  where: string,
): void {
  if (body === undefined) return;
  const node = body as Record<string, unknown>;
  const keys = Object.keys(node);
  if (keys.length !== 1 || keys[0] !== "content") {
    throw new SynthError(
      `${where}: the host reads a requestBody holding \`content\` and nothing else, and this has ` +
        `[${keys.join(", ")}].`,
    );
  }
  const content = node.content as Record<string, unknown>;
  if (!content || typeof content !== "object" || Object.keys(content).length !== 1) {
    throw new SynthError(
      `${where}: the host sends exactly one media type, so \`content\` holds exactly one key.`,
    );
  }
  const media = content["application/json"] as Record<string, unknown> | undefined;
  if (!media) {
    throw new SynthError(
      `${where}: the host sends application/json, and this body declares ` +
        `${Object.keys(content).join(", ")} instead.`,
    );
  }
  const mediaKeys = Object.keys(media);
  if (mediaKeys.length !== 1 || mediaKeys[0] !== "schema") {
    throw new SynthError(
      `${where}: the host reads the media type as holding \`schema\` and nothing else, and this ` +
        `has [${mediaKeys.join(", ")}].`,
    );
  }
  const schema = media.schema as Record<string, unknown>;
  if (!schema || typeof schema !== "object") {
    throw new SynthError(`${where}: its body declares no schema.`);
  }
  const resolved = checkCapturedBodySchema(schema, document, where);
  if (resolved !== undefined && resolved.type !== "object") {
    throw new SynthError(
      `${where}: the host sends a JSON object as a body, and this schema resolves to ` +
        `${JSON.stringify(resolved.type)}.`,
    );
  }
}

/** Every `$ref` value anywhere in a document, however deep. */
function collectRefs(node: unknown): unknown[] {
  if (Array.isArray(node)) return node.flatMap(collectRefs);
  if (!node || typeof node !== "object") return [];
  return Object.entries(node as Record<string, unknown>).flatMap(([key, child]) =>
    key === "$ref" ? [child] : collectRefs(child),
  );
}

/**
 * Refuses an output tree where a vendored document would overwrite a file synth
 * itself generates, or where two vendored documents would overwrite each other.
 *
 * This runs once every rendered and vendored file is known, so it sees the whole
 * output tree at once: a vendored `url` that happens to resolve to the same path as
 * `apis/apis.yml` or `realm.yml`, discovered only after those are rendered, is still
 * caught before anything gets written.
 *
 * Two api entries landing at the same output path are allowed only when they read the
 * exact same file: the same resolved source path. That happens when a definition
 * vendors one document for two namespaces on purpose. Two different source files
 * landing at the same path is refused, since writing one would silently overwrite the
 * other's bytes.
 */
function checkOutputCollisions(
  files: EmittedFile[],
  vendoredRecords: VendoredRecord[],
  realmRoot: string,
): void {
  const renderedPaths = new Set(
    files.filter((file) => file.kind === "rendered").map((file) => file.path),
  );

  const seenByPath = new Map<string, VendoredRecord>();
  for (const record of vendoredRecords) {
    // Defense in depth. checkRelativePath already refuses a "url" with a leading
    // slash or a ".." segment before this point, so this should never fire. It stays
    // here as a hard stop in case that earlier check is ever loosened or bypassed.
    const resolvedRoot = resolve(realmRoot);
    const resolvedTarget = resolve(realmRoot, record.path);
    const rel = relative(resolvedRoot, resolvedTarget);
    if (rel === ".." || rel.startsWith(`..${sep}`) || isAbsolute(rel)) {
      throw new SynthError(
        `$.apis.${record.key}.url: the vendored output path "${record.path}" escapes the realm root. This should already be unreachable.`,
      );
    }

    if (renderedPaths.has(record.path)) {
      throw new SynthError(
        `$.apis.${record.key}.url: the vendored output path "${record.path}" collides with a file synth generates at that same path. Give this api a different url so the two do not overwrite each other.`,
      );
    }

    const existing = seenByPath.get(record.path);
    if (existing && existing.sourcePath !== record.sourcePath) {
      throw new SynthError(
        `$.apis.${record.key}.url: the vendored output path "${record.path}" collides with the document vendored for $.apis.${existing.key}.url, and the two point at different source files ("${record.sourcePath}" and "${existing.sourcePath}"). Give one of them a different url so both keep their own bytes.`,
      );
    }
    if (!existing) seenByPath.set(record.path, record);
  }
}

/**
 * Checks one operation reference against the realm's declared apis, when both apply.
 *
 * Only a dotted reference (`namespace.verb`) carries enough information to check: a
 * bare verb, the form a producer's own `operation` conventionally uses, names no
 * namespace, so which api it would mean is ambiguous in today's model. This leaves a
 * bare reference unvalidated. It never guesses. When the realm declares no apis at all,
 * every reference is left exactly as it always was: unvalidated.
 *
 * An entry with no allowlist exposes every operation its document declares, so there is
 * nothing to hold the verb against and the reference passes. That is the honest answer,
 * not a gap: the allowlist is the only thing synth has, and a realm that declined to
 * write one declined the check with it.
 */
function checkApiReference(
  operation: string,
  apis: Record<string, ApiSpec> | undefined,
  where: string,
): void {
  if (!apis) return;
  const dot = operation.indexOf(".");
  if (dot === -1) return;
  const ns = operation.slice(0, dot);
  const opId = operation.slice(dot + 1);
  const found = apiNamespaces(apis).get(ns);
  if (!found) {
    const filedUnderKey = apis[ns];
    if (filedUnderKey !== undefined) {
      const declared = effectiveApiName(ns, filedUnderKey);
      throw new SynthError(
        declared === undefined
          ? `${where}: "${operation}" names namespace "${ns}", but $.apis.${ns} sets name: null, so ` +
              `the engine derives that entry's namespace from its url and there is no name to ` +
              `reference it by. Give the entry a name, or call the operation bare.`
          : `${where}: "${operation}" names namespace "${ns}", but $.apis.${ns} declares the name ` +
              `"${declared}", which is the namespace the engine registers. Reference it as ` +
              `"${declared}.${opId}".`,
      );
    }
    throw new SynthError(
      `${where}: "${operation}" names namespace "${ns}", but the realm declares no api for it`,
    );
  }
  const { spec } = found;
  if (spec.operationIds === undefined) return;
  if (!spec.operationIds.includes(opId)) {
    throw new SynthError(
      `${where}: "${opId}" is not allowlisted for namespace "${ns}" (${spec.url} allows: ${spec.operationIds.join(", ")})`,
    );
  }
}

/**
 * Renders the realm's producers into the list `producers/<realm>.yml` holds, checking
 * each one against what the engine will actually read.
 *
 * Same order, and for the same reason, as the types file: the checks that can name a key
 * the author wrote run first, then the entry is rendered, then the rendered bytes go
 * through the wire allowlist. The allowlist matters more here than anywhere else,
 * because a producers file is polymorphic — the entry's own `kind` picks which engine
 * class binds it, and the three classes overlap far less than they look like they do. A
 * `volatility` that is exactly right on a generative producer reaches no field at all on
 * a remote one, and nothing except this check would say so.
 */
function producerEntries(realm: Realm): JsonValue[] {
  const producers = realm.producers as Record<string, ProducerSpec>;

  for (const [id, producer] of Object.entries(producers)) {
    checkProducer(id, producer, realm);
  }

  const sorted = Object.keys(producers).sort();
  const entries = named(producers, "$.producers");
  entries.forEach((entry, i) => {
    const where = `$.producers.${sorted[i]}`;
    const kind = (entry as JsonObject).kind;
    const shape = PRODUCER_SPECS[String(kind)];
    if (!shape) {
      throw new SynthError(
        `${where}.kind: ${JSON.stringify(kind)} is not a producer kind synth emits. ` +
          `It emits: ${Object.keys(PRODUCER_SPECS).sort().join(", ")}.`,
      );
    }
    checkWireShape(entry, shape, where);
  });
  return entries;
}

/** Everything about one producer that is worth saying in terms of the definition the author wrote. */
function checkProducer(id: string, producer: ProducerSpec, realm: Realm): void {
  const where = `$.producers.${id}`;

  // First, because everything below it reads fields that only exist on one kind. The
  // engine registers many more kinds than synth emits — sql, vector, cypher and a dozen
  // others — so this is a real thing an author can write, not a typo guard.
  if (!PRODUCER_SPECS[producer.kind]) {
    throw new SynthError(
      `${where}.kind: ${JSON.stringify(producer.kind)} is not a producer kind synth emits. ` +
        `It emits: ${Object.keys(PRODUCER_SPECS).sort().join(", ")}.`,
    );
  }

  // Only the aggregate backend owns its own collection, so only it can hash the inputs a
  // graph cache is keyed on. Everywhere else the engine reads the policy, shrugs, and
  // caches nothing — which reads as "cached in the graph" in the definition and is not.
  if (producer.cache?.kind === "graph" && producer.kind !== "aggregate") {
    throw new SynthError(
      `${where}.cache: a graph cache persists the producer's result as a real node, and only an ` +
        `aggregate producer can do that. On a ${producer.kind} producer the engine falls back to ` +
        `no caching at all, silently.`,
    );
  }

  if (producer.kind === "remote") {
    checkRemoteFetch(producer, where, realm);
    return;
  }

  if (producer.kind === "generative") {
    for (const field of ["edgeType", "identityField"] as const) {
      refuseBlank(producer[field], `${where}.${field}`);
    }
    if (producer.generator.kind === "llm") {
      if (producer.generator.prompt?.trim() === "") {
        throw new SynthError(
          `${where}.generator.prompt: cannot be blank. The host ships no domain prompt, so an ` +
            `empty one leaves the model with nothing but the anchors.`,
        );
      }
    } else {
      refuseBlank(producer.generator.operation, `${where}.generator.operation`);
    }
    if (producer.resolveVia) {
      checkRemoteFetch(producer.resolveVia, `${where}.resolveVia`, realm);
      refuseBlank(producer.resolveVia.name, `${where}.resolveVia.name`);
    } else if (producer.resolveRelaxation !== undefined) {
      throw new SynthError(
        `${where}.resolveRelaxation: relaxation is how resolution retries a name it could not ` +
          `match, and with no resolveVia there is no resolution to relax. The engine ignores it.`,
      );
    }
    return;
  }

  refuseBlank(producer.edgeType, `${where}.edgeType`);
  for (const field of ["targetLabel", "via", "text"] as const) {
    refuseBlank(producer.collect?.[field], `${where}.collect.${field}`);
  }
  if (producer.collect.anchorKeyProperty !== undefined) {
    // Per-anchor mode produces one node per anchor, so the node's own identity and the
    // key it links back by are two different things. Both default to "userId", so a
    // per-anchor producer that leaves them alone has every anchor's result colliding on
    // one identity — the failure looks like missing data, never like a config mistake.
    const identity = producer.identityField ?? "userId";
    const anchorKey = producer.anchorKeyField ?? "userId";
    if (identity === anchorKey) {
      throw new SynthError(
        `${where}: collect.anchorKeyProperty puts this producer in per-anchor mode, where ` +
          `identityField carries each produced node's own id and anchorKeyField carries the value ` +
          `it links back by. Both are "${identity}" here, so every anchor's result would merge ` +
          `onto one node.`,
      );
    }
  }
}

/**
 * Everything about one captured producer worth saying in terms of what the author
 * wrote — the counterpart to `checkProducer` for the captured shape.
 */
function checkCapturedProducer(producer: CapturedProducerSpec, where: string): void {
  refuseBlank(producer.handler, `${where}.handler`);
  refuseBlank(producer.keyArgument, `${where}.keyArgument`);
  if (producer.joins.length === 0 || producer.joins.length > 8) {
    throw new SynthError(
      `${where}.joins: needs 1 to 8 joins — the host refuses a producer declaring none or more ` +
        `than 8, got ${producer.joins.length}.`,
    );
  }
  producer.joins.forEach((join, i) => {
    for (const field of [
      "targetLabel",
      "anchorLabel",
      "relationship",
      "keyField",
      "recordKeyField",
    ] as const) {
      refuseBlank(join[field], `${where}.joins[${i}].${field}`);
    }
  });
  if (producer.page) {
    if (producer.page.argument === producer.keyArgument) {
      throw new SynthError(
        `${where}.page.argument: must differ from keyArgument ("${producer.keyArgument}") — the ` +
          `host refuses a page cursor that shadows the key argument.`,
      );
    }
    if (producer.page.maxPages < 1 || producer.page.maxPages > 16) {
      throw new SynthError(
        `${where}.page.maxPages: must be between 1 and 16, got ${producer.page.maxPages}`,
      );
    }
  }
  const taken = new Set([producer.keyArgument, producer.page?.argument].filter(Boolean));
  const seen = new Set<string>();
  (producer.pushdown ?? []).forEach((rule, i) => {
    refuseBlank(rule.property, `${where}.pushdown[${i}].property`);
    refuseBlank(rule.argument, `${where}.pushdown[${i}].argument`);
    if (taken.has(rule.argument) || seen.has(rule.argument)) {
      throw new SynthError(
        `${where}.pushdown[${i}].argument: "${rule.argument}" is already the key argument, the page ` +
          `argument or another pushdown's argument, and the host refuses a producer that reuses one.`,
      );
    }
    seen.add(rule.argument);
  });
}

/**
 * Refuses a field written as whitespace. A missing field is left to the wire allowlist,
 * which knows whether the engine has a default for it and says so either way — this is
 * only for the case where something IS written and means nothing.
 */
function refuseBlank(field: string | undefined, where: string): void {
  if (typeof field === "string" && field.trim() === "") {
    throw new SynthError(`${where}: cannot be blank`);
  }
}

/**
 * The checks a remote fetch is held to, wherever it appears — as a producer of its own,
 * or nested inside a generative producer as the resolver that turns a generated name
 * into a real record. Same engine class either way, so the same rules.
 */
function checkRemoteFetch(spec: RemoteProducer | ResolveVia, where: string, realm: Realm): void {
  // Both types emitters turn the operation into an identifier, so a string that cannot
  // be one is caught here, with the path in the definition that put it there.
  checkGatewayOperation(spec.operation, `${where}.operation`);
  checkApiReference(spec.operation, realm.apis, `${where}.operation`);

  if (spec.keyArgs !== undefined) {
    if (spec.keyArgs.length === 0) {
      throw new SynthError(
        `${where}.keyArgs: an empty list is what leaving the field out already means. Name the ` +
          `arguments the key splits into, or remove it.`,
      );
    }
    spec.keyArgs.forEach((arg, i) => {
      if (arg.trim() === "") throw new SynthError(`${where}.keyArgs[${i}]: cannot be blank`);
    });
  }
  if (spec.keySplit !== undefined) {
    if (spec.keyArgs === undefined) {
      throw new SynthError(
        `${where}.keySplit: keySplit is the delimiter keyArgs splits a key on, and with no keyArgs ` +
          `nothing splits. The engine never reads it.`,
      );
    }
    if (spec.keySplit === "") {
      throw new SynthError(
        `${where}.keySplit: cannot be empty — a key would split into characters`,
      );
    }
  }
  if (spec.keyTransform) {
    if (spec.keyTransform.instruction?.trim() === "") {
      throw new SynthError(
        `${where}.keyTransform.instruction: cannot be blank. The instruction is the whole of what ` +
          `tells the model which query language to rewrite into.`,
      );
    }
    spec.keyTransform.examples?.forEach((example, i) => {
      for (const field of ["input", "output"] as const) {
        if (example[field].trim() === "") {
          throw new SynthError(`${where}.keyTransform.examples[${i}].${field}: cannot be blank`);
        }
      }
    });
  }
}

/**
 * Renders the realm's types into the list `types/<realm>.yml` holds, checking each one
 * against what the engine will actually read.
 *
 * The order matters. Everything that needs the author's own object — a producer name to
 * cross-check, a Cypher example to parse — happens first, so a failure can name the key
 * in `realm.ts` the author wrote. Then the entry is rendered, and the rendered bytes go
 * through the wire allowlist, which is the backstop: whatever a check above missed, a
 * key the engine has no field for stops here rather than shipping.
 */
function typeEntries(realm: Realm): JsonValue[] {
  const types = realm.types as Record<string, TypeSpec>;
  const prepared: Record<string, unknown> = {};

  for (const [name, spec] of Object.entries(types)) {
    const where = `$.types.${name}`;
    if (!IDENTIFIER.test(name)) {
      throw new SynthError(
        `${where}: "${name}" is not a valid identifier for a generated type name`,
      );
    }
    checkType(name, spec, realm);
    // Methods are keyed by name in the definition and read as a list by the engine, the
    // same fold `named` does for types themselves, one level down.
    prepared[name] = spec.methods
      ? { ...spec, methods: named(spec.methods, `${where}.methods`) }
      : spec;
  }

  const sorted = Object.keys(prepared).sort();
  const entries = named(prepared, "$.types");
  entries.forEach((entry, i) => {
    checkWireShape(entry, TYPE_ENTRY, `$.types.${sorted[i]}`);
  });
  return entries;
}

/** Everything about one type that is worth saying in terms of the definition the author wrote. */
function checkType(name: string, spec: TypeSpec, realm: Realm): void {
  const where = `$.types.${name}`;

  if (spec.retrieval) {
    checkGatewayOperation(spec.retrieval.operation, `${where}.retrieval.operation`);
    checkApiReference(spec.retrieval.operation, realm.apis, `${where}.retrieval.operation`);
  }

  spec.parents?.forEach((parent, i) => {
    if (parent.trim() === "")
      throw new SynthError(`${where}.parents[${i}]: a parent name cannot be blank`);
  });

  // The engine's UserAnchorSpec asserts the predicate is uppercase and refuses it
  // otherwise — inside the deserializer, which means the whole types file fails to load
  // and every type in it disappears. A lowercase predicate is an easy thing to write and
  // an impossible thing to debug, so it stops here.
  if (spec.userAnchor && typeof spec.userAnchor === "object") {
    const predicate = spec.userAnchor.predicate;
    if (predicate.trim() === "") {
      throw new SynthError(`${where}.userAnchor.predicate: cannot be blank`);
    }
    if (predicate !== predicate.toUpperCase()) {
      throw new SynthError(
        `${where}.userAnchor.predicate: the engine requires an uppercase predicate, so write ` +
          `"${predicate.toUpperCase()}" rather than "${predicate}".`,
      );
    }
  }

  if (spec.population) {
    for (const field of ["sourceKind", "operation"] as const) {
      if (spec.population[field].trim() === "") {
        throw new SynthError(`${where}.population.${field}: cannot be blank`);
      }
    }
  }

  spec.virtualJoins?.forEach((join, i) => {
    const jw = `${where}.virtualJoins[${i}]`;
    for (const field of ["anchorLabel", "relationship", "keyField", "producer"] as const) {
      if (join[field].trim() === "") throw new SynthError(`${jw}.${field}: cannot be blank`);
    }
    checkProducerReference(join.producer, realm, `${jw}.producer`);
  });

  for (const [method, binding] of Object.entries(spec.methods ?? {})) {
    const mw = `${where}.methods.${method}.gatewayTool`;
    if (!IDENTIFIER.test(method)) {
      throw new SynthError(
        `${where}.methods.${method}: "${method}" is not a valid identifier for a method name`,
      );
    }
    checkGatewayOperation(binding.gatewayTool, mw);
    checkMethodTarget(binding.gatewayTool, realm, mw);
  }

  spec.examples?.forEach((example, i) => {
    if (example.q.trim() === "") throw new SynthError(`${where}.examples[${i}].q: cannot be blank`);
    checkCypher(example.cypher, `${where}.examples[${i}].cypher`);
  });
}

/**
 * A virtual join names the producer that fetches its records, and a name that resolves
 * to nothing means the join never fires. Held to the same rule as an operation against
 * `apis`: a realm that declares no producers gets no checking, because there is nothing
 * to check against; once it declares some, the set is the truth.
 */
function checkProducerReference(producer: string, realm: Realm, where: string): void {
  if (!realm.producers) return;
  const declared = Object.keys(realm.producers);
  if (declared.includes(producer)) return;
  throw new SynthError(
    `${where}: "${producer}" is not a producer this realm declares (it has: ${declared.sort().join(", ")}). ` +
      `A join whose producer does not resolve fetches nothing.`,
  );
}

/**
 * A captured profile that names one of the realm's own handlers as `namespace.verb` —
 * a browser app's callable list, a lens's view producer. The host only ever grants a
 * handler the realm's manifest registers, so one it does not is a surface that can never
 * work; `consequence` says what would go wrong, since that differs per profile.
 */
export function checkCapturedHandlerReference(
  name: string,
  realm: CapturedRealm,
  where: string,
  consequence: string,
): void {
  const available = declaredHandlerNames(realm);
  if (available.has(name)) return;
  const inventory =
    available.size === 0
      ? "it declares no handlers"
      : `it has: ${[...available].sort().join(", ")}`;
  throw new SynthError(
    `${where}: "${name}" is not a handler this realm declares (${inventory}). ${consequence} ` +
      `Declare it under handlers, or name one that is already there, spelled <namespace>.<verb>.`,
  );
}

/** The one input type a captured goal may name without anything declaring it. */
const USER_INPUT = "UserInput";

/**
 * Warns about a goal input or output type this realm does not declare.
 *
 * Not a refusal. The host resolves a goal's types against the whole World, so a type another
 * realm or the owner declares works fine, and synth cannot see those. But a type nobody
 * declares drops the goal at load time, so the author hears about it here first.
 */
function warnUndeclaredGoalTypes(
  goal: { input: string; output: string },
  realm: CapturedRealm,
  where: string,
  warn: (message: string) => void,
): void {
  const declared = new Set(Object.keys(realm.types ?? {}));
  for (const field of ["input", "output"] as const) {
    const name = goal[field];
    if (declared.has(name) || (field === "input" && name === USER_INPUT)) continue;
    warn(
      `WARNING ${where}.${field}: "${name}" is not a type this realm declares. The host looks ` +
        `goal types up across the whole World and drops this goal if nothing there declares ` +
        `"${name}". Declare it under types, unless another realm or the owner provides it.`,
    );
  }
}

/**
 * Every handler a captured realm can name, as `namespace.verb`. A realm with no handlers
 * block declares none, the same answer `defineRealm` gives at compile time: the host has no
 * manifest entry to dispatch to, so every reference would fail.
 */
export function declaredHandlerNames(realm: CapturedRealm): ReadonlySet<string> {
  return new Set(
    Object.entries(realm.handlers ?? {}).map(([key, spec]) => `${spec.namespace}.${key}`),
  );
}

/**
 * The lowercase-and-dashes grammar `CapturedLensManifest.kt` reads a lens id as and
 * `CapturedWatchManifest.kt` reads both a watch name and its lens reference as. One
 * pattern because they are one grammar: a watch's `lens` has to spell a lens id.
 */
const WATCH_NAME_PATTERN = /^[a-z][a-z0-9-]{0,63}$/;

/** `CapturedLensManifest.kt`'s `Module.function` handler grammar. */
const CAPTURED_LENS_HANDLER_PATTERN = /^[A-Za-z_$][A-Za-z0-9_$]*\.[A-Za-z_$][A-Za-z0-9_$]*$/;

/**
 * `CapturedLensManifest.kt`'s `CapturedRealmLens.Declaration`. One object per file under
 * `lenses/`, and nothing like the conventional `Lens`: no `spec`, and a `handler` the
 * conventional shape has no field for at all. The reader refuses the whole `lenses/`
 * directory over one file it cannot read, and every watch naming a lens goes down with
 * it, so this is checked as strictly as the watch shape itself.
 */
const CAPTURED_LENS_SPEC: WireShape = {
  kind: "object",
  name: "CapturedRealmLens.Declaration",
  of: {
    version: { kind: "integer", name: "version", min: 1, max: 1 },
    id: { kind: "text", name: "ID_PATTERN", pattern: WATCH_NAME_PATTERN, max: 64 },
    name: { kind: "text", name: "name", max: 128 },
    handler: {
      kind: "text",
      name: "HANDLER_PATTERN",
      pattern: CAPTURED_LENS_HANDLER_PATTERN,
      max: 256,
    },
    description: { kind: "text", name: "description", max: 512 },
    result: { kind: "enum", name: "lens result", of: ["json", "content"] },
  },
  required: ["version", "id", "name", "handler"],
};

/** `CapturedWatchManifest.kt`'s own byte caps for a watch's free-text fields. */
const WATCH_CRITERIA_BYTES = 2048;
const WATCH_JUDGE_BYTES = 1024;

/** The host reads at most this many watch files out of one captured realm's `watches/`. */
const CAPTURED_MAX_WATCHES = 16;

/**
 * `CapturedWatchManifest.kt`'s `CapturedWatchDeclaration`. One object per file under
 * `watches/`. `criteria` and `judge` carry no `max` here — the host's own cap on them is
 * counted in UTF-8 bytes, not characters, so `checkUtf8ByteLimit` checks those two fields
 * separately rather than through this declarative shape.
 */
const WATCH_SPEC: WireShape = {
  kind: "object",
  name: "CapturedWatchDeclaration",
  of: {
    version: { kind: "integer", name: "version", min: 1, max: 1 },
    name: { kind: "text", name: "NAME_PATTERN", pattern: WATCH_NAME_PATTERN, max: 64 },
    lens: { kind: "text", name: "NAME_PATTERN", pattern: WATCH_NAME_PATTERN, max: 64 },
    schedule: { kind: "text", name: "schedule", max: 64 },
    criteria: { kind: "text", name: "criteria" },
    // No `emptyOk`: an omitted judge means "no judge at all" and reads fine, but a judge
    // that is there goes through `CapturedApiDocuments.string`, which refuses an empty
    // string and takes the whole file down with it.
    judge: { kind: "text", name: "judge" },
  },
  required: ["version", "name", "lens", "schedule", "criteria"],
};

/** Refuses a string past a byte cap the host counts in UTF-8 bytes, not characters. */
function checkUtf8ByteLimit(value: string, maxBytes: number, name: string, where: string): void {
  const bytes = Buffer.byteLength(value, "utf8");
  if (bytes > maxBytes) {
    throw new SynthError(
      `${where}: ${name} is read with a ${maxBytes}-byte limit, counting UTF-8 bytes rather than ` +
        `characters, and this is ${bytes} bytes.`,
    );
  }
}

/**
 * A watch names one of this realm's own lenses to re-read on schedule.
 * `CapturedWatchManifest.kt` refuses one naming a lens this realm's manifest never
 * declares, so synth catches it here instead of leaving it for the host to discover at
 * install time that the watch can never run.
 */
function checkWatchLensReference(lens: string, realm: CapturedRealm, where: string): void {
  const available = new Set(Object.keys(realm.capturedLenses ?? {}));
  if (available.has(lens)) return;
  throw new SynthError(
    `${where}: "${lens}" is not a lens this realm declares (it has: ${[...available].sort().join(", ") || "none"}). ` +
      `A watch naming a lens it cannot open would never run.`,
  );
}

/** A trigger can only bind names declared by this realm's one data-pipe document. */
function checkDataPipeReference(
  value: string,
  realm: CapturedRealm,
  where: string,
  kind: "source" | "consumer",
): void {
  const declared = realm.dataPipes?.[kind === "source" ? "sources" : "consumers"];
  if (declared && Object.hasOwn(declared, value)) return;
  throw new SynthError(`${where} references undeclared dataPipes ${kind} ${JSON.stringify(value)}`);
}

/** Refuse top-level authoring keys before the map-to-list projection can discard them. */
function checkCapturedDataPipesShape(value: unknown, where: string): void {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    throw new SynthError(`${where}: expected an object with sources and consumers maps`);
  }
  for (const key of Object.keys(value)) {
    if (key !== "sources" && key !== "consumers") {
      throw new SynthError(
        `${where}.${key}: this field is not part of a captured data-pipes declaration`,
      );
    }
  }
}

/**
 * One parsed cron field: whether it is a wildcard, and the concrete values it allows
 * otherwise. The values are kept twice over, as a set and in ascending order, because the
 * walk below asks both "does this moment match" and "what is the next value from here"
 * hundreds of thousands of times for a schedule sitting on the floor.
 */
interface CronFieldMatch {
  wildcard: boolean;
  values: Set<number>;
  ascending: number[];
}

/** No constraint from this field: `*`, or `?` in one of the two day fields. */
function anyCronValue(): CronFieldMatch {
  return { wildcard: true, values: new Set(), ascending: [] };
}

/** The largest number Java's `Integer.parseInt` reads, and so the largest a cron field may hold. */
const CRON_MAX_NUMBER = 2147483647;

/**
 * Reads one number out of a cron field the way the host's parser does, or `undefined` when
 * the host would not read it at all.
 *
 * Spring's `BitsCronField` hands every number in an expression — a value, the far end of a
 * range, the increment after a slash — to `Integer.parseInt`, so a number past what Java
 * reads as a signed int makes the host refuse the whole expression. `Number()` reads
 * `2147483648` happily and hands back a step so large the walk treats it as "once, at the
 * start of the field", which is how `0 0/2147483648 * * * *` passed synth as an hourly
 * schedule and then failed at install.
 *
 * Digits only. `Integer.parseInt` does take a sign, but a field is split on `-` and `/`
 * before any number is read, so nothing signed ever reaches it: `+5` and `-5` are not
 * forms a field has.
 */
function parseCronNumber(text: string | undefined): number | undefined {
  if (text === undefined || !/^\d+$/.test(text)) return undefined;
  const value = Number(text);
  return value <= CRON_MAX_NUMBER ? value : undefined;
}

/**
 * Parses one whitespace-separated field of a six-field cron expression into the values
 * it allows, within `[min, max]`. Reads what Spring's `CronExpression` reads of the
 * digit-and-punctuation forms: a wildcard, a bare number, a well-formed range, a step
 * over either, and a comma-separated list of any of those.
 *
 * `undefined` means "cannot read this", and three of those cases are the point of the
 * function. A wildcard inside a range — `*-23` — is malformed, and Spring throws
 * `IllegalArgumentException` on it rather than treating it as anything; so does this. A
 * range that runs backwards is the same story, since Spring builds it through
 * `ValueRange.of(min, max)`. A number the host's own parser cannot read is the third, and
 * that one is `parseCronNumber`'s job. The forms Spring reads and this does not — a named
 * month or weekday, `L`, `W`, `#`, a macro like `@daily` — also come back `undefined`,
 * which refuses a schedule the host would in fact have accepted. That is the safe
 * direction to be wrong in: it costs an author a rewrite into digits, where the other
 * direction ships a watch the host refuses at install time.
 */
function parseCronField(field: string, min: number, max: number): CronFieldMatch | undefined {
  if (field === "*") return anyCronValue();
  const values = new Set<number>();
  for (const part of field.split(",")) {
    // A range starts at a number, never at a wildcard: `*` and `*/N` cover the whole
    // field, and there is no reading of `*-23` at all.
    const match = /^(?:(\*)|(\d+)(?:-(\d+))?)(?:\/(\d+))?$/.exec(part);
    if (!match) return undefined;
    const [, wholeField, startText, endText, stepText] = match;
    const step = stepText === undefined ? 1 : parseCronNumber(stepText);
    // A step of zero would step nowhere. Spring reads the increment and then walks the
    // field with it, so it has to be at least one.
    if (step === undefined || step < 1) return undefined;
    const start = wholeField !== undefined ? min : parseCronNumber(startText);
    if (start === undefined) return undefined;
    const end =
      endText !== undefined
        ? parseCronNumber(endText)
        : wholeField !== undefined || stepText !== undefined
          ? max
          : start;
    if (end === undefined) return undefined;
    if (start < min || start > max || end < min || end > max || end < start) return undefined;
    for (let value = start; value <= end; value += step) values.add(value);
  }
  return { wildcard: false, values, ascending: [...values].sort((a, b) => a - b) };
}

/**
 * One of the two day fields, where `?` is legal and means the same as `*`: no constraint
 * from this field. Everywhere else `?` is not a form the host reads, so it falls through
 * to the ordinary parse and comes back unreadable.
 */
function parseCronDayField(field: string, min: number, max: number): CronFieldMatch | undefined {
  return field === "?" ? anyCronValue() : parseCronField(field, min, max);
}

/** A parsed six-field cron expression, one matcher per field. */
interface ParsedCronSchedule {
  second: CronFieldMatch;
  minute: CronFieldMatch;
  hour: CronFieldMatch;
  dayOfMonth: CronFieldMatch;
  month: CronFieldMatch;
  dayOfWeek: CronFieldMatch;
}

/**
 * Parses a schedule string into its six fields, or `undefined` when it is not a
 * six-field cron expression this reads. Day-of-week's domain is 0 to 7 with both 0 and
 * 7 meaning Sunday, so a parsed 7 is folded into 0 here, once, rather than at every
 * comparison later.
 */
function parseCronSchedule(schedule: string): ParsedCronSchedule | undefined {
  const fields = schedule.trim().split(/\s+/);
  if (fields.length !== 6) return undefined;
  const [secondText, minuteText, hourText, domText, monthText, dowText] = fields as [
    string,
    string,
    string,
    string,
    string,
    string,
  ];
  const second = parseCronField(secondText, 0, 59);
  const minute = parseCronField(minuteText, 0, 59);
  const hour = parseCronField(hourText, 0, 23);
  const dayOfMonth = parseCronDayField(domText, 1, 31);
  const month = parseCronField(monthText, 1, 12);
  const dayOfWeek = parseCronDayField(dowText, 0, 7);
  if (!second || !minute || !hour || !dayOfMonth || !month || !dayOfWeek) return undefined;
  if (dayOfWeek.values.has(7)) {
    dayOfWeek.values.delete(7);
    dayOfWeek.values.add(0);
    dayOfWeek.ascending = [...dayOfWeek.values].sort((a, b) => a - b);
  }
  return { second, minute, hour, dayOfMonth, month, dayOfWeek };
}

/**
 * Whether the UTC calendar day at `epochMs` matches a schedule's month, day-of-month and
 * day-of-week fields.
 *
 * Both day fields have to match. Standard cron ors them when both are restricted — a day
 * that satisfies either one fires — but the host parses schedules with Spring's
 * `CronExpression`, which advances the date through each field in turn and so lands on
 * the intersection instead. The difference is not academic: `0 0 0 30 2 1` reads as
 * "February Mondays" under an or and never fires at all under Spring, because no
 * February has a 30th.
 *
 * A schedule that constrains none of the three matches every day, and saying so first
 * keeps the common case — a five-minute schedule and its two hundred thousand fires —
 * from building a calendar date it would not read.
 */
function cronDayMatches(epochMs: number, schedule: ParsedCronSchedule): boolean {
  if (schedule.month.wildcard && schedule.dayOfMonth.wildcard && schedule.dayOfWeek.wildcard) {
    return true;
  }
  const date = new Date(epochMs);
  if (!schedule.month.wildcard && !schedule.month.values.has(date.getUTCMonth() + 1)) return false;
  const domOk = schedule.dayOfMonth.wildcard || schedule.dayOfMonth.values.has(date.getUTCDate());
  const dowOk = schedule.dayOfWeek.wildcard || schedule.dayOfWeek.values.has(date.getUTCDay());
  return domOk && dowOk;
}

const CRON_MINUTE_MS = 60 * 1000;
const CRON_HOUR_MS = 60 * CRON_MINUTE_MS;
const CRON_DAY_MS = 24 * CRON_HOUR_MS;

/**
 * The window every watch schedule is walked across: two years and a few days, from 30
 * December 2023 to 2 January 2026.
 *
 * The host walks from a fixed, zone-free moment so that one declaration always reads the
 * same way wherever it is installed, and synth walks the same window in UTC — a
 * `LocalDateTime` carries no zone either, so no offset and no daylight saving shift can
 * make the two disagree.
 *
 * The odd-looking ends are the point. A pair of fast fires can straddle a year boundary,
 * and a window that stopped on a round date would miss it: `0 0,59 0,23 31,1 12,1 3,4`
 * fires at 23:59 on Wednesday 31 December 2025 and again a minute later on Thursday 1
 * January 2026, and `0 0,59 0,23 30,31 12 0,6` does the same across the start of the
 * window. Starting a day early and ending a day late puts both pairs inside it.
 */
const WATCH_SCHEDULE_WINDOW_START = Date.UTC(2023, 11, 30, 0, 0, 0);
const WATCH_SCHEDULE_WINDOW_END = Date.UTC(2026, 0, 2, 0, 0, 0);

/** A watch may run no more often than this. */
const WATCH_SCHEDULE_FLOOR_MS = 5 * 60_000;

/**
 * The most fires one walk will look at: one per floor-length slice of the window, plus the
 * first fire at or after the far end.
 *
 * A schedule that keeps to the floor cannot fit more than this many fires in the window, so
 * this is not a limit any legal schedule meets: a schedule firing every five minutes walks
 * exactly this many and is kept. It is the second lock on the walk's cost, behind refusing at the first gap
 * under the floor: whatever a future edit does to the gap check, the walk still stops.
 */
export const WATCH_SCHEDULE_FIRE_CAP =
  Math.ceil((WATCH_SCHEDULE_WINDOW_END - WATCH_SCHEDULE_WINDOW_START) / WATCH_SCHEDULE_FLOOR_MS) +
  1;

/**
 * One complete Gregorian calendar cycle. Numeric cron fields have no year component, so
 * their month, day-of-month and weekday matches repeat after these 146,097 days. Searching
 * a whole cycle therefore either finds the same successor Spring does or proves that this
 * expression has no later fire; it is a bound on work, not a shorter schedule horizon.
 */
const CRON_GREGORIAN_CYCLE_MS = 146_097 * CRON_DAY_MS;

/** The smallest value at or after `from` this field allows, or `undefined` when it has none. */
function nextAllowedCronValue(
  field: CronFieldMatch,
  from: number,
  max: number,
): number | undefined {
  if (field.wildcard) return from <= max ? from : undefined;
  for (const value of field.ascending) {
    if (value >= from) return value;
  }
  return undefined;
}

/**
 * The first moment strictly after `afterMs` that the schedule fires, or `undefined` when
 * there is none at or before `deadlineMs`.
 *
 * A jump rather than a scan: a field that does not match moves the cursor to the next
 * moment that could, so a five-minute schedule costs two or three steps per fire instead
 * of the three hundred seconds between them. Everything is UTC, matching the host's
 * zone-free reference.
 */
function nextCronFire(
  schedule: ParsedCronSchedule,
  afterMs: number,
  deadlineMs: number,
): number | undefined {
  let cursor = afterMs + 1000;
  while (cursor <= deadlineMs) {
    const dayStart = Math.floor(cursor / CRON_DAY_MS) * CRON_DAY_MS;
    if (!cronDayMatches(dayStart, schedule)) {
      cursor = dayStart + CRON_DAY_MS;
      continue;
    }
    const timeOfDay = cursor - dayStart;
    const hour = Math.floor(timeOfDay / CRON_HOUR_MS);
    const nextHour = nextAllowedCronValue(schedule.hour, hour, 23);
    if (nextHour === undefined) {
      cursor = dayStart + CRON_DAY_MS;
      continue;
    }
    if (nextHour > hour) {
      cursor = dayStart + nextHour * CRON_HOUR_MS;
      continue;
    }
    const minute = Math.floor((timeOfDay % CRON_HOUR_MS) / CRON_MINUTE_MS);
    const nextMinute = nextAllowedCronValue(schedule.minute, minute, 59);
    if (nextMinute === undefined) {
      cursor = dayStart + (hour + 1) * CRON_HOUR_MS;
      continue;
    }
    if (nextMinute > minute) {
      cursor = dayStart + hour * CRON_HOUR_MS + nextMinute * CRON_MINUTE_MS;
      continue;
    }
    const second = Math.floor((timeOfDay % CRON_MINUTE_MS) / 1000);
    const nextSecond = nextAllowedCronValue(schedule.second, second, 59);
    if (nextSecond === undefined) {
      cursor = dayStart + hour * CRON_HOUR_MS + (minute + 1) * CRON_MINUTE_MS;
      continue;
    }
    const fire = dayStart + hour * CRON_HOUR_MS + minute * CRON_MINUTE_MS + nextSecond * 1000;
    return fire <= deadlineMs ? fire : undefined;
  }
  return undefined;
}

/** What walking one schedule found. */
export interface WatchScheduleWalk {
  /** Why the host would refuse this schedule, or `undefined` when it stands. */
  refusal?: "unreadable" | "never-fires" | "too-frequent" | "too-many-fires";
  /**
   * How many fires the walk looked at, which is also how many next-fire searches it ran
   * (bar the one at the end that finds nothing). Reported so a test can hold the walk to
   * its bound: an every-second schedule has to be refused after two fires, not after the
   * sixty-three million the window holds.
   */
  fires: number;
}

/**
 * Walks a watch's schedule across the window and reports what the host would make of it.
 *
 * The walk mirrors the host's, step for step, because a schedule the two read differently
 * is either a watch that installs and then refuses to run or one synth turns away for no
 * reason:
 *
 * - the first fire is the first at or after the start of the window, so a schedule that
 *   fires exactly on the reference is paired with the one after it rather than skipped;
 * - every consecutive gap is measured, including the gap whose later fire is the first one
 *   at or after the far end — the walk stops after measuring that gap, not before, since
 *   that is exactly where a fast pair straddling the boundary would hide;
 * - the first gap under the floor refuses the schedule, so a walk never runs longer than
 *   the schedule deserves;
 * - a schedule with no fire anywhere in the window is refused rather than assumed safe: a
 *   cadence the host cannot watch is a cadence nobody has checked.
 */
export function walkWatchSchedule(schedule: string): WatchScheduleWalk {
  const parsed = parseCronSchedule(schedule);
  if (!parsed) return { refusal: "unreadable", fires: 0 };
  const first = nextCronFire(parsed, WATCH_SCHEDULE_WINDOW_START - 1000, WATCH_SCHEDULE_WINDOW_END);
  if (first === undefined) return { refusal: "never-fires", fires: 0 };
  let fires = 1;
  let current = first;
  while (current < WATCH_SCHEDULE_WINDOW_END) {
    // Checked before the next search rather than after it, so the count bounds the work
    // the walk does and not just what it reports.
    if (fires > WATCH_SCHEDULE_FIRE_CAP) return { refusal: "too-many-fires", fires };
    const next = nextCronFire(parsed, current, current + CRON_GREGORIAN_CYCLE_MS);
    if (next === undefined) break;
    fires += 1;
    if (next - current < WATCH_SCHEDULE_FLOOR_MS) return { refusal: "too-frequent", fires };
    current = next;
  }
  return { fires };
}

/**
 * Checks a watch's schedule the way `CapturedWatchManifest.kt` does: a six-field cron
 * expression the host can walk and prove never fires faster than once every five minutes.
 * The floor is checked on real fire times rather than on how the expression looks, because
 * a cron expression can hide a fast run inside a slow-looking one (`0 0,1 * * * *` reads as
 * hourly and fires twice a minute apart).
 *
 * Every way of failing that walk is the same refusal on the host — it cannot prove the
 * floor, so it turns the watch away — and each gets its own sentence here, because this is
 * the last place an author sees which of them it was.
 */
function checkWatchSchedule(schedule: string, where: string): void {
  const walk = walkWatchSchedule(schedule);
  if (walk.refusal === undefined) return;
  if (walk.refusal === "unreadable") {
    throw new SynthError(
      `${where}: needs a six-field cron expression (second minute hour day-of-month month ` +
        `day-of-week) built from digits, "*", "-", ",", "/" and "?" in the two day fields, with ` +
        `every number in it one the host's own parser reads — digits only, no sign, nothing past ` +
        `${CRON_MAX_NUMBER}, and a step of at least 1. The host cannot walk ` +
        `${JSON.stringify(schedule)} at all, so it refuses the watch rather than assume it keeps ` +
        `to the five-minute floor. Every five minutes is "0 */5 * * * *".`,
    );
  }
  if (walk.refusal === "never-fires") {
    throw new SynthError(
      `${where}: ${JSON.stringify(schedule)} never fires in the two years the host walks it ` +
        `across. It requires the day-of-month and day-of-week fields to both match when both are ` +
        `restricted — Spring's CronExpression ands them where standard cron ors them — so a date ` +
        `like the 30th of February never comes round. A cadence the host cannot watch is one ` +
        `nobody has checked, so it refuses the watch rather than assume it is safe.`,
    );
  }
  if (walk.refusal === "too-frequent") {
    throw new SynthError(
      `${where}: ${JSON.stringify(schedule)} can fire less than five minutes apart. A watch may ` +
        `run no more often than once every five minutes.`,
    );
  }
  throw new SynthError(
    `${where}: ${JSON.stringify(schedule)} fires more than ${WATCH_SCHEDULE_FIRE_CAP} times in ` +
      `the window the host walks, which nothing keeping to the five-minute floor can do. The walk ` +
      `stops there rather than run on, and the watch is refused.`,
  );
}

/**
 * A type method calls `namespace.verb` through the gateway. The namespace can be a
 * vendored API, and then the verb has to be one the allowlist admits — but it can also
 * be the realm's own handlers, which register their namespace at load time and are not
 * declared in `apis`. So an unknown namespace passes: refusing it would make a
 * handler-backed method unwritable, which is a bigger loss than the check is a gain.
 */
function checkMethodTarget(gatewayTool: string, realm: Realm, where: string): void {
  const dot = gatewayTool.indexOf(".");
  if (dot === -1 || !realm.apis) return;
  if (!realm.apis[gatewayTool.slice(0, dot)]) return;
  checkApiReference(gatewayTool, realm.apis, where);
}

/**
 * Folds a name-keyed object into the list the loader reads, putting each key in as
 * `name`. Writing a producer's name twice is the kind of thing that drifts, so the key
 * is the single source of it, and an entry that states a conflicting `name` fails the
 * build. Silently picking a winner would hide the mistake.
 */
function named(entries: Record<string, unknown>, where: string): JsonValue[] {
  return Object.keys(entries)
    .sort()
    .map((key) => {
      const entry = entries[key] as Record<string, unknown>;
      const declared = entry.name;
      if (declared !== undefined && declared !== key) {
        throw new SynthError(
          `${where}.${key}: filed as "${key}" but declares name "${String(declared)}". Remove the name.`,
        );
      }
      return canonicalize({ ...entry, name: key }, `${where}.${key}`);
    });
}

/**
 * Engine-bound names a view's cypher may use without declaring them, and may not declare.
 * `userId` is bound by the host's scope rewriter, `agent` is the asking agent, and the rest
 * are directive namespaces and producer-template variables. Mirrors
 * `ViewSpec.RESERVED_PARAM_NAMES`.
 */
const VIEW_RESERVED_PARAMS = [
  "ai",
  "realm",
  "userId",
  "agent",
  "anchors",
  "exclude",
  "want",
  "hint",
];

/** What a value of each view parameter type looks like, in the host's own words. */
const VIEW_PARAM_FORM: Record<string, string> = {
  int: "a whole number, e.g. 25",
  number: "a number, e.g. 0.5",
  float: "a number, e.g. 0.5",
  double: "a number, e.g. 0.5",
  boolean: "true or false",
  date: "an ISO-8601 calendar date, e.g. 2026-07-01",
};

/** A decimal or hex floating point literal as Kotlin's `toDoubleOrNull` reads one. */
const JVM_DOUBLE =
  /^[+-]?(?:NaN|Infinity|(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?|0[xX](?:[0-9a-fA-F]+\.?[0-9a-fA-F]*|\.[0-9a-fA-F]+)[pP][+-]?\d+)[fFdD]?$/;

const LONG_MIN = -(2n ** 63n);
const LONG_MAX = 2n ** 63n - 1n;

/** True for a date `LocalDate.parse` takes: ISO year, month and day, and a real day. */
function isIsoDate(text: string): boolean {
  const match = /^(\d{4}|-\d{4,9}|\+\d{5,9})-(\d{2})-(\d{2})$/.exec(text);
  if (match === null) return false;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (month < 1 || month > 12 || day < 1) return false;
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const days = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1] as number;
  return day <= days;
}

/** The value of a hex floating point literal such as `0x1.8p1`, which `Number` cannot read. */
function hexDouble(text: string): number {
  const match = /^([+-]?)0[xX]([0-9a-fA-F]*)\.?([0-9a-fA-F]*)[pP]([+-]?\d+)$/.exec(text);
  if (match === null) return Number.NaN;
  const [, sign, whole, fraction, exponent] = match as unknown as string[];
  const mantissa = Number.parseInt(`${whole}${fraction}` || "0", 16);
  const value = mantissa * 2 ** (Number(exponent) - 4 * (fraction as string).length);
  return sign === "-" ? -value : value;
}

/**
 * A view parameter value as the host coerces it to `type`, or undefined when the host would
 * refuse it. Mirrors `ViewSpec.coerce`, which the host runs on every default and choice when
 * it reads the views file. Coerced values compare the way the host's `in` does, so a default
 * can be checked against the choices.
 */
function coerceViewParam(type: string, value: JsonValue): unknown {
  switch (type) {
    case "int": {
      if (typeof value === "number") return Number.isInteger(value) ? hostLong(value) : undefined;
      if (typeof value !== "string" || !/^[+-]?\d+$/.test(value.trim())) return undefined;
      const whole = BigInt(value.trim());
      return whole >= LONG_MIN && whole <= LONG_MAX ? whole : undefined;
    }
    case "number":
    case "float":
    case "double": {
      // A JavaScript -0 is written as the integer 0, which the host reads back as 0.0.
      if (typeof value === "number") return value === 0 ? 0 : value;
      if (typeof value !== "string" || !JVM_DOUBLE.test(value.trim())) return undefined;
      const text = value.trim().replace(/[fFdD]$/, "");
      return /^[+-]?0[xX]/.test(text) ? hexDouble(text) : Number(text);
    }
    case "boolean": {
      if (typeof value === "boolean") return value;
      if (typeof value !== "string") return undefined;
      const text = value.trim().toLowerCase();
      return text === "true" ? true : text === "false" ? false : undefined;
    }
    case "date":
      return typeof value === "string" && isIsoDate(value.trim()) ? value.trim() : undefined;
    default:
      return value === null ? undefined : hostString(value);
  }
}

/**
 * Whether the host reads a number synth writes as a Double rather than a whole number. The
 * YAML is written with JavaScript's own number form, so a fraction or anything big enough to
 * print with an exponent (1e21 and up) comes back as a Double, and everything else as an
 * Integer, Long or BigInteger.
 */
function hostReadsDouble(value: number): boolean {
  return !Number.isInteger(value) || String(value).includes("e");
}

/**
 * A whole number the way the host's `int` coercion ends up with it: `toLong()` on whatever
 * it read. A BigInteger keeps its low 64 bits and a Double clamps to the Long range, which is
 * nonsense for a parameter but is what the host compares.
 */
function hostLong(value: number): bigint {
  if (hostReadsDouble(value)) return value < 0 ? LONG_MIN : LONG_MAX;
  // From the digits the YAML carries, which past 2^53 are not the double's exact value.
  return BigInt.asIntN(64, BigInt(String(value)));
}

/**
 * A Double printed the way the JVM's `Double.toString` prints it: plain between 0.001 and
 * ten million, scientific (`1.0E-4`, `1.23456785E7`) outside that, and always with a digit
 * after the point. The digits are the shortest that read back as the same number, which
 * JavaScript already finds, except that the JVM never settles for one digit: where one would
 * do it picks the closest two-digit form, which is why the smallest Double prints as `4.9E-324`.
 */
function jvmDoubleString(value: number): string {
  if (value === 0) return Object.is(value, -0) ? "-0.0" : "0.0";
  const sign = value < 0 ? "-" : "";
  const magnitude = Math.abs(value);
  const shortest = magnitude.toExponential();
  const two = magnitude.toExponential(1);
  const chosen = /^\de/.test(shortest) && Number(two) === magnitude ? two : shortest;
  const [mantissa = "", exponentText = "0"] = chosen.split("e");
  const digits = mantissa.replace(".", "");
  const exponent = Number(exponentText);
  if (magnitude >= 1e-3 && magnitude < 1e7) {
    if (exponent < 0) {
      return `${sign}0.${"0".repeat(-exponent - 1)}${digits.replace(/0+$/, "") || "0"}`;
    }
    const whole = digits.slice(0, exponent + 1).padEnd(exponent + 1, "0");
    const fraction = digits.slice(exponent + 1).replace(/0+$/, "");
    return `${sign}${whole}.${fraction || "0"}`;
  }
  const [lead = "", ...rest] = digits;
  const fraction = rest.join("").replace(/0+$/, "");
  return `${sign}${lead}.${fraction || "0"}E${exponent}`;
}

/**
 * A value the way the host turns it into a string parameter: Kotlin's `toString` on what
 * Jackson read out of the YAML. Lists print as `[1, 2]` and maps as `{a=1, b=2}`, with
 * strings inside them unquoted, so two values that differ as JSON can print the same here.
 */
function hostString(value: JsonValue): string {
  if (value === null) return "null";
  if (Array.isArray(value)) return `[${value.map(hostString).join(", ")}]`;
  if (typeof value === "object") {
    const entries = Object.entries(value).map(([key, item]) => `${key}=${hostString(item)}`);
    return `{${entries.join(", ")}}`;
  }
  if (typeof value === "number") {
    return hostReadsDouble(value) ? jvmDoubleString(value) : String(value);
  }
  return String(value);
}

/** A `$name` parameter reference in Cypher. */
const CYPHER_PARAM = /\$([A-Za-z_][A-Za-z0-9_]*)/g;

/**
 * The parameters a query refers to, ignoring anything inside a string literal, a
 * backquoted name or a comment, where a `$` is just a character.
 */
function cypherParams(cypher: string): string[] {
  const code = cypher.replace(
    /'(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*"|`[^`]*`|\/\/[^\n]*|\/\*[\s\S]*?\*\//g,
    " ",
  );
  return [...code.matchAll(CYPHER_PARAM)].map((match) => match[1] as string);
}

/** A cypher that returns one bare node variable, the way the host tells a node view apart. */
const SINGLE_NODE_RETURN =
  /\bRETURN\s+(?:DISTINCT\s+)?([A-Za-z_]\w*)\s*(?:\bLIMIT\b|\bORDER\b|\bSKIP\b|$)/is;

/**
 * The node label the host infers for a view that declares none, or undefined for a tabular
 * view. Mirrors `withInferredOutputLabel`: the first bare node variable a RETURN names, looked
 * up in the query. A trailing line break is dropped first because the JVM's `$` matches before
 * one and JavaScript's does not.
 */
function inferredOutputLabel(cypher: string): string | undefined {
  const body = cypher.replace(/(?:\r\n|[\n\r\u0085\u2028\u2029])$/, "");
  const returned = SINGLE_NODE_RETURN.exec(body)?.[1];
  if (returned === undefined) return undefined;
  return new RegExp(`\\(\\s*${returned}\\s*:\\s*([A-Za-z_]\\w*)`).exec(body)?.[1];
}

/**
 * Checks a view's parameter defaults and choices the way the host does when it reads them.
 * Every choice has to coerce to the parameter's type, and so does the default, which also has
 * to be one of the choices when there are any.
 */
function checkViewParamValues(params: Record<string, CapturedViewParamSpec>, where: string): void {
  for (const [param, spec] of Object.entries(params)) {
    const at = `${where}.params.${param}`;
    const refuse = (field: string, value: JsonValue | undefined): never => {
      const form = VIEW_PARAM_FORM[spec.type];
      throw new SynthError(
        `${at}.${field}: the host cannot coerce ${JSON.stringify(value)} to ${spec.type}` +
          `${form ? `. Pass ${form}` : ""}. The host refuses the view, and with it every view in ` +
          `the file.`,
      );
    };
    const choices = spec.choices?.map((choice, i) => {
      const coerced = coerceViewParam(spec.type, choice);
      return coerced === undefined ? refuse(`choices[${i}]`, choice) : coerced;
    });
    if (spec.default === undefined || spec.default === null) continue;
    const coerced = coerceViewParam(spec.type, spec.default);
    if (coerced === undefined) refuse("default", spec.default);
    if (choices !== undefined && !choices.some((choice) => Object.is(choice, coerced))) {
      const reads =
        typeof coerced === "string" &&
        typeof spec.default !== "string" &&
        coerced !== JSON.stringify(spec.default)
          ? ` (the host reads it as ${JSON.stringify(coerced)})`
          : "";
      throw new SynthError(
        `${at}.default: ${JSON.stringify(spec.default)}${reads} is not one of its choices. The ` +
          `host refuses the view, and with it every view in the file.`,
      );
    }
  }
}

/**
 * The reasons the host refuses a view that carries a data contract. A contract describes
 * the rows of a tabular view, so a materialized view or one that returns nodes cannot carry
 * one, and each of the contract's names has to say something.
 */
function checkViewDataContract(view: CapturedViewSpec, where: string): void {
  const contract = view.dataContract;
  if (contract === undefined) return;
  if (view.materialized === true) {
    throw new SynthError(
      `${where}.dataContract: a materialized view cannot carry a data contract. The host ` +
        `refuses the view, and with it every view in the file.`,
    );
  }
  const label = view.outputLabel ?? inferredOutputLabel(view.cypher);
  if (label !== undefined) {
    const why =
      view.outputLabel === undefined
        ? `its cypher returns a bare (:${label}) node, so the host reads it as a node view`
        : `it declares outputLabel "${label}", so it returns nodes`;
    throw new SynthError(
      `${where}.dataContract: ${why}. A contracted view has to be a tabular projection, like ` +
        `RETURN n.name AS name. The host refuses the view, and with it every view in the file.`,
    );
  }
  for (const field of ["id", "version", "object"] as const) {
    if (String(contract[field]).trim() === "") {
      throw new SynthError(`${where}.dataContract.${field}: must not be blank.`);
    }
  }
}

/**
 * Renders a captured realm's views as the one list the host reads out of `views/`, in the
 * order they were declared. The host takes a view whose cypher names an undeclared `$param`
 * and only fails when someone runs it, so synth refuses it here instead.
 */
function capturedViews(views: readonly CapturedViewSpec[]): JsonValue[] {
  const seen = new Map<string, number>();
  return views.map((view, i) => {
    const where = `$.views[${i}]`;
    const earlier = seen.get(view.name);
    if (earlier !== undefined) {
      throw new SynthError(
        `${where}.name: "${view.name}" is already the name of $.views[${earlier}]. The host keeps ` +
          `one view per name, so the other would silently disappear.`,
      );
    }
    seen.set(view.name, i);
    if (typeof view.cypher !== "string" || view.cypher.trim() === "") {
      throw new SynthError(`${where}.cypher: a view needs a query`);
    }
    const params = view.params ?? {};
    for (const [param, spec] of Object.entries(params)) {
      if (spec?.type === undefined) {
        throw new SynthError(
          `${where}.params.${param}: declare a type (string, int, number, boolean or date). The ` +
            `host coerces every supplied value to it.`,
        );
      }
      if (VIEW_RESERVED_PARAMS.includes(param)) {
        throw new SynthError(
          `${where}.params.${param}: "${param}" is reserved by the host (${VIEW_RESERVED_PARAMS.join(", ")}), ` +
            `which refuses the view over it.`,
        );
      }
    }
    if (view.materialized === true && Object.keys(params).length > 0) {
      throw new SynthError(
        `${where}.params: a materialized view is cached per user, not per argument, so the host ` +
          `refuses one that declares params.`,
      );
    }
    for (const param of new Set(cypherParams(view.cypher))) {
      if (Object.hasOwn(params, param) || VIEW_RESERVED_PARAMS.includes(param)) continue;
      throw new SynthError(
        `${where}.cypher: uses $${param}, which ${where}.params does not declare. Declare it with ` +
          `a type, and a default if callers may leave it out.`,
      );
    }
    const doc = canonicalize(view, where);
    checkWireShape(doc, VIEW_SPEC, where);
    // The written view, not the declared one: its map keys are sorted the way the YAML lists
    // them, and a map value prints its entries in that order on the host.
    const written = (doc as { params?: Record<string, CapturedViewParamSpec> }).params;
    checkViewParamValues(written ?? {}, where);
    checkViewDataContract(view, where);
    return doc;
  });
}
