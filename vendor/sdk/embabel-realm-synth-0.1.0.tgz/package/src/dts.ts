import type {
  CapturedApiSpec,
  CapturedGraphqlSpec,
  CapturedGraphqlVariableSpec,
  CapturedRealm,
  DependencyValueType,
  PropertySpec,
  Realm,
  TypeSpec,
} from "@embabel/realm-types";
import { SynthError } from "./canonical.ts";
import { declaredResponse, essence, type ResponseFormat, UNDECLARED_FORMAT } from "./responses.ts";

/**
 * The TypeScript spelling of one dependency method's argument or return type. `i64`
 * reads as `string`: the value can overflow what a `number` holds exactly (both are
 * IEEE doubles beyond 2^53), so the wire carries it as a decimal-digit string instead.
 * `string` is text and reads as `string` too. `i32`, `f32` and `f64` all fit a `number`
 * safely.
 */
export function tsValueType(type: DependencyValueType): string {
  return type === "i64" || type === "string" ? "string" : "number";
}

/**
 * The shape the host actually hands a handler, written down in one place.
 *
 * Everything the three emitters generate is a claim about the object the wasm shim
 * builds at dispatch. When the claim and the object disagree, the author's code
 * typechecks and then fails at runtime, which is the worst way to find out about
 * anything. So the shape lives here as one record, all three emitters read it, and a
 * drift test checks the generated output against it.
 *
 * The shim is in another repository (the host, at `tooling/wasm-realm/shim.js`), so a test
 * in this one cannot open it on every machine. This record stands in for it: change
 * the shim, change this, and the drift test says which emitter you forgot. The shim
 * code it stands for, in outline:
 *
 *     var deps = buildDependencyContext(...)
 *     var context = {
 *       gateway: gateway,
 *       deps: deps,
 *       call: hostCall,
 *       writePropose: function (proposal) { return hostCall('write_propose', proposal) },
 *       log: function (message) { ... },
 *     }
 */
export const HOST_CONTEXT = {
  /**
   * The context member holding the realm's declared dependencies, one per declared
   * name — so a handler reaches a dependency as `ctx.deps.db`, not `ctx.db`.
   *
   * They sit in a container rather than directly on the context because the two sets
   * of names have different owners. A realm author picks the dependency names; the
   * host owns the built-in members and keeps adding to them, `log` and `gateway`
   * today and more later. Share one namespace and every new built-in is a chance to
   * break a realm that already chose that name. The container makes that collision
   * impossible by construction, instead of policing it with a list of reserved words
   * that goes stale the moment someone adds a built-in and forgets.
   */
  dependencyContainer: "deps",
  /**
   * What the host puts on the context itself, alongside the container. `call` is the
   * raw host call, which answers in place. The TypeScript emitter types it only for the
   * model call of a realm with the model capability; see MODEL_DECLARATIONS.
   */
  builtInMembers: ["call", "gateway", "log"],
  /**
   * What the shim also puts on every context, but only a captured realm's types declare,
   * because only a captured realm has a flow that uses it.
   */
  capturedMembers: ["writePropose"],
} as const;

/**
 * What a captured realm's context carries beyond the members above, and the wire names
 * behind it.
 *
 * A captured realm reaches the graph by proposing a write rather than performing one, and
 * that proposal is a document the host validates field by field. Left as
 * `ctx.call("write_propose", ...)` the guest gets no help at all: a misspelled field, a
 * reserved name or a five-deep object all compile and then come back as one refusal with
 * nothing named. So the captured surface declares the call as a member with the document's
 * own type, and this record is where the two spellings live.
 *
 * Only a captured realm gets it. A conventional realm has no proposal flow, and declaring
 * a member the host does not build for it would be the drift `host-context-drift.test.ts`
 * exists to catch. The wasm shim in the host builds `writePropose` on every context as
 * `call("write_propose", proposal)` with the name fixed, so it answers and fails exactly as
 * that call does.
 */
export const CAPTURED_HOST_CONTEXT = {
  /** The context member a captured handler proposes a write through. */
  writeProposalMember: "writePropose",
  /** The host-call name that member stands for, as `GatewayCapturedRealmHostCalls` reads it. */
  writeProposalCall: "write_propose",
  /**
   * The reserved argument key a write operation's request body travels under. The host reads
   * one arguments object per call and splits it: this key is the body, everything else is a
   * declared path or query parameter. An operation that declares a parameter of this name is
   * refused, so synth refuses it too rather than emit an argument type that cannot work.
   */
  requestBodyArgument: "body",
  /** The host call a realm with the model capability asks the owner's model through. */
  modelCall: "ai_complete",
} as const;

/**
 * The model call, typed for a realm that declares `capabilities: ["model"]`. The shim puts
 * the raw `call` on every context and it answers in place, so this is only a type over that
 * member: the request the host reads, the reply it sends, and a `call` signature that takes
 * exactly that request. The host refuses any other field, a role it does not know, more
 * than eight skills, a skill name outside 1 to 64 characters and a token budget that is not
 * a positive whole number. The last three are counts and lengths a type cannot hold, so they
 * are said in the comments.
 */
const MODEL_DECLARATIONS: string[] = [
  "/** Which of the owner's models answers: the cheapest, the everyday one, or the best. */",
  'export type ModelRole = "cheap" | "workhorse" | "best";',
  "",
  `/** What a handler sends the owner's model with \`ctx.call("${CAPTURED_HOST_CONTEXT.modelCall}", ...)\`. The host refuses any other field. */`,
  "export interface AiCompleteRequest {",
  "  /** What to ask. Not blank. */",
  "  prompt: string;",
  "  /** Which model answers. The owner's default when left out. */",
  "  role?: ModelRole;",
  "  /**",
  "   * Up to eight skill names, each 1 to 64 characters: this realm's own, bare or as",
  "   * `<realm>-<skill>`, or one the owner's world has.",
  "   */",
  "  skills?: readonly string[];",
  "  /** The most tokens the reply may run to. A positive whole number. */",
  "  maxOutputTokens?: number;",
  "}",
  "",
  "/** What the model sends back. */",
  "export interface AiCompleteReply {",
  "  /** The model's text, cut to the host's limit when it ran longer. */",
  "  text: string;",
  "  /** True when the host cut `text`. */",
  "  truncated: boolean;",
  "}",
  "",
];

/** The type names the model declarations claim, refused as realm type names in a realm that has them. */
const MODEL_FIXED_NAMES: readonly string[] = declaredNames(MODEL_DECLARATIONS);

/** Whether a realm declares the model capability, which is what gives it a typed model call. */
function hasModelCapability(realm: Realm): boolean {
  return (
    realm.execution === "captured" &&
    Array.isArray(realm.capabilities) &&
    realm.capabilities.includes("model")
  );
}

/**
 * The write-proposal document, written into the generated types so a handler can build one
 * without importing anything.
 *
 * This mirrors `WriteProposal` in `@embabel/realm-types` (`captured.ts`), which mirrors
 * `CapturedWriteProposal.kt`. The generated file imports nothing — a realm's handlers
 * compile against it alone, wherever it is written — so the declarations are repeated here
 * rather than referenced. `typed-host-calls.test.ts` compiles the two against each other in
 * both directions, so a change to one that the other misses fails the build rather than
 * quietly letting the emitted type drift away from the authored one.
 */
const WRITE_PROPOSAL_DECLARATIONS: string[] = [
  "/** How a proposed write reaches the graph: through a named, approved method, or as a plain field decoration. */",
  'export type WriteProposalKind = "method-write-back" | "decoration";',
  "",
  "/** Whether a proposed write stays in the owner's own storage or reaches something outside it. */",
  'export type WriteProposalEffect = "private-storage" | "external";',
  "",
  "/**",
  " * The alphabet, written out so a template literal can fix the first character of a name the",
  " * host's grammar pins. Only the first character: the rest of each grammar — letters and",
  " * digits, up to 64 of them — stays a refusal at dispatch.",
  " */",
  "type WriteProposalUpperLetter =",
  ...[..."ABCDEFGHIJKLMNOPQRSTUVWXYZ"].map(
    (letter, index, all) => `  | "${letter}"${index === all.length - 1 ? ";" : ""}`,
  ),
  "type WriteProposalLowerLetter = Lowercase<WriteProposalUpperLetter>;",
  "",
  "/** A node label, which the host reads as a type name: `Note`, never `note` or `com.foo.Note`. */",
  `export type WriteProposalLabel = \`\${WriteProposalUpperLetter}\${string}\`;`,
  "",
  "/** A write-back method name, which the host reads as a member name: `archive`, never `Archive`. */",
  `export type WriteProposalMethodName = \`\${WriteProposalLowerLetter}\${string}\`;`,
  "",
  "/** The record a proposed write targets: its label and its key. */",
  "export interface WriteProposalTarget {",
  "  label: WriteProposalLabel;",
  "  /** The record's own key. At most 2048 bytes of UTF-8. */",
  "  key: string;",
  "}",
  "",
  "/**",
  " * Field names a proposed write may never carry, at any depth: the host's own identity and",
  " * ownership fields, plus anything starting with an underscore. They are `never` rather than",
  " * absent so a separately declared object holding one is caught too, not just a fresh literal.",
  " */",
  "export type WriteProposalReservedFields = {",
  "  userId?: never;",
  "  worldId?: never;",
  "  workspaceId?: never;",
  "  visibleTo?: never;",
  "  owner?: never;",
  "  ownerId?: never;",
  "  labels?: never;",
  `} & { [name: \`_\${string}\`]: never };`,
  "",
  "/** A leaf a proposed write can carry. */",
  "type WriteProposalScalar = string | number | boolean | null;",
  "",
  "/**",
  " * The nesting cap, one type per level, because the host counts levels and refuses past four:",
  " * the `fields` object is level one, so three nested objects or arrays inside it are as deep as",
  " * a proposal goes.",
  " */",
  "type WriteProposalLevel4 =",
  "  | WriteProposalScalar",
  "  | WriteProposalScalar[]",
  "  | ({ [name: string]: WriteProposalScalar } & WriteProposalReservedFields);",
  "type WriteProposalLevel3 =",
  "  | WriteProposalScalar",
  "  | WriteProposalLevel4[]",
  "  | ({ [name: string]: WriteProposalLevel4 } & WriteProposalReservedFields);",
  "type WriteProposalLevel2 =",
  "  | WriteProposalScalar",
  "  | WriteProposalLevel3[]",
  "  | ({ [name: string]: WriteProposalLevel3 } & WriteProposalReservedFields);",
  "",
  "/**",
  " * What a proposed write actually sets: at least one field, at most 64 in any one object or",
  " * array, none of them reserved. The count is the part a type cannot say, so it stays a",
  " * refusal at dispatch.",
  " */",
  "export type WriteProposalFields = {",
  "  [name: string]: WriteProposalLevel2;",
  "} & WriteProposalReservedFields;",
  "",
  "/** Fields every proposed write carries, whichever kind it is. */",
  "interface WriteProposalBase {",
  "  /** The document version the host reads. There is one. */",
  "  version: 1;",
  "  target: WriteProposalTarget;",
  "  fields: WriteProposalFields;",
  "  effect: WriteProposalEffect;",
  "  /**",
  "   * The revision the guest believes the record is at, so the host can refuse a write built on",
  "   * a stale read. A whole number, never negative. Absent or null means don't check.",
  "   */",
  "  expectedRevision?: number | null;",
  "}",
  "",
  "/**",
  " * What a captured handler hands the host when it wants to write something back to the graph.",
  " * It is only a proposal: the host still validates it, shows it and confirms it, and nothing is",
  " * applied by proposing. The whole document is at most 65536 bytes of UTF-8.",
  " */",
  "export type WriteProposal =",
  "  | (WriteProposalBase & {",
  '      kind: "method-write-back";',
  "      /** The approved method the host calls on the record. */",
  "      method: WriteProposalMethodName;",
  "    })",
  "  | (WriteProposalBase & {",
  '      kind: "decoration";',
  "      /** A decoration sets fields directly, so naming a method is a compile error. */",
  "      method?: never;",
  "    });",
  "",
  "/**",
  " * What comes back when the host accepts a proposal: the id it filed it under. A refusal",
  " * arrives as a rejected promise carrying one fixed message, never as a value.",
  " */",
  "export interface WriteProposalResult {",
  "  proposalId: string;",
  "}",
  "",
];

/**
 * The type that makes "no field the declaration never mentioned" mean it, however the value
 * was built.
 *
 * TypeScript only refuses an undeclared field on an object literal written at the call
 * itself. Move that literal one line up into a `const` — which is what anyone does as soon as
 * the object gets long enough to name — and the same call compiles, and the host then refuses
 * it at dispatch with one message that names nothing. That is the failure this typing exists
 * to prevent, so a call whose document has an exact set of allowed fields takes its argument
 * through a generic instead of by plain type: the argument's own type comes back with every
 * declared key untouched and every other key turned into `never`, which no value satisfies.
 *
 * Emitted for a captured realm only, because that is where the two calls that use it live.
 */
/**
 * The journal calls every captured handler can make through `ctx.gateway.channel`, typed
 * with what the host returns: the receipt carries `receiptId`, and a batch receipt carries one
 * offset per event. These are the host calls as they are. The `ctx.publish` shortcut a channel
 * or consumer handler gets is a different member, and its `Receipt` names the id `id`.
 */
const HOST_CHANNEL_DECLARATIONS: string[] = [
  "/** One event for the journal. */",
  "export interface ChannelEventInput {",
  "  /** Stable across retries: a retry with the same id, stream and payload is the same event. */",
  "  eventId: string;",
  "  streamId: string;",
  "  /** An ISO instant. */",
  "  occurredAt: string;",
  "  payload: { [key: string]: unknown };",
  "}",
  "",
  "/** What `gateway.channel.publish` resolves to once the event is durably appended. */",
  "export interface ChannelPublishReceipt {",
  "  receiptId: string;",
  "  /** Where the event landed in the source's sequence. */",
  "  offset: number;",
  "  /** True when the journal already held this event and handed the first receipt back. */",
  "  replayed: boolean;",
  "}",
  "",
  "/** What `gateway.channel.publishBatch` resolves to: one offset per event, in order. */",
  "export interface ChannelBatchReceipt {",
  "  receiptId: string;",
  "  offsets: number[];",
  "  replayed: boolean;",
  "}",
  "",
  "/** The journal calls on `ctx.gateway.channel`. Each needs the matching source grant. */",
  "export interface HostChannelGateway {",
  "  /** Appends one event to one of this realm's sources. */",
  "  publish(event: ChannelEventInput & { source: string }): Promise<ChannelPublishReceipt>;",
  "  /**",
  "   * Appends a page of events and moves the source's cursor in one step. A mismatched",
  "   * `expectedPosition` refuses the batch. An empty event list may still move the cursor.",
  "   */",
  "  publishBatch(batch: {",
  "    source: string;",
  "    batchId: string;",
  "    expectedPosition: string | null;",
  "    nextPosition: string;",
  "    events: ChannelEventInput[];",
  "  }): Promise<ChannelBatchReceipt>;",
  "  /** Reads where a source's cursor stands. Null before the first batch. */",
  "  position(request: { source: string }): Promise<{ position: string | null }>;",
  "}",
  "",
];

const EXACT_ARGUMENT_DECLARATIONS: string[] = [
  "/**",
  " * The supplied type with every field the declaration does not have turned into `never`, so",
  " * an undeclared field is a compile error even when the value was built somewhere else",
  " * first: excess-property checking only ever looks at a literal written at the call.",
  " */",
  "type OnlyDeclaredFields<Declared, Supplied> = {",
  "  [Key in keyof Supplied]: Key extends keyof Declared",
  "    ? OnlyDeclaredFieldValue<NonNullable<Declared[Key]>, Supplied[Key]>",
  "    : never;",
  "};",
  "",
  "/**",
  " * One field's value, checked the same way a level further down when the declaration says",
  " * exactly which fields it has. A declaration that takes free-form keys — a proposal's",
  " * `fields`, a body the document left as any JSON object — takes whatever it always did, and",
  " * so does a scalar or an `unknown`. An array whose elements have a closed shape is checked",
  " * element by element the same way.",
  " */",
  // An optional or nullable array field's value is `Array<...> | undefined` (or `| null`), and
  // checking that whole union against `[readonly unknown[]]` in one step fails — a union only
  // extends something every member extends, and `undefined` is not an array, so the field fell
  // through unrecursed. `Supplied extends undefined` is a naked (distributive) check, so it
  // peels `undefined`/`null` off one union member at a time instead, and each remaining member
  // reaches the array (or object) branch below on its own, keeping the mapped array type
  // homomorphic — mapping over `keyof Supplied` only preserves an array's own shape when
  // `Supplied` is a concrete array type rather than still a union with `undefined` in it.
  "type OnlyDeclaredFieldValue<Declared, Supplied> = Supplied extends null | undefined",
  "  ? Supplied",
  "  : [Supplied] extends [object]",
  "    ? [Supplied] extends [readonly unknown[]]",
  "      ? {",
  "          [Index in keyof Supplied]: OnlyDeclaredFieldValue<",
  "            DeclaredArrayElement<Declared>,",
  "            Supplied[Index]",
  "          >;",
  "        }",
  "      : [keyof Declared] extends [never]",
  "        ? Supplied",
  "        : string extends keyof Declared",
  "          ? Supplied",
  "          : OnlyDeclaredFields<Declared, Supplied>",
  "    : Supplied;",
  "",
  "/**",
  " * The element type of a declared array field, so an array field's elements get checked one",
  " * level further down instead of passing through untouched. Falls back to `unknown` — which",
  " * lets the element through as-is — when the declaration itself says nothing about elements,",
  " * the same free-form fallback the field-level check already gives an untyped body.",
  " */",
  "type DeclaredArrayElement<Declared> = Declared extends readonly (infer Element)[]",
  "  ? Element",
  "  : unknown;",
  "",
];

/**
 * The handler surface a captured realm's channels bring with them: what arrives on a live
 * connection, what a handler can do with it, and what the journal gives back.
 *
 * Written out here rather than imported, like the write-proposal document above it, because
 * the generated file imports nothing — a realm's handlers compile against it alone. `stream`
 * and `headers` live in their own small interfaces instead of on `ChannelCtx` because they
 * only exist on one transport each: a webhook handler reaching for `stream` has to be a
 * compile error, and a member typed optional would let it through.
 */
const CHANNEL_CONTEXT_DECLARATIONS: string[] = [
  "/**",
  " * A frame the host raises about the connection itself rather than one the provider sent:",
  " * the channel came up, the declared keepalive ticked, or it went away for a reason worth",
  " * knowing.",
  " *",
  " * `open` is always a real socket opening, so a handler that has to authenticate does it",
  " * there every time, whatever it persisted in its cursor before. `keepalive` goes only to a",
  " * channel's `keepalive.handler`, and only while the socket is up. A close reason of",
  " * `guest` is the handler's own doing: it called `stream.close()` and the host is",
  " * reconnecting.",
  " */",
  "export type ControlFrame =",
  '  | { kind: "open" }',
  '  | { kind: "keepalive" }',
  '  | { kind: "close"; reason: "remote" | "rotation" | "budget" | "revoked" | "error" | "guest" };',
  "",
  "/**",
  " * What arrives on a channel: the provider's own text, or one of the host's control frames.",
  " *",
  " * Binary frames are dropped and counted this release, so nothing here is bytes.",
  " */",
  "export type Frame = string | ControlFrame;",
  "",
  "/** The keepalive tick on its own. Only a channel's `keepalive.handler` is ever handed one. */",
  'export type KeepaliveFrame = Extract<ControlFrame, { kind: "keepalive" }>;',
  "",
  "/**",
  " * Everything except the keepalive tick: the provider's own text, the open and the close.",
  " *",
  " * This is what a handler that is not its channel's `keepalive.handler` can ever be handed,",
  " * so a branch for the tick in one of those handlers is a compile error rather than dead",
  " * code waiting for a dispatch that never comes.",
  " */",
  "export type FrameWithoutKeepalive = Exclude<Frame, KeepaliveFrame>;",
  "",
  "/** A JSON value, written out here because the generated file imports nothing. */",
  "export type JsonValue = string | number | boolean | null | JsonValue[] | { [k: string]: JsonValue };",
  "",
  "/** An object whose every leaf is a JSON value. */",
  "export type JsonObject = { [k: string]: JsonValue };",
  "",
  "/**",
  " * What `ctx.publish` resolves to once an event is published. The host's receipt calls the id",
  " * `receiptId`, and the shim hands it on here as `id`; `ctx.gateway.channel.publish` returns",
  " * the host's receipt as it is.",
  " */",
  "export interface Receipt {",
  "  /** The receipt's id in the journal. */",
  "  id: string;",
  "  /** Where it landed in the source's sequence. */",
  "  offset: number;",
  "  /** True when the journal already held this key and handed the first receipt back. */",
  "  replayed: boolean;",
  "}",
  "",
  "/**",
  " * What a channel handler gets on top of the ordinary handler context: the transport",
  " * frame that caused dispatch, the cursor the host kept for it, and the way to publish",
  " * an event to the realm.",
  " *",
  " * `Sources` is the set of source names this realm declared, so publishing to a name nobody",
  " * declared is a compile error here instead of a refusal at dispatch. `F` is the set of",
  " * frames this particular handler can be dispatched, which is narrower than `Frame` for",
  " * every handler that does not serve all of its channel's roles.",
  " */",
  "export interface ChannelCtx<Sources extends string, F extends Frame = Frame>",
  "  extends HandlerContext {",
  "  /**",
  "   * What caused this dispatch: the websocket frame, the long-poll response body, or the",
  "   * webhook body. A channel handler is handed the same value as its first argument too, so",
  "   * read whichever reads better where you are.",
  "   */",
  "  frame: F;",
  "  /** The last sequence or offset a handler returned. Absent on a first open. */",
  "  cursor?: string;",
  "  /**",
  "   * Files an event under one of this realm's declared sources. The journal keys it by",
  "   * `(source, key)`, so a frame the host redelivers publishes to the same event and gets",
  "   * the original receipt back rather than writing a second one.",
  "   */",
  "  publish(",
  "    source: NoInfer<Sources>,",
  "    event: JsonObject,",
  "    key: string,",
  "    options?: { streamId?: string; occurredAt?: string },",
  "  ): Promise<Receipt>;",
  "}",
  "",
  "/** A journal delivery gives the consumer its published event as the context frame. */",
  'export interface ConsumerCtx<Sources extends string> extends Omit<ChannelCtx<Sources>, "frame"> {',
  "  /** The published JSON object, also passed as the consumer's first argument. */",
  "  frame: JsonObject;",
  "}",
  "",
  "/** A live socket, as far as a handler can act on it. Websocket channels only. */",
  "export interface StreamCtx {",
  "  stream: {",
  "    /** Sends one frame. The token placeholder is substituted on the way out. */",
  "    send(data: string): Promise<void>;",
  "    /**",
  "     * Asks the host to end this connection and reconnect through its normal policy, for",
  "     * when the provider has said the session is finished and only a fresh one will do.",
  "     *",
  "     * It is a request, not a promise of timing: the connection ends once the handler in",
  "     * flight returns. What arrives next is a `close` with the reason `guest`, and then an",
  "     * `open` to authenticate on again. Nothing about the credential or the cursor changes.",
  "     */",
  "    close(): Promise<void>;",
  "  };",
  "}",
  "",
  "/**",
  " * The headers of a request the host has already verified. On a webhook channel's handler,",
  " * and nowhere else: an unverified request is refused before a handler ever sees it.",
  " */",
  "export interface RequestCtx {",
  "  headers: Readonly<Record<string, string>>;",
  "}",
  "",
  "/** Why the host refused an assistant call: no grant for this consumer, or a sender not paired. */",
  'export type AssistantRefusalCode = "ASSISTANT_NOT_GRANTED" | "SENDER_NOT_PAIRED";',
  "",
  "/**",
  " * What an assistant call rejects with when the host refuses it. The code is on the error, so",
  " * a realm can answer with its own pairing hint. A refusal that names no reason has no code.",
  " */",
  "export interface AssistantRefusal extends Error {",
  "  code?: AssistantRefusalCode;",
  "}",
  "",
  "/**",
  " * The owner's assistant. Only a consumer that declared `assistant: true` carries this, and",
  " * the grant and the sender's pairing are checked on every call.",
  " */",
  "export interface AssistantCtx {",
  "  assistant: {",
  "    /**",
  "     * Asks the owner's assistant and resolves to its final message. A refusal rejects with an",
  "     * `AssistantRefusal` carrying `ASSISTANT_NOT_GRANTED` or `SENDER_NOT_PAIRED` as its code.",
  "     */",
  "    chat(text: string, thread: string): Promise<string>;",
  "  };",
  "}",
  "",
];

/** The type names a block of fixed declarations claims, read off the declarations themselves. */
function declaredNames(lines: readonly string[]): string[] {
  return lines.flatMap((line) => {
    const match = /^(?:export )?(?:interface|type) ([A-Za-z0-9_$]+)/.exec(line);
    return match?.[1] === undefined ? [] : [match[1]];
  });
}

/**
 * Every type name the fixed captured declarations claim, read off the declarations themselves
 * so the list cannot fall behind them.
 */
const CAPTURED_FIXED_NAMES: readonly string[] = declaredNames([
  ...WRITE_PROPOSAL_DECLARATIONS,
  ...EXACT_ARGUMENT_DECLARATIONS,
  ...HOST_CHANNEL_DECLARATIONS,
]);

/**
 * The names the channel declarations claim. Kept apart from `CAPTURED_FIXED_NAMES` because a
 * captured realm without channels never emits them, and refusing a domain type called `Frame`
 * in a realm that has no channel would be a rename asked for nothing.
 */
const CHANNEL_FIXED_NAMES: readonly string[] = declaredNames(CHANNEL_CONTEXT_DECLARATIONS);

/**
 * Refuses a captured realm whose own domain types are named after a declaration every
 * captured realm gets for free.
 *
 * A realm type called `WriteProposal` emits an interface of its own, and then the fixed type
 * alias of that name lands in the same file: TypeScript reports both as duplicate
 * identifiers and nothing in the realm compiles. Refusing here, naming both sides, is the
 * difference between a rename and an afternoon reading generated code.
 */
function checkCapturedFixedNames(realm: Realm): void {
  const model = hasModelCapability(realm);
  for (const name of Object.keys(realm.types ?? {}).sort()) {
    if (CAPTURED_FIXED_NAMES.includes(name)) {
      throw new SynthError(
        `$.types.${name}: "${name}" is also the name of a declaration every captured realm's ` +
          `generated types carry, and the two would collide in one file. Rename the realm type.`,
      );
    }
    if (model && MODEL_FIXED_NAMES.includes(name)) {
      throw new SynthError(
        `$.types.${name}: "${name}" is also the name of a declaration a realm with the model ` +
          `capability carries in its generated types, and the two would collide in one file. ` +
          `Rename the realm type.`,
      );
    }
  }
}

/** The three declaration names every realm's generated types carry, whether captured or conventional. */
const GENERATED_FIXED_NAMES: readonly string[] = ["RealmTypes", "HandlerContext", "Handlers"];

/**
 * Refuses a domain type named after a declaration the generator writes for free: one of the
 * three names above, or a namespace's own `<Base>Gateway` interface.
 *
 * TypeScript reports two declarations sharing one name as a duplicate identifier, with
 * nothing to say which side is the realm's own type and which is generated. Catching it
 * here instead names both, while there is still a rename to suggest.
 */
function checkGeneratedNameCollisions(
  typeNames: string[],
  gatewayNames: Map<string, string>,
  handlerNames: string[],
): void {
  const gatewayTypeNames = new Set([...gatewayNames.values()].map((base) => `${base}Gateway`));
  for (const name of typeNames) {
    if (GENERATED_FIXED_NAMES.includes(name)) {
      throw new SynthError(
        `$.types.${name}: "${name}" is also the name of a declaration every realm's generated ` +
          `types carry, and the two would collide in one file. Rename the domain type.`,
      );
    }
    if (gatewayTypeNames.has(name)) {
      throw new SynthError(
        `$.types.${name}: "${name}" is also the generated gateway interface for one of this ` +
          `realm's api namespaces, and the two would collide in one file. Rename the domain type.`,
      );
    }
  }
  const claims = new Map(typeNames.map((name) => [name, `$.types.${name}`]));
  for (const name of handlerNames) {
    const where = `$.handlers.${name}`;
    for (const symbol of [
      `${pascalCase(name)}Input`,
      `${pascalCase(name)}Output`,
      `${pascalCase(name)}Handler`,
    ]) {
      const claimedBy = claims.get(symbol);
      if (claimedBy !== undefined) {
        throw new SynthError(
          `${where}: generated symbol "${symbol}" collides with ${claimedBy}. Rename one of the declarations.`,
        );
      }
      claims.set(symbol, where);
    }
  }
}

/**
 * The module whose known bridge a dependency gets. A `sqlite` kind gets SQLite's whatever its
 * module is called, a dependency with no kind is looked up by its module, and any other kind
 * gets none, so its declared methods type it.
 */
export function bridgeModule(spec: { module: string; kind?: string }): string {
  if (spec.kind === undefined) return spec.module;
  return spec.kind === "sqlite" ? "sqlite3-wasi" : "";
}

/** A known dependency module's typed bridge surface. */
interface BridgeSpec {
  /** The exported type name the bridge interface gets. */
  typeName: string;
  /** Doc comment placed on the exported bridge interface. */
  doc: string;
  /** Member lines emitted inside the bridge interface, already indented one level. */
  members: string[];
}

/**
 * The bridge surface for every dependency module synth knows how to type today. A
 * module absent from this map still gets a context member, typed `unknown`: the real
 * surface is defined by the module's registry entry and arrives with the host
 * mechanism, so synth cannot type it in advance.
 */
const BRIDGES: Record<string, BridgeSpec> = {
  "sqlite3-wasi": {
    typeName: "SqliteBridge",
    doc: "The bridge to a mounted SQLite dependency. State is ephemeral unless the declaration set persistent. The realm owns its database entirely.",
    members: [
      `  exec(
    sql: string,
    params?: (string | number | null)[],
  ): Promise<Record<string, string | number | null>[]>;`,
    ],
  },
};

/**
 * Every string below comes from the realm definition, and a definition can put
 * anything in a description, a module id or a realm name. These two functions are
 * where that text gets made safe before it lands in generated TypeScript, so nobody
 * has to remember to escape it at each call site.
 */

/** Breaks up the two-character sequence that closes a block comment, so definition text can never end one early. */
function escapeBlockComment(text: string): string {
  return text.replace(/\*\//g, "* /");
}

/** Collapses newlines, so definition text can never break out of a single-line comment. */
function escapeLineComment(text: string): string {
  return text.replace(/[\r\n]+/g, " ");
}

/** The shape a name has when TypeScript can carry it bare, as an identifier or as a property name. */
const TS_IDENTIFIER = /^[A-Za-z_$][A-Za-z0-9_$]*$/;

/**
 * One member key, ready to be written into an interface body.
 *
 * A property name comes from the realm definition or from a handler's JSON Schema, and
 * both can carry any text at all: a key like `x: string; }` followed by a newline would
 * close the interface and start declarations of its own. A key shaped like an
 * identifier is written bare, and everything else is written as a quoted string
 * literal, which is what TypeScript reads a property name as. `JSON.stringify` does the
 * quoting: it escapes backslashes, quotes and every control character, and it escapes
 * lone surrogates too, so whatever the key carries lands as one inert key. The two line
 * separators get escaped here as well, because JSON leaves them bare and older
 * TypeScript parsers read them as line breaks.
 *
 * Reserved words are left alone. TypeScript accepts every one of them as a property
 * name, so `class` and `if` stay readable.
 */
function tsMemberKey(key: string): string {
  if (TS_IDENTIFIER.test(key)) return key;
  return JSON.stringify(key)
    .replace(/\u2028/g, "\\u2028")
    .replace(/\u2029/g, "\\u2029");
}

/**
 * Refuses a name that has to land as a TypeScript identifier, because quoting cannot
 * save it there.
 *
 * A member key can be quoted, and `tsMemberKey` quotes it. A type name cannot: it is
 * written after `interface` and referenced by other declarations, so anything that is
 * not an identifier would be source of its own. emit() checks these names as well, with
 * the definition path to blame. Checking again here covers a caller that reaches for
 * `emitHandlerTypes` on its own.
 */
function checkTsName(name: string, where: string, describe: string): void {
  if (!TS_IDENTIFIER.test(name)) {
    throw new SynthError(
      `${where}: "${escapeLineComment(name)}" is not a valid identifier for ${describe}`,
    );
  }
}

/**
 * The names a captured api entry may carry, taken from the host rather than from
 * TypeScript: `CapturedApiContract.kt` matches `[A-Za-z_][A-Za-z0-9_-]{0,63}` against a whole
 * name. Hyphens are in, dollar signs are out, and 64 characters is the ceiling — none of
 * which is what TypeScript would say about an identifier. So the two questions are kept
 * apart: this one decides whether the host would install the api at all, and
 * `gatewayTypeBase` makes whatever it accepts safe to write into generated TypeScript.
 */
const CAPTURED_API_NAMESPACE = /^[A-Za-z_][A-Za-z0-9_-]{0,63}$/;

/**
 * Refuses a captured api namespace the host itself would refuse — and nothing else.
 *
 * Stricter than the host is worse than useless: it refuses to generate types for an api the
 * host installs and dispatches happily, which leaves the author with no typed surface at all
 * for something that works. Looser than the host emits a namespace no call can ever reach.
 */
function checkCapturedApiName(name: unknown, where: string): void {
  if (typeof name !== "string" || !CAPTURED_API_NAMESPACE.test(name)) {
    throw new SynthError(
      `${where}: ${JSON.stringify(name)} is not a namespace the host reads. It has to match ` +
        `${CAPTURED_API_NAMESPACE.source} — a letter or underscore, then up to 63 letters, ` +
        `digits, underscores or hyphens.`,
    );
  }
}

/** A gateway member becomes an identifier in generated code, so every segment of an operation is checked against this. */
const OPERATION_SEGMENT = /^[A-Za-z_$][A-Za-z0-9_$]*$/;

/**
 * Refuses a gateway operation that cannot become the code both emitters write from it.
 *
 * An operation reads as "namespace.verb" or as a bare verb, and each half lands as an
 * identifier: a method on a gateway interface, and a property holding the namespace.
 * A definition can put anything in that string, and text carrying a newline or a
 * comment marker would land as source of its own. A third segment is refused too,
 * because only the first two reach the generated gateway and the rest would go missing
 * without a word.
 *
 * The Python emitter calls this as well, then adds its own checks: Python has a
 * narrower idea of an identifier than TypeScript does.
 */
export function checkGatewayOperation(operation: string, where: string): void {
  const segments = operation.split(".");
  if (segments.length > 2) {
    throw new SynthError(
      `${where}: an operation reads as "namespace.verb" or as a bare verb, and ${JSON.stringify(operation)} carries ${segments.length} segments`,
    );
  }
  for (const segment of segments) {
    if (!OPERATION_SEGMENT.test(segment)) {
      throw new SynthError(
        `${where}: ${JSON.stringify(segment)} is not a valid identifier for a generated gateway member`,
      );
    }
  }
}

/**
 * Generates the TypeScript a realm's handlers import.
 *
 * A realm already declares its domain types and the operations its producers call. The
 * handlers then re-describe the same shapes by hand, and nothing checks the two against
 * each other: a handler can return a field the type never declared and the mismatch only
 * shows up as missing data in the graph.
 *
 * This closes that: the definition is the single declaration, and the handlers import
 * from it. Rename a property and the handler stops compiling.
 *
 * `documents` carries a captured realm's vendored OpenAPI documents, already parsed, keyed
 * by the `apis` entry each was vendored for. They are what a write operation's request-body
 * type is derived from, and they are optional because the realm declaration alone does not
 * hold them: a caller with no document in hand still gets the whole surface, with the
 * arguments of a write operation left as the untyped escape hatch and a generated comment
 * saying why.
 */
export function emitHandlerTypes(
  realm: Realm,
  documents?: VendoredApiDocuments,
  skillDigests?: Readonly<Record<string, string>>,
): string {
  const out: string[] = [
    `// Generated from realm.ts by @embabel/realm-synth. Do not edit.`,
    `// Realm: ${escapeLineComment(realm.name)} (${escapeLineComment(realm.version)})`,
    "",
  ];

  const typeNames = Object.keys(realm.types ?? {}).sort();
  const handlerNames = Object.keys(realm.handlers ?? {}).sort();

  for (const name of typeNames) {
    checkTsName(name, `$.types.${name}`, "a generated type name");
    const spec = (realm.types as Record<string, TypeSpec>)[name] as TypeSpec;
    out.push(...emitInterface(name, spec), "");
  }

  if (typeNames.length > 0) {
    out.push("/** Every domain type this realm contributes, keyed by label. */");
    out.push("export interface RealmTypes {");
    for (const name of typeNames) out.push(`  ${name}: ${name};`);
    out.push("}", "");
  }

  const operations = gatewayOperations(realm);
  // emit() checks these too, with the definition path to blame. Checking again here
  // covers a caller that reaches for emitHandlerTypes on its own.
  for (const op of operations) checkGatewayOperation(op, `gateway operation ${JSON.stringify(op)}`);
  if (operations.length > 0) {
    out.push("/** The gateway operations this realm's producers call. */");
    out.push(`export type RealmOperation = ${operations.map((o) => `"${o}"`).join(" | ")};`);
    out.push("");
  }

  // Build the gateway type: DefaultGateway with namespace overlays. A namespace holds the
  // lines each of its members emits rather than just the member names, because a captured
  // realm's write operations arrive typed from the vendored document while every other
  // operation stays the untyped escape hatch it has always been.
  const namespaces = new Map<string, Map<string, string[]>>();
  const bare = new Set<string>();

  for (const op of operations) {
    if (op.includes(".")) {
      const [ns, name] = op.split(".", 2);
      if (!namespaces.has(ns)) namespaces.set(ns, new Map());
      (namespaces.get(ns) as Map<string, string[]>).set(name, [untypedGatewayMember(name)]);
    } else {
      bare.add(op);
    }
  }

  // Every namespace a captured realm's api entries declare, registered before anything is
  // named. The name each namespace's own declarations get has to be unique across the whole
  // file, and that cannot be decided one entry at a time.
  if (realm.execution === "captured") {
    checkCapturedFixedNames(realm);
    for (const [key, spec] of capturedApiEntries(realm)) {
      checkCapturedApiName(spec.name, `$.apis.${key}.name`);
      if (!namespaces.has(spec.name)) namespaces.set(spec.name, new Map());
    }
    if (realm.graphql !== undefined) {
      checkCapturedApiName(realm.graphql.name, "$.graphql.name");
      if (!namespaces.has(realm.graphql.name)) namespaces.set(realm.graphql.name, new Map());
    }
  }
  const gatewayNames = gatewayTypeBases(namespaces.keys());
  checkGeneratedNameCollisions(typeNames, gatewayNames, handlerNames);

  // A captured realm's api entries name their whole allowed surface up front, and the
  // vendored document says what a write actually takes, so those operations reach the
  // gateway typed. The declarations they refer to are pushed ahead of the interfaces using
  // them, and unlisted operations are not emitted at all: the allowlist is the surface.
  if (realm.execution === "captured") {
    out.push(...EXACT_ARGUMENT_DECLARATIONS);
    out.push(...HOST_CHANNEL_DECLARATIONS);
    out.push(...capturedApiTypes(realm, namespaces, gatewayNames, documents));
    if (realm.graphql !== undefined) graphqlMembers(realm.graphql, namespaces);
  }

  // Emit namespace interfaces and DefaultGateway
  for (const ns of [...namespaces.keys()].sort()) {
    // A namespace is an api entry's declared name, falling back to the key it is filed
    // under — the same rule emit.ts holds the gateway to, since the engine registers the
    // entry's name as the prefix. An entry that sets `name: null` contributes no
    // namespace and so matches nothing here.
    const apiSpec = Object.entries(realm.apis ?? {}).find(
      ([key, spec]) => (spec.name === null ? undefined : (spec.name ?? key)) === ns,
    )?.[1];
    if (apiSpec) out.push(...jsdoc(`Operations from ${apiSpec.url}.`));
    out.push(`interface ${gatewayNames.get(ns) as string}Gateway {`);
    const ops = namespaces.get(ns) as Map<string, string[]>;
    for (const op of [...ops.keys()].sort()) {
      out.push(...(ops.get(op) as string[]));
    }
    out.push("}");
    out.push("");
  }

  out.push("interface DefaultGateway {");
  for (const op of [...bare].sort()) {
    out.push(untypedGatewayMember(op));
  }
  out.push("  [namespace: string]: unknown;");
  out.push("}");
  out.push("");

  // Build the gateway type intersection
  let gatewayType =
    realm.execution === "captured"
      ? "DefaultGateway & { channel: HostChannelGateway }"
      : "DefaultGateway";
  if (namespaces.size > 0) {
    const overlays = [...namespaces.keys()]
      .sort()
      .map((ns) => `{ ${tsMemberKey(ns)}: ${gatewayNames.get(ns) as string}Gateway }`);
    gatewayType = `${gatewayType} & ${overlays.join(" & ")}`;
  }

  const dependencyEntries = Object.entries(realm.dependencies ?? {}).sort(([a], [b]) =>
    a < b ? -1 : a > b ? 1 : 0,
  );
  const usedBridges = new Set<string>();
  for (const [, spec] of dependencyEntries) {
    if (BRIDGES[bridgeModule(spec)]) usedBridges.add(bridgeModule(spec));
  }
  for (const moduleId of [...usedBridges].sort()) {
    const bridge = BRIDGES[moduleId] as BridgeSpec;
    out.push(...jsdoc(bridge.doc), `export interface ${bridge.typeName} {`);
    for (const member of bridge.members) out.push(member);
    out.push("}", "");
  }

  // A dependency outside the built-in BRIDGES map still gets a real, typed bridge when
  // the realm declares the methods it calls on it: the operator's allowlist, not this
  // repository, owns the module's actual surface, so the only surface synth can type in
  // advance is exactly what the realm says it uses. One interface per dependency key,
  // not per module, because two declarations of the same module can each call a
  // different subset of it.
  const declaredBridgeNames = new Set<string>();
  for (const [key, spec] of dependencyEntries) {
    if (BRIDGES[bridgeModule(spec)] || !spec.methods || Object.keys(spec.methods).length === 0)
      continue;
    const where = `$.dependencies.${key}.methods`;
    const typeName = `${pascalCase(key)}Bridge`;
    checkTsName(typeName, where, "a generated dependency bridge name");
    if (declaredBridgeNames.has(typeName)) {
      throw new SynthError(
        `${where}: the generated bridge name "${typeName}" collides with another dependency's bridge`,
      );
    }
    declaredBridgeNames.add(typeName);
    out.push(
      ...jsdoc(
        `The bridge to the "${spec.module}" dependency, typed from exactly the methods this realm declares it calls.`,
      ),
      `export interface ${typeName} {`,
    );
    for (const methodName of Object.keys(spec.methods).sort()) {
      const methodWhere = `${where}.${methodName}`;
      checkTsName(methodName, methodWhere, "a generated bridge method name");
      const method = spec.methods[methodName];
      const args = (method?.args ?? []).map((argType, i) => `arg${i}: ${tsValueType(argType)}`);
      const result = tsValueType(method?.returns as DependencyValueType);
      // One batch entry is what one call sends: the value itself for a single argument,
      // otherwise the arguments as a positional array.
      const entry =
        method?.args?.length === 1
          ? tsValueType(method.args[0] as DependencyValueType)
          : `(readonly [${args.join(", ")}])`;
      out.push(
        `  ${methodName}: {`,
        `    (${args.join(", ")}): Promise<${result}>;`,
        ...jsdoc(
          [
            "Runs many calls at once on the host and resolves to one result per entry, in the",
            "order given. Each entry is one call's arguments: the value itself when the method",
            "takes one, otherwise an array of them. The host takes 1 to 256 entries.",
          ].join("\n"),
          "    ",
        ),
        `    batch(calls: readonly ${entry}[]): Promise<${result}[]>;`,
        "  };",
      );
    }
    out.push("}", "");
  }

  if (realm.execution === "captured" && realm.skills !== undefined && realm.skills.length > 0) {
    out.push(...skillDigestConstant(realm.skills, skillDigests), "");
  }

  // The write-proposal document goes in ahead of the context that takes one, and only for a
  // captured realm: a conventional realm has no proposal flow, so nothing there would refer
  // to these declarations.
  if (realm.execution === "captured") out.push(...WRITE_PROPOSAL_DECLARATIONS);
  if (hasModelCapability(realm)) out.push(...MODEL_DECLARATIONS);

  out.push(
    "/** What the host passes a handler as its second argument. */",
    "export interface HandlerContext {",
    "  /** Writes a line to the host log, attributed to this realm. */",
    "  log(message: string): void;",
    "  /**",
    "   * Calls out through the host. Credentials stay host-side: the guest never sees",
    "   * an API key, and the host injects it on the way out.",
    "   */",
    `  gateway: ${gatewayType};`,
  );
  if (realm.execution === "captured") {
    out.push(
      ...jsdoc(
        [
          "Proposes a write back to the graph. This hands the host a description of the write and",
          "nothing more: the host validates it, shows it for confirmation, and only then applies",
          "anything, so a resolved promise means the proposal was filed under the id it carries,",
          "not that the write happened.",
          "",
          `The host reads it as the \`${CAPTURED_HOST_CONTEXT.writeProposalCall}\` call. A refused proposal — a reserved field`,
          "name, an object nested too deep, a document over 65536 bytes — comes back as a rejected",
          "promise carrying one fixed message that names nothing, which is why as much of the",
          "document as a type can hold is checked here instead. That includes the field list being",
          "exact: a field the document does not declare is a compile error even when the proposal",
          "was built as a value first, which is what the generic here is for.",
        ].join("\n"),
        "  ",
      ),
      `  ${CAPTURED_HOST_CONTEXT.writeProposalMember}<Proposal extends WriteProposal>(`,
      "    proposal: Proposal & OnlyDeclaredFields<WriteProposal, Proposal>,",
      "  ): Promise<WriteProposalResult>;",
    );
  }
  if (hasModelCapability(realm)) {
    out.push(
      ...jsdoc(
        [
          "Asks the owner's model, once the owner has granted this realm the model. It answers in",
          "place, so the reply is there without awaiting. A refusal is thrown as an Error whose",
          "`code` says why: MODEL_NOT_GRANTED, MODEL_SKILL_UNKNOWN, MODEL_CALL_BUDGET,",
          "MODEL_DAILY_BUDGET or MODEL_PROMPT_TOO_LARGE. A request the host cannot read is",
          "refused with no code. A field the request does not declare is a compile error even",
          "when the request was built as a value first, which is what the generic is for.",
        ].join("\n"),
        "  ",
      ),
      "  call<Request extends AiCompleteRequest>(",
      `    tool: "${CAPTURED_HOST_CONTEXT.modelCall}",`,
      "    request: Request & OnlyDeclaredFields<AiCompleteRequest, Request>,",
      "  ): AiCompleteReply;",
    );
  }
  // Dependencies go inside a container rather than straight onto the context, because
  // the author names them and the host names everything else here. See HOST_CONTEXT
  // for why that separation has to be structural, and note that a realm declaring no
  // dependencies emits no container at all, so its types are unchanged.
  if (dependencyEntries.length > 0) {
    out.push(
      ...jsdoc(
        "The dependencies this realm declared, each under the name it was declared with. They live in their own container so an author's chosen name can never collide with a context member the host adds later.",
        "  ",
      ),
      `  ${HOST_CONTEXT.dependencyContainer}: {`,
    );
    for (const [key, spec] of dependencyEntries) {
      const bridge = BRIDGES[bridgeModule(spec)];
      if (bridge) {
        out.push(`    ${tsMemberKey(key)}: ${bridge.typeName};`);
      } else if (spec.methods && Object.keys(spec.methods).length > 0) {
        out.push(`    ${tsMemberKey(key)}: ${pascalCase(key)}Bridge;`);
      } else {
        out.push(
          ...jsdoc(
            `The bridge surface for "${spec.module}" is defined by the module's registry entry and arrives with the host mechanism.`,
            "    ",
          ),
          `    ${tsMemberKey(key)}: unknown;`,
        );
      }
    }
    out.push("  };");
  }
  out.push(
    "}",
    "",
    "/** A verb this realm exposes. */",
    "export type Handler<Input, Output> = (input: Input, ctx: HandlerContext) => Promise<Output>;",
    "",
  );

  // Emit handler types from the handlers block if present
  const handlers = realm.handlers ?? {};

  if (handlerNames.length > 0) {
    for (const name of handlerNames) {
      checkTsName(name, `$.handlers.${name}`, "a generated verb name");
    }

    // Generate Input/Output types for each handler
    for (const name of handlerNames) {
      const spec = handlers[name];
      if (!spec) continue;
      const inputTypeName = `${pascalCase(name)}Input`;
      const outputTypeName = `${pascalCase(name)}Output`;

      // Generate input type. Only an object literal can be an interface body; a
      // scalar or array schema becomes a type alias.
      const inputType = jsonSchemaToTsType(spec.input);
      if (inputType !== "Record<string, never>" && inputType.startsWith("{")) {
        out.push(...jsdoc(`Input for the ${name} handler.`));
        out.push(`export interface ${inputTypeName} ${inputType}`);
      } else if (inputType !== "Record<string, never>") {
        out.push(...jsdoc(`Input for the ${name} handler.`));
        out.push(`export type ${inputTypeName} = ${inputType};`);
      } else {
        out.push(`export type ${inputTypeName} = Record<string, never>;`);
      }
      out.push("");

      // Generate output type
      const outputType = jsonSchemaToTsType(spec.output, "unknown");
      out.push(`export type ${outputTypeName} = ${outputType};`);
      out.push("");
    }

    // Generate Handlers interface
    out.push(
      "/** Every handler this realm exposes, keyed by name and typed by input/output. */",
      "export interface Handlers {",
    );
    for (const name of handlerNames) {
      const inputTypeName = `${pascalCase(name)}Input`;
      const outputTypeName = `${pascalCase(name)}Output`;
      out.push(`  ${tsMemberKey(name)}: Handler<${inputTypeName}, ${outputTypeName}>;`);
    }
    out.push("}");
    out.push("");

    // Generate named type aliases for each handler
    for (const name of handlerNames) {
      const inputTypeName = `${pascalCase(name)}Input`;
      const outputTypeName = `${pascalCase(name)}Output`;
      const aliasName = `${pascalCase(name)}Handler`;
      out.push(`export type ${aliasName} = Handler<${inputTypeName}, ${outputTypeName}>;`);
    }
    out.push("");
  }

  out.push(...emitChannelContext(realm, typeNames, handlerNames));

  return out.join("\n");
}

/**
 * The verb half of a handler reference: `discord.gateway` is the `gateway` verb in the
 * `discord` namespace. The namespace belongs to the whole realm, so repeating it in every
 * generated alias name would say nothing — the verb is what tells two handlers apart.
 */
function handlerVerb(reference: string): string {
  const dot = reference.indexOf(".");
  return dot === -1 ? reference : reference.slice(dot + 1);
}

/** One string, quoted and escaped so it is safe to write as a literal type. */
function tsStringLiteral(value: string): string {
  return JSON.stringify(value)
    .replace(/\u2028/g, "\\u2028")
    .replace(/\u2029/g, "\\u2029");
}

/**
 * Where the formatter wraps a line. The repository sets biome's line width to 100, and a
 * generated `.d.ts` is committed beside hand-written code and checked with it.
 */
const LINE_WIDTH = 100;

/**
 * One shape in a handler's `ctx`: a plain name like `StreamCtx`, or `ChannelCtx` with the
 * realm's source names as its first type argument and this handler's frame type as its
 * second.
 *
 * The sources are kept apart as a list rather than pre-joined into one string because the
 * formatter breaks a union between its alternatives, and the wrapping below has to be able
 * to do the same.
 */
type CtxShape =
  | string
  | { readonly name: string; readonly union: readonly string[]; readonly frame?: string };

/** A shape as it reads with nothing wrapped. */
function flatShape(shape: CtxShape): string {
  if (typeof shape === "string") return shape;
  const args = shape.frame === undefined ? "" : `, ${shape.frame}`;
  return `${shape.name}<${shape.union.join(" | ")}${args}>`;
}

/**
 * The `ctx` parameter, wrapped exactly where the formatter would wrap it.
 *
 * Three places can break, innermost last, and each only breaks because the one outside it
 * did not fit: the intersection puts its first shape after `ctx: ` and every later shape on
 * its own line ending in `&`; a `ChannelCtx` that is still too wide opens its angle bracket
 * and drops the whole union onto one indented line; a union too wide even for that goes one
 * alternative per line behind a leading `|`. A single type argument has nowhere to break, so
 * an enormous lone source name stays put — and so does the formatter.
 */
function ctxParameterLines(shapes: readonly CtxShape[]): string[] {
  const oneLine = `  ctx: ${shapes.map(flatShape).join(" & ")},`;
  if (oneLine.length <= LINE_WIDTH) return [oneLine];
  const lines: string[] = [];
  shapes.forEach((shape, index) => {
    const indent = index === 0 ? 2 : 4;
    const opening = index === 0 ? "  ctx: " : "    ";
    const closing = index === shapes.length - 1 ? "," : " &";
    const flat = `${opening}${flatShape(shape)}${closing}`;
    const breakable =
      typeof shape !== "string" && (shape.union.length > 1 || shape.frame !== undefined);
    if (flat.length <= LINE_WIDTH || typeof shape === "string" || !breakable) {
      lines.push(flat);
      return;
    }
    const inner = " ".repeat(indent + 2);
    // A second type argument turns the sources into one entry in a list rather than the
    // whole of it, so whichever line the union ends on picks up the comma before it.
    const comma = shape.frame === undefined ? "" : ",";
    const union = `${inner}${shape.union.join(" | ")}${comma}`;
    lines.push(`${opening}${shape.name}<`);
    if (union.length <= LINE_WIDTH) lines.push(union);
    else {
      const last = shape.union.length - 1;
      lines.push(...shape.union.map((one, at) => `${inner}| ${one}${at === last ? comma : ""}`));
    }
    if (shape.frame !== undefined) lines.push(`${inner}${shape.frame}`);
    lines.push(`${" ".repeat(indent)}>${closing}`);
  });
  return lines;
}

/**
 * One handler alias, written the way the formatter would write it: on one line while it fits,
 * and broken from the outside in once it does not.
 *
 * This matters because the file is committed. An alias built from a long context type — three
 * intersected shapes and eight of the realm's own source names — runs well past two hundred
 * columns, and a line the formatter would have broken fails `bun run check` in whichever
 * example ships the generated file. Emitting the broken shape up front is what keeps that
 * example honest instead of excluded. The wrapping has to stay conditional at every level:
 * the formatter puts a short alias back on one line, so always breaking would fail the same
 * check from the other side.
 */
function typeAlias(
  name: string,
  first: string,
  shapes: readonly CtxShape[],
  result: string,
): string[] {
  const ctx = `ctx: ${shapes.map(flatShape).join(" & ")}`;
  const oneLine = `export type ${name} = (${first}, ${ctx}) => ${result};`;
  if (oneLine.length <= LINE_WIDTH) return [oneLine];
  return [
    `export type ${name} = (`,
    `  ${first},`,
    ...ctxParameterLines(shapes),
    `) => ${result};`,
  ];
}

/**
 * The channel block: the frame and context declarations, then one alias per channel handler
 * and per consumer handler saying exactly what that handler is handed and what it owes back.
 *
 * Only a captured realm that declared a channel or a consumer gets any of this, so every
 * realm that existed before channels did emits byte-identical types to what it always did.
 *
 * The alias is the point. A handler is a bare function in a file the host loads by name, and
 * nothing else would tell its author that a websocket handler returns a cursor, that a webhook
 * handler has headers and no socket to write to, or that `publish` only takes the sources this
 * realm declared. Two handlers sharing a verb share an alias — a keepalive usually points at
 * the same handler as `onFrame` — and are refused if they would need different ones, because
 * one name cannot mean two things in one file.
 */
function emitChannelContext(realm: Realm, typeNames: string[], handlerNames: string[]): string[] {
  if (realm.execution !== "captured") return [];
  const byKey = ([a]: [string, unknown], [b]: [string, unknown]): number =>
    a < b ? -1 : a > b ? 1 : 0;
  const channels = Object.entries(realm.channels ?? {}).sort(byKey);
  const consumers = Object.entries(realm.consumers ?? {}).sort(byKey);
  if (channels.length === 0 && consumers.length === 0) return [];

  // Everything already named in this file by the time the channel block lands. A collision
  // here reads as a duplicate identifier with nothing to say which side is the realm's own,
  // so it is caught while there is still a rename to suggest.
  const taken = new Set<string>([
    ...GENERATED_FIXED_NAMES,
    ...CAPTURED_FIXED_NAMES,
    ...typeNames,
    ...handlerNames.flatMap((name) => [
      `${pascalCase(name)}Input`,
      `${pascalCase(name)}Output`,
      `${pascalCase(name)}Handler`,
    ]),
  ]);
  for (const name of CHANNEL_FIXED_NAMES) {
    if (taken.has(name)) {
      throw new SynthError(
        `$.channels: "${name}" is also the name of a declaration a realm with channels carries ` +
          `in its generated types, and the two would collide in one file. Rename the realm's own "${name}".`,
      );
    }
  }

  // The sources a handler may publish to are this realm's own, written as a union of the
  // declared names. A realm that declares none gets `never`, which says the honest thing:
  // there is nowhere to publish, so no call compiles.
  const declared = Object.keys(realm.sources ?? {}).sort();
  const sources = declared.length === 0 ? ["never"] : declared.map(tsStringLiteral);
  const channelCtx = (frame: string): CtxShape => ({ name: "ChannelCtx", union: sources, frame });
  const consumerCtx: CtxShape = { name: "ConsumerCtx", union: sources };

  // Which websocket handlers a realm named where, gathered before anything is emitted
  // because one handler can be this channel's reader and that channel's keepalive, and the
  // frame type it is owed is whatever both roles put in front of it. A reference is read
  // for its roles, not for the field that happens to be in hand.
  const readers = new Set<string>();
  const tickers = new Set<string>();
  for (const [, spec] of channels) {
    if (spec.transport !== "websocket") continue;
    if (typeof spec.onFrame === "string" && spec.onFrame.length > 0) readers.add(spec.onFrame);
    const ticker = spec.keepalive?.handler;
    if (typeof ticker === "string" && ticker.length > 0) tickers.add(ticker);
  }

  // The keepalive tick reaches the handler a channel named as its `keepalive.handler` and
  // nobody else, so nobody else may have a branch for it: `{ kind: "keepalive" }` in a
  // webhook, a long poll or a socket reader that is not also the ticker is a branch the
  // host can never dispatch, and it should not compile.
  const websocketFrame = (reference: string): string => {
    if (!tickers.has(reference)) return "FrameWithoutKeepalive";
    return readers.has(reference) ? "Frame" : "KeepaliveFrame";
  };

  const websocketDoc = (frame: string): string => {
    if (frame === "KeepaliveFrame") {
      return "The declared keepalive ticking on a socket that is already up, and nothing else: this handler is its channel's keepalive handler and not its reader. Return the cursor the host should persist, or nothing to leave it where it was.";
    }
    const tick =
      frame === "Frame"
        ? " This handler is its channel's keepalive handler too, so the tick arrives here as well."
        : " The keepalive tick goes to another handler, so it never arrives here.";
    return `Every frame a websocket channel carries, and every control frame the host raises on it.${tick} Return the cursor the host should persist, or nothing to leave it where it was.`;
  };

  const aliases = new Map<string, string[]>();
  const claim = (name: string, where: string, lines: string[]): void => {
    checkTsName(name, where, "a generated channel handler alias");
    const already = aliases.get(name);
    if (already === undefined) {
      if (taken.has(name)) {
        throw new SynthError(
          `${where}: the generated alias "${name}" is already the name of another declaration ` +
            `in the same file. Rename the handler verb.`,
        );
      }
      aliases.set(name, lines);
      return;
    }
    if (already.join("\n") !== lines.join("\n")) {
      throw new SynthError(
        `${where}: "${name}" is already generated with a different shape by another channel or ` +
          `consumer. Two handlers sharing a verb have to be handed the same thing.`,
      );
    }
  };

  // What every channel handler resolves to. A long-poll handler gets the wider one: it is
  // the only transport whose cursor travels as a query parameter, so it is the only one
  // that has a name to tell the host.
  const cursorReturn = "Promise<{ cursor?: string }>";
  const longPollReturn = "Promise<{ cursor?: string; cursorParam?: string }>";

  const frameAlias = (
    name: string,
    frame: string,
    shapes: readonly CtxShape[],
    doc: string,
    returns: string = cursorReturn,
  ): string[] => [...jsdoc(doc), ...typeAlias(name, `frame: ${frame}`, shapes, returns)];

  for (const [key, spec] of channels) {
    const where = `$.channels.${key}`;
    if (spec.transport === "websocket") {
      const references: readonly (readonly [string, string | undefined])[] = [
        ["onFrame", spec.onFrame],
        ["keepalive.handler", spec.keepalive?.handler],
      ];
      for (const [field, reference] of references) {
        if (typeof reference !== "string" || reference.length === 0) continue;
        const name = `${pascalCase(handlerVerb(reference))}FrameHandler`;
        const frame = websocketFrame(reference);
        const context: readonly CtxShape[] = [channelCtx(frame), "StreamCtx"];
        claim(name, `${where}.${field}`, frameAlias(name, frame, context, websocketDoc(frame)));
      }
    } else if (spec.transport === "long-poll") {
      const reference = spec.onResponse;
      if (typeof reference !== "string" || reference.length === 0) continue;
      const name = `${pascalCase(handlerVerb(reference))}ResponseHandler`;
      claim(
        name,
        `${where}.onResponse`,
        frameAlias(
          name,
          "FrameWithoutKeepalive",
          [channelCtx("FrameWithoutKeepalive")],
          "One long-poll response body. There is no socket here for a keepalive to tick on, so the tick never arrives. Return the offset to fetch from next, as the cursor, and `cursorParam` to name the query parameter the host should send it as — return that name on every response, so a restart keeps it.",
          longPollReturn,
        ),
      );
    } else if (spec.transport === "webhook") {
      const reference = spec.onRequest;
      if (typeof reference !== "string" || reference.length === 0) continue;
      const name = `${pascalCase(handlerVerb(reference))}RequestHandler`;
      claim(
        name,
        `${where}.onRequest`,
        frameAlias(
          name,
          "FrameWithoutKeepalive",
          [channelCtx("FrameWithoutKeepalive"), "RequestCtx"],
          "One inbound webhook body, already verified by the host. There is no socket here for a keepalive to tick on, so the tick never arrives, and there is no cursor to keep on a webhook either, so returning nothing is the ordinary case.",
        ),
      );
    }
  }

  for (const [key, spec] of consumers) {
    const reference = spec.handler;
    if (typeof reference !== "string" || reference.length === 0) continue;
    const name = `${pascalCase(handlerVerb(reference))}ConsumerHandler`;
    const context: readonly CtxShape[] = [
      "HandlerContext",
      consumerCtx,
      ...(spec.assistant === true ? ["AssistantCtx"] : []),
    ];
    const doc =
      spec.assistant === true
        ? "One event from the source this consumer reads, with the owner's assistant to answer through."
        : "One event from the source this consumer reads.";
    claim(name, `$.consumers.${key}.handler`, [
      ...jsdoc(doc),
      ...typeAlias(name, "event: JsonObject", context, "Promise<JsonObject>"),
    ]);
  }

  const out: string[] = [...CHANNEL_CONTEXT_DECLARATIONS];
  for (const lines of aliases.values()) out.push(...lines, "");
  return out;
}

function emitInterface(name: string, spec: TypeSpec): string[] {
  const lines: string[] = [];
  if (spec.description) lines.push(...jsdoc(spec.description));
  lines.push(`export interface ${name} {`);

  for (const property of Object.keys(spec.properties).sort()) {
    const declared = spec.properties[property] as PropertySpec;
    const description = typeof declared === "string" ? declared : declared.description;
    const doc: PropertyDoc = { description, deprecated: false, facetLines: [] };
    if (hasPropertyDoc(doc)) lines.push(...tsPropertyJsdoc(doc, "  "));
    lines.push(`  ${tsMemberKey(property)}${optional(declared)}: ${tsType(declared)};`);
  }

  lines.push("}");
  return lines;
}

/**
 * A property is required when it is the identity or says so. Everything else is optional:
 * a realm materializes records from sources that routinely omit fields, and a type that
 * claims otherwise would make handlers lie about what they have.
 */
function optional(spec: PropertySpec): string {
  if (typeof spec === "string") return "?";
  return spec.identity === true || spec.required === true ? "" : "?";
}

/**
 * A property with no declared type, or one the switch below doesn't recognize, is
 * treated as text: most fields like that are display strings anyway.
 *
 * A LIST or SET property holds many values, so it types as an array. Getting that wrong
 * would hand a handler author a `string` where the graph has a list, which compiles and
 * then fails at run time — the exact shape of bug the wire allowlist exists to stop.
 */
function tsType(spec: PropertySpec): string {
  if (typeof spec === "string") return "string";
  const scalar = tsScalar(spec.type);
  return isMultiValued(spec) ? `${scalar}[]` : scalar;
}

function tsScalar(type: string | undefined): string {
  switch (type) {
    case "int":
    case "number":
      return "number";
    case "boolean":
      return "boolean";
    default:
      return "string";
  }
}

/** True when the property holds many values rather than one. Shared reading of `cardinality` across all three emitters. */
export function isMultiValued(spec: PropertySpec): boolean {
  if (typeof spec === "string") return false;
  return spec.cardinality === "LIST" || spec.cardinality === "SET";
}

/** Convert a string to PascalCase. */
export function pascalCase(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/**
 * One segment of a synthetic type name, built from a property key.
 *
 * The Python and Rust emitters both name a nested object type after the key it sits
 * under, and a key is any JSON string: "user-id" would give "EchoInputUser-id", which
 * neither language can carry. Every character outside the identifier alphabet becomes
 * an underscore here, so the name is always writable. Two different keys can sanitize
 * to the same segment, and each emitter's symbol table catches that with both source
 * paths named.
 */
export function syntheticNameSegment(key: string): string {
  return pascalCase(key.replace(/[^A-Za-z0-9_]/g, "_"));
}

/**
 * The identifier a namespace's own generated declarations are named after: its gateway
 * interface, and the argument and body types of every write operation in it.
 *
 * A namespace is a host name rather than a TypeScript one — a captured api may be called
 * `catalog-api` — so anything TypeScript cannot carry in an identifier becomes an underscore.
 * A namespace that already read as an identifier comes back exactly as it was.
 */
function gatewayTypeBase(namespace: string): string {
  return pascalCase(namespace.replace(/[^A-Za-z0-9_$]/g, "_"));
}

/**
 * One distinct base per namespace, decided for the whole file at once.
 *
 * `pascalCase` only touches the first character, so `foo` and `Foo` — two namespaces the host
 * installs and dispatches separately, each with its own operations — would both be named
 * `FooGateway`. TypeScript merges two interfaces of one name, and the merged interface offers
 * each namespace's operations through the other, so a call the host has no operation for
 * compiles. The later namespace in sorted order takes a counted suffix instead, which is the
 * same answer on every run.
 */
export function gatewayTypeBases(namespaces: Iterable<string>): Map<string, string> {
  return disambiguatedNames(namespaces, gatewayTypeBase);
}

/**
 * Names a set of namespaces deterministically, one call per kind of name a namespace
 * needs (a gateway interface, a snake_case accessor, whatever else a language wants):
 * processed in sorted order, and whenever a namespace's own name was already taken by an
 * earlier one, a counted suffix (2, 3, ...) is appended until it is unique. The same
 * namespace gets the same name on every run, and the earliest namespace in sorted order
 * always keeps the plain name — this is the rule `gatewayTypeBases` applies to a
 * TypeScript interface name, generalized so the Python and Rust emitters can apply the
 * identical rule to their own gateway class and trait names.
 */
export function disambiguatedNames(
  namespaces: Iterable<string>,
  name: (namespace: string) => string,
): Map<string, string> {
  const names = new Map<string, string>();
  const taken = new Set<string>();
  for (const namespace of [...namespaces].sort()) {
    const candidate = name(namespace);
    let unique = candidate;
    for (let n = 2; taken.has(unique); n += 1) unique = `${candidate}${n}`;
    taken.add(unique);
    names.set(namespace, unique);
  }
  return names;
}

/** Every distinct operation the realm's producers reach for, including resolvers. Shared with the Python emitter, so both languages type the same gateway from the same walk. */
export function gatewayOperations(realm: Realm): string[] {
  const found = new Set<string>();
  for (const producer of Object.values(realm.producers ?? {})) {
    if (producer.kind === "remote") found.add(producer.operation);
    if (producer.kind === "generative" && producer.resolveVia) {
      found.add(producer.resolveVia.operation);
    }
  }
  for (const type of Object.values(realm.types ?? {})) {
    if (type.retrieval) found.add(type.retrieval.operation);
  }
  return [...found].sort();
}

function jsdoc(text: string, indent = ""): string[] {
  const body = escapeBlockComment(text.trim()).split("\n");
  if (body.length === 1) return [`${indent}/** ${body[0]} */`];
  return [`${indent}/**`, ...body.map((l) => `${indent} * ${l}`.trimEnd()), `${indent} */`];
}

/**
 * What one property carries beyond its bare type, read the same way for a domain
 * type's declared shape and for a handler's JSON Schema. Every emitter renders these
 * in the same fixed order: the description first, then whether the property is
 * deprecated, then the labelled facet lines. Nothing here is escaped yet. Each
 * emitter fits this into its own comment syntax and runs its own escaping before any
 * of it lands in generated source, the same way it already does for `description`.
 */
export interface PropertyDoc {
  description?: string;
  deprecated: boolean;
  /**
   * `format`, `pattern`, `minimum`/`maximum`, `minLength`/`maxLength`, `enum`,
   * `default` and `examples`, each as one short line like `Format: date-time.`, in
   * that order. Only the facets a schema actually declares appear here.
   */
  facetLines: string[];
}

/** Whether `doc` has anything worth writing a comment for at all. */
export function hasPropertyDoc(doc: PropertyDoc): boolean {
  return doc.description !== undefined || doc.deprecated || doc.facetLines.length > 0;
}

/**
 * A compact, human-readable rendering of one JSON value for a doc line: a string
 * quoted, everything else as its plain form. This is prose meant for a reader, so it
 * still passes through the target language's own comment escaping before it reaches
 * generated source, so a value can carry anything without corrupting the line it
 * lands on.
 */
function renderDocValue(value: unknown): string {
  if (typeof value === "string") {
    return `'${value.replace(/\\/g, "\\\\").replace(/'/g, "\\'")}'`;
  }
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  if (value === null) return "null";
  if (Array.isArray(value)) return `[${value.map(renderDocValue).join(", ")}]`;
  if (typeof value === "object") {
    try {
      return JSON.stringify(value);
    } catch {
      return "{...}";
    }
  }
  return String(value);
}

/**
 * Reads the documentation facets off one JSON Schema property, in the fixed order
 * every emitter carries them: description, deprecated, format, pattern,
 * minimum/maximum, minLength/maxLength, enum, default, examples.
 */
export function propertyDoc(schema: unknown): PropertyDoc {
  const obj = schema && typeof schema === "object" ? (schema as Record<string, unknown>) : {};
  const description = typeof obj.description === "string" ? obj.description : undefined;
  const deprecated = obj.deprecated === true;
  const facetLines: string[] = [];
  if (typeof obj.format === "string") facetLines.push(`Format: ${obj.format}.`);
  if (typeof obj.pattern === "string") facetLines.push(`Pattern: ${obj.pattern}.`);
  if (obj.minimum !== undefined) facetLines.push(`Minimum: ${renderDocValue(obj.minimum)}.`);
  if (obj.maximum !== undefined) facetLines.push(`Maximum: ${renderDocValue(obj.maximum)}.`);
  if (obj.minLength !== undefined) facetLines.push(`Min length: ${renderDocValue(obj.minLength)}.`);
  if (obj.maxLength !== undefined) facetLines.push(`Max length: ${renderDocValue(obj.maxLength)}.`);
  if (Array.isArray(obj.enum) && obj.enum.length > 0) {
    facetLines.push(`Enum: ${obj.enum.map(renderDocValue).join(" | ")}.`);
  }
  if (obj.default !== undefined) facetLines.push(`Default: ${renderDocValue(obj.default)}.`);
  if (Array.isArray(obj.examples) && obj.examples.length > 0) {
    const examples = obj.examples;
    const label = examples.length === 1 ? "Example" : "Examples";
    facetLines.push(`${label}: ${examples.map(renderDocValue).join(", ")}.`);
  }
  return { description, deprecated, facetLines };
}

/**
 * Whose schema is being typed. A conventional handler's input and output are typed the way
 * they always have been: a string enum narrows to its members and nothing else narrows at
 * all, because nothing checks a handler's own values against the schema at run time. A
 * captured api's parameters and request body are a different story — the host checks every
 * value against the document before the call leaves the machine — so there the emitter
 * narrows every scalar enum down to the values the host would actually accept.
 */
type SchemaSurface = "conventional" | "captured";

/**
 * The values of an `enum` facet, when the schema declares `type: "string"` and every
 * member is itself a string: the shape a TS union, a Python `Literal` and a Rust doc
 * comment can each do something with. `undefined` when the schema has no string enum
 * to narrow against.
 */
export function stringEnumValues(schema: unknown): string[] | undefined {
  if (!schema || typeof schema !== "object") return undefined;
  const obj = schema as Record<string, unknown>;
  if (obj.type !== "string") return undefined;
  if (!Array.isArray(obj.enum) || obj.enum.length === 0) return undefined;
  if (!obj.enum.every((v) => typeof v === "string")) return undefined;
  return obj.enum as string[];
}

/**
 * `doc` composed into the paragraphs a JSDoc block renders: the description, then the
 * facet lines as their own paragraph, then `@deprecated` when the property is
 * deprecated. Empty when there is nothing to say.
 */
function tsPropertyJsdoc(doc: PropertyDoc, indent: string): string[] {
  const sections: string[] = [];
  if (doc.description) sections.push(doc.description.trim());
  if (doc.facetLines.length > 0) sections.push(doc.facetLines.join("\n"));
  if (doc.deprecated) sections.push("@deprecated");
  return jsdoc(sections.join("\n\n"), indent);
}

/**
 * A verb's input and output are declared as JSON-Schema, because that's what the
 * manifest carries to the engine, but a handler is a TypeScript function, so this is
 * where that schema becomes the type it implements against. The mapping is small on
 * purpose: string, number, boolean, array and object-with-properties cover every shape
 * a handler has needed so far. Anything else falls back to `unknown`; it does not guess.
 * No schema at all means no input to type, so the default is `Record<string, never>`: an
 * empty object.
 *
 * An object property also carries whatever documentation its schema declares: a
 * description, a deprecation notice, and the labelled facet lines `propertyDoc`
 * reads off it, rendered as a JSDoc block above the field. A string property with a
 * string `enum` narrows to the literal union those values name. Every other string
 * property just gets the bare `string` type.
 *
 * `surface` says whose schema this is, and it is the only thing that changes the answer:
 * see `SchemaSurface`.
 */
function jsonSchemaToTsType(
  schema: unknown,
  fallback = "Record<string, never>",
  surface: SchemaSurface = "conventional",
  where = "its request body",
): string {
  if (!schema || typeof schema !== "object") {
    return fallback;
  }

  const obj = schema as Record<string, unknown>;
  const type = obj.type as string | undefined;

  if (!type) {
    return fallback;
  }

  if (type === "string" || type === "integer" || type === "number" || type === "boolean") {
    if (surface === "captured") {
      const narrowed = capturedEnumType(obj, "body", where);
      if (narrowed !== undefined) return narrowed;
    } else {
      const values = stringEnumValues(obj);
      if (values) return values.map((value) => JSON.stringify(value)).join(" | ");
    }
    return type === "string" ? "string" : type === "boolean" ? "boolean" : "number";
  }

  if (type === "array") {
    const items = obj.items as Record<string, unknown> | undefined;
    // The reader's own Obj validation (CapturedRealmApis.kt:191-199) rejects every key an
    // object schema doesn't declare, so on the captured surface `items: {type: "object"}` with
    // no properties is a genuinely closed empty object, not "no schema at all" -- the ordinary
    // "unknown" fallback is for when there really is no schema information, which this isn't.
    const itemFallback =
      surface === "captured" && (items as Record<string, unknown> | undefined)?.type === "object"
        ? "Record<string, never>"
        : "unknown";
    return tsArrayOf(jsonSchemaToTsType(items, itemFallback, surface, where));
  }

  if (type === "object") {
    const properties = obj.properties as Record<string, unknown> | undefined;
    const required = (obj.required as string[] | undefined) ?? [];

    if (!properties || Object.keys(properties).length === 0) {
      return fallback;
    }

    const fields: string[] = [];
    for (const prop of Object.keys(properties).sort()) {
      const propSchema = properties[prop];
      const propWhere = `${where} property "${prop}"`;
      const propType = jsonSchemaToTsType(propSchema, "unknown", surface, propWhere);
      const isRequired = required.includes(prop);
      const optional = isRequired ? "" : "?";
      const doc = propertyDoc(propSchema);
      if (surface === "captured") {
        noteUnreachableChoices(doc, capturedEnum(propSchema, "body", propWhere));
      }
      if (hasPropertyDoc(doc)) fields.push(...tsPropertyJsdoc(doc, "  "));
      fields.push(`  ${tsMemberKey(prop)}${optional}: ${propType};`);
    }

    return `{\n${fields.join("\n")}\n}`;
  }

  return "unknown";
}

/**
 * `T[]` for one item type, with parentheses around a union.
 *
 * `[]` binds tighter than `|`, so appending it to an enum's literal union gives
 * `"draft" | "published"[]`: a type that takes the bare string `"draft"` and refuses the array
 * `["draft"]`, which is exactly backwards. Only a union written at the top level needs the
 * parentheses — one inside an object literal's own property is already fenced by the braces —
 * so every array type that was already right keeps the spelling it had.
 */
function tsArrayOf(itemType: string): string {
  return isTopLevelUnion(itemType) ? `(${itemType})[]` : `${itemType}[]`;
}

/** True when a `|` sits outside every brace, bracket, parenthesis and quoted string. */
function isTopLevelUnion(type: string): boolean {
  let depth = 0;
  let quote = "";
  for (let index = 0; index < type.length; index += 1) {
    const char = type[index] as string;
    if (quote !== "") {
      if (char === "\\") index += 1;
      else if (char === quote) quote = "";
    } else if (char === '"' || char === "'" || char === "`") {
      quote = char;
    } else if (char === "{" || char === "[" || char === "(") {
      depth += 1;
    } else if (char === "}" || char === "]" || char === ")") {
      depth -= 1;
    } else if (char === "|" && depth === 0) {
      return true;
    }
  }
  return false;
}

/**
 * A captured realm's vendored OpenAPI documents, already parsed, keyed by the `apis` entry
 * each was vendored for — the same key the emitted `apis/apis.yml` entry is built from.
 */
export type VendoredApiDocuments = Record<string, unknown>;

/** A captured realm's api entries, in the order every generated name is decided in. */
function capturedApiEntries(realm: CapturedRealm): [string, CapturedApiSpec][] {
  return Object.entries(realm.apis ?? {}).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
}

/** The TypeScript type one declared GraphQL variable takes. */
function graphqlVariableType(variable: CapturedGraphqlVariableSpec): string {
  if (variable.enum !== undefined && variable.enum.length > 0) {
    return variable.enum.map((value) => JSON.stringify(value)).join(" | ");
  }
  return variable.type === "string" ? "string" : variable.type === "boolean" ? "boolean" : "number";
}

/**
 * A captured realm's GraphQL operations, as members of their namespace. A call passes only
 * `variables`, typed from the declaration, and resolves to the response's `data` member,
 * which nothing here knows the shape of.
 */
function graphqlMembers(
  spec: CapturedGraphqlSpec,
  namespaces: Map<string, Map<string, string[]>>,
): void {
  const members = namespaces.get(spec.name) ?? new Map<string, string[]>();
  namespaces.set(spec.name, members);
  for (const name of Object.keys(spec.operations).sort()) {
    const variables = spec.operations[name]?.variables ?? [];
    const fields = variables.map((variable) =>
      variable.required === true
        ? `${tsMemberKey(variable.name)}: ${graphqlVariableType(variable)}`
        : `${tsMemberKey(variable.name)}?: ${graphqlVariableType(variable)} | null`,
    );
    const anyRequired = variables.some((variable) => variable.required === true);
    const args =
      variables.length === 0
        ? "args?: { variables?: Record<string, never> }"
        : `args${anyRequired ? "" : "?"}: { variables${anyRequired ? "" : "?"}: { ${fields.join("; ")} } }`;
    members.set(name, [
      ...jsdoc(
        `Runs the persisted GraphQL query "${name}" against ${spec.endpoint}. Resolves to the ` +
          "response's `data` member.",
        "  ",
      ),
      `  ${tsMemberKey(name)}(${args}): Promise<unknown>;`,
    ]);
  }
}

/** One gateway member left as the escape hatch: an untyped arguments bag and an untyped result. */
function untypedGatewayMember(name: string): string {
  return `  ${tsMemberKey(name)}(args?: Record<string, unknown>): Promise<unknown>;`;
}

/**
 * A read the host parses as newline-delimited JSON. It answers with every complete record
 * and whether it dropped an incomplete last line, so the result is that pair. `T` is the
 * record type the handler expects; nothing checks it.
 */
function ndjsonGatewayMember(name: string): string[] {
  return [
    ...jsdoc(
      "Reads a newline-delimited JSON stream: every complete record, and `truncated` when the host dropped an incomplete last line.",
      "  ",
    ),
    `  ${tsMemberKey(name)}<T = unknown>(args?: Record<string, unknown>): Promise<{ records: T[]; truncated: boolean }>;`,
  ];
}

/** The name of the generated XML element type, declared only when an operation answers with XML. */
const XML_ELEMENT = "CapturedXmlElement";

/** The declaration of {@link XML_ELEMENT}, in the shape the host's XML decoder hands over. */
const XML_ELEMENT_DECLARATION = [
  ...jsdoc(
    "An XML element as the host hands it over. An attribute is `@name` holding its value, and a " +
      "namespace declaration is `@xmlns` or `@xmlns:p`. Each child element's name holds every child " +
      "of that name in document order, as an array even when there is one. `#text` holds the text " +
      "and CDATA joined, and is left out when it is only whitespace.",
  ),
  `export interface ${XML_ELEMENT} {`,
  '  "#text"?: string;',
  "  [attribute: `@${string}`]: string;",
  `  [child: string]: string | ${XML_ELEMENT}[] | undefined;`,
  "}",
  "",
];

/**
 * What a handler receives for one operation's reply, as a TypeScript type, with a line saying
 * what the host does to the body. Undefined for a JSON or YAML document, which stays `unknown`
 * because nothing here knows its shape, and for a record stream, which has its own member.
 */
function replyShape(format: ResponseFormat): { type: string; doc: string } | undefined {
  const type = essence(format.media);
  if (format.raw) {
    return {
      type: "{ contentType: string | null; text: string }",
      doc:
        `Answers with \`${type}\`, which the handler decodes itself: the reply's Content-Type, ` +
        "null for an empty body, and the body as text.",
    };
  }
  switch (format.codec) {
    case "xml":
      return {
        type: `{ [root: string]: ${XML_ELEMENT} } | null`,
        doc: `Answers with \`${type}\`, decoded to its root element under the root's name, or null for an empty body.`,
      };
    case "csv": {
      const header = format.media.parameters.header?.toLowerCase() === "present";
      return {
        type: header
          ? "{ header: string[] | null; rows: string[][] }"
          : "{ header: null; rows: string[][] }",
        doc: header
          ? "Answers with CSV whose first row is the header, null for an empty body. Every row is a list of strings."
          : "Answers with CSV with no header row. Every row is a list of strings.",
      };
    }
    case "form":
      return {
        type: "Record<string, string | string[]>",
        doc: "Answers with a form body: each key's value, and every value of a key that repeats.",
      };
    case "text":
      return { type: "string", doc: `Answers with \`${type}\`, as one string.` };
    default:
      return undefined;
  }
}

/**
 * The format one operation answers in: its declared `response`, or JSON when it declares
 * none, whatever its document names, because that is how the host reads it. A declaration
 * emit() would refuse counts as JSON here, since emit() is where the author hears about it.
 */
function operationFormat(spec: CapturedApiSpec, id: string, write: boolean): ResponseFormat {
  const declared = spec.operations?.[id]?.response;
  if (declared === undefined) return UNDECLARED_FORMAT;
  const read = declaredResponse(declared, write);
  return "refused" in read ? UNDECLARED_FORMAT : read.format;
}

/** The HTTP methods a captured write goes out as. A read is always a GET, so it never appears here. */
const CAPTURED_WRITE_METHODS = ["post", "put", "patch", "delete"] as const;

/** Where one operation sits in a vendored document, and the two nodes its arguments come from. */
interface FoundOperation {
  method: string;
  path: string;
  pathItem: Record<string, unknown>;
  operation: Record<string, unknown>;
}

/** One argument a captured operation takes, ready to be written into an arguments interface. */
interface CapturedArgument {
  name: string;
  type: string;
  required: boolean;
  doc: PropertyDoc;
}

/**
 * The typed gateway surface for a captured realm's api entries.
 *
 * A captured api entry names its exact allowed surface up front — `operationIds` to read
 * with, `writeOperationIds` to write with — and the host will dispatch nothing else, so
 * those two lists are the whole namespace and an operation absent from both is absent here.
 * A read stays typed as it always was, an untyped arguments bag: what a GET takes is its
 * declared parameters, and nothing about this change makes them any better known.
 *
 * A write is different. The host reads one arguments object and splits it — the reserved
 * `body` key is the request body, everything else is a declared path or query parameter —
 * and the vendored document says what both halves hold. So a write operation gets an
 * arguments interface built from that document, and its body gets a named type. Missing the
 * document, or meeting a schema shape the host does not read, the operation falls back to
 * the same untyped bag with a comment saying which of those it was.
 *
 * Fills `namespaces` in place and returns the declarations the members refer to.
 */
function capturedApiTypes(
  realm: CapturedRealm,
  namespaces: Map<string, Map<string, string[]>>,
  gatewayNames: Map<string, string>,
  documents: VendoredApiDocuments | undefined,
): string[] {
  const lines: string[] = [];
  let needsXml = false;
  // Every generated name in one table, so a collision is a message naming both sources
  // rather than a second declaration TypeScript reports as a duplicate identifier. A
  // realm's own domain types are already in the file, so they are in the table too.
  const claimed = new Map<string, string>();
  for (const name of Object.keys(realm.types ?? {})) claimed.set(name, `$.types.${name}`);
  const claim = (name: string, where: string): void => {
    const previous = claimed.get(name);
    if (previous !== undefined) {
      throw new SynthError(
        `${where}: the generated type name "${name}" is already taken by ${previous}. Rename one of them.`,
      );
    }
    claimed.set(name, where);
  };

  for (const [key, spec] of capturedApiEntries(realm)) {
    const where = `$.apis.${key}`;
    const namespace = spec.name;
    // emitHandlerTypes checked this name against the host's grammar and decided what its
    // declarations are called before anything was emitted; both are read back here.
    const namespaceBase = gatewayNames.get(namespace) as string;
    const members = namespaces.get(namespace) ?? new Map<string, string[]>();
    namespaces.set(namespace, members);
    const document = asRecord(documents?.[key]);

    for (const id of [...(spec.operationIds ?? [])].sort()) {
      const format = operationFormat(spec, id, false);
      if (format.codec === "records") {
        members.set(id, ndjsonGatewayMember(id));
        continue;
      }
      const reply = replyShape(format);
      if (reply === undefined) {
        members.set(id, [untypedGatewayMember(id)]);
        continue;
      }
      if (format.codec === "xml") needsXml = true;
      members.set(id, [
        ...jsdoc(reply.doc, "  "),
        `  ${tsMemberKey(id)}(args?: Record<string, unknown>): Promise<${reply.type}>;`,
      ]);
    }

    // The host's key for a write operation is "$namespace.$name" and its call names keep
    // "$name" verbatim (CapturedApiContract.kt:207-208), so two ids differing only in case —
    // "Foo" and "foo" — stay two distinct operations there. `syntheticNameSegment` only
    // touches an id's first character, so those two land on the same generated type base
    // ("...Foo") and the second `claim()` below would throw. Same rule as the namespace
    // names just above it: sorted, counted-suffix, decided for every id in this namespace at
    // once, so a case-only clash gets two real names instead of a build failure.
    const typeBaseSegments = disambiguatedNames(spec.writeOperationIds ?? [], syntheticNameSegment);
    for (const id of [...(spec.writeOperationIds ?? [])].sort()) {
      const reply = replyShape(operationFormat(spec, id, true));
      if (reply !== undefined && reply.type.includes(XML_ELEMENT)) needsXml = true;
      const result = reply?.type ?? "unknown";
      const found = document === undefined ? undefined : findWriteOperation(document, id);
      const unread =
        document === undefined
          ? `the vendored document for the "${key}" api entry did not reach the types emitter`
          : found === undefined
            ? `"${spec.url}" declares no POST, PUT, PATCH or DELETE carrying the operation id "${id}"`
            : undefined;
      const read = found === undefined ? undefined : capturedArguments(found);
      const reason = unread ?? read?.reason;
      if (document === undefined || found === undefined || read?.parameters === undefined) {
        // The arguments stay the untyped bag rather than a guess. A parameter left out of a
        // typed interface would be a compile error on a call the host would have accepted.
        members.set(id, [
          ...jsdoc(
            `Writes through the captured api. Its arguments are not typed here because ${reason}.` +
              (reply === undefined ? "" : ` ${reply.doc}`),
            "  ",
          ),
          `  ${tsMemberKey(id)}(args?: Record<string, unknown>): Promise<${result}>;`,
        ]);
        continue;
      }

      const parameters = read.parameters;
      if (parameters.some((p) => p.name === CAPTURED_HOST_CONTEXT.requestBodyArgument)) {
        throw new SynthError(
          `${where}: operation "${id}" declares a parameter named ` +
            `"${CAPTURED_HOST_CONTEXT.requestBodyArgument}", which is the argument key the host reads a ` +
            `write's request body under. It refuses such an operation outright rather than choose between ` +
            `the two, so rename the parameter.`,
        );
      }

      const typeBase = `${namespaceBase}${typeBaseSegments.get(id) as string}`;
      const argsName = `${typeBase}Args`;
      const bodyName = `${typeBase}Body`;
      const body = capturedRequestBody(
        found.operation,
        document,
        bodyName,
        `${where}: operation "${id}"`,
      );
      if (body.declaration.length > 0) {
        claim(bodyName, `${where}.writeOperationIds "${id}"`);
        lines.push(...body.declaration, "");
      }
      claim(argsName, `${where}.writeOperationIds "${id}"`);
      lines.push(
        ...jsdoc(
          `Arguments for \`${namespace}.${id}\`, the ${found.method.toUpperCase()} the host sends to ` +
            `\`${found.path}\`: its declared path and query parameters, and the request body under ` +
            `\`${CAPTURED_HOST_CONTEXT.requestBodyArgument}\`. The host reads them as one object and ` +
            `splits them itself.`,
        ),
        `export interface ${argsName} {`,
      );
      for (const parameter of [...parameters].sort((a, b) => (a.name < b.name ? -1 : 1))) {
        if (hasPropertyDoc(parameter.doc)) lines.push(...tsPropertyJsdoc(parameter.doc, "  "));
        lines.push(
          `  ${tsMemberKey(parameter.name)}${parameter.required ? "" : "?"}: ${parameter.type};`,
        );
      }
      lines.push(...body.member, "}", "");

      const anyRequired = parameters.some((parameter) => parameter.required);
      members.set(id, [
        ...jsdoc(
          `Writes through the captured api: the ${found.method.toUpperCase()} the host sends to ` +
            `\`${found.path}\`. Credentials stay host-side, and the write is idempotent per identical ` +
            `arguments — the host derives its idempotency key from them.` +
            (reply === undefined ? "" : ` ${reply.doc}`),
          "  ",
        ),
        `  ${tsMemberKey(id)}<Args extends ${argsName}>(`,
        `    args${anyRequired ? "" : "?"}: Args & OnlyDeclaredFields<${argsName}, Args>,`,
        `  ): Promise<${result}>;`,
      ]);
    }
  }
  if (needsXml) {
    claim(XML_ELEMENT, "the type of an XML reply");
    lines.unshift(...XML_ELEMENT_DECLARATION);
  }
  return lines;
}

/** Where a write operation with this id sits in the document, if it is there at all. */
function findWriteOperation(
  document: Record<string, unknown>,
  id: string,
): FoundOperation | undefined {
  const paths = asRecord(document.paths);
  if (paths === undefined) return undefined;
  for (const [path, item] of Object.entries(paths)) {
    const pathItem = asRecord(item);
    if (pathItem === undefined) continue;
    for (const method of CAPTURED_WRITE_METHODS) {
      const operation = asRecord(pathItem[method]);
      if (operation !== undefined && operation.operationId === id) {
        return { method, path, pathItem, operation };
      }
    }
  }
  return undefined;
}

/**
 * The path and query parameters one operation takes, read from the two places OpenAPI lets
 * them be declared and merged the way the host merges them.
 *
 * Anything the host would not pass — a `$ref`, a `content` parameter, a schema that is not a
 * scalar — comes back as a reason instead of a parameter list, because a partial list is
 * worse than none: it would refuse a call at compile time that the host would have taken.
 */
function capturedArguments(found: FoundOperation): {
  parameters?: CapturedArgument[];
  reason?: string;
} {
  const parameters: CapturedArgument[] = [];
  for (const declaration of [found.pathItem.parameters, found.operation.parameters]) {
    if (declaration === undefined || declaration === null) continue;
    if (!Array.isArray(declaration)) return { reason: "its parameter list is not a list" };
    for (const entry of declaration) {
      const parameter = asRecord(entry);
      if (parameter === undefined) return { reason: "one of its parameters is not an object" };
      const name = parameter.name;
      if (typeof name !== "string" || name === "") {
        return { reason: "one of its parameters has no name" };
      }
      if ("$ref" in parameter || "content" in parameter) {
        return {
          reason: `its parameter "${name}" is a $ref or carries \`content\`, and the host reads only a parameter declared inline with a plain schema`,
        };
      }
      const schema = asRecord(parameter.schema);
      const parameterWhere = `parameter "${name}"`;
      const type = schema === undefined ? undefined : capturedScalarType(schema, parameterWhere);
      if (type === undefined) {
        return {
          reason: `its parameter "${name}" is not the string, integer, number or boolean the host passes`,
        };
      }
      const doc = propertyDoc(schema);
      if (doc.description === undefined && typeof parameter.description === "string") {
        doc.description = parameter.description;
      }
      noteUnreachableChoices(doc, capturedEnum(schema, "parameter", parameterWhere));
      parameters.push({ name, type, required: parameter.required === true, doc });
    }
  }
  const names = parameters.map((parameter) => parameter.name);
  const duplicate = names.find((name, index) => names.indexOf(name) !== index);
  if (duplicate !== undefined) {
    return { reason: `it declares the parameter "${duplicate}" twice, which the host refuses` };
  }
  return { parameters };
}

/**
 * One scalar parameter schema's TypeScript, narrowed to a literal union whenever the schema
 * names an enum — of numbers or booleans just as much as of strings.
 *
 * The host records the choices for every scalar type it passes, and at dispatch a value whose
 * own text is outside them is refused. So an integer parameter declared `enum: [1, 2]` takes
 * `1 | 2` and nothing else, and `enum: [true]` takes `true`: emitting `number` or `boolean`
 * there would compile a call the host has already decided to refuse.
 */
function capturedScalarType(schema: Record<string, unknown>, where: string): string | undefined {
  const narrowed = capturedEnumType(schema, "parameter", where);
  if (narrowed !== undefined) return narrowed;
  switch (schema.type) {
    case "string":
      return "string";
    case "integer":
    case "number":
      return "number";
    case "boolean":
      return "boolean";
    default:
      return undefined;
  }
}

/**
 * Where a captured value travels, because the host checks the two places differently. A
 * parameter's value is turned into text by `CapturedApiDocuments.string` and friends
 * (`CapturedApiContract.kt`:88-100), and that refuses an empty string and any ISO control
 * character outright (`CapturedApiDocuments.kt`:50-55). A body property is compared as it
 * arrives, with no such rule (`CapturedRealmApis.kt`:201-212). So a choice one place can
 * never receive, the other can.
 */
type CapturedValuePlace = "parameter" | "body";

/**
 * A captured scalar enum as the emitter reads it: the TypeScript literals a guest can
 * actually send, and a plain description of each member it had to leave out.
 */
interface CapturedEnum {
  readonly literals: readonly string[];
  readonly unreachable: readonly string[];
}

/** Plain decimal text, which is the only numeric spelling both sides write the same way. */
const PLAIN_DECIMAL = /^-?[0-9]+(\.[0-9]+)?$/;

/** Plain integer text. */
const INTEGER_TEXT = /^-?[0-9]+$/;

/** The range java.lang.Long can hold, the same range CapturedApiContract.kt's canConvertToLong() checks an integer choice against. */
const LONG_MIN = -9223372036854775808n;
const LONG_MAX = 9223372036854775807n;

/**
 * A captured scalar enum as the type it narrows to, or `undefined` when the schema declares
 * no enum at all or a type the host does not pass. `never` when it declares one but nothing
 * in it is a value a guest could send: narrowing to the widened primitive there would compile
 * a call the host refuses every time.
 */
function capturedEnumType(
  schema: unknown,
  place: CapturedValuePlace,
  where: string,
): string | undefined {
  const narrowed = capturedEnum(schema, place, where);
  if (narrowed === undefined) return undefined;
  return narrowed.literals.length > 0 ? narrowed.literals.join(" | ") : "never";
}

/**
 * A parameter's own window on the length of the text a choice becomes, read the way the host
 * does (`CapturedApiContract.kt`'s `bound()`): the schema's own `minLength`/`maxLength` when
 * it declares them, `0`/`2048` — the host's own defaults — when it doesn't.
 */
function capturedParameterLengthBounds(schema: Record<string, unknown>): {
  min: number;
  max: number;
} {
  const min = typeof schema.minLength === "number" ? schema.minLength : 0;
  const max =
    typeof schema.maxLength === "number" ? schema.maxLength : CAPTURED_PARAMETER_MAX_LENGTH;
  return { min, max };
}

/** The host's own default, `CapturedApiParameter.maxLength` (`CapturedApiContract.kt`:29). */
const CAPTURED_PARAMETER_MAX_LENGTH = 2048;

/**
 * Reads one schema's `enum` the way the host does.
 *
 * The host does not keep an enum member as the JSON value the document wrote. It calls
 * `asText()` on each one and keeps a set of strings (`CapturedApiContract.kt`:320 for a
 * parameter, :275 for a body property), then at dispatch turns the guest's own value into
 * text the same way and asks whether that text is in the set. So a member's type in the
 * document decides nothing on its own: `"1"` sitting in an integer enum is the text an
 * integer `1` produces and therefore admits it, while a member no value a guest can send
 * ever produces the text of — an integer past `Number.MAX_SAFE_INTEGER`, whose digits the
 * host keeps exactly and JavaScript cannot — admits nothing and is left out.
 */
function capturedEnum(
  schema: unknown,
  place: CapturedValuePlace,
  where: string,
): CapturedEnum | undefined {
  const obj = asRecord(schema);
  const type = obj?.type;
  if (obj === undefined || typeof type !== "string") return undefined;
  if (type !== "string" && type !== "integer" && type !== "number" && type !== "boolean") {
    return undefined;
  }
  const values = obj.enum;
  if (!Array.isArray(values) || values.length === 0) return undefined;
  const bounds = place === "parameter" ? capturedParameterLengthBounds(obj) : undefined;
  const literals: string[] = [];
  const unreachable: string[] = [];
  for (const value of values) {
    const literal = capturedEnumLiteral(value, type, place, where, bounds);
    if (literal === undefined) unreachable.push(describeChoice(value));
    else if (!literals.includes(literal)) literals.push(literal);
  }
  return { literals, unreachable };
}

/**
 * One enum member as the TypeScript literal that satisfies it, or `undefined` when no value
 * a guest can send would. The member is read in two steps, the same two the host takes: the
 * text the host would hold for it, and then whether a value of the declared type can produce
 * that text again on the way back in.
 *
 * Two more of the host's own rules apply once that text is known, both parameter-only because
 * they come from `CapturedApiParameter`'s own fields rather than from `CapturedApiSchema`: the
 * text has to fall inside the parameter's declared length window (`CapturedApiContract.kt`'s
 * `scalar()`), and a string one has to be UTF-8 representable, the same as any other parameter
 * text (`CapturedApiDocuments.kt`:53). Unlike a member of the wrong JSON kind or an
 * unreachable control character, which just never shows up in the narrowed union, either of
 * these means the document declared a choice nothing could ever send — so this refuses the
 * whole build and names the parameter, rather than let the author read the type and wonder why
 * a documented choice isn't in it.
 */
function capturedEnumLiteral(
  value: unknown,
  type: string,
  place: CapturedValuePlace,
  where: string,
  bounds: { min: number; max: number } | undefined,
): string | undefined {
  const text = capturedChoiceText(value, type);
  if (text === undefined) return undefined;
  // A length bound is measured on the text the host holds, and for a number written into a
  // number or integer enum that is Jackson's spelling of it, not JavaScript's: 0.00001 is the
  // seven-character "0.00001" here and the six-character "1.0E-5" there.
  const measured =
    typeof value === "number" && (type === "number" || type === "integer")
      ? Number.isInteger(value)
        ? String(value)
        : javaDoubleText(value)
      : text;
  if (bounds !== undefined && (measured.length < bounds.min || measured.length > bounds.max)) {
    throw new SynthError(
      `${where}: the enum member ${JSON.stringify(value)} is ${measured.length} characters as the host ` +
        `holds it, outside the ${bounds.min} to ${bounds.max} character range this parameter accepts, ` +
        "so no call could ever send it. Remove it from the schema or widen the declared length.",
    );
  }
  if (place === "parameter" && type === "string" && !isUtf8Representable(text)) {
    throw new SynthError(
      `${where}: the enum member ${JSON.stringify(value)} is not representable as UTF-8, which every ` +
        "parameter value the host reads has to be, so no call could ever send it. Remove it from the schema.",
    );
  }
  switch (type) {
    case "string":
      if (place === "parameter" && (text === "" || [...text].some(isHostControlCharacter))) {
        return undefined;
      }
      return JSON.stringify(text);
    case "integer": {
      // A JS double this large can't tell "the document wrote this exact integer" apart from
      // "the document wrote some other integer that also rounds to it" — 9007199254740993 and
      // 9007199254740992 already parsed to the same value by the time this runs. The host still
      // holds whichever exact digits the document had, so guessing either way could compile a
      // call the host refuses, or silently drop a choice that would have been fine. Refusing
      // the build is the only honest answer.
      if (typeof value === "number" && !Number.isSafeInteger(value)) {
        throw new SynthError(
          `${where}: the enum member ${value} is not an integer JavaScript can hold exactly, and the ` +
            "host keeps whatever exact digits the document wrote for it, so no integer a guest sends " +
            "could ever be confirmed to match. Remove it from the schema.",
        );
      }
      // The round trip is the rest of the check: the host holds `text`, and a guest can only
      // send a value whose own text comes back the same. That is what rules out a member the
      // document wrote in a spelling nothing produces, like "01".
      if (!(INTEGER_TEXT.test(text) && String(Number(text)) === text)) return undefined;
      // A text that survives the round trip can still name a number outside what the host
      // actually accepts: canConvertToLong() only holds Long.MIN_VALUE to Long.MAX_VALUE
      // (CapturedApiContract.kt's scalar(), CapturedRealmApis.kt:191-199), so a choice like
      // "10000000000000000000" would compile fine here and never be sendable.
      const asLong = BigInt(text);
      if (asLong < LONG_MIN || asLong > LONG_MAX) {
        throw new SynthError(
          `${where}: the enum member ${text} is outside the range Java's Long can hold ` +
            "(canConvertToLong), so the host would refuse any call that sent it. Remove it " +
            "from the schema or narrow it to a value Long can hold.",
        );
      }
      return text;
    }
    case "number": {
      if (typeof value === "number" && Number.isInteger(value) && !Number.isSafeInteger(value)) {
        return undefined; // Same ambiguity as the integer case, but a float member is only ever left out, never refused.
      }
      if (!PLAIN_DECIMAL.test(text) || String(Number(text)) !== text) return undefined;
      // The host first insists a guest's value is a finite number (`CapturedRealmApis.kt`:207,
      // `CapturedApiContract.kt`:92) and only then compares the text Jackson gives that number
      // with the text it holds for the member (`CapturedRealmApis.kt`:211). Which text it holds
      // depends on how the document wrote the member.
      if (typeof value === "number") {
        // Written as a JSON number: the host holds Jackson's own text for it, and a guest's
        // number goes through Jackson too, so any fractional value matches itself. A whole
        // number is the exception: by the time this runs, JSON.parse has erased whether the
        // document wrote `1` (an IntNode the host shows as "1") or `1.0` (a DoubleNode it shows
        // as "1.0"), and a guest can only ever send the bare `1`. Rather than guess, it is left
        // out of the union like any other unsendable choice.
        return text.includes(".") ? text : undefined;
      }
      // Written as a string: the host holds that exact text, and the guest's number has to come
      // back from Jackson spelled the same way. A whole number comes back as an IntNode with its
      // plain digits; anything else comes back as a DoubleNode printed by Java's Double.toString,
      // which is not how JavaScript prints the same value ("1.0E-4" against "0.0001").
      const parsed = Number(text);
      const guestText = Number.isInteger(parsed) ? String(parsed) : javaDoubleText(parsed);
      return guestText === text ? String(parsed) : undefined;
    }
    default:
      return text === "true" || text === "false" ? text : undefined;
  }
}

/**
 * How Java's `Double.toString`, and so Jackson's `DoubleNode.asText()`, prints [value]: the
 * shortest digits that round-trip (the same digits JavaScript picks), written plainly with at
 * least one digit after the point when the exponent is between -3 and 6, and otherwise as
 * `d.dddE<exponent>` with no plus sign. JavaScript switches to scientific notation at different
 * magnitudes, so its own `String(value)` is not what the host compares against. In scientific
 * notation Java also never prints fewer than two significant digits, and when the shortest form
 * has only one it takes the two-digit form closest to the exact value, which is not always that
 * digit followed by a zero: the smallest double is 4.9E-324, not 5.0E-324.
 */
export function javaDoubleText(value: number): string {
  const [mantissa, exponentText] = Math.abs(value).toExponential().split("e");
  const exponent = Number(exponentText);
  const digits = mantissa.replace(".", "");
  const sign = value < 0 ? "-" : "";
  if (exponent >= -3 && exponent < 7) {
    if (exponent >= 0) {
      const wholePart = digits.slice(0, exponent + 1).padEnd(exponent + 1, "0");
      const fraction = digits.slice(exponent + 1) || "0";
      return `${sign}${wholePart}.${fraction}`;
    }
    return `${sign}0.${"0".repeat(-exponent - 1)}${digits}`;
  }
  if (digits.length === 1) {
    // toExponential(1) rounds the exact value to two significant digits, which is the form Java picks.
    const [pair, pairExponent] = Math.abs(value).toExponential(1).split("e");
    return `${sign}${pair}E${Number(pairExponent)}`;
  }
  return `${sign}${digits[0]}.${digits.slice(1)}E${exponent}`;
}

/**
 * The text the host holds for one enum member, or `undefined` when the parsed document no
 * longer says what that text was. JSON has been through `JSON.parse` by the time it gets
 * here, so a number is a JavaScript double: `1e400` has already become `Infinity`, and the
 * host still holds what the document wrote — no literal written from the rounded value would
 * be one it accepts.
 *
 * A number written into a string enum is the one place the declared type changes the answer.
 * The host keeps it as Jackson's text for the number (`CapturedApiContract.kt`:275), and a
 * guest's string has to match that text exactly, so the member is spelled the way Java's
 * `Double.toString` prints it rather than the way JavaScript would. A whole number is held as
 * "7" or "7.0" depending on how the document wrote it, and JSON.parse has erased that, so it
 * is left out rather than guessed.
 */
function capturedChoiceText(value: unknown, type: string): string | undefined {
  if (typeof value === "string") return value;
  if (typeof value === "boolean") return String(value);
  if (typeof value !== "number" || !Number.isFinite(value)) return undefined;
  if (type === "string") return Number.isInteger(value) ? undefined : javaDoubleText(value);
  const text = String(value);
  return PLAIN_DECIMAL.test(text) ? text : undefined;
}

/**
 * True when `text` is well-formed UTF-16 — no lone surrogate half — and so can round-trip
 * through UTF-8 the way `Charsets.UTF_8.newEncoder().canEncode()` requires on the host side
 * (`CapturedApiDocuments.kt`:53). A lone surrogate is legal inside a JS string but has no
 * Unicode scalar value of its own, so nothing can encode it.
 */
function isUtf8Representable(text: string): boolean {
  return !/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/.test(text);
}

/** One left-out member, in words, for the note the declaration carries. */
function describeChoice(value: unknown): string {
  if (typeof value === "number" && Number.isInteger(value) && !Number.isSafeInteger(value)) {
    return `an integer past what JavaScript holds exactly (read here as ${value})`;
  }
  return String(JSON.stringify(value));
}

/**
 * True for a character the host refuses inside a parameter's text: `Char.isISOControl`
 * (`CapturedApiDocuments.kt`:53) covers the C0 controls, DEL and the C1 controls.
 */
function isHostControlCharacter(character: string): boolean {
  const code = character.charCodeAt(0);
  return code <= 0x1f || code === 0x7f || (code >= 0x80 && code <= 0x9f);
}

/**
 * Adds a line to a declaration's own comment for the choices the emitter left out, so an
 * author reading the generated type can see that the host holds a choice their code has no
 * way to send rather than wonder where it went. Nothing is added when every choice made it.
 */
function noteUnreachableChoices(doc: PropertyDoc, narrowed: CapturedEnum | undefined): void {
  if (narrowed === undefined || narrowed.unreachable.length === 0) return;
  doc.facetLines.push(
    `The host also holds ${narrowed.unreachable.join(", ")} among this value's choices, but ` +
      `nothing this type can send matches the text it holds for those, so they are left out.`,
  );
}

/**
 * A write operation's request body: the named type for it, and the member that carries it in
 * the arguments interface.
 *
 * The body is always optional. The host treats a declared `requestBody` as something a call
 * may send, not something it must, so a guest that leaves it out sends none — and an
 * operation that declares no `requestBody` at all refuses one, which is why the member is
 * typed `never` there rather than simply left out.
 *
 * A schema the host reads becomes a real interface. Anything else — no `application/json`
 * schema, a body that resolves to something other than an object, an object declaring no
 * properties — falls back to `Record<string, unknown>`, and the comment above the type says
 * which of those it was. It never guesses: a wrong body type is a call that compiles and
 * then comes back refused.
 */
/** The only place the host follows a body `$ref` to. */
const CAPTURED_BODY_REF_PREFIX = "#/components/";

/**
 * The keywords the host's write-body reader accepts on each kind of JSON-Schema node
 * (`CapturedApiContract.schemaNode`). It refuses everything else outright instead of ignoring
 * it, so a body carrying `oneOf`, `pattern`, `additionalProperties`, `maxLength` or `minimum`
 * would install fine here and then have every real call turned down at the host. `description`
 * and `format` are documentation over there — read, never enforced — so they are welcome here.
 */
export const CAPTURED_BODY_SCHEMA_KEYWORDS = {
  object: ["type", "properties", "required", "description"],
  array: ["type", "items", "description"],
  string: ["type", "enum", "description", "format"],
  integer: ["type", "enum", "description", "format"],
  number: ["type", "enum", "description", "format"],
  boolean: ["type", "enum", "description", "format"],
} as const;

/** Where a write's body schema sits in its operation, as the pointer a refusal quotes. */
const CAPTURED_BODY_SCHEMA_POINTER = "requestBody/content/application~1json/schema";

/** What the host reads on a node of this `type`, or undefined when it reads no such type at all. */
function capturedBodySchemaKeywords(type: unknown): readonly string[] | undefined {
  const table: Readonly<Record<string, readonly string[] | undefined>> =
    CAPTURED_BODY_SCHEMA_KEYWORDS;
  return typeof type === "string" ? table[type] : undefined;
}

/**
 * Walks a write operation's body schema the way the host reads it, throwing on the first thing
 * the host would refuse: a keyword outside the table above, a node whose `type` it does not
 * read, a `$ref` carrying something beside the pointer, or one pointing outside
 * `#/components/`. Returns the node the host ends up on once the `$ref`s in the way are
 * followed, so a caller can go on to insist the body lands on an object, and undefined when
 * the walk ran out of schema to read — a pointer into nothing, or one that circles back on
 * itself. Those two are the reader's own resolution and depth business, and the type
 * generation below already reports such a body as untyped, naming why.
 *
 * Every refusal names the operation, the pointer into the body and the keyword: "unsupported
 * keyword" on its own leaves the author hunting through the document for it.
 */
export function checkCapturedBodySchema(
  schema: unknown,
  document: Record<string, unknown>,
  where: string,
  pointer: string = CAPTURED_BODY_SCHEMA_POINTER,
  followed: readonly string[] = [],
): Record<string, unknown> | undefined {
  const node = asRecord(schema);
  if (node === undefined) {
    throw new SynthError(`${where}: the body schema at "${pointer}" is not a JSON object.`);
  }
  if ("$ref" in node) {
    const beside = Object.keys(node)
      .filter((key) => key !== "$ref")
      .sort();
    if (beside.length > 0) {
      throw new SynthError(
        `${where}: the body schema at "${pointer}" is a $ref, and the host reads nothing beside ` +
          `the pointer, so ${beside.join(", ")} refuses it.`,
      );
    }
    const ref = String(node.$ref);
    if (!ref.startsWith(CAPTURED_BODY_REF_PREFIX)) {
      throw new SynthError(
        `${where}: the body schema at "${pointer}" points at "${ref}", and the host follows a ` +
          `body $ref into "${CAPTURED_BODY_REF_PREFIX}" and nowhere else.`,
      );
    }
    const resolved = resolvePointer(document, ref);
    if (resolved === undefined || followed.includes(ref)) {
      // A pointer into nothing, or one pointing back at a schema this walk already read on the
      // way in. Either way there is nothing further to check here: whether a body may dangle or
      // nest this deep is the host reader's own resolution and depth business.
      return resolved === undefined ? undefined : asRecord(resolved);
    }
    return checkCapturedBodySchema(resolved, document, where, pointer, [...followed, ref]);
  }
  const keywords = capturedBodySchemaKeywords(node.type);
  if (keywords === undefined) {
    const named = Object.keys(node)
      .filter((key) => key !== "type")
      .sort();
    throw new SynthError(
      `${where}: the body schema at "${pointer}" declares ` +
        `${named.length > 0 ? named.join(", ") : "nothing readable"}` +
        `${node.type === undefined ? " and no `type`" : ` with type ${JSON.stringify(node.type)}`}. ` +
        `The host reads a body schema node as an object, an array, a string, an integer, a ` +
        `number, a boolean or a $ref, and refuses anything else.`,
    );
  }
  const refused = Object.keys(node)
    .filter((key) => !keywords.includes(key))
    .sort();
  if (refused.length > 0) {
    throw new SynthError(
      `${where}: the body schema at "${pointer}" declares ${refused.join(", ")}, which the host ` +
        `does not read on a "${String(node.type)}" node. It refuses the body outright rather than ` +
        `ignore the constraint, so drop the keyword or check it in the handler instead.`,
    );
  }
  if (node.type === "object" && "properties" in node) {
    const properties = asRecord(node.properties);
    if (properties === undefined) {
      throw new SynthError(
        `${where}: the body schema at "${pointer}" declares \`properties\` as something other ` +
          `than a mapping of property name to schema.`,
      );
    }
    for (const [name, property] of Object.entries(properties)) {
      checkCapturedBodySchema(property, document, where, `${pointer}/properties/${name}`, followed);
    }
  }
  if (node.type === "array") {
    if (!("items" in node)) {
      throw new SynthError(
        `${where}: the array body schema at "${pointer}" declares no \`items\`, and the host ` +
          `refuses an array whose element schema it cannot read.`,
      );
    }
    checkCapturedBodySchema(node.items, document, where, `${pointer}/items`, followed);
  }
  return node;
}

function capturedRequestBody(
  operation: Record<string, unknown>,
  document: Record<string, unknown>,
  bodyName: string,
  operationWhere: string,
): { declaration: string[]; member: string[] } {
  if (!("requestBody" in operation)) {
    return {
      declaration: [],
      member: [
        ...jsdoc(
          "This operation declares no request body, and the host refuses one supplied anyway, so there is nothing to send here.",
          "  ",
        ),
        "  body?: never;",
      ],
    };
  }

  const media = asRecord(asRecord(asRecord(operation.requestBody)?.content)?.["application/json"]);
  const declared = media?.schema;
  const fallback = (reason: string): { declaration: string[]; member: string[] } => ({
    declaration: [
      ...jsdoc(
        `The request body for this operation, as any JSON object: ${reason}, so this is as much as the document says.`,
      ),
      `export type ${bodyName} = Record<string, unknown>;`,
    ],
    member: [
      "  /** The request body. Optional: the host sends one only when the call supplies it. */",
      `  body?: ${bodyName};`,
    ],
  });

  if (declared === undefined) {
    return fallback("its requestBody declares no `application/json` schema");
  }
  checkCapturedBodySchema(declared, document, operationWhere);
  const schema = asRecord(inlineRefs(declared, document, { left: MAX_REF_INLINES }, [], 0));
  if (schema === undefined) {
    return fallback("its body schema is not an object schema at all");
  }
  if (schema.type !== "object") {
    // A $ref that leads nowhere lands here too, inlined as an empty schema: the host sends a
    // JSON object as a body and would refuse anything else, so any-object is the honest type.
    const named = typeof schema.type === "string" ? `a ${schema.type}` : "no type";
    return fallback(`its body schema declares ${named} where the host sends a JSON object`);
  }
  const literal = jsonSchemaToTsType(
    schema,
    "Record<string, unknown>",
    "captured",
    `the "${bodyName}" body`,
  );
  if (!literal.startsWith("{")) {
    return fallback("its body schema declares no properties");
  }
  return {
    declaration: [
      ...jsdoc("The request body for this operation, from the vendored document's own schema."),
      `export interface ${bodyName} ${literal}`,
    ],
    member: [
      "  /** The request body. Optional: the host sends one only when the call supplies it. */",
      `  body?: ${bodyName};`,
    ],
  };
}

/** How many `$ref`s one body schema may resolve before the emitter stops following them. */
const MAX_REF_INLINES = 256;

/** How deep into one body schema the emitter walks. */
const MAX_SCHEMA_DEPTH = 16;

/**
 * One schema with every local `$ref` replaced by what it points at, so the converter walks a
 * plain tree.
 *
 * The host only follows a pointer into `#/components/`, and a vendored document that holds
 * any other kind is refused whole, so anything else is left as an empty schema here — which
 * types as the fallback rather than as a guess. The same goes for a pointer that leads
 * nowhere and for one that leads back to a `$ref` already followed on this path: a
 * self-referential schema is legal OpenAPI and has no finite TypeScript spelling, so it
 * stops at the point it would repeat.
 */
function inlineRefs(
  node: unknown,
  document: Record<string, unknown>,
  budget: { left: number },
  seen: readonly string[],
  depth: number,
): unknown {
  if (depth > MAX_SCHEMA_DEPTH) return {};
  if (Array.isArray(node)) {
    return node.map((child) => inlineRefs(child, document, budget, seen, depth + 1));
  }
  if (!node || typeof node !== "object") return node;
  const obj = node as Record<string, unknown>;
  const ref = obj.$ref;
  if (typeof ref === "string") {
    if (budget.left <= 0 || seen.includes(ref) || !ref.startsWith("#/components/")) return {};
    const target = resolvePointer(document, ref);
    if (target === undefined) return {};
    budget.left -= 1;
    return inlineRefs(target, document, budget, [...seen, ref], depth + 1);
  }
  const copy: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(obj)) {
    copy[key] = inlineRefs(value, document, budget, seen, depth + 1);
  }
  return copy;
}

/**
 * What a `#/`-rooted reference names in this document, resolved exactly the way
 * `CapturedApiContract.schemaNode` resolves it on the host: each segment between the slashes
 * is a literal property name, looked up as-is. This is deliberately NOT standard JSON
 * Pointer resolution — the host never unescapes `~1` back to `/`, `~0` back to `~`, or a
 * percent escape, so neither does this. A component whose name happens to contain one of
 * those sequences is a real, literal name over there; decoding it here would walk this
 * function to a different node than the host reads, so synth-time validation could pass a
 * body the host actually refuses (or the reverse).
 */
function resolvePointer(document: Record<string, unknown>, ref: string): unknown {
  let node: unknown = document;
  for (const segment of ref.slice(2).split("/")) {
    const record = asRecord(node);
    if (record === undefined) return undefined;
    node = record[segment];
  }
  return node;
}

/** One JSON object, or undefined for anything else — an array and a null included. */
function asRecord(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : undefined;
}

/**
 * The skill digests as a value the handler imports. The guest cannot read its own skill
 * files, so this is how a handler learns which revision of a skill it is working with: the
 * same digest the bundle carries in `dist/skills.json`, which admission checks against the
 * captured files. Being a value, it only works from a `.ts` types file, never a `.d.ts`.
 */
function skillDigestConstant(
  skills: readonly string[],
  digests: Readonly<Record<string, string>> | undefined,
): string[] {
  const missing = skills.filter((name) => digests?.[name] === undefined);
  if (missing.length > 0) {
    throw new SynthError(
      `$.skills: no digest for ${missing.join(", ")}. A skill's digest is taken from the folder ` +
        `the synth run copies, so generate these types from a synth run.`,
    );
  }
  return [
    ...jsdoc(
      [
        "The sha256 of each skill folder this realm ships, exactly as synth copied it. Admission",
        "checks these against the captured files, so a cache keyed on one changes whenever the",
        "skill text the model is given does.",
      ].join("\n"),
    ),
    "export const skills = {",
    "  digest: {",
    ...skills.map((name) => `    ${JSON.stringify(name)}: ${JSON.stringify(digests?.[name])},`),
    "  },",
    "} as const;",
  ];
}
