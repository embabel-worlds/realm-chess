import { readFileSync } from "node:fs";
import type { Realm } from "@embabel/realm-types";
import { SynthError } from "./canonical.ts";

/**
 * Execution profiles, and the operator limits that go with them.
 *
 * A realm is written once and can run in more than one place: the reference host's Wasm
 * backend, its Docker backend, and whatever execution environments come after them. They do
 * not all load the same things. One refuses a realm that declares dependency layers, another
 * mounts them. One ignores a captured realm's conventional `actions/` folder, another may read
 * it. None of that belongs in the realm types, because the realm does not know where it will
 * run.
 *
 * So synth always writes everything the realm declares, and a profile is how an author asks
 * "will this run there?" before shipping. A profile names the features its environment does
 * not load and says whether that is worth a warning or a refusal. It can also carry its own
 * app size limits. Nothing here runs unless the caller picks a profile: with no profile,
 * synth checks only the structural rules every environment shares.
 *
 * Adding an environment means adding a profile, either to `BUILT_IN_PROFILES` or as a JSON
 * file passed to `--profile`. Adding something a profile can object to means adding one entry
 * to `PROFILE_FEATURES`.
 */

const MIB = 1_048_576;

/** How big a captured browser app may be. Every byte limit counts raw file bytes. */
export interface AppLimits {
  /** The app's HTML page. */
  pageBytes: number;
  /** Any one stylesheet or script the app inlines. */
  resourceBytes: number;
  /** All of one app's resources together. */
  resourcesTotalBytes: number;
  /** How many resources one app may name. */
  resourcesPerApp: number;
}

/**
 * The limits synth holds an app to when nobody says otherwise. They match the reference
 * host's own defaults. An operator can run a host with larger ones, and a big demo app
 * (a whole emulator inlined into one page, say) needs them, so every one can be raised
 * with a CLI flag, through `SynthOptions.appLimits`, or by a profile.
 */
export const DEFAULT_APP_LIMITS: Readonly<AppLimits> = Object.freeze({
  pageBytes: 10 * MIB,
  resourceBytes: 10 * MIB,
  resourcesTotalBytes: 10 * MIB,
  resourcesPerApp: 16,
});

/**
 * The CLI flag that raises each limit, so a refusal can tell the author exactly what to type.
 * `--app-limit` sets all three byte limits at once.
 */
export const APP_LIMIT_FLAGS: Readonly<Record<keyof AppLimits, string>> = Object.freeze({
  pageBytes: "--app-page-limit",
  resourceBytes: "--app-resource-limit",
  resourcesTotalBytes: "--app-total-limit",
  resourcesPerApp: "--app-resource-count",
});

/**
 * Fills in the limits a run actually uses. Later layers win: the defaults, then the
 * profile's own limits, then whatever the caller passed explicitly.
 */
export function resolveAppLimits(
  profile?: ExecutionProfile,
  overrides?: Partial<AppLimits>,
): AppLimits {
  const limits: AppLimits = { ...DEFAULT_APP_LIMITS, ...profile?.appLimits, ...overrides };
  for (const key of Object.keys(DEFAULT_APP_LIMITS) as (keyof AppLimits)[]) {
    checkLimit(limits[key], `appLimits.${key}`);
  }
  return limits;
}

/** A limit has to be a whole number of at least one. There is no upper cap. */
function checkLimit(value: unknown, where: string): asserts value is number {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 1) {
    throw new SynthError(`${where}: expected a whole number of at least 1, got ${String(value)}.`);
  }
}

const SIZE_UNITS: Readonly<Record<string, number>> = {
  "": 1,
  b: 1,
  k: 1024,
  kb: 1024,
  kib: 1024,
  m: MIB,
  mb: MIB,
  mib: MIB,
  g: 1024 * MIB,
  gb: 1024 * MIB,
  gib: 1024 * MIB,
};

/**
 * Reads a size the way people write one: `10485760`, `512KiB`, `32MiB`, `1GiB`. Units are
 * binary whichever spelling is used, so `32MB` and `32MiB` are the same number, which is what
 * someone asking for "32 megs" means. `flag` is only there to name the source of a bad value.
 */
export function parseByteSize(text: string, flag: string): number {
  const match = /^([0-9]+)\s*([a-z]*)$/i.exec(text.trim());
  const unit = match ? SIZE_UNITS[(match[2] ?? "").toLowerCase()] : undefined;
  if (!match || unit === undefined) {
    throw new SynthError(
      `${flag}: "${text}" is not a size. Write a whole number of bytes, or one with a unit, like ` +
        `"10485760", "512KiB" or "32MiB".`,
    );
  }
  const bytes = Number(match[1]) * unit;
  if (!Number.isSafeInteger(bytes) || bytes < 1) {
    throw new SynthError(`${flag}: "${text}" has to come to at least 1 byte, and a sane number.`);
  }
  return bytes;
}

/** Reads a plain count, like the number of resources one app may name. */
export function parseCount(text: string, flag: string): number {
  if (!/^[0-9]+$/.test(text.trim())) {
    throw new SynthError(`${flag}: "${text}" is not a whole number.`);
  }
  const count = Number(text.trim());
  if (!Number.isSafeInteger(count) || count < 1) {
    throw new SynthError(`${flag}: "${text}" has to be at least 1.`);
  }
  return count;
}

/** What a profile does about a feature its environment does not load. */
export type FeatureSupport = "supported" | "warn" | "refuse";

/** Something a realm can declare that not every execution environment loads. */
export interface ProfileFeature {
  /** A short phrase for messages, like "dependency layers". */
  label: string;
  /** The places in this realm that use the feature, as `$.` paths. Empty when it is unused. */
  find(realm: Realm): string[];
}

/** Paths for every key of a record field the realm set, sorted so messages are stable. */
function keysOf(realm: Realm, field: "actions" | "events" | "focuses" | "webhooks"): string[] {
  const value = realm[field];
  if (value === undefined || value === null) return [];
  return Object.keys(value)
    .sort()
    .map((key) => `$.${field}.${key}`);
}

/** The conventional folders a captured realm can still declare, and synth still writes. */
function capturedConventional(
  field: "actions" | "events" | "focuses" | "webhooks",
  label: string,
): ProfileFeature {
  return {
    label,
    find: (realm) => (realm.execution === "captured" ? keysOf(realm, field) : []),
  };
}

/**
 * Every feature a profile can object to, by id. The id is what a profile file writes.
 */
export const PROFILE_FEATURES = {
  layers: {
    label: "dependency layers",
    find: (realm: Realm) => (realm.layers?.length ? ["$.layers"] : []),
  },
  "captured-actions": capturedConventional("actions", "conventional actions in a captured realm"),
  "captured-events": capturedConventional("events", "conventional events in a captured realm"),
  "captured-focuses": capturedConventional("focuses", "focuses in a captured realm"),
  "captured-webhooks": capturedConventional(
    "webhooks",
    "conventional webhooks in a captured realm",
  ),
} as const satisfies Record<string, ProfileFeature>;

export type ProfileFeatureId = keyof typeof PROFILE_FEATURES;

/**
 * One execution environment's view of a realm: what it will not load, and how big an app it
 * takes. Everything is optional. A feature that is not listed is taken as supported.
 */
export interface ExecutionProfile {
  /** How messages name the profile, like "reference-wasm". */
  name: string;
  description?: string;
  features?: Partial<Record<ProfileFeatureId, FeatureSupport>>;
  /** Replaces the default app limits. Explicit CLI flags still win over these. */
  appLimits?: Partial<AppLimits>;
}

/**
 * What the reference host does not load. It refuses a realm that declares layers, whichever
 * backend runs it. For a captured realm it does not copy `actions/`, `events/` or
 * `webhooks/`; it does load `focuses/`. Those are warnings rather than refusals because the
 * host leaves the files behind rather than refusing the realm.
 */
const REFERENCE_FEATURES: Partial<Record<ProfileFeatureId, FeatureSupport>> = {
  layers: "refuse",
  "captured-actions": "warn",
  "captured-events": "warn",
  "captured-webhooks": "warn",
};

/** Profiles synth knows by name. `--profile` also takes a path to a JSON profile file. */
export const BUILT_IN_PROFILES: Readonly<Record<string, ExecutionProfile>> = Object.freeze({
  "reference-wasm": {
    name: "reference-wasm",
    description: "The reference host running handlers under Wasm.",
    features: REFERENCE_FEATURES,
  },
  "reference-docker": {
    name: "reference-docker",
    description: "The reference host running handlers under Docker.",
    features: REFERENCE_FEATURES,
  },
});

const FEATURE_SUPPORT: readonly FeatureSupport[] = ["supported", "warn", "refuse"];

/**
 * Checks a profile written as data, such as one read from a JSON file. Unknown keys and
 * feature ids are refused, so a typo cannot quietly turn a check off.
 */
export function parseProfile(value: unknown, where: string): ExecutionProfile {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    throw new SynthError(`${where}: a profile is a JSON object.`);
  }
  const record = value as Record<string, unknown>;
  for (const key of Object.keys(record)) {
    if (!["name", "description", "features", "appLimits"].includes(key)) {
      throw new SynthError(
        `${where}.${key}: not a profile field. A profile has name, description, features and appLimits.`,
      );
    }
  }
  if (typeof record.name !== "string" || record.name.trim() === "") {
    throw new SynthError(`${where}.name: a profile needs a name for messages to use.`);
  }
  if (record.description !== undefined && typeof record.description !== "string") {
    throw new SynthError(`${where}.description: expected text.`);
  }
  const profile: ExecutionProfile = { name: record.name };
  if (record.description !== undefined) profile.description = record.description as string;
  if (record.features !== undefined) {
    if (typeof record.features !== "object" || record.features === null) {
      throw new SynthError(`${where}.features: expected an object of feature ids.`);
    }
    const features: Partial<Record<ProfileFeatureId, FeatureSupport>> = {};
    for (const [id, support] of Object.entries(record.features)) {
      if (!Object.hasOwn(PROFILE_FEATURES, id)) {
        throw new SynthError(
          `${where}.features.${id}: not a feature synth knows. It knows ` +
            `${Object.keys(PROFILE_FEATURES).join(", ")}.`,
        );
      }
      if (!FEATURE_SUPPORT.includes(support as FeatureSupport)) {
        throw new SynthError(
          `${where}.features.${id}: expected ${FEATURE_SUPPORT.map((s) => `"${s}"`).join(", ")}.`,
        );
      }
      features[id as ProfileFeatureId] = support as FeatureSupport;
    }
    profile.features = features;
  }
  if (record.appLimits !== undefined) {
    if (typeof record.appLimits !== "object" || record.appLimits === null) {
      throw new SynthError(`${where}.appLimits: expected an object of limits.`);
    }
    const limits: Partial<AppLimits> = {};
    for (const [key, limit] of Object.entries(record.appLimits)) {
      if (!Object.hasOwn(DEFAULT_APP_LIMITS, key)) {
        throw new SynthError(
          `${where}.appLimits.${key}: not an app limit. The limits are ` +
            `${Object.keys(DEFAULT_APP_LIMITS).join(", ")}.`,
        );
      }
      checkLimit(limit, `${where}.appLimits.${key}`);
      limits[key as keyof AppLimits] = limit;
    }
    profile.appLimits = limits;
  }
  return profile;
}

/**
 * Finds a profile by built-in name, or reads one from a JSON file when the value ends in
 * `.json`.
 */
export function resolveProfile(nameOrPath: string): ExecutionProfile {
  const builtIn = BUILT_IN_PROFILES[nameOrPath];
  if (builtIn !== undefined) return builtIn;
  if (nameOrPath.endsWith(".json")) {
    let text: string;
    try {
      text = readFileSync(nameOrPath, "utf8");
    } catch {
      throw new SynthError(`--profile ${nameOrPath}: no profile file there.`);
    }
    let value: unknown;
    try {
      value = JSON.parse(text);
    } catch {
      throw new SynthError(`--profile ${nameOrPath}: the file is not valid JSON.`);
    }
    return parseProfile(value, nameOrPath);
  }
  throw new SynthError(
    `--profile ${nameOrPath}: no built-in profile has that name. The built-in profiles are ` +
      `${Object.keys(BUILT_IN_PROFILES).join(", ")}, or pass a path to a .json profile file.`,
  );
}

/**
 * Holds a realm to a profile. A refused feature stops the run with every place it is used;
 * a warned one goes to `warn` and the run carries on. The files are written either way, so a
 * realm built for one environment still carries everything another might load.
 */
export function checkProfile(
  realm: Realm,
  profile: ExecutionProfile | undefined,
  warn: (message: string) => void,
): void {
  if (profile?.features === undefined) return;
  const refusals: string[] = [];
  for (const [id, support] of Object.entries(profile.features) as [
    ProfileFeatureId,
    FeatureSupport,
  ][]) {
    if (support === "supported") continue;
    const feature: ProfileFeature = PROFILE_FEATURES[id];
    const used = feature.find(realm);
    if (used.length === 0) continue;
    if (support === "refuse") {
      refusals.push(
        `${used.join(", ")}: the "${profile.name}" profile refuses ${feature.label}. Leave them ` +
          `out to run there, or build without --profile ${profile.name} for an environment that ` +
          `supports them.`,
      );
    } else {
      warn(
        `PROFILE ${profile.name}: ${used.join(", ")} declares ${feature.label}, which this ` +
          `profile does not load. Synth still writes them, for environments that do.`,
      );
    }
  }
  if (refusals.length > 0) throw new SynthError(refusals.join("\n"));
}
