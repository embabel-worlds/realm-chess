import type { JsonValue } from "@embabel/realm-types";

/**
 * Rejects anything that has no realm wire representation, and sorts object keys.
 *
 * Two jobs, done together because they need the same walk. The rejection is the
 * important half: a definition is ordinary TypeScript, so it can hand back a function,
 * a Date, a Map or a cycle, none of which mean anything in a realm spec. Catching that
 * here, with the path to the offending value, beats emitting YAML that fails to load
 * hours later.
 *
 * Sorting is what makes a synth run reproducible: same definition, same bytes, so the
 * fingerprint that decides whether to rebuild is stable.
 */
export function canonicalize(value: unknown, path = "$", seen = new Set<object>()): JsonValue {
  if (value === null) return null;
  const t = typeof value;

  if (t === "string" || t === "boolean") return value as JsonValue;
  if (t === "number") {
    if (!Number.isFinite(value as number)) {
      throw new SynthError(`${path}: ${String(value)} cannot be represented`);
    }
    return value as number;
  }

  if (t === "undefined") throw new SynthError(`${path}: undefined is not allowed. Omit the key.`);
  if (t === "function") throw new SynthError(`${path}: a function cannot be emitted`);
  if (t === "bigint") throw new SynthError(`${path}: BigInt has no YAML representation`);
  if (t === "symbol") throw new SynthError(`${path}: a symbol cannot be emitted`);

  if (value instanceof Date) {
    throw new SynthError(
      `${path}: Date is not allowed. Emit an ISO string, or a value that does not vary per run.`,
    );
  }
  if (value instanceof Map || value instanceof Set) {
    throw new SynthError(
      `${path}: ${value.constructor.name} is not allowed. Use a plain object or array.`,
    );
  }

  if (typeof value === "object") {
    if (seen.has(value)) throw new SynthError(`${path}: circular reference`);
    seen.add(value);

    if (Array.isArray(value)) {
      const out = value.map((v, i) => canonicalize(v, `${path}[${i}]`, seen));
      seen.delete(value);
      return out;
    }

    const out: Record<string, JsonValue> = {};
    for (const key of Object.keys(value as object).sort()) {
      const v = (value as Record<string, unknown>)[key];
      if (v === undefined) continue;
      out[key] = canonicalize(v, `${path}.${key}`, seen);
    }
    seen.delete(value);
    return out;
  }

  throw new SynthError(`${path}: ${t} cannot be emitted`);
}

/** A synth failure that names where in the definition it happened. */
export class SynthError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "SynthError";
  }
}
