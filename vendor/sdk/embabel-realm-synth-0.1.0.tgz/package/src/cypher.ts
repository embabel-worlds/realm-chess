import { SynthError } from "./canonical.ts";

/**
 * A first-pass syntax check on a `vc` query.
 *
 * A broken query fails the build, so it never reaches the realm. This does the cheap
 * structural checks that catch real typos: balanced delimiters, a recognisable opening
 * clause, no stray template markers. It is deliberately not a Cypher parser.
 *
 * Neo4j publishes one (`@neo4j-cypher/language-support`) and it is where this should end
 * up. It ships prereleases only, so adopting it means pinning an exact version and
 * keeping it a build-time dependency; that swap changes this function and nothing else.
 * The deeper check, whether a label is reachable through a registered door, cannot
 * happen here at all, because it needs every installed realm's types.
 */
export function checkCypher(query: string, where: string): void {
  const text = query.trim();
  if (text.length === 0) throw new SynthError(`${where}: empty query`);

  for (const [open, close, name] of [
    ["(", ")", "parenthesis"],
    ["{", "}", "brace"],
    ["[", "]", "bracket"],
  ] as const) {
    const depth = balance(text, open, close);
    if (depth !== 0) {
      throw new SynthError(
        `${where}: unbalanced ${name} (${depth > 0 ? `${depth} unclosed` : `${-depth} unopened`})`,
      );
    }
  }

  const quotes = countUnescaped(text, "'");
  if (quotes % 2 !== 0) throw new SynthError(`${where}: unbalanced single quote`);

  const opening = /^\s*(MATCH|OPTIONAL\s+MATCH|WITH|UNWIND|CALL|RETURN|MERGE|CREATE)\b/i;
  if (!opening.test(text)) {
    throw new SynthError(
      `${where}: does not start with a Cypher reading clause (MATCH, WITH, UNWIND, CALL, RETURN)`,
    );
  }

  if (/\$\{/.test(text)) {
    throw new SynthError(`${where}: unresolved \${...}. Interpolate before tagging, or escape it.`);
  }
}

/** Depth of `open` over `close`, ignoring anything inside single quotes. */
function balance(text: string, open: string, close: string): number {
  let depth = 0;
  let inQuote = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === "'" && text[i - 1] !== "\\") inQuote = !inQuote;
    if (inQuote) continue;
    if (c === open) depth++;
    else if (c === close) depth--;
  }
  return depth;
}

function countUnescaped(text: string, ch: string): number {
  let n = 0;
  for (let i = 0; i < text.length; i++) {
    if (text[i] === ch && text[i - 1] !== "\\") n++;
  }
  return n;
}
