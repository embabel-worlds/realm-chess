import type {
  DependencyValueType,
  HandlerSpec,
  PropertySpec,
  Realm,
  TypeSpec,
} from "@embabel/realm-types";
import { SynthError } from "./canonical.ts";
import {
  bridgeModule,
  disambiguatedNames,
  gatewayOperations,
  HOST_CONTEXT,
  isMultiValued,
  type PropertyDoc,
  pascalCase,
  propertyDoc,
  syntheticNameSegment,
} from "./dts.ts";

/** The trait the dependency container gets, so `ctx.deps().db()` has something to resolve against. */
const DEPENDENCY_TRAIT = "Dependencies";

/** A known dependency module's typed bridge surface, in Rust. */
interface RustBridgeSpec {
  /** The exported trait name the bridge gets. */
  typeName: string;
  /** Doc comment placed on the exported bridge trait. */
  doc: string;
  /** Member lines emitted inside the bridge trait, already indented one level (4 spaces). */
  members: string[];
  /** Extra top-level items (enums, type aliases) the bridge's members reference, emitted right after the trait, in order. */
  extraBlocks: string[];
  /** The top-level names those extra blocks define, so the symbol table can hold them back from the realm. */
  extraNames: string[];
}

/**
 * The bridge surface for every dependency module the Rust emitter knows how to type
 * today. A module absent from this map still gets a context method, returning `&dyn
 * std::any::Any`: the real surface is defined by the module's registry entry and
 * arrives with the host mechanism, so synth cannot type it in advance. The compiled
 * guest runtime does not exist yet. Every member here describes the synchronous
 * command-mode shape the shim will expose.
 */
const BRIDGES: Record<string, RustBridgeSpec> = {
  "sqlite3-wasi": {
    typeName: "SqliteBridge",
    doc: "The bridge to a mounted SQLite dependency. State is ephemeral unless the declaration set persistent. The realm owns its database entirely.",
    members: ["    fn exec(&self, sql: &str, params: &[SqlParam]) -> Vec<SqlRow>;"],
    extraBlocks: [
      [
        "#[derive(Debug, Clone)]",
        '#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]',
        "pub enum SqlParam {",
        "    Text(String),",
        "    Int(i64),",
        "    Float(f64),",
        "    Null,",
        "}",
      ].join("\n"),
      "pub type SqlRow = std::collections::HashMap<String, SqlValue>;",
      [
        "#[derive(Debug, Clone)]",
        '#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]',
        "pub enum SqlValue {",
        "    Text(String),",
        "    Int(i64),",
        "    Float(f64),",
        "    Null,",
        "}",
      ].join("\n"),
    ],
    extraNames: ["SqlParam", "SqlRow", "SqlValue"],
  },
};

/**
 * The Rust spelling of one dependency method's argument or return type. `i64` reads as
 * `String`, the same as every other guest language, even though Rust's own `i64` could
 * carry the value exactly: the host still marshals it as a decimal-digit string on the
 * wire, because a JSON number is an IEEE double wherever the *other* guest languages
 * read it, and the wire format is the same for every runtime. `string` is text and reads
 * as `String` too. `i32`, `f32` and `f64` carry over natively. {@link DependencyValueType} is the exhaustive list, so this
 * switch needs no default.
 */
function rustValueType(type: DependencyValueType): string {
  switch (type) {
    case "i32":
      return "i32";
    case "i64":
    case "string":
      return "String";
    case "f32":
      return "f32";
    case "f64":
      return "f64";
  }
}

/**
 * The names the generated module always defines itself, whatever the realm declares.
 *
 * `Dependencies` is only written when the realm declares a dependency, but it is held
 * back either way, so a realm that is valid today stays valid the day it adds its
 * first dependency.
 */
const MODULE_NAMES = ["Dependencies", "Gateway", "HandlerContext"];

/** Every Rust 2021 keyword a generated identifier could collide with, strict and reserved alike. */
const RUST_KEYWORDS = new Set([
  "as",
  "break",
  "const",
  "continue",
  "crate",
  "dyn",
  "else",
  "enum",
  "extern",
  "false",
  "fn",
  "for",
  "if",
  "impl",
  "in",
  "let",
  "loop",
  "match",
  "mod",
  "move",
  "mut",
  "pub",
  "ref",
  "return",
  "self",
  "Self",
  "static",
  "struct",
  "super",
  "trait",
  "true",
  "type",
  "unsafe",
  "use",
  "where",
  "while",
  "async",
  "await",
  "abstract",
  "become",
  "box",
  "do",
  "final",
  "macro",
  "override",
  "priv",
  "try",
  "typeof",
  "unsized",
  "virtual",
  "yield",
]);

/**
 * The four keywords Rust refuses to write as a raw identifier. Every other keyword
 * takes an `r#` prefix and compiles, `r#extern` and `r#type` included; these four fail
 * with "`self` cannot be a raw identifier", so a name that lands on one of them is
 * refused with the path that declared it.
 */
const NON_RAW_KEYWORDS = new Set(["Self", "crate", "self", "super"]);

/** The shape a bare Rust identifier has. Every name this emitter writes has already been folded into this alphabet, so a name that fails here carried something no conversion could rescue. */
const RS_IDENTIFIER = /^[A-Za-z_][A-Za-z0-9_]*$/;

/** A field or method type carrying raw JSON text, doc-commented so a reader knows why. */
const RAW_JSON_FIELD_DOC = "Raw JSON text. This field's shape is not modeled yet.";

/** A handler input or output type carrying raw JSON text, for a schema this emitter cannot model. */
const RAW_JSON_TYPE_DOC = "Raw JSON text. This schema is not modeled yet.";

/**
 * Every string below comes from the realm definition, and a definition can put
 * anything in a description, a module id, an operation id or a realm name. These
 * functions are where that text gets made safe before it lands in generated Rust, so
 * nobody has to remember to escape it at each call site.
 */

/** Collapses newlines, so definition text can never break out of a single-line comment. */
function escapeLineComment(text: string): string {
  return text.replace(/[\r\n]+/g, " ");
}

/** Folds CRLF and CR line endings to LF, so a multi-line description becomes one `///` line per source line and never smuggles a raw carriage return into the file. */
function foldLineEndings(text: string): string {
  return text.replace(/\r\n?/g, "\n");
}

/** Escapes a value going inside a Rust string literal: folds newlines to spaces, then escapes backslashes and double quotes. */
function escapeRustString(text: string): string {
  return escapeLineComment(text).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

/** A `///` doc comment for `text`, as lines indented by `indent`. Rust doc comments run to end of line, so a description can carry any text without escaping; a literal newline in it just becomes another `///` line. */
function rustDoc(text: string, indent = ""): string[] {
  const body = foldLineEndings(text.trim()).split("\n");
  return body.map((line) => `${indent}/// ${line}`.trimEnd());
}

/**
 * A realm names things in JSON and TypeScript terms, and this emitter writes those
 * names into Rust source. The two vocabularies do not line up: `type` is a fine JSON
 * key and a Rust keyword, `fooBar` and `foo_bar` are two distinct JSON keys that
 * snake_case folds into one Rust field, and a name carrying a newline can close the
 * line it sits on. Everything below is the gate that keeps such a name out of the
 * generated module, applied here at the emitter boundary so a caller reaching for
 * `emitRustTypes` directly gets the same refusals a full synth run gets.
 */

/**
 * `name` as the identifier the generated module writes, or a `SynthError` naming the
 * path and the offending name when Rust has no way to carry it.
 *
 * A keyword gets the `r#` prefix, which is how Rust writes a name it also reads as a
 * keyword. Four keywords have no raw form at all, and `_` on its own is the wildcard
 * pattern, so those are refused.
 */
function rustIdentifier(name: string, where: string, describe: string): string {
  if (!RS_IDENTIFIER.test(name) || name === "_") {
    throw new SynthError(
      `${where}: "${escapeLineComment(name)}" is not a valid Rust identifier for ${describe}. A generated name carries letters, digits and underscores, and it opens with a letter or an underscore.`,
    );
  }
  if (NON_RAW_KEYWORDS.has(name)) {
    throw new SynthError(
      `${where}: "${name}" is a Rust keyword with no raw form, so the generated module has no way to write ${describe}.`,
    );
  }
  return RUST_KEYWORDS.has(name) ? `r#${name}` : name;
}

/**
 * Every name the generated module defines at the top level, and what put it there.
 *
 * Rust does report a duplicate definition, but that error lands in the handler author's
 * build with nothing to say about which two parts of the realm met. The realm has
 * several places that mint a top-level name (domain types, gateway traits, per-handler
 * input and output types, nested structs synthesized from a schema), and this is the
 * table that catches a clash while there is still a synth run to fail, with both
 * sources named.
 */
class RustSymbols {
  private readonly sources = new Map<string, string>();

  /** Claims a name the generated module owns in every run. */
  reserve(name: string): void {
    this.sources.set(name, "a name the generated module reserves");
  }

  /** Claims a name for `describe`, throwing when something else already holds it. */
  declare(name: string, where: string, describe: string): void {
    const existing = this.sources.get(name);
    if (existing !== undefined) {
      throw new SynthError(`${where}: the generated name "${name}" collides with ${existing}.`);
    }
    this.sources.set(name, describe);
  }
}

/**
 * The field or method names one struct or trait has already used.
 *
 * snake_case folds distinct JSON names together: "fooBar" and "foo_bar" both come out
 * as "foo_bar", and `$a` and `_a` both come out as "_a". Rust calls that a duplicate
 * field or a duplicate method, in the handler author's build. This calls it first, and
 * names both of the declarations that produced it.
 */
class MemberNames {
  private readonly taken = new Map<string, string>();

  /** Claims one member name for `source`, throwing when another source already produced it. */
  claim(ident: string, source: string, kind: "field" | "method", where: string): void {
    const existing = this.taken.get(ident);
    if (existing !== undefined) {
      throw new SynthError(
        `${where}: the generated ${kind} "${ident}" is claimed by both ${existing} and ${source}.`,
      );
    }
    this.taken.set(ident, source);
  }
}

/** What one emitter run accumulates: the top-level names it has defined so far. */
interface RustEmission {
  symbols: RustSymbols;
}

/** The names the module holds back from the realm: the traits it always writes, and every bridge trait and bridge helper type it knows how to write. The list is fixed, so a realm that is valid today stays valid when a later realm adds the dependency that pulls one of these in. */
function reservedNames(): string[] {
  const names = new Set<string>(MODULE_NAMES);
  for (const bridge of Object.values(BRIDGES)) {
    names.add(bridge.typeName);
    for (const extra of bridge.extraNames) names.add(extra);
  }
  return [...names].sort();
}

/**
 * `doc` composed into one doc comment body: the description, a "Deprecated." line,
 * then the facet lines, in the fixed order every emitter carries them. `undefined`
 * when there is nothing to say. `rustDoc` folds whatever comes back here safely, one
 * `///` per resulting line, so nothing needs escaping ahead of time: any character a
 * schema puts in a description or a facet value, an embedded newline included, stays
 * inert and lands as its own doc-comment line.
 */
function rustFieldDocText(doc: PropertyDoc): string | undefined {
  const lines: string[] = [];
  if (doc.description) lines.push(doc.description.trim());
  if (doc.deprecated) lines.push("Deprecated.");
  lines.push(...doc.facetLines);
  return lines.length > 0 ? lines.join("\n") : undefined;
}

/**
 * Converts a JSON property, operation, or dependency name to a Rust-idiomatic
 * snake_case identifier. "imdbId" becomes "imdb_id"; "text" is unchanged.
 */
function toSnakeCase(name: string): string {
  let out = name
    .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
    .replace(/([A-Z]+)([A-Z][a-z])/g, "$1_$2")
    .toLowerCase();
  out = out.replace(/[^a-z0-9_]/g, "_");
  if (!/^[a-z_]/.test(out)) out = `_${out}`;
  return out;
}

/**
 * A JSON property or dependency name, resolved to the Rust field or method identifier
 * it gets and whether that identifier needs a `serde(rename = "...")` to keep the wire
 * name intact. Renaming is needed whenever the identifier reads differently from the
 * wire name, which covers both a spelling snake_case changed and a name carrying the
 * `r#` prefix the wire format must not see.
 */
function rustMemberName(
  jsonName: string,
  where: string,
  describe: string,
): { ident: string; rename: boolean } {
  const ident = rustIdentifier(toSnakeCase(jsonName), where, describe);
  return { ident, rename: ident !== jsonName };
}

/** The plain form of a name, for building a nested type name from it. A parent struct written `r#type` prefixes its children with "type". */
function namePrefix(name: string): string {
  return name.startsWith("r#") ? name.slice(2) : name;
}

/**
 * Generates the Rust a realm's handlers import, for a realm declared `runtime:
 * "compiled"` with a `--types <path>.rs` output.
 *
 * This is the Rust counterpart to `emitPythonTypes`: the same declaration, walked the
 * same way, landing as `struct`s and a `HandlerContext` trait a Rust handler compiles
 * against. A hand-written surface can drift from the realm. This one cannot: it comes
 * from the same declaration. Serde derives sit behind a `serde` feature so the module
 * typechecks with no crate dependencies at all; a build that wants JSON (de)serialization
 * turns the feature on.
 */
export function emitRustTypes(realm: Realm): string {
  const em: RustEmission = { symbols: new RustSymbols() };
  for (const name of reservedNames()) em.symbols.reserve(name);
  const blocks: string[] = [];

  const typeNames = Object.keys(realm.types ?? {}).sort();
  for (const name of typeNames) {
    const where = `$.types.${name}`;
    const structName = rustIdentifier(name, where, "a generated struct");
    em.symbols.declare(structName, where, `the domain type "${name}"`);
    const spec = (realm.types as Record<string, TypeSpec>)[name] as TypeSpec;
    blocks.push(emitDomainStruct(structName, spec, where).join("\n"));
  }

  const dependencyEntries = Object.entries(realm.dependencies ?? {}).sort(([a], [b]) =>
    a < b ? -1 : a > b ? 1 : 0,
  );
  const usedBridgeIds = new Set<string>();
  for (const [, spec] of dependencyEntries) {
    if (BRIDGES[bridgeModule(spec)]) usedBridgeIds.add(bridgeModule(spec));
  }
  for (const moduleId of [...usedBridgeIds].sort()) {
    const bridge = BRIDGES[moduleId] as RustBridgeSpec;
    blocks.push(
      [...rustDoc(bridge.doc), `pub trait ${bridge.typeName} {`, ...bridge.members, "}"].join("\n"),
    );
    for (const extra of bridge.extraBlocks) blocks.push(extra);
  }

  // A dependency outside the built-in BRIDGES map still gets a real, typed bridge when
  // the realm declares the methods it calls on it: the operator's allowlist owns the
  // module's actual surface, not this package, so the only surface synth can type in
  // advance is exactly what the realm says it uses. One trait per dependency key, not
  // per module, because two declarations of the same module can each call a different
  // subset of it.
  const declaredBridgeTypes = new Map<string, string>();
  for (const [key, spec] of dependencyEntries) {
    if (BRIDGES[bridgeModule(spec)] || !spec.methods || Object.keys(spec.methods).length === 0)
      continue;
    const where = `$.dependencies.${key}.methods`;
    const traitName = rustIdentifier(`${pascalCase(key)}Bridge`, where, "a generated bridge trait");
    em.symbols.declare(traitName, where, `the bridge generated for the "${key}" dependency`);
    declaredBridgeTypes.set(key, traitName);
    const methods = new MemberNames();
    const lines = [
      ...rustDoc(
        `The bridge to the "${spec.module}" dependency, typed from exactly the methods this realm declares it calls.`,
      ),
      `pub trait ${traitName} {`,
    ];
    for (const methodName of Object.keys(spec.methods).sort()) {
      const methodWhere = `${where}.${methodName}`;
      const { ident } = rustMemberName(methodName, methodWhere, "a dependency bridge method");
      methods.claim(ident, `the method "${methodName}"`, "method", where);
      const method = spec.methods[methodName];
      const args = (method?.args ?? [])
        .map((argType, i) => `, arg${i}: ${rustValueType(argType)}`)
        .join("");
      lines.push(
        `    fn ${ident}(&self${args}) -> ${rustValueType(method?.returns as DependencyValueType)};`,
      );
    }
    lines.push("}");
    blocks.push(lines.join("\n"));
  }

  const operations = gatewayOperations(realm);
  const namespaces = new Map<string, Set<string>>();
  const bare = new Set<string>();
  for (const op of operations) {
    if (op.includes(".")) {
      const [ns, opName] = op.split(".", 2) as [string, string];
      if (!namespaces.has(ns)) namespaces.set(ns, new Set());
      (namespaces.get(ns) as Set<string>).add(opName);
    } else {
      bare.add(op);
    }
  }

  if (operations.length > 0) {
    // Two namespaces differing only in case ("foo" and "Foo") both pascalCase to "Foo",
    // and the host installs and dispatches them separately — so this has to name them
    // apart rather than pick whichever happened to build second and let that one fail.
    // `disambiguatedNames` decides every namespace's base at once, sorted, the same rule
    // the TypeScript emitter applies to its gateway interfaces, so a realm's Rust and
    // TypeScript surfaces land on identical names for the same namespaces.
    const gatewayBases = disambiguatedNames([...namespaces.keys()], pascalCase);
    const traitNames = new Map<string, string>();
    for (const ns of [...namespaces.keys()].sort()) {
      const where = `gateway namespace "${ns}"`;
      const traitName = rustIdentifier(
        `${gatewayBases.get(ns)}Gateway`,
        where,
        "a generated gateway trait",
      );
      em.symbols.declare(traitName, where, `the gateway trait generated for "${ns}"`);
      traitNames.set(ns, traitName);
      const methods = new MemberNames();
      const ops = namespaces.get(ns) as Set<string>;
      // Two op names in the same namespace differing only in case ("Foo" and "foo") both
      // fold to the same snake_case method name, so they get the same counted-suffix
      // disambiguation the namespace names above already get, rather than the second one
      // failing the build.
      const methodNames = disambiguateCaseCollisions(ops, toSnakeCase);
      const nsLines = [`pub trait ${traitName} {`];
      for (const op of [...ops].sort()) {
        nsLines.push(
          ...gatewayMethod(`${ns}.${op}`, methodNames.get(op) as string, methods, where),
        );
      }
      nsLines.push("}");
      blocks.push(nsLines.join("\n"));
    }

    // snake_case folds case away entirely, so "foo" and "Foo" would also collide as the
    // accessor method that reaches each one — a second place the same case-only clash
    // shows up, disambiguated by the same rule so the accessor and the trait it returns
    // stay a matched, deterministic pair.
    const gatewayAccessors = disambiguatedNames([...namespaces.keys()], toSnakeCase);
    const gatewayMethods = new MemberNames();
    // Bare (non-namespaced) op names share this same method table with the namespace
    // accessors below, so a case-only clash among them needs the same disambiguation.
    const bareNames = disambiguateCaseCollisions(bare, toSnakeCase);
    const gatewayLines = ["pub trait Gateway {"];
    for (const op of [...bare].sort()) {
      gatewayLines.push(
        ...gatewayMethod(
          op,
          bareNames.get(op) as string,
          gatewayMethods,
          `gateway operation "${op}"`,
        ),
      );
    }
    for (const ns of [...namespaces.keys()].sort()) {
      const where = `gateway namespace "${ns}"`;
      const accessor = rustIdentifier(
        gatewayAccessors.get(ns) as string,
        where,
        "a gateway accessor method",
      );
      gatewayMethods.claim(accessor, `the namespace "${ns}"`, "method", "the Gateway trait");
      gatewayLines.push(
        ...rustDoc(`Reaches the "${ns}" namespace of the gateway.`, "    "),
        `    fn ${accessor}(&self) -> &dyn ${traitNames.get(ns) as string};`,
      );
    }
    gatewayLines.push("}");
    blocks.push(gatewayLines.join("\n"));
  }

  // Dependencies get their own trait and reach the context through a single `deps()`
  // accessor, rather than one accessor each on the context trait. The author picks
  // those names and the host picks every other method on the context, so keeping them
  // in separate traits is what stops a built-in added later from colliding with a name
  // a realm already uses. HOST_CONTEXT has the longer version. A realm with no
  // dependencies writes no trait and no accessor, so its module is unchanged.
  if (dependencyEntries.length > 0) {
    const depMethods = new MemberNames();
    const depLines = [
      ...rustDoc("The dependencies this realm declared, each under the name it was declared with."),
      `pub trait ${DEPENDENCY_TRAIT} {`,
    ];
    let first = true;
    for (const [key, spec] of dependencyEntries) {
      const where = `$.dependencies.${key}`;
      const bridge = BRIDGES[bridgeModule(spec)];
      const { ident } = rustMemberName(key, where, "a dependency accessor method");
      depMethods.claim(ident, `the dependency "${key}"`, "method", `the ${DEPENDENCY_TRAIT} trait`);
      if (!first) depLines.push("");
      first = false;
      const declaredTrait = declaredBridgeTypes.get(key);
      if (bridge) {
        depLines.push(`    fn ${ident}(&self) -> &dyn ${bridge.typeName};`);
      } else if (declaredTrait) {
        depLines.push(`    fn ${ident}(&self) -> &dyn ${declaredTrait};`);
      } else {
        depLines.push(
          ...rustDoc(
            `The bridge surface for "${spec.module}" is defined by the module's registry entry and arrives with the host mechanism.`,
            "    ",
          ),
          `    fn ${ident}(&self) -> &dyn std::any::Any;`,
        );
      }
    }
    depLines.push("}");
    blocks.push(depLines.join("\n"));
  }

  const contextMethods = new MemberNames();
  const ctxLines = [
    ...rustDoc("What the host passes a handler as its second argument."),
    "pub trait HandlerContext {",
    ...rustDoc("Writes a line to the host log, attributed to this realm.", "    "),
    "    fn log(&self, message: &str);",
  ];
  contextMethods.claim("log", "the host log method", "method", "the HandlerContext trait");
  if (operations.length > 0) {
    contextMethods.claim("gateway", "the gateway accessor", "method", "the HandlerContext trait");
    ctxLines.push(
      "",
      ...rustDoc(
        "Calls out through the host. Credentials stay host-side: the guest never sees an API key, and the host injects it on the way out.",
        "    ",
      ),
      "    fn gateway(&self) -> &dyn Gateway;",
    );
  }
  if (dependencyEntries.length > 0) {
    contextMethods.claim(
      HOST_CONTEXT.dependencyContainer,
      "the dependency container accessor",
      "method",
      "the HandlerContext trait",
    );
    ctxLines.push(
      "",
      ...rustDoc(
        "The dependencies this realm declared. They live in their own trait so an author's chosen name can never collide with a context method the host adds later.",
        "    ",
      ),
      `    fn ${HOST_CONTEXT.dependencyContainer}(&self) -> &dyn ${DEPENDENCY_TRAIT};`,
    );
  }
  ctxLines.push("}");
  blocks.push(ctxLines.join("\n"));

  const handlers = realm.handlers ?? {};
  const handlerNames = Object.keys(handlers).sort();
  if (handlerNames.length > 0) {
    // Every per-handler name is claimed before any handler is emitted, so a collision
    // between two handlers is reported the same way whichever one is walked first.
    for (const name of handlerNames) {
      const where = `$.handlers.${name}`;
      const stem = pascalCase(name);
      for (const [suffix, describe] of [
        ["Input", "the input type"],
        ["Output", "the output type"],
        ["Handler", "the handler alias"],
      ] as const) {
        const generated = rustIdentifier(`${stem}${suffix}`, where, "a generated type name");
        em.symbols.declare(generated, where, `${describe} generated for the ${name} handler`);
      }
    }

    for (const name of handlerNames) {
      const spec = handlers[name] as HandlerSpec;
      const stem = pascalCase(name);
      blocks.push(
        handlerType(
          spec.input,
          `${stem}Input`,
          "input",
          em,
          `$.handlers.${name}.input`,
          `Input for the ${name} handler.`,
        ).join("\n"),
      );
      blocks.push(
        handlerType(spec.output, `${stem}Output`, "output", em, `$.handlers.${name}.output`).join(
          "\n",
        ),
      );
    }

    const aliasLines: string[] = [];
    for (const name of handlerNames) {
      const stem = pascalCase(name);
      aliasLines.push(
        `pub type ${stem}Handler = fn(${stem}Input, &dyn HandlerContext) -> ${stem}Output;`,
      );
    }
    blocks.push(aliasLines.join("\n"));
  }

  const header = [
    "// Generated from realm.ts by @embabel/realm-synth. Do not edit.",
    `// Realm: ${escapeLineComment(realm.name)} (${escapeLineComment(realm.version)})`,
  ];

  return `${header.join("\n")}\n\n${blocks.join("\n\n\n")}\n`;
}

/**
 * Disambiguates only the names in `names` that collide purely because `toName` folds their
 * case away — "Foo" and "foo" both landing on "foo", the same clash the namespace names
 * above already get a counted suffix for. A collision between two names that are not case
 * variants of each other ("getMovie" and "get_movie" both folding to "get_movie") is a real,
 * distinct name clash rather than a case artifact, so this leaves those alone and lets
 * `MemberNames.claim` refuse it, same as it always has.
 */
function disambiguateCaseCollisions(
  names: Iterable<string>,
  toName: (name: string) => string,
): Map<string, string> {
  const groups = new Map<string, string[]>();
  for (const name of names) {
    const folded = toName(name).toLowerCase();
    const group = groups.get(folded);
    if (group) group.push(name);
    else groups.set(folded, [name]);
  }
  const result = new Map<string, string>();
  const taken = new Set<string>();
  // Every plain (non-case-variant) name is reserved first. It comes from the same complete
  // set of names as any case-variant group, so a counted suffix that happens to match another
  // operation's own ordinary name -- "foo2" is its own operation here, not a spare slot for
  // "foo" -- is exactly the collision this function exists to prevent, the same clash
  // MemberNames.claim() would otherwise catch downstream by refusing the build.
  for (const group of groups.values()) {
    const first = group[0] as string;
    const pureCaseVariants = group.every((name) => name.toLowerCase() === first.toLowerCase());
    if (group.length === 1 || !pureCaseVariants) {
      for (const name of group) {
        const plain = toName(name);
        result.set(name, plain);
        taken.add(plain);
      }
    }
  }
  for (const group of groups.values()) {
    const first = group[0] as string;
    const pureCaseVariants = group.every((name) => name.toLowerCase() === first.toLowerCase());
    if (group.length > 1 && pureCaseVariants) {
      // Sorted the same way `disambiguatedNames` sorts a namespace's own names, so the
      // earliest name in the group keeps the plain spelling and each later one takes the next
      // counted suffix `taken` doesn't already hold -- whether that suffix was already taken
      // by another case-variant group or by a plain, unrelated operation name.
      for (const name of [...group].sort()) {
        const candidate = toName(name);
        let unique = candidate;
        for (let n = 2; taken.has(unique); n += 1) unique = `${candidate}${n}`;
        taken.add(unique);
        result.set(name, unique);
      }
    }
  }
  return result;
}

/**
 * One gateway method: a doc comment naming the raw-JSON contract, then the signature.
 * `fullOpId` is the dotted id the host resolves at install; `methodName` is already the
 * snake_case identifier the caller decided on for it — pre-decided rather than derived here,
 * because two op names differing only in case ("Foo" and "foo") both fold to the same
 * snake_case text, and the caller has to disambiguate that across the whole set of names it
 * is naming at once, not one call at a time.
 */
function gatewayMethod(
  fullOpId: string,
  methodName: string,
  methods: MemberNames,
  where: string,
): string[] {
  const method = rustIdentifier(methodName, where, "a gateway method");
  methods.claim(method, `the operation "${fullOpId}"`, "method", where);
  return [
    ...rustDoc(
      `Calls the "${fullOpId}" gateway operation. Argument and result are raw JSON text; this operation's schema is not modeled yet.`,
      "    ",
    ),
    `    fn ${method}(&self, args: &str) -> String;`,
  ];
}

/** A declared domain type, as a `pub struct`. Property mapping mirrors `tsType` in dts.ts and `domainPyType` in pytypes.ts. */
function emitDomainStruct(name: string, spec: TypeSpec, where: string): string[] {
  const fieldLines: string[] = [];
  const fields = new MemberNames();
  for (const property of Object.keys(spec.properties).sort()) {
    const declared = spec.properties[property] as PropertySpec;
    const description = typeof declared === "string" ? declared : declared.description;
    const optional = domainOptional(declared);
    const rustType = domainRustType(declared);
    const { ident, rename } = rustMemberName(property, where, "a struct field");
    fields.claim(ident, `the property "${property}"`, "field", where);
    fieldLines.push(...emitField(ident, property, rename, rustType, optional, description));
  }
  return emitStruct(name, spec.description, fieldLines);
}

/**
 * A domain property is required when it is the identity or says so. Everything else is
 * optional: a realm materializes records from sources that routinely omit fields, and a
 * type that claims otherwise would make handlers lie about what they have.
 */
function domainOptional(spec: PropertySpec): boolean {
  if (typeof spec === "string") return true;
  return !(spec.identity === true || spec.required === true);
}

/**
 * A domain property with no declared type, or one this doesn't recognize, is treated as
 * text, the same default dts.ts and pytypes.ts use. A LIST or SET property becomes a
 * `Vec<...>`, so the Rust side sees the same arity the graph holds.
 */
function domainRustType(spec: PropertySpec): string {
  if (typeof spec === "string") return "String";
  const scalar = rustScalar(spec.type);
  return isMultiValued(spec) ? `Vec<${scalar}>` : scalar;
}

function rustScalar(type: string | undefined): string {
  switch (type) {
    case "int":
      return "i64";
    case "number":
      return "f64";
    case "boolean":
      return "bool";
    default:
      return "String";
  }
}

/**
 * A handler's input or output schema, as the Rust the handler compiles against.
 *
 * The shape follows what the other two emitters do with the same schema. An object
 * schema with properties becomes a named `pub struct`. A scalar or an array becomes a
 * named type alias, so a handler taking a bare string is typed as taking a bare string
 * and a handler returning a list of integers is typed as returning `Vec<i64>`. An input
 * that is absent, empty or unrecognized becomes an empty struct, which is the Rust
 * reading of "no fields", and an output in that position becomes an alias for `String`
 * carrying raw JSON, which is what this emitter falls back to everywhere it cannot
 * model a schema.
 *
 * The name is always emitted, because the per-verb alias references it either way.
 */
function handlerType(
  schema: unknown,
  name: string,
  role: "input" | "output",
  em: RustEmission,
  where: string,
  doc?: string,
): string[] {
  const obj =
    schema && typeof schema === "object" ? (schema as Record<string, unknown>) : undefined;
  const type = typeof obj?.type === "string" ? (obj.type as string) : undefined;

  if (type === "object") {
    const properties = (obj?.properties as Record<string, unknown> | undefined) ?? {};
    const required = (obj?.required as string[] | undefined) ?? [];
    if (Object.keys(properties).length > 0) {
      return buildStruct(name, properties, required, em, where, doc);
    }
  } else if (type !== undefined) {
    const walked = walkRustType(schema, name, em, where);
    if (!walked.fallback) return aliasBlock(name, walked.type, walked.nested, doc);
  }

  if (role === "input") return emitStruct(name, doc, []);
  return aliasBlock(name, "String", [], doc ? `${doc}\n\n${RAW_JSON_TYPE_DOC}` : RAW_JSON_TYPE_DOC);
}

/** A named type alias, preceded by any nested structs the alias names. */
function aliasBlock(name: string, target: string, nested: string[][], doc?: string): string[] {
  const lines: string[] = [];
  for (const block of nested) lines.push(...block, "", "");
  if (doc) lines.push(...rustDoc(doc));
  lines.push(`pub type ${name} = ${target};`);
  return lines;
}

/** What one property's schema resolved to: the Rust type, whether the walk gave up on it, and any nested struct block it needs defined ahead of it. */
interface Walked {
  type: string;
  fallback: boolean;
  nested: string[][];
}

/**
 * The subset of JSON Schema `jsonSchemaToTsType` in dts.ts supports, walked the same
 * way, landing as a Rust type: string/integer/number/boolean, arrays, and nested
 * objects (each becoming its own named struct, defined ahead of whatever references
 * it). A schema this walk cannot resolve, at any point in an array's item chain,
 * falls back to a plain `String` carrying raw JSON text. A partially typed `Vec`
 * whose items nobody can name is not a type worth generating.
 * Unlike TypeScript's `enum` narrowing, a Rust `String` field stays `String` even
 * when its schema declares one: a real enum needs serde rename plumbing this walk
 * does not build, so the allowed values are listed in the field's doc comment
 * instead, in `buildStruct`, which is also where the rest of a field's documentation
 * gets attached. This walk only resolves the type each field gets.
 */
function walkRustType(
  schema: unknown,
  syntheticName: string,
  em: RustEmission,
  where: string,
): Walked {
  if (!schema || typeof schema !== "object") return { type: "String", fallback: true, nested: [] };
  const obj = schema as Record<string, unknown>;
  const type = obj.type as string | undefined;
  if (!type) return { type: "String", fallback: true, nested: [] };

  if (type === "string") return { type: "String", fallback: false, nested: [] };
  if (type === "integer") return { type: "i64", fallback: false, nested: [] };
  if (type === "number") return { type: "f64", fallback: false, nested: [] };
  if (type === "boolean") return { type: "bool", fallback: false, nested: [] };

  if (type === "array") {
    const items = obj.items as Record<string, unknown> | undefined;
    const itemResult = walkRustType(items, `${syntheticName}Item`, em, `${where}.items`);
    if (itemResult.fallback) return { type: "String", fallback: true, nested: [] };
    return { type: `Vec<${itemResult.type}>`, fallback: false, nested: itemResult.nested };
  }

  if (type === "object") {
    const properties = obj.properties as Record<string, unknown> | undefined;
    const required = (obj.required as string[] | undefined) ?? [];
    if (!properties || Object.keys(properties).length === 0) {
      return { type: "String", fallback: true, nested: [] };
    }
    const structName = rustIdentifier(syntheticName, where, "a generated struct");
    em.symbols.declare(structName, where, `the nested type generated for ${where}`);
    return {
      type: structName,
      fallback: false,
      nested: [buildStruct(structName, properties, required, em, where)],
    };
  }

  return { type: "String", fallback: true, nested: [] };
}

/** One `pub struct`, as its lines in emission order: any nested structs its own fields need, then the struct itself. */
function buildStruct(
  name: string,
  properties: Record<string, unknown>,
  required: string[],
  em: RustEmission,
  where: string,
  doc?: string,
): string[] {
  const childBlocks: string[][] = [];
  const fieldLines: string[] = [];
  const fields = new MemberNames();
  const prefix = namePrefix(name);
  for (const prop of Object.keys(properties).sort()) {
    const propSchema = properties[prop];
    const isRequired = required.includes(prop);
    const { ident, rename } = rustMemberName(prop, where, "a struct field");
    fields.claim(ident, `the property "${prop}"`, "field", where);
    const walked = walkRustType(
      propSchema,
      `${prefix}${syntheticNameSegment(prop)}`,
      em,
      `${where}.properties.${prop}`,
    );
    const fieldDoc = propertyDoc(propSchema);
    const docText = rustFieldDocText(fieldDoc);
    if (walked.fallback) {
      const combinedDoc = docText ? `${docText}\n\n${RAW_JSON_FIELD_DOC}` : RAW_JSON_FIELD_DOC;
      fieldLines.push(
        ...emitField(ident, prop, rename, "String", !isRequired, combinedDoc, fieldDoc.deprecated),
      );
    } else {
      childBlocks.push(...walked.nested);
      fieldLines.push(
        ...emitField(ident, prop, rename, walked.type, !isRequired, docText, fieldDoc.deprecated),
      );
    }
  }

  const lines: string[] = [];
  for (const block of childBlocks) lines.push(...block, "", "");
  lines.push(...emitStruct(name, doc, fieldLines));
  return lines;
}

/**
 * One struct field: an optional doc comment, a `#[deprecated]` attribute when the
 * property says so, an optional `cfg_attr` carrying the serde rename and/or
 * skip-if-absent, then the field itself. `#[deprecated]` is always safe to write here:
 * it is a plain attribute on a plain field, with no serde plumbing to get wrong.
 */
function emitField(
  ident: string,
  jsonName: string,
  rename: boolean,
  rustType: string,
  optional: boolean,
  doc?: string,
  deprecated = false,
): string[] {
  const lines: string[] = [];
  if (doc) lines.push(...rustDoc(doc, "    "));
  if (deprecated) lines.push("    #[deprecated]");
  const attrs: string[] = [];
  if (rename) attrs.push(`rename = "${escapeRustString(jsonName)}"`);
  if (optional) attrs.push('skip_serializing_if = "Option::is_none"');
  if (attrs.length > 0)
    lines.push(`    #[cfg_attr(feature = "serde", serde(${attrs.join(", ")}))]`);
  lines.push(`    pub ${ident}: ${optional ? `Option<${rustType}>` : rustType},`);
  return lines;
}

/** One `pub struct`: an optional doc comment, the derive lines every generated struct carries, then the struct body. `serde`'s own derives stay feature-gated so the module typechecks with no crate dependencies. */
function emitStruct(name: string, doc: string | undefined, fieldLines: string[]): string[] {
  const lines: string[] = [];
  if (doc) lines.push(...rustDoc(doc));
  lines.push(
    "#[derive(Debug, Clone)]",
    '#[cfg_attr(feature = "serde", derive(serde::Serialize, serde::Deserialize))]',
  );
  if (fieldLines.length === 0) {
    lines.push(`pub struct ${name} {}`);
  } else {
    lines.push(`pub struct ${name} {`, ...fieldLines, "}");
  }
  return lines;
}
