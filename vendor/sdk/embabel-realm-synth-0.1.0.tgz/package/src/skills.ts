import { createHash } from "node:crypto";
import { existsSync, readdirSync, readFileSync, realpathSync, statSync } from "node:fs";
import { join } from "node:path";
import { parse as parseYaml } from "yaml";
import { SynthError } from "./canonical.ts";

/**
 * Where the bundle carries each skill's digest, for admission to check against the copied
 * files. `dist/` is where the handler bundle lives, and the host reads nothing else there by
 * name apart from `manifest.json` and `handlers.wasm`.
 */
export const SKILL_DIGESTS_PATH = "dist/skills.json";

/**
 * A skill's name, which is also its folder. The Agent Skills rule: lowercase letters, digits
 * and single hyphens, at most 64 characters. It also keeps the name a single plain folder.
 */
const SKILL_NAME = /^[a-z0-9]+(-[a-z0-9]+)*$/;

/** One file of a skill folder, relative to the realm root, with its bytes. */
export interface SkillFile {
  path: string;
  bytes: Buffer;
}

/** What checking a realm's declared skills produced. */
export interface CapturedSkills {
  /** Every file to copy into the bundle, as found. */
  files: SkillFile[];
  /** Each skill's folder digest, keyed by skill name, in declaration order. */
  digest: Record<string, string>;
}

/**
 * The sha256 of one skill folder: each file's path inside the folder, a NUL, the hex sha256
 * of its bytes and a newline, for every file in byte order of path, hashed together. Hashing
 * the paths as well as the contents means a renamed reference file changes the digest too.
 */
export function skillDigest(files: readonly { path: string; bytes: Buffer }[]): string {
  const sorted = [...files].sort((a, b) =>
    Buffer.compare(Buffer.from(a.path), Buffer.from(b.path)),
  );
  const hash = createHash("sha256");
  for (const file of sorted) {
    hash.update(`${file.path}\0${createHash("sha256").update(file.bytes).digest("hex")}\n`);
  }
  return hash.digest("hex");
}

/**
 * Checks every skill a captured realm names and reads its folder, ready to copy as it is.
 * Synth never rewrites skill text: the bytes read here are the bytes shipped and hashed.
 *
 * `contain` resolves a path through any symlink and refuses one that lands outside the realm.
 */
export function checkCapturedSkills(
  names: readonly string[],
  realmRoot: string,
  contain: (absPath: string, label: string) => string,
): CapturedSkills {
  const files: SkillFile[] = [];
  const digest: Record<string, string> = {};
  names.forEach((name, i) => {
    const where = `$.skills[${i}]`;
    if (typeof name !== "string" || name.length > 64 || !SKILL_NAME.test(name)) {
      throw new SynthError(
        `${where}: ${JSON.stringify(name)} is not a skill name. It names the folder under skills/, ` +
          `so it is lowercase letters, digits and single hyphens, at most 64 characters.`,
      );
    }
    if (Object.hasOwn(digest, name)) {
      throw new SynthError(`${where}: "${name}" is already declared.`);
    }
    const folder = `skills/${name}`;
    const folderAbs = join(realmRoot, folder);
    if (
      !existsSync(folderAbs) ||
      !statSync(contain(folderAbs, `${where} "${folder}"`)).isDirectory()
    ) {
      throw new SynthError(`${where}: there is no folder at ${folder} to ship.`);
    }
    const skillFiles = folderFiles(folderAbs, "", folder, where, contain);
    const skillMd = skillFiles.find((file) => file.path === "SKILL.md");
    if (skillMd === undefined) {
      throw new SynthError(
        `${where}: ${folder}/SKILL.md is missing. Every skill folder needs one.`,
      );
    }
    checkSkillMd(skillMd.bytes.toString("utf8"), name, `${folder}/SKILL.md`, where, (ref) =>
      skillFiles.some((file) => file.path === ref || file.path.startsWith(`${ref}/`)),
    );
    digest[name] = skillDigest(skillFiles);
    for (const file of skillFiles)
      files.push({ path: `${folder}/${file.path}`, bytes: file.bytes });
  });
  return { files, digest };
}

/**
 * Every file under one skill folder, paths relative to that folder. A symlink that leads back
 * into a folder already being walked would never end, so it is refused, and so is one that
 * cannot be resolved at all.
 */
function folderFiles(
  dirAbs: string,
  prefix: string,
  folder: string,
  where: string,
  contain: (absPath: string, label: string) => string,
  walking: ReadonlySet<string> = new Set([realpathSync(dirAbs)]),
): SkillFile[] {
  const out: SkillFile[] = [];
  for (const entry of readdirSync(dirAbs).sort()) {
    const abs = join(dirAbs, entry);
    const path = `${prefix}${entry}`;
    const label = `${where}: "${folder}/${path}"`;
    let real: string;
    try {
      real = contain(abs, label);
    } catch (error) {
      if (error instanceof SynthError) throw error;
      throw new SynthError(
        `${label} is a symlink that cannot be resolved, such as one that points at itself.`,
      );
    }
    const stat = statSync(real);
    if (stat.isDirectory()) {
      if (walking.has(real)) {
        throw new SynthError(
          `${label} leads back into a folder it is inside, so the folder never ends.`,
        );
      }
      out.push(
        ...folderFiles(abs, `${path}/`, folder, where, contain, new Set([...walking, real])),
      );
    } else if (stat.isFile()) {
      out.push({ path, bytes: readFileSync(real) });
    }
  }
  return out;
}

/**
 * Checks a SKILL.md the way the host's skill loader reads it: YAML frontmatter between `---`
 * lines whose `name` is the folder's, and every file the instructions point at present in
 * the folder. The loader skips a skill with a missing reference and keeps going, so without
 * this the realm would admit and the skill would quietly never load.
 */
function checkSkillMd(
  text: string,
  name: string,
  path: string,
  where: string,
  exists: (ref: string) => boolean,
): void {
  const lines = text.split(/\r?\n/);
  const end = lines.findIndex((line, i) => i > 0 && line.trim() === "---");
  if (lines[0]?.trim() !== "---" || end < 0) {
    throw new SynthError(`${where}: ${path} has to start with YAML frontmatter between --- lines.`);
  }
  let frontmatter: unknown;
  try {
    frontmatter = parseYaml(lines.slice(1, end).join("\n"));
  } catch (error) {
    throw new SynthError(`${where}: ${path} frontmatter is not YAML: ${(error as Error).message}`);
  }
  const fields = (frontmatter ?? {}) as Record<string, unknown>;
  if (fields.name !== name) {
    throw new SynthError(
      `${where}: ${path} names the skill ${JSON.stringify(fields.name ?? null)}, but its folder is ` +
        `"${name}". The host files a skill under its folder, so the two have to match.`,
    );
  }
  // `license` is the one frontmatter field the spec lets point at a bundled file. A value that
  // reads as a path, rather than a licence name like "Apache-2.0", has to be there.
  const license = fields.license;
  if (typeof license === "string" && /\/|\.[A-Za-z]+$/.test(license) && !/\s/.test(license)) {
    const ref = license.replace(/^\.\//, "");
    if (!exists(ref)) {
      throw new SynthError(
        `${where}: ${path} frontmatter names a license file ${ref} that is not in the folder.`,
      );
    }
  }
  for (const ref of instructionReferences(lines.slice(end + 1).join("\n"))) {
    if (!exists(ref)) {
      throw new SynthError(
        `${where}: ${path} refers to ${ref}, which is not in the folder. The host's skill loader ` +
          `skips a skill with a missing file.`,
      );
    }
  }
}

/**
 * The files a skill's instructions point at, found the way the skill loader finds them: local
 * markdown link targets and `scripts/`, `references/` or `assets/` paths, outside code fences.
 */
function instructionReferences(body: string): Set<string> {
  const text = body.replace(/^[ \t]*(`{3,}|~{3,})[\s\S]*?(?:^[ \t]*\1[ \t]*$|(?![\s\S]))/gm, "");
  const refs = new Set<string>();
  const normalize = (path: string): string => path.trim().replace(/^\.\//, "").replace(/\/+$/, "");
  for (const match of text.matchAll(/\[([^\]]*)\]\(([^)]+)\)/g)) {
    const target = match[2] as string;
    if (/^(https?:|mailto:|#)/.test(target) || target.includes("://")) continue;
    refs.add(normalize(target));
  }
  for (const match of text.matchAll(/(?:^|[^\w/])((scripts|references|assets)\/[\w./-]*\w)/gm)) {
    refs.add(normalize(match[1] as string));
  }
  return refs;
}
